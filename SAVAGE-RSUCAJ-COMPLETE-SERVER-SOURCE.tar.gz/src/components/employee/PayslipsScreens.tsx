import React, { useEffect, useMemo, useState } from 'react';
import {
  CalendarDays,
  Download,
  Loader2,
  RefreshCw,
  Wallet,
} from 'lucide-react';
import { apiFetch, downloadAuthenticatedBlob, formatPeso } from '../../lib/api';
import type { PayrollItem, PayrollRun } from '../../types';
import {
  EMPLOYEE_PRIMARY_BTN_CLASS,
  EmployeeShieldLogo,
  EmptyState,
  ErrorState,
  LoadingState,
  PayslipCard,
} from './EmployeePrimitives';
import { extractErrorMessage, formatMonthLabel } from './types';

/* -------------------------------------------------------------------------- */
/* Screen 08: My Payslips (Matches 08_My_Payslips.png with accurate title)    */
/* -------------------------------------------------------------------------- */
export const MyPayslipsScreen: React.FC<{
  payslips: PayrollItem[];
  employeeId: number | null;
  loading: boolean;
  error: string | null;
  onRefresh: () => void;
  onSelectPayslip: (item: PayrollItem) => void;
}> = ({ payslips, employeeId, loading, error, onRefresh, onSelectPayslip }) => {
  const [selectedMonth, setSelectedMonth] = useState<string>('ALL');
  const [downloadingKey, setDownloadingKey] = useState<string | null>(null);
  const [downloadError, setDownloadError] = useState<string | null>(null);

  const monthOptions = useMemo(() => {
    const months = new Set<string>();
    for (const p of payslips) {
      const m = (p.start_date || p.end_date || '').slice(0, 7);
      if (/^\d{4}-\d{2}$/.test(m)) months.add(m);
    }
    return Array.from(months).sort((a, b) => b.localeCompare(a));
  }, [payslips]);

  const filtered = useMemo(() => {
    if (selectedMonth === 'ALL') return payslips;
    return payslips.filter((p) => {
      const s = (p.start_date || '').slice(0, 7);
      const e = (p.end_date || '').slice(0, 7);
      return s === selectedMonth || e === selectedMonth;
    });
  }, [payslips, selectedMonth]);

  const handleDownloadPdf = async (item: PayrollItem) => {
    const targetEmpId = item.employee_id || employeeId;
    if (!targetEmpId) return;
    const key = `${item.payroll_run_id}-${item.id}`;
    setDownloadingKey(key);
    setDownloadError(null);
    try {
      const safeLabel = (item.period_label || `Run-${item.payroll_run_id}`).replace(
        /[^A-Za-z0-9_-]+/g,
        '_'
      );
      await downloadAuthenticatedBlob(
        `/api/payroll/${item.payroll_run_id}/payslip/${targetEmpId}/pdf`,
        `Payslip-${safeLabel}.pdf`
      );
    } catch (err) {
      setDownloadError(extractErrorMessage(err));
    } finally {
      setDownloadingKey(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Page Title matching 08_My_Payslips.png icon & layout, corrected title */}
      <div className="flex items-start justify-between gap-3 pt-1">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
            <Wallet className="h-6 w-6" />
          </div>
          <div>
            <h1 className="font-display text-[21px] font-extrabold text-slate-950 leading-tight">
              My Payslips
            </h1>
            <p className="text-[13px] text-slate-600">
              View and download your released payslips
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onRefresh}
          aria-label="Refresh payslips"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#DCEAE2] bg-white text-[#065A32] hover:bg-[#F2FAF5] cursor-pointer"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Month Filter Bar matching 08_My_Payslips.png */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        <div className="flex items-center gap-2 rounded-xl border border-[#DCEAE2] bg-white px-3.5 min-h-[46px] text-[13.5px] font-semibold text-slate-700">
          <CalendarDays className="h-4 w-4 text-[#08693B] shrink-0" />
          <span>Select Month</span>
        </div>
        <select
          aria-label="Filter payslips by month"
          value={selectedMonth}
          onChange={(e) => setSelectedMonth(e.target.value)}
          className="min-h-[46px] rounded-xl border border-[#DCEAE2] bg-white px-3.5 text-[13.5px] font-semibold text-slate-900 focus:outline-none focus:border-[#08693B] cursor-pointer"
        >
          <option value="ALL">All Released Months</option>
          {monthOptions.map((m) => (
            <option key={m} value={m}>
              {formatMonthLabel(m)}
            </option>
          ))}
        </select>
      </div>

      {downloadError && (
        <ErrorState message={downloadError} onDismiss={() => setDownloadError(null)} />
      )}
      {error && <ErrorState message={error} onRetry={onRefresh} />}

      {loading && payslips.length === 0 ? (
        <LoadingState label="Loading released payslips..." />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Wallet}
          title="No Released Payslips"
          description={
            selectedMonth === 'ALL'
              ? 'Payslips appear here once Payroll Administration releases a payroll run.'
              : `No released payslip found for ${formatMonthLabel(selectedMonth)}.`
          }
          action={
            selectedMonth !== 'ALL' ? (
              <button
                type="button"
                onClick={() => setSelectedMonth('ALL')}
                className="min-h-[40px] rounded-xl bg-[#065A32] px-4 text-xs font-bold text-white hover:bg-[#086E3E] cursor-pointer"
              >
                Show All Payslips
              </button>
            ) : undefined
          }
        />
      ) : (
        <div className="space-y-3">
          {filtered.map((item) => {
            const key = `${item.payroll_run_id}-${item.id}`;
            return (
              <PayslipCard
                key={key}
                item={item}
                downloading={downloadingKey === key}
                onViewDetails={() => onSelectPayslip(item)}
                onDownloadPdf={() => handleDownloadPdf(item)}
              />
            );
          })}
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Screen 14: Payslip Details (Matches 14_Payslip_Details.png)                */
/* -------------------------------------------------------------------------- */
interface PayslipDetailResponse {
  run: PayrollRun;
  payslip: PayrollItem;
  campus?: string;
}

export const PayslipDetailsScreen: React.FC<{
  item: PayrollItem;
  employeeId: number | null;
}> = ({ item, employeeId }) => {
  const targetEmpId = item.employee_id || employeeId;
  const [detail, setDetail] = useState<PayslipDetailResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [downloading, setDownloading] = useState(false);
  const [downloadErr, setDownloadErr] = useState<string | null>(null);

  useEffect(() => {
    if (!targetEmpId) {
      setLoading(false);
      return;
    }
    let active = true;
    setLoading(true);
    setError(null);
    apiFetch<PayslipDetailResponse>(
      `/api/payroll/${item.payroll_run_id}/payslip/${targetEmpId}`
    )
      .then((res) => {
        if (active) setDetail(res);
      })
      .catch((err) => {
        if (active) setError(extractErrorMessage(err));
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [item.payroll_run_id, targetEmpId]);

  const slip = detail?.payslip || item;
  const periodLabel = detail?.run?.period_label || item.period_label || `Payroll Run #${item.payroll_run_id}`;

  const basicPay = Number(slip.prorated_basic_pay ?? slip.basic_pay ?? 0);
  const allowance = Number(slip.allowances ?? 0);
  const overtimePay = Number(slip.overtime_pay ?? 0);
  const holidayPay = Number(slip.holiday_rest_pay ?? 0);
  const otherEarnings = Number(slip.other_earnings ?? 0);
  const totalEarnings = Number(
    slip.gross_pay ?? basicPay + allowance + overtimePay + holidayPay + otherEarnings
  );

  const withholdingTax = Number(slip.tax_deduction ?? 0);
  const statutory = Number(slip.statutory_deductions ?? 0);
  const attendanceDeductions =
    Number(slip.late_deduction ?? 0) +
    Number(slip.undertime_deduction ?? 0) +
    Number(slip.absence_deduction ?? 0) +
    Number(slip.unpaid_leave_deduction ?? 0);
  const otherDeductions = Number(slip.other_deductions ?? 0);
  const totalDeductions = Number(slip.deductions ?? 0);
  const netPay = Number(slip.net_pay ?? 0);

  const handleDownload = async () => {
    if (!targetEmpId) return;
    setDownloading(true);
    setDownloadErr(null);
    try {
      const safeLabel = periodLabel.replace(/[^A-Za-z0-9_-]+/g, '_');
      await downloadAuthenticatedBlob(
        `/api/payroll/${item.payroll_run_id}/payslip/${targetEmpId}/pdf`,
        `Payslip-${safeLabel}.pdf`
      );
    } catch (err) {
      setDownloadErr(extractErrorMessage(err));
    } finally {
      setDownloading(false);
    }
  };

  if (loading && !detail) {
    return <LoadingState label="Loading official payslip details..." />;
  }

  return (
    <div className="mx-auto max-w-xl space-y-4">
      {error && <ErrorState message={error} />}
      {downloadErr && (
        <ErrorState message={downloadErr} onDismiss={() => setDownloadErr(null)} />
      )}

      <div className="rounded-2xl border border-[#DCEAE2] bg-white p-5 sm:p-6 shadow-[0_4px_16px_rgba(5,71,40,0.06)] space-y-5">
        {/* Top Institutional Shield & Header matching 14_Payslip_Details.png */}
        <div className="flex flex-col items-center text-center">
          <div className="flex items-center justify-center gap-3">
            <EmployeeShieldLogo size={46} />
            <div className="font-display text-[20px] font-extrabold tracking-tight text-slate-950">
              SAVAGE-RSUCAJ
            </div>
          </div>
          <p className="mt-2.5 text-[14px] text-slate-600">
            Payroll for:{' '}
            <strong className="font-bold text-slate-950">{periodLabel}</strong>
          </p>
        </div>

        {/* Employee Information Block */}
        <div className="space-y-1.5 text-[13.5px] border-t border-slate-100 pt-4">
          <div className="flex items-center justify-between gap-4">
            <span className="text-slate-500">Employee:</span>
            <span className="font-bold text-slate-950 text-right">{slip.employee_name}</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-slate-500">Employee ID:</span>
            <span className="font-bold text-slate-950 font-mono-num text-right">
              {slip.employee_code}
            </span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-slate-500">Department:</span>
            <span className="font-bold text-slate-950 text-right">
              {slip.department_name || slip.department_code}
            </span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-slate-500">Position:</span>
            <span className="font-bold text-slate-950 text-right">{slip.position_name}</span>
          </div>
        </div>

        {/* Earnings Section */}
        <div className="space-y-2">
          <div className="rounded-lg bg-[#F1F5F3] px-3 py-1.5 text-[13px] font-extrabold text-slate-900">
            Earnings
          </div>
          <div className="space-y-2 px-1 text-[13.5px]">
            <div className="flex items-center justify-between gap-3">
              <span className="text-slate-600">Basic Salary</span>
              <span className="font-semibold text-slate-900 font-mono-num">
                {formatPeso(basicPay)}
              </span>
            </div>
            <div className="flex items-center justify-between gap-3">
              <span className="text-slate-600">Allowance</span>
              <span className="font-semibold text-slate-900 font-mono-num">
                {formatPeso(allowance)}
              </span>
            </div>
            {overtimePay > 0 && (
              <div className="flex items-center justify-between gap-3">
                <span className="text-slate-600">Overtime Pay</span>
                <span className="font-semibold text-slate-900 font-mono-num">
                  {formatPeso(overtimePay)}
                </span>
              </div>
            )}
            {holidayPay > 0 && (
              <div className="flex items-center justify-between gap-3">
                <span className="text-slate-600">Holiday / Rest Day Pay</span>
                <span className="font-semibold text-slate-900 font-mono-num">
                  {formatPeso(holidayPay)}
                </span>
              </div>
            )}
            {otherEarnings > 0 && (
              <div className="flex items-center justify-between gap-3">
                <span className="text-slate-600">Other Earnings</span>
                <span className="font-semibold text-slate-900 font-mono-num">
                  {formatPeso(otherEarnings)}
                </span>
              </div>
            )}
            <div className="flex items-center justify-between gap-3 border-t border-slate-200 pt-2 font-display text-[14.5px] font-extrabold text-slate-950">
              <span>Total Earnings</span>
              <span className="font-mono-num">{formatPeso(totalEarnings)}</span>
            </div>
          </div>
        </div>

        {/* Deductions Section */}
        <div className="space-y-2">
          <div className="rounded-lg bg-[#F1F5F3] px-3 py-1.5 text-[13px] font-extrabold text-slate-900">
            Deductions
          </div>
          <div className="space-y-2 px-1 text-[13.5px]">
            <div className="flex items-center justify-between gap-3">
              <span className="text-slate-600">Withholding Tax</span>
              <span className="font-semibold text-slate-900 font-mono-num">
                {formatPeso(withholdingTax)}
              </span>
            </div>
            {statutory > 0 && (
              <div className="flex items-center justify-between gap-3">
                <span className="text-slate-600">Statutory Contributions</span>
                <span className="font-semibold text-slate-900 font-mono-num">
                  {formatPeso(statutory)}
                </span>
              </div>
            )}
            {attendanceDeductions > 0 && (
              <div className="flex items-center justify-between gap-3">
                <span className="text-slate-600">Late / Undertime / Absence</span>
                <span className="font-semibold text-slate-900 font-mono-num">
                  {formatPeso(attendanceDeductions)}
                </span>
              </div>
            )}
            <div className="flex items-center justify-between gap-3">
              <span className="text-slate-600">Other Deductions</span>
              <span className="font-semibold text-slate-900 font-mono-num">
                {formatPeso(otherDeductions)}
              </span>
            </div>
            <div className="flex items-center justify-between gap-3 border-t border-slate-200 pt-2 font-display text-[14.5px] font-extrabold text-slate-950">
              <span>Total Deductions</span>
              <span className="font-mono-num">{formatPeso(totalDeductions)}</span>
            </div>
          </div>
        </div>

        {/* Golden Net Pay Banner matching 14_Payslip_Details.png */}
        <div className="flex items-center justify-between gap-3 rounded-xl bg-gradient-to-r from-[#FDE68A] via-[#FEF08A] to-[#FCD34D] px-4 py-3.5 border border-[#F59E0B]/30">
          <span className="font-display text-[16px] font-extrabold text-slate-950">
            Net Pay
          </span>
          <span className="font-display text-[19px] font-extrabold text-slate-950 font-mono-num">
            {formatPeso(netPay)}
          </span>
        </div>

        {/* Download PDF CTA matching 14_Payslip_Details.png */}
        <button
          type="button"
          disabled={downloading}
          onClick={handleDownload}
          className={EMPLOYEE_PRIMARY_BTN_CLASS}
        >
          {downloading ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              <span>Preparing Official PDF...</span>
            </>
          ) : (
            <>
              <span>Download PDF</span>
              <Download className="h-5 w-5" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
