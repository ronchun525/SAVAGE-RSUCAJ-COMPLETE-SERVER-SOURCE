import type { AttendanceRecord } from '../../types';

/** Official SAVAGE-RSUCAJ Attendance Shield Logo uploaded by the institution */
export const EMPLOYEE_SHIELD_LOGO_URL =
  '/assets/aistudio/Savage-Rsucaj_Attendance_Shield_bca5b40c.png';

export type EmployeeTab = 'today' | 'attendance' | 'requests' | 'payslips' | 'profile';

export type EmployeeScreen =
  | 'today'
  | 'attendance'
  | 'requests'
  | 'payslips'
  | 'profile'
  | 'leave-form'
  | 'request-success'
  | 'correction-form'
  | 'payslip-details'
  | 'change-password'
  | 'account-security'
  | 'notifications'
  | 'about'
  | 'onboarding-preview';

export interface EmployeeProfileData {
  id: number;
  employee_code: string;
  full_name: string;
  email: string;
  status: string;
  hired_date: string;
  department_code: string;
  department_name: string;
  position_name: string;
  shift_name: string;
  shift_time_in: string;
  shift_time_out: string;
}

export interface EmployeeTodayResponse {
  date: string;
  calendar_date?: string;
  active_prior_shift?: boolean;
  timezone: string;
  read_only: true;
  allow_manual_punch: false;
  server_timestamp_utc: string;
  employee: {
    id?: number;
    employee_code: string;
    full_name: string;
    department_code?: string;
    department_name: string;
    shift_name: string;
    shift_time_in?: string;
    shift_time_out?: string;
  };
  attendance: AttendanceRecord | null;
  events: Array<{
    id: number;
    punch_type: string;
    punch_time: string;
    decision: string;
    device_name?: string;
  }>;
}

export interface EmployeeMonthRow {
  date: string;
  time_in: string | null;
  time_out: string | null;
  break_out: string | null;
  break_in: string | null;
  overtime_out?: string | null;
  work_hours: string;
  status: string;
  late_minutes: number | null;
  undertime_minutes: number | null;
  overtime_minutes?: number | null;
}

export interface EmployeeNotificationItem {
  key: string;
  category:
    | 'System Announcement'
    | 'Leave Update'
    | 'Attendance Correction'
    | 'Payroll'
    | 'Attendance';
  title: string;
  message: string;
  timestamp: string;
  is_read: boolean;
  target_tab: 'today' | 'attendance' | 'requests' | 'payslips';
  entity_id: number | null;
}

export interface EmployeeSessionInfo {
  session_id: string;
  is_current: boolean;
  is_active: boolean;
  status: 'Active' | 'Revoked' | 'Expired';
  revoked_reason: string | null;
  ip_address: string;
  user_agent: string;
  created_at: string;
  expires_at_utc: string;
}

export interface EmployeeSecuritySessionsResponse {
  twoFactorSupported: boolean;
  twoFactorNotice: string;
  sessionTimeoutHours: number;
  currentSessionExpiresAtUtc: string;
  activeCount: number;
  sessions: EmployeeSessionInfo[];
}

export interface RequestSuccessPayload {
  kind: 'leave' | 'correction';
  id: number;
  referenceNo: string;
  subtitle: string;
}

export interface SystemHealthMeta {
  version: string;
  build: string;
  timezone: string;
  status: string;
}

export function formatTime12h(value?: string | null): string {
  if (!value || value === '-') return '—';
  const match = /^(\d{1,2}):(\d{2})/.exec(value.trim());
  if (!match) return value;
  const hour = Number(match[1]);
  if (Number.isNaN(hour) || hour > 23) return value;
  const meridiem = hour >= 12 ? 'PM' : 'AM';
  const h12 = String(hour % 12 || 12).padStart(2, '0');
  return `${h12}:${match[2]} ${meridiem}`;
}

export function formatDateWithWeekday(isoDate: string): string {
  if (!isoDate) return '—';
  const parts = isoDate.split('-');
  if (parts.length !== 3) return isoDate;
  const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  if (Number.isNaN(d.getTime())) return isoDate;
  const base = d.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
  const weekday = d.toLocaleDateString('en-US', { weekday: 'short' });
  return `${base} (${weekday})`;
}

export function formatShortDate(isoDate: string): string {
  if (!isoDate) return '—';
  const parts = isoDate.split('-');
  if (parts.length !== 3) return isoDate;
  const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  if (Number.isNaN(d.getTime())) return isoDate;
  return d.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function formatDateRange(startIso: string, endIso: string): string {
  if (!startIso) return '—';
  if (!endIso || startIso === endIso) return formatShortDate(startIso);
  const sp = startIso.split('-');
  const ep = endIso.split('-');
  if (sp.length !== 3 || ep.length !== 3) return `${startIso} – ${endIso}`;
  const sd = new Date(Number(sp[0]), Number(sp[1]) - 1, Number(sp[2]));
  const ed = new Date(Number(ep[0]), Number(ep[1]) - 1, Number(ep[2]));
  if (Number.isNaN(sd.getTime()) || Number.isNaN(ed.getTime())) {
    return `${startIso} – ${endIso}`;
  }
  const startLabel = sd.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    ...(sp[0] !== ep[0] ? { year: 'numeric' } : {}),
  });
  const endLabel = ed.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
  return `${startLabel} – ${endLabel}`;
}

export function formatMonthLabel(yyyyMm: string): string {
  if (!/^\d{4}-\d{2}$/.test(yyyyMm)) return yyyyMm;
  const [y, m] = yyyyMm.split('-').map(Number);
  const d = new Date(y, m - 1, 1);
  if (Number.isNaN(d.getTime())) return yyyyMm;
  return d.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
}

export function formatFullMonthLabel(yyyyMm: string): string {
  if (!/^\d{4}-\d{2}$/.test(yyyyMm)) return yyyyMm;
  const [y, m] = yyyyMm.split('-').map(Number);
  const d = new Date(y, m - 1, 1);
  if (Number.isNaN(d.getTime())) return yyyyMm;
  return d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

export function formatLeaveReference(id: number, dateStr?: string): string {
  const year = (dateStr || '').slice(0, 4) || String(new Date().getFullYear());
  return `LV-${year}-${String(id).padStart(5, '0')}`;
}

export function formatCorrectionReference(id: number, dateStr?: string): string {
  const year = (dateStr || '').slice(0, 4) || String(new Date().getFullYear());
  return `AC-${year}-${String(id).padStart(5, '0')}`;
}

export function formatRelativeTimestamp(raw: string): string {
  if (!raw) return '';
  const normalized = raw.includes('T') ? raw : raw.replace(' ', 'T');
  const parsed = Date.parse(normalized);
  if (Number.isNaN(parsed)) return raw;
  const diffSec = Math.max(0, Math.floor((Date.now() - parsed) / 1000));
  if (diffSec < 60) return 'Just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDays = Math.floor(diffHr / 24);
  if (diffDays < 30) return `${diffDays}d ago`;
  return new Date(parsed).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export function extractErrorMessage(err: unknown): string {
  return err instanceof Error ? err.message : 'Unable to complete the request. Please try again.';
}

export function parseUserAgentSummary(ua: string): string {
  if (!ua) return 'Web Browser';
  const browser = /Edg\//.test(ua)
    ? 'Microsoft Edge'
    : /Chrome\//.test(ua)
      ? 'Google Chrome'
      : /Firefox\//.test(ua)
        ? 'Mozilla Firefox'
        : /Safari\//.test(ua)
          ? 'Safari'
          : 'Web Browser';
  const os = /Android/i.test(ua)
    ? 'Android'
    : /iPhone|iPad|iOS/i.test(ua)
      ? 'iOS'
      : /Windows/i.test(ua)
        ? 'Windows'
        : /Mac OS/i.test(ua)
          ? 'macOS'
          : /Linux/i.test(ua)
            ? 'Linux'
            : 'Device';
  return `${browser} · ${os}`;
}
