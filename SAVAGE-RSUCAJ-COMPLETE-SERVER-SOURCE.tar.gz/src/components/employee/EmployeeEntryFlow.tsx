import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Eye,
  EyeOff,
  Lock,
  ShieldAlert,
  User,
  X,
} from 'lucide-react';
import { apiFetch, setCsrfToken } from '../../lib/api';
import type { AuthUser } from '../../types';
import {
  EMPLOYEE_PRIMARY_BTN_CLASS,
  EmployeeShieldLogo,
  FooterEmeraldGoldWave,
  HeaderGoldWave,
} from './EmployeePrimitives';

const ONBOARDING_STORAGE_KEY = 'savage_rsucaj_employee_onboarding_v1';

export function hasCompletedEmployeeOnboarding(): boolean {
  try {
    return typeof window !== 'undefined' && window.localStorage.getItem(ONBOARDING_STORAGE_KEY) === '1';
  } catch {
    return false;
  }
}

export function markEmployeeOnboardingCompleted(): void {
  try {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(ONBOARDING_STORAGE_KEY, '1');
    }
  } catch {
    // Ignore storage restriction errors (private browsing)
  }
}

/* -------------------------------------------------------------------------- */
/* Screen 01: Splash Screen (Matches 01_Splash_Screen.png)                    */
/* -------------------------------------------------------------------------- */
export const EmployeeSplashScreen: React.FC<{
  statusText?: string;
}> = ({ statusText = 'Loading...' }) => {
  return (
    <div
      className="min-h-[100dvh] w-full flex flex-col justify-between bg-gradient-to-b from-[#043D22] via-[#06522E] to-[#043A20] text-white overflow-hidden"
      role="status"
      aria-live="polite"
    >
      <div className="flex-1 flex flex-col items-center justify-center px-6 pt-12 pb-6 text-center">
        <EmployeeShieldLogo
          size={152}
          className="drop-shadow-[0_12px_28px_rgba(0,0,0,0.36)]"
        />

        <h1 className="mt-7 font-display text-[30px] sm:text-[34px] font-extrabold tracking-tight text-white leading-none">
          SAVAGE-RSUCAJ
        </h1>
        <p className="mt-2 font-display text-[13px] sm:text-[14px] font-bold tracking-[0.16em] uppercase text-emerald-100/95">
          SMART ATTENDANCE SYSTEM
        </p>

        {/* Reference-matched dual-tone circular initialization spinner */}
        <div className="mt-10 flex flex-col items-center gap-4">
          <div className="relative h-12 w-12" aria-hidden="true">
            <div className="absolute inset-0 rounded-full border-[4px] border-white/85 border-t-[#19B566] border-l-[#19B566] animate-spin" />
          </div>
          <p className="text-[15px] font-semibold tracking-wide text-emerald-50">
            {statusText}
          </p>
        </div>
      </div>

      <FooterEmeraldGoldWave height={64} />
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Onboarding Illustrations (Matches Screens 02, 03, 04 PNG references)       */
/* -------------------------------------------------------------------------- */
const FaceAttendanceIllustration: React.FC = () => (
  <svg
    viewBox="0 0 240 240"
    className="w-[210px] h-[210px] sm:w-[232px] sm:h-[232px]"
    fill="none"
    aria-hidden="true"
  >
    <circle cx="120" cy="120" r="106" fill="#E6F4EC" />
    {/* Smartphone body */}
    <rect x="64" y="28" width="112" height="184" rx="18" fill="#054A29" />
    <rect x="74" y="44" width="92" height="148" rx="8" fill="#F0FAF4" />
    {/* Top speaker slot & bottom home pill */}
    <rect x="104" y="34" width="32" height="4" rx="2" fill="#0B6D3D" />
    <rect x="106" y="198" width="28" height="6" rx="3" fill="#03361D" />
    {/* Face recognition corner brackets */}
    <path d="M84 82V66H100" stroke="#065A32" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M156 82V66H140" stroke="#065A32" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M84 128V144H100" stroke="#065A32" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M156 128V144H140" stroke="#065A32" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    {/* Person silhouette */}
    <path
      d="M78 188C78 164 96 152 120 152C144 152 162 164 162 188V192H78V188Z"
      fill="#F4B400"
    />
    <rect x="110" y="136" width="20" height="20" rx="8" fill="#FDBA8C" />
    <ellipse cx="120" cy="112" rx="22" ry="26" fill="#FDBA8C" />
    <path
      d="M98 106C98 86 112 78 122 78C136 78 144 88 144 104C144 108 142 112 140 112C138 100 132 95 120 95C108 95 102 101 100 112C98.5 111 98 108 98 106Z"
      fill="#0F172A"
    />
    {/* Verified green check badge */}
    <circle cx="170" cy="172" r="28" fill="#FFFFFF" />
    <circle cx="170" cy="172" r="23" fill="#0D9F4F" />
    <path
      d="M159 172L166.5 179.5L181.5 164.5"
      stroke="#FFFFFF"
      strokeWidth="4.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const TrackRecordsIllustration: React.FC = () => (
  <svg
    viewBox="0 0 240 240"
    className="w-[210px] h-[210px] sm:w-[232px] sm:h-[232px]"
    fill="none"
    aria-hidden="true"
  >
    <circle cx="120" cy="120" r="106" fill="#E6F4EC" />
    {/* Calendar binding rings */}
    <rect x="74" y="42" width="14" height="30" rx="7" fill="#043D22" />
    <rect x="113" y="42" width="14" height="30" rx="7" fill="#043D22" />
    <rect x="152" y="42" width="14" height="30" rx="7" fill="#043D22" />
    {/* Calendar body */}
    <rect x="46" y="58" width="148" height="132" rx="22" fill="#065831" />
    <rect x="58" y="94" width="124" height="84" rx="12" fill="#FFFFFF" />
    {/* Calendar grid squares */}
    <rect x="74" y="108" width="22" height="22" rx="4" fill="#52A47A" />
    <rect x="109" y="108" width="22" height="22" rx="4" fill="#52A47A" />
    <rect x="144" y="108" width="22" height="22" rx="4" fill="#52A47A" />
    <rect x="74" y="142" width="22" height="22" rx="4" fill="#52A47A" />
    <rect x="109" y="142" width="22" height="22" rx="4" fill="#52A47A" />
    {/* Verified green check badge */}
    <circle cx="164" cy="170" r="34" fill="#FFFFFF" />
    <circle cx="164" cy="170" r="28" fill="#0D9F4F" />
    <path
      d="M150 170L159.5 179.5L178.5 160.5"
      stroke="#FFFFFF"
      strokeWidth="5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const SecureReliableIllustration: React.FC = () => (
  <svg
    viewBox="0 0 240 240"
    className="w-[210px] h-[210px] sm:w-[232px] sm:h-[232px]"
    fill="none"
    aria-hidden="true"
  >
    <circle cx="120" cy="120" r="106" fill="#E6F4EC" />
    {/* Outer white shield rim */}
    <path
      d="M120 30L188 54V116C188 162 158 196 120 212C82 196 52 162 52 116V54L120 30Z"
      fill="#FFFFFF"
    />
    {/* Deep emerald shield */}
    <path
      d="M120 42L176 62V116C176 155 151 184 120 198C89 184 64 155 64 116V62L120 42Z"
      fill="#054A29"
    />
    <path
      d="M120 52L166 68V116C166 149 145 174 120 187C95 174 74 149 74 116V68L120 52Z"
      fill="#086B3C"
    />
    {/* Crisp white padlock */}
    <path
      d="M98 112V98C98 85.85 107.85 76 120 76C132.15 76 142 85.85 142 98V112"
      stroke="#FFFFFF"
      strokeWidth="10"
      strokeLinecap="round"
    />
    <rect x="90" y="108" width="60" height="48" rx="10" fill="#FFFFFF" />
    <circle cx="120" cy="128" r="5.5" fill="#054A29" />
    <path d="M120 132L117.5 143H122.5L120 132Z" fill="#054A29" />
  </svg>
);

const ONBOARDING_SLIDES = [
  {
    key: 'face',
    title: 'Face Attendance',
    description: 'Secure and accurate attendance using face recognition.',
    Illustration: FaceAttendanceIllustration,
  },
  {
    key: 'records',
    title: 'Track Your Records',
    description: 'View your daily attendance, leaves, and payslips anytime, anywhere.',
    Illustration: TrackRecordsIllustration,
  },
  {
    key: 'security',
    title: 'Secure & Reliable',
    description: 'Your data is protected with role-based access and encryption.',
    Illustration: SecureReliableIllustration,
  },
] as const;

/* -------------------------------------------------------------------------- */
/* Screens 02–04: Onboarding Flow                                             */
/* -------------------------------------------------------------------------- */
export const EmployeeOnboardingFlow: React.FC<{
  onComplete: () => void;
  previewMode?: boolean;
}> = ({ onComplete, previewMode = false }) => {
  const [step, setStep] = useState(0);
  const current = ONBOARDING_SLIDES[step];
  const isLast = step === ONBOARDING_SLIDES.length - 1;
  const Illustration = current.Illustration;

  useEffect(() => {
    if (previewMode || typeof window === 'undefined' || !window.history?.replaceState) return;
    try {
      window.history.replaceState({ empOnboardingStep: 0 }, '', window.location.pathname + window.location.search);
    } catch {
      // ignore history restrictions
    }
    const onPopState = (ev: PopStateEvent) => {
      const state = ev.state as { empOnboardingStep?: number } | null;
      if (state && typeof state.empOnboardingStep === 'number') {
        const clamped = Math.max(0, Math.min(ONBOARDING_SLIDES.length - 1, state.empOnboardingStep));
        setStep(clamped);
      }
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, [previewMode]);

  const goToStep = (nextStep: number) => {
    const clamped = Math.max(0, Math.min(ONBOARDING_SLIDES.length - 1, nextStep));
    setStep(clamped);
    if (!previewMode && typeof window !== 'undefined' && window.history?.pushState) {
      try {
        window.history.pushState({ empOnboardingStep: clamped }, '', window.location.pathname + window.location.search);
      } catch {
        // ignore history restrictions
      }
    }
  };

  const finish = () => {
    if (!previewMode) {
      markEmployeeOnboardingCompleted();
    }
    onComplete();
  };

  return (
    <div className="min-h-[100dvh] w-full bg-[#F4F8F6] flex flex-col items-center justify-center sm:p-6">
      <div className="w-full max-w-[430px] min-h-[100dvh] sm:min-h-[700px] sm:rounded-[28px] bg-white sm:shadow-2xl sm:border sm:border-emerald-950/10 flex flex-col justify-between px-6 py-8 sm:px-8 sm:py-10">
        {/* Top subtle indicator */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <EmployeeShieldLogo size={26} />
            <span className="font-display text-xs font-extrabold tracking-wide text-[#064E2C]">
              SAVAGE-RSUCAJ
            </span>
          </div>
          {previewMode && (
            <button
              type="button"
              onClick={finish}
              aria-label="Close onboarding guide"
              className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          )}
        </div>

        {/* Center Illustration & Copy */}
        <div className="my-auto flex flex-col items-center text-center py-6">
          <Illustration />
          <h1 className="mt-7 font-display text-[26px] font-extrabold text-slate-950 tracking-tight">
            {current.title}
          </h1>
          <p className="mt-3 max-w-[290px] text-[15px] leading-relaxed text-slate-600">
            {current.description}
          </p>
        </div>

        {/* Pagination Dots + Controls */}
        <div className="space-y-6">
          <div className="flex items-center justify-center gap-2.5" role="tablist" aria-label="Onboarding steps">
            {ONBOARDING_SLIDES.map((slide, idx) => (
              <button
                key={slide.key}
                type="button"
                role="tab"
                aria-selected={idx === step}
                aria-label={`Slide ${idx + 1}: ${slide.title}`}
                onClick={() => goToStep(idx)}
                className={`h-2.5 rounded-full transition-all cursor-pointer ${
                  idx === step ? 'w-6 bg-[#06522E]' : 'w-2.5 bg-slate-300 hover:bg-slate-400'
                }`}
              />
            ))}
          </div>

          {!isLast ? (
            <div className="grid grid-cols-2 gap-3.5">
              <button
                type="button"
                onClick={finish}
                className="min-h-[48px] rounded-xl bg-slate-100 text-slate-800 font-display text-[15px] font-bold hover:bg-slate-200 transition cursor-pointer"
              >
                Skip
              </button>
              <button
                type="button"
                onClick={() => goToStep(step + 1)}
                className={EMPLOYEE_PRIMARY_BTN_CLASS}
              >
                <span>Next</span>
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={finish}
              className={EMPLOYEE_PRIMARY_BTN_CLASS}
            >
              <span>{previewMode ? 'Done' : 'Get Started'}</span>
              {!previewMode && <ArrowRight className="h-4 w-4" />}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Screen 05: Employee Login (Matches 05_Employee_Login.png)                  */
/* -------------------------------------------------------------------------- */
interface AuthConfigPayload {
  googleSsoConfigured: boolean;
  smtpConfigured: boolean;
}

export const EmployeeLoginScreen: React.FC<{
  onSuccess: (user: AuthUser) => void;
  sessionNotice?: string | null;
  onDismissSessionNotice?: () => void;
}> = ({
  onSuccess,
  sessionNotice,
  onDismissSessionNotice,
}) => {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [authConfig, setAuthConfig] = useState<AuthConfigPayload>({
    googleSsoConfigured: false,
    smtpConfigured: false,
  });

  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotMessage, setForgotMessage] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<AuthConfigPayload>('/api/auth/config')
      .then((cfg) => setAuthConfig(cfg))
      .catch(() => setAuthConfig({ googleSsoConfigured: false, smtpConfigured: false }));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!identifier.trim() || !password) {
      setError('Please enter your Employee ID (or username/email) and password.');
      return;
    }
    setSubmitting(true);
    try {
      const res = await apiFetch<{ user: AuthUser; csrfToken?: string }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({
          identifier: identifier.trim(),
          password,
          rememberMe,
        }),
      });
      setCsrfToken(res.csrfToken ?? null);
      setPassword('');
      onSuccess(res.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to sign in. Please verify your credentials.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authConfig.smtpConfigured || !forgotEmail.trim()) return;
    setForgotLoading(true);
    setForgotMessage(null);
    try {
      const res = await apiFetch<{ message?: string; error?: string }>('/api/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email: forgotEmail.trim() }),
      });
      setForgotMessage(res.message || res.error || 'Password reset request submitted.');
    } catch (err) {
      setForgotMessage(err instanceof Error ? err.message : 'Unable to process password reset request.');
    } finally {
      setForgotLoading(false);
    }
  };

  return (
    <div className="min-h-[100dvh] w-full bg-[#EEF5F2] flex flex-col items-center justify-center sm:p-6">
      <div className="w-full max-w-[430px] min-h-[100dvh] sm:min-h-[730px] sm:rounded-[28px] bg-white sm:shadow-2xl sm:border sm:border-emerald-950/10 flex flex-col justify-between overflow-hidden">
        {/* Top Deep Emerald Brand Header + Gold Sweeping Wave */}
        <div>
          <div className="bg-gradient-to-b from-[#043D22] via-[#06522E] to-[#054728] px-6 pt-10 pb-6 text-center text-white">
            <EmployeeShieldLogo
              size={112}
              className="mx-auto drop-shadow-[0_8px_20px_rgba(0,0,0,0.36)]"
            />
            <h1 className="mt-4 font-display text-[26px] font-extrabold tracking-tight text-white leading-tight">
              SAVAGE-RSUCAJ
            </h1>
            <p className="mt-1 text-[14px] font-semibold text-emerald-100">
              Employee Portal
            </p>
          </div>
          <HeaderGoldWave />
        </div>

        {/* Main Form */}
        <main className="flex-1 px-6 pt-5 pb-4 sm:px-8 flex flex-col justify-center">
          {sessionNotice && !error && (
            <div
              role="alert"
              className="mb-4 flex items-start justify-between gap-2.5 rounded-xl border border-amber-300 bg-amber-50 px-3.5 py-2.5 text-xs text-amber-900"
            >
              <div className="flex items-start gap-2">
                <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5 text-amber-600" />
                <span className="font-medium leading-relaxed">{sessionNotice}</span>
              </div>
              {onDismissSessionNotice && (
                <button
                  type="button"
                  onClick={onDismissSessionNotice}
                  aria-label="Dismiss session notice"
                  className="p-0.5 rounded text-amber-700 hover:bg-amber-100 cursor-pointer"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          )}

          {error && (
            <div
              role="alert"
              className="mb-4 flex items-start gap-2.5 rounded-xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs text-red-800"
            >
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="emp-login-id" className="sr-only">
                Employee ID, Username, or Email
              </label>
              <div className="relative">
                <User className="h-5 w-5 text-[#065A32] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="emp-login-id"
                  type="text"
                  autoComplete="username"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="Employee ID"
                  className="w-full min-h-[50px] rounded-xl border border-slate-200 bg-white pl-11 pr-4 text-[15px] text-slate-900 placeholder:text-slate-400 shadow-[0_1px_2px_rgba(0,0,0,0.03)] focus:outline-none focus:border-[#08693B] focus:ring-2 focus:ring-[#08693B]/15 transition"
                />
              </div>
            </div>

            <div>
              <label htmlFor="emp-login-password" className="sr-only">
                Password
              </label>
              <div className="relative">
                <Lock className="h-5 w-5 text-[#065A32] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="emp-login-password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  className="w-full min-h-[50px] rounded-xl border border-slate-200 bg-white pl-11 pr-12 text-[15px] text-slate-900 placeholder:text-slate-400 shadow-[0_1px_2px_rgba(0,0,0,0.03)] focus:outline-none focus:border-[#08693B] focus:ring-2 focus:ring-[#08693B]/15 transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 flex h-9 w-9 items-center justify-center rounded-lg text-slate-600 hover:bg-slate-100 hover:text-[#065A32] cursor-pointer"
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            <div className="pt-0.5">
              <label
                htmlFor="emp-login-remember"
                className="inline-flex items-center gap-2.5 text-[14px] font-medium text-slate-800 cursor-pointer select-none"
              >
                <input
                  id="emp-login-remember"
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="h-[18px] w-[18px] rounded border-slate-300 accent-[#065A32] cursor-pointer"
                />
                <span>Remember Me</span>
              </label>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className={`${EMPLOYEE_PRIMARY_BTN_CLASS} min-h-[52px] text-[16px] mt-1`}
            >
              {submitting ? 'Logging In...' : 'Log In'}
            </button>
          </form>

          <div className="mt-5 text-center">
            <button
              type="button"
              onClick={() => {
                setForgotMessage(null);
                setForgotEmail('');
                setForgotOpen(true);
              }}
              className="text-[14px] font-bold text-[#1D4ED8] hover:text-[#1E3A8A] underline-offset-2 hover:underline cursor-pointer"
            >
              Forgot Password?
            </button>
          </div>

        </main>

        {/* Bottom Emerald & Gold Sweeping Wave */}
        <FooterEmeraldGoldWave height={56} />
      </div>

      {/* Forgot Password Modal */}
      {forgotOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-4 backdrop-blur-[2px]"
          role="dialog"
          aria-modal="true"
          aria-labelledby="emp-forgot-title"
        >
          <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h2 id="emp-forgot-title" className="font-display text-lg font-extrabold text-slate-900">
                  Forgot Password?
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  RSU – Cajidiocan Campus Employee Account Recovery
                </p>
              </div>
              <button
                type="button"
                onClick={() => setForgotOpen(false)}
                aria-label="Close recovery dialog"
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {!authConfig.smtpConfigured ? (
              <div className="mt-4 space-y-3.5 text-xs text-slate-700">
                <div className="flex items-start gap-2.5 rounded-xl border border-amber-200 bg-amber-50 p-3 text-amber-900">
                  <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5 text-amber-600" />
                  <div className="space-y-1">
                    <p className="font-bold">Self-Service Email Reset Unavailable</p>
                    <p className="leading-relaxed">
                      Outbound email delivery is not configured on this campus server. Please contact the HR Office or MIS Administrator to issue a temporary password reset for your Employee ID.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setForgotOpen(false)}
                  className={EMPLOYEE_PRIMARY_BTN_CLASS}
                >
                  Close
                </button>
              </div>
            ) : (
              <form onSubmit={handleForgotSubmit} className="mt-4 space-y-3.5">
                <p className="text-xs text-slate-600 leading-relaxed">
                  Enter your registered institutional email address to request a password reset.
                </p>
                <input
                  type="email"
                  required
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  placeholder="name@rsucaj.edu.ph"
                  className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3.5 text-sm focus:outline-none focus:border-[#08693B] focus:ring-2 focus:ring-[#08693B]/15"
                />
                {forgotMessage && (
                  <p className="rounded-xl bg-amber-50 border border-amber-200 px-3 py-2 text-xs text-amber-900">
                    {forgotMessage}
                  </p>
                )}
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setForgotOpen(false)}
                    className="min-h-[44px] rounded-xl border border-slate-200 px-4 text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer"
                  >
                    Close
                  </button>
                  <button
                    type="submit"
                    disabled={forgotLoading}
                    className="min-h-[44px] rounded-xl bg-[#065A32] px-4 text-xs font-bold text-white hover:bg-[#086F3E] disabled:opacity-60 cursor-pointer"
                  >
                    {forgotLoading ? 'Sending...' : 'Request Reset'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Coordinated Pre-Login Entry Flow (Screens 02-04 -> Screen 05)              */
/* -------------------------------------------------------------------------- */
export const EmployeeEntryFlow: React.FC<{
  onSuccess: (user: AuthUser) => void;
  sessionNotice?: string | null;
  onDismissSessionNotice?: () => void;
}> = ({
  onSuccess,
  sessionNotice,
  onDismissSessionNotice,
}) => {
  const [showOnboarding, setShowOnboarding] = useState<boolean>(
    () => !sessionNotice && !hasCompletedEmployeeOnboarding()
  );

  useEffect(() => {
    if (sessionNotice) {
      setShowOnboarding(false);
    }
  }, [sessionNotice]);

  if (showOnboarding) {
    return (
      <EmployeeOnboardingFlow
        onComplete={() => setShowOnboarding(false)}
      />
    );
  }

  return (
    <EmployeeLoginScreen
      onSuccess={onSuccess}
      sessionNotice={sessionNotice}
      onDismissSessionNotice={onDismissSessionNotice}
    />
  );
};
