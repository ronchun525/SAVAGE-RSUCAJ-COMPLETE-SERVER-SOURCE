import React, { useEffect, useId, useRef } from 'react';
import { AlertTriangle, X } from 'lucide-react';

/**
 * Signature SAVAGE-RSUCAJ sculpted emerald & gold bottom wave ribbon
 * present across the 16 approved UI/UX reference screens.
 */
export const RsuBottomWave: React.FC<{ height?: number; className?: string }> = ({
  height = 24,
  className = '',
}) => (
  <svg
    viewBox="0 0 1200 44"
    preserveAspectRatio="none"
    style={{ height }}
    className={`w-full block shrink-0 pointer-events-none select-none ${className}`}
    aria-hidden="true"
  >
    <defs>
      <linearGradient id="rsuGoldWave" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#FACC15" />
        <stop offset="18%" stopColor="#F59E0B" />
        <stop offset="50%" stopColor="#FDE047" />
        <stop offset="82%" stopColor="#F59E0B" />
        <stop offset="100%" stopColor="#FACC15" />
      </linearGradient>
      <linearGradient id="rsuEmeraldWave" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#07442B" />
        <stop offset="35%" stopColor="#0F7B47" />
        <stop offset="65%" stopColor="#0A5C38" />
        <stop offset="100%" stopColor="#063924" />
      </linearGradient>
    </defs>
    {/* Outer sweeping gold corners */}
    <path
      d="M0 4C115 26 290 32 600 28C910 24 1085 26 1200 4V44H0V4Z"
      fill="url(#rsuGoldWave)"
    />
    {/* Inner deep emerald crest wave */}
    <path
      d="M55 44C235 16 420 12 600 18C780 24 965 16 1145 44H55Z"
      fill="url(#rsuEmeraldWave)"
    />
    {/* Bright highlight ribbon */}
    <path
      d="M170 44C340 24 510 20 710 26C880 31 1005 28 1090 44H170Z"
      fill="#169C53"
      fillOpacity="0.45"
    />
  </svg>
);

interface ModuleFrameProps {
  title: string;
  subtitle?: string;
  icon: React.ReactNode;
  headerAction?: React.ReactNode;
  children: React.ReactNode;
}

export const ModuleFrame: React.FC<ModuleFrameProps> = ({
  title,
  subtitle,
  icon,
  headerAction,
  children,
}) => {
  return (
    <section className="bg-white rounded-2xl border border-emerald-950/10 shadow-lg shadow-emerald-950/6 overflow-hidden flex flex-col">
      {/* Reference-Matched Deep Emerald Header with Circular Glowing Icon Badge */}
      <div className="relative bg-gradient-to-r from-[#053522] via-[#0A5337] to-[#0D6E48] px-5 pt-4 pb-6 text-white flex flex-wrap items-center justify-between gap-3 overflow-hidden">
        {/* Subtle luminous emerald highlight in header */}
        <div
          className="pointer-events-none absolute -right-12 -top-12 w-56 h-56 rounded-full bg-emerald-400/15 blur-2xl"
          aria-hidden="true"
        />
        <div className="relative z-10 flex items-center gap-3.5 min-w-0">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#20C562] to-[#0B783D] border border-emerald-200/35 shadow-md shadow-black/25 flex items-center justify-center shrink-0 text-white">
            {icon}
          </div>
          <div className="min-w-0">
            <h1 className="font-display text-lg sm:text-xl font-extrabold tracking-tight text-white leading-tight truncate">
              {title}
            </h1>
            {subtitle && (
              <p className="text-xs text-emerald-100/85 mt-0.5 truncate">{subtitle}</p>
            )}
          </div>
        </div>
        {headerAction && (
          <div className="relative z-10 flex items-center gap-2 shrink-0">{headerAction}</div>
        )}
      </div>

      {/* Elevated White Body with Curved Top Shoulder matching references 03–16 */}
      <div className="relative -mt-3 rounded-t-2xl bg-white px-4 sm:px-5 pt-5 pb-4 flex-1 min-w-0">{children}</div>

      {/* Signature Sculpted Emerald & Gold Bottom Wave */}
      <RsuBottomWave height={20} />
    </section>
  );
};

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  maxWidth?: string;
  children: React.ReactNode;
}

export const Modal: React.FC<ModalProps> = ({
  open,
  onClose,
  title,
  subtitle,
  maxWidth = 'max-w-lg',
  children,
}) => {
  const titleId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  // Keep the latest handler without re-running the focus effect on every keystroke.
  // Inline onClose lambdas change identity on form state updates.
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    if (!open) return;
    const previouslyFocused = document.activeElement as HTMLElement | null;
    dialogRef.current?.focus();

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onCloseRef.current();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      if (previouslyFocused && typeof previouslyFocused.focus === 'function') {
        previouslyFocused.focus();
      }
    };
  }, [open]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 backdrop-blur-[2px] p-3 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby={titleId}
      onClick={onClose}
    >
      <div
        ref={dialogRef}
        tabIndex={-1}
        className={`w-full ${maxWidth} bg-white rounded-2xl border border-emerald-950/15 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col focus:outline-none`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-gradient-to-r from-[#053522] via-[#0A5337] to-[#0D6E48] px-5 py-4 text-white flex items-start justify-between gap-4">
          <div className="min-w-0">
            <h2 id={titleId} className="font-display text-base font-bold break-words">
              {title}
            </h2>
            {subtitle && <p className="text-xs text-emerald-100/90 mt-0.5 break-words">{subtitle}</p>}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-emerald-100 hover:bg-white/15 hover:text-white transition-colors cursor-pointer shrink-0"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-4 sm:p-5 overflow-y-auto">{children}</div>
        <RsuBottomWave height={12} />
      </div>
    </div>
  );
};

interface ConfirmModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmLabel?: string;
  destructive?: boolean;
  busy?: boolean;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  open,
  onClose,
  onConfirm,
  title,
  message,
  confirmLabel = 'Confirm',
  destructive = true,
  busy = false,
}) => (
  <Modal open={open} onClose={onClose} title={title} maxWidth="max-w-md">
    <div className="space-y-4 text-xs">
      <div className="flex items-start gap-3">
        <div
          className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
            destructive ? 'bg-red-100 text-red-600' : 'bg-emerald-100 text-emerald-700'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
        </div>
        <p className="text-slate-600 leading-relaxed pt-1">{message}</p>
      </div>
      <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
        <button
          type="button"
          onClick={onClose}
          disabled={busy}
          className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 font-semibold cursor-pointer"
        >
          Cancel
        </button>
        <button
          type="button"
          onClick={onConfirm}
          disabled={busy}
          className={`px-4 py-2 rounded-lg text-white font-semibold cursor-pointer disabled:opacity-60 ${
            destructive ? 'bg-red-600 hover:bg-red-700' : 'btn-rsu-primary'
          }`}
        >
          {busy ? 'Processing...' : confirmLabel}
        </button>
      </div>
    </div>
  </Modal>
);

export const StatusLabel: React.FC<{ status: string; showDot?: boolean }> = ({
  status,
  showDot = false,
}) => {
  const s = status.toLowerCase();
  let cls = 'bg-slate-100 text-slate-700';
  let dotCls = 'bg-slate-500';

  if (s === 'approved' || s === 'released') {
    cls = 'bg-[#16A34A] text-white shadow-xs';
    dotCls = 'bg-white';
  } else if (['active', 'present', 'online', 'success', 'time in', 'low', 'accepted', 'synced'].includes(s)) {
    cls = 'bg-[#DCFCE7] text-[#15803D]';
    dotCls = 'bg-[#16A34A]';
  } else if (['pending', 'late', 'undertime', 'computed', 'warning', 'medium', 'special non-working', 'stale', 'partial'].includes(s)) {
    cls = 'bg-[#FEF08A] text-[#854D0E]';
    dotCls = 'bg-[#CA8A04]';
  } else if (['missing time in', 'missing time out', 'escalated', 'reversed'].includes(s)) {
    cls = 'bg-[#FFEDD5] text-[#C2410C]';
    dotCls = 'bg-[#EA580C]';
  } else if (s === 'absent' || s === 'rejected' || s === 'revoked') {
    cls = 'bg-[#EF4444] text-white shadow-xs';
    dotCls = 'bg-white';
  } else if (['offline', 'error', 'inactive', 'high'].includes(s)) {
    cls = 'bg-[#FEE2E2] text-[#B91C1C]';
    dotCls = 'bg-[#DC2626]';
  } else if (['on leave', 'ob', 'finalized', 'regular'].includes(s)) {
    cls = 'bg-[#DBEAFE] text-[#1D4ED8]';
    dotCls = 'bg-[#2563EB]';
  } else if (s === 'holiday') {
    cls = 'bg-[#CCFBF1] text-[#0F766E]';
    dotCls = 'bg-[#0D9488]';
  } else if (['rest day', 'no schedule', 'idle', 'cancelled'].includes(s)) {
    cls = 'bg-slate-100 text-slate-700';
    dotCls = 'bg-slate-500';
  }

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-xs font-semibold whitespace-nowrap ${cls}`}
    >
      {showDot && <span className={`w-1.5 h-1.5 rounded-full ${dotCls}`} />}
      {status}
    </span>
  );
};
