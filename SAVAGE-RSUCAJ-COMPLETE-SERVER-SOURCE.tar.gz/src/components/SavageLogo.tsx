import React, { useState } from 'react';

// Use the existing original transparent PNG, not the white-background emblem image.
export const SAVAGE_LOGO_URL = '/assets/aistudio/Savage-Rsucaj_Attendance_Shield_bca5b40c.png';

interface SavageLogoProps {
  size?: number;
  variant?: 'light' | 'dark';
  className?: string;
}

export const SavageLogo: React.FC<SavageLogoProps> = ({
  size = 64,
  variant = 'light',
  className = '',
}) => {
  const [imgFailed, setImgFailed] = useState(false);

  if (imgFailed) {
    return (
      <div
        style={{ width: size, height: size }}
        className={`rounded-xl bg-[#0B4D32] text-white font-display font-extrabold flex items-center justify-center text-xs tracking-tight border border-amber-400/50 ${className}`}
        aria-label="SAVAGE-RSUCAJ Official Emblem"
      >
        RSU
      </div>
    );
  }

  return (
    <img
      src={SAVAGE_LOGO_URL}
      alt="SAVAGE-RSUCAJ Smart Attendance System Official Emblem"
      referrerPolicy="no-referrer"
      onError={() => setImgFailed(true)}
      style={{ width: size, height: size }}
      className={`object-contain select-none shrink-0 ${variant === 'dark' ? 'drop-shadow-[0_2px_6px_rgba(0,0,0,0.2)]' : ''} ${className}`}
    />
  );
};
