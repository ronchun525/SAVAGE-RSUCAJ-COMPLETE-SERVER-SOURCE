// BUILD 05: Session authentication uses server-backed HttpOnly cookies only.
// No session tokens or sensitive secrets are stored in localStorage or sessionStorage.
// Double-submit CSRF token is kept in memory (with readable CSRF cookie fallback) and attached
// on state-changing HTTP methods.

const CSRF_COOKIE_NAME = 'savage_rsucaj_csrf';
const MUTATING_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

let memoryCsrfToken: string | null = null;
let unauthorizedHandler: (() => void) | null = null;

function readCookieFromDocument(name: string): string | null {
  if (typeof document === 'undefined' || !document.cookie) return null;
  for (const part of document.cookie.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const k = part.slice(0, idx).trim();
    if (k === name) {
      try {
        return decodeURIComponent(part.slice(idx + 1).trim());
      } catch {
        return part.slice(idx + 1).trim();
      }
    }
  }
  return null;
}

export function setCsrfToken(token: string | null | undefined): void {
  memoryCsrfToken = token && token.trim() ? token.trim() : null;
}

export function getCsrfToken(): string | null {
  const cookieToken = readCookieFromDocument(CSRF_COOKIE_NAME);
  if (cookieToken) {
    memoryCsrfToken = cookieToken;
    return cookieToken;
  }
  return memoryCsrfToken;
}

export function clearCsrfToken(): void {
  memoryCsrfToken = null;
}

export function setUnauthorizedHandler(handler: (() => void) | null): void {
  unauthorizedHandler = handler;
}

export async function apiFetch<T = unknown>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const method = (options.method || 'GET').toUpperCase();
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string> | undefined),
  };
  if (options.body && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }
  if (MUTATING_METHODS.has(method) && !headers['X-CSRF-Token'] && !headers['x-csrf-token']) {
    const csrf = getCsrfToken();
    if (csrf) {
      headers['X-CSRF-Token'] = csrf;
    }
  }

  const res = await fetch(path, {
    ...options,
    method,
    credentials: 'include',
    headers,
  });

  const text = await res.text();
  let data: Record<string, unknown> = {};
  if (text) {
    try {
      data = JSON.parse(text) as Record<string, unknown>;
    } catch {
      data = { error: text };
    }
  }

  if (!res.ok) {
    if (
      res.status === 401 &&
      !path.startsWith('/api/auth/login') &&
      !path.startsWith('/api/auth/me') &&
      !path.startsWith('/api/auth/config')
    ) {
      clearCsrfToken();
      if (unauthorizedHandler) unauthorizedHandler();
    }
    const errMsg = typeof data.error === 'string' ? data.error : `Request failed (${res.status})`;
    throw new Error(errMsg);
  }

  return data as T;
}

export function formatPeso(amount: number): string {
  return (
    '₱' +
    Number(amount || 0).toLocaleString('en-PH', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  );
}

export function getManilaTodayIso(now: Date = new Date()): string {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Manila',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(now);
  const year = parts.find((p) => p.type === 'year')?.value ?? '1970';
  const month = parts.find((p) => p.type === 'month')?.value ?? '01';
  const day = parts.find((p) => p.type === 'day')?.value ?? '01';
  return `${year}-${month}-${day}`;
}

export function formatDisplayDate(isoDate: string): string {
  if (!isoDate) return '-';
  const parts = isoDate.split('-');
  if (parts.length !== 3) return isoDate;
  const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  if (Number.isNaN(d.getTime())) return isoDate;
  return d.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
}

export function downloadCsv(filename: string, columns: string[], rows: Record<string, unknown>[]): void {
  const escapeCell = (val: unknown) => {
    const raw = val === null || val === undefined ? '' : String(val);
    const trimmedLeading = raw.replace(/^[ ]+/, '');
    const str = trimmedLeading.length > 0 && /^[=+\-@\t\r]/.test(trimmedLeading) ? `'${raw}` : raw;
    if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };
  const header = columns.map(escapeCell).join(',');
  const lines = rows.map((r) => columns.map((c) => escapeCell(r[c])).join(','));
  const csv = [header, ...lines].join('\r\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function downloadJson(filename: string, payload: unknown): void {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export async function downloadAuthenticatedBlob(urlPath: string, fallbackFilename: string): Promise<void> {
  const res = await fetch(urlPath, {
    method: 'GET',
    credentials: 'include',
  });
  if (!res.ok) {
    if (res.status === 401) {
      clearCsrfToken();
      if (unauthorizedHandler) unauthorizedHandler();
    }
    const text = await res.text();
    let msg = `Download failed (${res.status})`;
    if (text) {
      try {
        const parsed = JSON.parse(text) as { error?: string };
        if (parsed.error) msg = parsed.error;
      } catch {
        msg = text;
      }
    }
    throw new Error(msg);
  }

  const disp = res.headers.get('content-disposition') || '';
  const match = disp.match(/filename="?([^";]+)"?/i);
  const filename = match?.[1] || fallbackFilename;

  const blob = await res.blob();
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = objectUrl;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(objectUrl);
}

