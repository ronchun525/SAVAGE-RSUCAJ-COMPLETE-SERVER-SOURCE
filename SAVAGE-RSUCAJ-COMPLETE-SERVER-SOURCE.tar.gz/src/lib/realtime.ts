import { useEffect, useRef } from 'react';

export interface RealtimeFrame {
  seq: number;
  type: string;
  server_emitted_utc: string;
  data: Record<string, unknown>;
}

export type RealtimeConnectionStatus = 'connecting' | 'live' | 'reconnecting' | 'polling';

export interface UseRealtimeStreamOptions {
  /** Event channels to listen for (e.g. ['attendance:updated', 'device:telemetry']) */
  channels: string[];
  /** Invoked whenever an authorized server event arrives or a reconnect resync occurs */
  onEvent: (frame: RealtimeFrame) => void;
  /** Invoked on reconnect after a drop or on polling fallback tick */
  onResync: () => void;
  /** Allows the UI to show verified SSE state versus polling fallback. */
  onStatusChange?: (status: RealtimeConnectionStatus) => void;
  /** Polling fallback interval (ms) while SSE is disconnected; defaults to 15000ms */
  fallbackIntervalMs?: number;
  /** Disable stream when user is not logged in */
  enabled?: boolean;
}

/**
 * Authenticated SSE subscriber with automatic reconnect backoff + jitter,
 * immediate resync on reconnect, and automatic polling fallback if SSE drops.
 */
export function useRealtimeStream(options: UseRealtimeStreamOptions): void {
  const onEventRef = useRef(options.onEvent);
  const onResyncRef = useRef(options.onResync);
  onEventRef.current = options.onEvent;
  onResyncRef.current = options.onResync;
  const onStatusRef = useRef(options.onStatusChange);
  onStatusRef.current = options.onStatusChange;

  const channelsKey = options.channels.join(',');
  const enabled = options.enabled !== false;
  const fallbackIntervalMs = options.fallbackIntervalMs ?? 15_000;

  useEffect(() => {
    if (!enabled || typeof window === 'undefined') return;

    let disposed = false;
    let source: EventSource | null = null;
    let reconnectTimer: number | null = null;
    let fallbackPollTimer: number | null = null;
    let attempt = 0;
    let hasConnectedOnce = false;
    let lastSeq = 0;
    let streamConnectionId: string | null = null;
    const setStatus = (next: RealtimeConnectionStatus) => {
      if (!disposed) onStatusRef.current?.(next);
    };
    setStatus('connecting');

    const clearTimers = () => {
      if (reconnectTimer !== null) {
        window.clearTimeout(reconnectTimer);
        reconnectTimer = null;
      }
      if (fallbackPollTimer !== null) {
        window.clearInterval(fallbackPollTimer);
        fallbackPollTimer = null;
      }
    };

    const startFallbackPolling = () => {
      if (fallbackPollTimer !== null || disposed) return;
      setStatus('polling');
      // Recover promptly after a failed EventSource handshake.
      onResyncRef.current();
      fallbackPollTimer = window.setInterval(() => {
        if (!disposed) onResyncRef.current();
      }, fallbackIntervalMs);
    };

    const stopFallbackPolling = () => {
      if (fallbackPollTimer !== null) {
        window.clearInterval(fallbackPollTimer);
        fallbackPollTimer = null;
      }
    };

    const handleFrame = (rawData: string) => {
      try {
        const parsed = JSON.parse(rawData) as RealtimeFrame;
        if (!parsed || !Number.isSafeInteger(parsed.seq) || parsed.seq <= 0 || typeof parsed.type !== 'string' || !parsed.data || typeof parsed.data !== 'object') return;
        if (parsed.seq <= lastSeq && parsed.type !== 'connected') {
          return;
        }
        lastSeq = parsed.seq;
        if (parsed.type === 'resync:required') {
          onResyncRef.current();
          return;
        }
        onEventRef.current(parsed);
      } catch {
        // Ignore malformed frames
      }
    };

    const connect = () => {
      if (disposed) return;
      if (typeof EventSource === 'undefined') {
        startFallbackPolling();
        return;
      }

      const qs = channelsKey ? `?channels=${encodeURIComponent(channelsKey)}` : '';
      setStatus(hasConnectedOnce ? 'reconnecting' : 'connecting');
      const es = new EventSource(`/api/events/stream${qs}`, { withCredentials: true });
      source = es;

      es.addEventListener('connected', (event) => {
        if (disposed) return;
        // Validate the server handshake before reporting that realtime is live.
        try {
          const frame = JSON.parse((event as MessageEvent).data) as RealtimeFrame;
          const id = frame?.data?.client_id;
          if (frame.type !== 'connected' || typeof id !== 'string' || !id.trim()) {
            es.close();
            startFallbackPolling();
            return;
          }
          // A server restart can reset its sequence counter. A fresh client_id
          // is a new stream epoch; don't discard every subsequent event.
          if (streamConnectionId !== id) {
            streamConnectionId = id;
            lastSeq = 0;
          }
        } catch {
          es.close();
          startFallbackPolling();
          return;
        }
        stopFallbackPolling();
        const isReconnect = hasConnectedOnce;
        hasConnectedOnce = true;
        attempt = 0;
        setStatus('live');
        if (isReconnect) onResyncRef.current();
      });

      const listenTypes = new Set<string>([
        ...channelsKey.split(',').filter(Boolean),
        'resync:required',
      ]);
      for (const evtType of listenTypes) {
        es.addEventListener(evtType, (ev) => {
          if (disposed) return;
          handleFrame((ev as MessageEvent).data);
        });
      }

      es.onerror = () => {
        if (disposed) return;
        es.close();
        if (source === es) source = null;
        startFallbackPolling();
        // Exponential backoff with +/- 25% jitter (1.5s -> 30s)
        const base = Math.min(30_000, 1_500 * Math.pow(2, attempt));
        const jitter = base * 0.25 * (Math.random() * 2 - 1);
        const delay = Math.max(1_000, Math.round(base + jitter));
        attempt = Math.min(attempt + 1, 6);
        reconnectTimer = window.setTimeout(connect, delay);
      };
    };

    connect();

    return () => {
      disposed = true;
      clearTimers();
      if (source) {
        source.close();
        source = null;
      }
    };
  }, [channelsKey, enabled, fallbackIntervalMs]);
}
