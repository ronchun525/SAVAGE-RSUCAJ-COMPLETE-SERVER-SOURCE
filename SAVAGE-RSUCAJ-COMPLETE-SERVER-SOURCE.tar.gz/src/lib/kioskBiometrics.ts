/**
 * SAVAGE-RSUCAJ BUILD 36 — Browser Biometrics Service
 *
 * Manages:
 * 1) Browser front-camera stream initialization, constraint fallback, disconnect tracking & cleanup
 * 2) TensorFlow Lite (.tflite) model discovery & integrity-verified loading from KIOSK_MODELS_DIR
 * 3) Frontal face detection/quality analysis & BUILD 20 tensor preprocessing pipeline
 *    (MiniFASNetV1 PAD [1,80,80,3] RGB NHWC, MiniFASNetV2 Liveness [1,3,80,80] BGR NCHW,
 *     MobileFaceNet Recognition [1,112,112,3] RGB NHWC)
 * 4) Strict attendance-only voice prompts ("Thank you." / "Try again.")
 *
 * CRITICAL HONESTY RULES:
 * - Never fabricate biometric identity matches, liveness scores, or neural inference.
 * - Real getUserMedia camera acquisition with explicit error classification.
 * - Real TFL3 FlatBuffers header + SHA-256 verification before caching or executing any model.
 * - Voice synthesis ("Thank you." / "Try again.") plays ONLY for actual attendance results.
 */

// ============================================================================
// 1. ENVIRONMENT & MODEL SPECIFICATIONS (BUILD 20 CONTRACTS)
// ============================================================================

export type KioskModelKey = 'anti_spoofing_pad' | 'liveness_detection' | 'face_recognition';

export interface KioskModelSpec {
  key: KioskModelKey;
  filename: string;
  architecture: string;
  expectedSha256: string;
  inputShape: readonly [number, number, number, number];
  layout: 'NHWC' | 'NCHW';
  colorOrder: 'RGB' | 'BGR';
  normalization: 'MINUS_ONE_TO_ONE' | 'ZERO_TO_ONE';
  outputShape: readonly [number, number];
  liveClassIndex: number | null;
  embeddingDim: number | null;
  cropScale: number;
}

export const KIOSK_MODEL_SPECS: Record<KioskModelKey, KioskModelSpec> = {
  anti_spoofing_pad: {
    key: 'anti_spoofing_pad',
    filename: 'anti_spoofing_pad.tflite',
    architecture: 'MiniFASNetV1',
    expectedSha256: '5d573d20b795a19d7b2a0f67cc4c1130ce8ec30d5f6aa06b2c788a344a49d4dd',
    inputShape: [1, 80, 80, 3],
    layout: 'NHWC',
    colorOrder: 'RGB',
    normalization: 'MINUS_ONE_TO_ONE',
    outputShape: [1, 3],
    liveClassIndex: 0,
    embeddingDim: null,
    cropScale: 2.7,
  },
  liveness_detection: {
    key: 'liveness_detection',
    filename: 'liveness_detection.tflite',
    architecture: 'MiniFASNetV2',
    expectedSha256: '4ff758f470b757d9005b418c9978693f09b8f2a5e7b7ee848c160db21208e1b2',
    inputShape: [1, 3, 80, 80],
    layout: 'NCHW',
    colorOrder: 'BGR',
    normalization: 'ZERO_TO_ONE',
    outputShape: [1, 3],
    liveClassIndex: 1,
    embeddingDim: null,
    cropScale: 2.7,
  },
  face_recognition: {
    key: 'face_recognition',
    filename: 'face_recognition.tflite',
    architecture: 'MobileFaceNet',
    expectedSha256: 'be4bc7cfc53f7bc336d0f28b1ab92535f618c913a422b683210750f6b5354854',
    inputShape: [1, 112, 112, 3],
    layout: 'NHWC',
    colorOrder: 'RGB',
    normalization: 'MINUS_ONE_TO_ONE',
    outputShape: [1, 192],
    liveClassIndex: null,
    embeddingDim: 192,
    cropScale: 1.25,
  },
};

export const KIOSK_EMBEDDING_DIMENSION = 192;

interface KioskImportMetaEnv {
  VITE_KIOSK_MODELS_DIR?: string;
  KIOSK_MODELS_DIR?: string;
}

/**
 * Resolves the configured KIOSK_MODELS_DIR path across browser (Vite) and Node/test runtimes.
 * Precedence:
 * 1) Explicit caller override (e.g. live server-reported models_dir)
 * 2) Runtime process.env.KIOSK_MODELS_DIR (Node/SSR/test)
 * 3) Vite env VITE_KIOSK_MODELS_DIR or Vite-defined import.meta.env.KIOSK_MODELS_DIR
 * 4) Default "./models"
 */
export function resolveKioskModelsDir(overrideDir?: string): string {
  if (typeof overrideDir === 'string' && overrideDir.trim().length > 0) {
    return overrideDir.trim();
  }

  const nodeEnv =
    typeof process !== 'undefined' && process && typeof process.env === 'object'
      ? process.env.KIOSK_MODELS_DIR || process.env.VITE_KIOSK_MODELS_DIR
      : undefined;
  if (typeof nodeEnv === 'string' && nodeEnv.trim().length > 0) {
    return nodeEnv.trim();
  }

  const metaEnv = (import.meta as unknown as { env?: KioskImportMetaEnv }).env;
  const viteOverride = metaEnv?.VITE_KIOSK_MODELS_DIR;
  if (typeof viteOverride === 'string' && viteOverride.trim().length > 0) {
    return viteOverride.trim();
  }

  const definedDir = metaEnv?.KIOSK_MODELS_DIR;
  if (typeof definedDir === 'string' && definedDir.trim().length > 0) {
    return definedDir.trim();
  }

  return './models';
}

/**
 * Resolves the browser-fetchable URL for a verified .tflite artifact.
 * - If KIOSK_MODELS_DIR is configured as an explicit HTTP(S) URL or a web-relative path
 *   such as "/models", fetches directly from that URL prefix.
 * - Otherwise (filesystem directory such as "./models" or "/var/lib/savage-rsucaj/models"),
 *   routes through the Express verified artifact endpoint "/api/kiosk/web/models/:filename",
 *   which reads directly from process.env.KIOSK_MODELS_DIR on the server.
 */
export function resolveModelArtifactUrl(
  filename: string,
  modelsDir: string = resolveKioskModelsDir(),
  apiBase = ''
): string {
  const cleanName = encodeURIComponent(filename.trim());
  const normalizedBase = apiBase.replace(/\/+$/, '');
  const trimmedDir = modelsDir.trim().replace(/\/+$/, '');

  if (/^https?:\/\//i.test(trimmedDir)) {
    return `${trimmedDir}/${cleanName}`;
  }

  // Root-relative web static directory (e.g. "/models" or "/static/models"), excluding absolute OS paths like "/app/..." or "/var/..."
  const looksLikeOsAbsolutePath = /^\/(app|var|opt|home|etc|tmp|usr|srv|mnt|data)(\/|$)/i.test(trimmedDir);
  if (trimmedDir.startsWith('/') && !looksLikeOsAbsolutePath && trimmedDir.length > 1) {
    return `${normalizedBase}${trimmedDir}/${cleanName}`;
  }

  return `${normalizedBase}/api/kiosk/web/models/${cleanName}`;
}

// ============================================================================
// 2. CAMERA STREAM INITIALIZATION & ERROR CLASSIFICATION
// ============================================================================

export type CameraErrorCode =
  | 'INSECURE_CONTEXT'
  | 'UNSUPPORTED'
  | 'PERMISSION_DENIED'
  | 'NOT_FOUND'
  | 'IN_USE'
  | 'DISCONNECTED'
  | 'UNKNOWN';

export interface CameraErrorInfo {
  code: CameraErrorCode;
  message: string;
}

export interface CameraInitOptions {
  idealWidth?: number;
  idealHeight?: number;
  idealFrameRate?: number;
  deviceId?: string;
  onTrackEnded?: () => void;
}

export type KioskDiagnosticCode =
  | 'READY'
  | 'NO_FACE'
  | 'MULTIPLE_FACES'
  | 'CAMERA_BLOCKED'
  | 'LOW_LIGHT'
  | 'BLURRY_IMAGE'
  | 'OCCLUSION_OR_POSE'
  | 'FROZEN_FRAME'
  | 'LIVENESS_UNVERIFIED'
  | 'PAD_REJECTED'
  | 'UNKNOWN_FACE'
  | 'NOT_ENROLLED'
  | 'MODEL_ERROR'
  | 'BACKEND_UNAVAILABLE'
  | 'SESSION_EXPIRED'
  | 'TIMEOUT'
  | 'COOLDOWN_ACTIVE';

export type KioskVerificationStage =
  | 'WAITING_CAMERA_MODEL'
  | 'FACE_DETECTED'
  | 'QUALITY_CHECKS'
  | 'MULTI_FRAME_PAD_LIVENESS'
  | 'IDENTITY_VERIFICATION'
  | 'BACKEND_VERIFICATION'
  | 'SERVER_CONFIRMED'
  | 'FAILED_COOLDOWN';

export type KioskIndicatorStatus = 'PENDING' | 'CHECKING' | 'PASS' | 'FAIL';

export interface FrameQualityAnalysis {
  /** False when browser Shape Detection API is unavailable; only server YuNet may decide NO_FACE. */
  faceDetectionAvailable?: boolean;
  faceDetected: boolean;
  faceCount: number;
  centered: boolean;
  sizeOk: boolean;
  lightingOk: boolean;
  sharpnessOk: boolean;
  frozenFrame: boolean;
  frontalPoseOk: boolean;
  occlusionSuspected: boolean;
  bboxStable: boolean;
  bboxDrift: number;
  timestampMs: number;
  diagnosticCode: KioskDiagnosticCode;
  brightness: number;
  sharpness: number;
  detectionConfidence: number;
  qualityScore: number;
  guidance: string;
  boundingBox: NormalizedBoundingBox | null;
}

export interface NormalizedBoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface PixelCropBox {
  sx: number;
  sy: number;
  sw: number;
  sh: number;
}

export interface KioskModelFileStatus {
  key: KioskModelKey;
  filename: string;
  architecture: string;
  status: 'VERIFIED_ON_DISK' | 'MISSING' | 'INVALID_HEADER' | 'HASH_MISMATCH';
  size_bytes: number | null;
  expected_sha256: string;
  actual_sha256: string | null;
  reason: string;
}

export interface KioskModelsStatusPayload {
  models_dir: string;
  all_models_verified_on_disk: boolean;
  server_inference_available: boolean;
  production_attendance_ready: boolean;
  blocking_reasons: string[];
  models: {
    anti_spoofing_pad: KioskModelFileStatus;
    liveness_detection: KioskModelFileStatus;
    face_recognition: KioskModelFileStatus;
  };
}

export function classifyCameraError(err: unknown): CameraErrorInfo {
  if (typeof window !== 'undefined' && window.isSecureContext === false) {
    return {
      code: 'INSECURE_CONTEXT',
      message: 'Camera access requires HTTPS (or localhost). Open this kiosk over https://rsu-cajidiocan.tech/kiosk.',
    };
  }
  if (typeof navigator === 'undefined' || !navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== 'function') {
    return {
      code: 'UNSUPPORTED',
      message: 'This browser does not support camera capture (MediaDevices.getUserMedia unavailable).',
    };
  }

  const name = err && typeof err === 'object' && 'name' in err ? String((err as { name: unknown }).name) : '';
  switch (name) {
    case 'NotAllowedError':
    case 'PermissionDeniedError':
      return {
        code: 'PERMISSION_DENIED',
        message: 'Camera permission was denied. Allow camera access in your browser address bar, then retry.',
      };
    case 'NotFoundError':
    case 'DevicesNotFoundError':
      return {
        code: 'NOT_FOUND',
        message: 'No front camera was detected on this device. Connect a webcam or camera module and retry.',
      };
    case 'NotReadableError':
    case 'TrackStartError':
      return {
        code: 'IN_USE',
        message: 'The camera is currently in use by another application or tab. Close it and retry.',
      };
    default:
      return {
        code: 'UNKNOWN',
        message:
          err instanceof Error && err.message
            ? `Unable to start camera: ${err.message}`
            : 'Unable to access the front camera. Check device permissions and connection.',
      };
  }
}

export async function startFrontCameraStream(options: CameraInitOptions = {}): Promise<MediaStream> {
  if (typeof window !== 'undefined' && window.isSecureContext === false) {
    const e = new Error('Insecure context');
    e.name = 'SecurityError';
    throw e;
  }
  if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
    const e = new Error('getUserMedia unsupported');
    e.name = 'UnsupportedError';
    throw e;
  }

  const idealWidth = options.idealWidth ?? 1280;
  const idealHeight = options.idealHeight ?? 720;
  const idealFrameRate = options.idealFrameRate ?? 24;

  // Try preferred front-facing HD constraints first, then automatically fall back to relaxed constraints
  // so low-res Raspberry Pi / USB cameras never fail with OverconstrainedError.
  const constraintLadder: MediaStreamConstraints[] = [];

  if (options.deviceId) {
    constraintLadder.push({
      video: {
        deviceId: { exact: options.deviceId },
        width: { ideal: idealWidth, min: 320 },
        height: { ideal: idealHeight, min: 240 },
        frameRate: { ideal: idealFrameRate, max: 30 },
      },
      audio: false,
    });
  }

  constraintLadder.push(
    {
      video: {
        facingMode: { ideal: 'user' },
        width: { ideal: idealWidth, min: 320 },
        height: { ideal: idealHeight, min: 240 },
        frameRate: { ideal: idealFrameRate, max: 30 },
      },
      audio: false,
    },
    {
      video: {
        facingMode: 'user',
        width: { ideal: 640 },
        height: { ideal: 480 },
      },
      audio: false,
    },
    { video: true, audio: false }
  );

  let lastError: unknown = null;
  for (const constraints of constraintLadder) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      if (options.onTrackEnded) {
        for (const track of stream.getVideoTracks()) {
          track.addEventListener('ended', options.onTrackEnded, { once: true });
        }
      }
      return stream;
    } catch (err) {
      lastError = err;
      const errName = err && typeof err === 'object' && 'name' in err ? String((err as { name: unknown }).name) : '';
      if (errName === 'NotAllowedError' || errName === 'PermissionDeniedError' || errName === 'NotFoundError') {
        throw err;
      }
    }
  }
  throw lastError;
}

export function stopMediaStream(stream: MediaStream | null): void {
  if (!stream) return;
  for (const track of stream.getTracks()) {
    try {
      track.stop();
    } catch {
      // ignore track stop errors
    }
  }
}

// ============================================================================
// 3. REAL FRONTAL FRAME ANALYZER (DETECTION + QUALITY + FROZEN FRAME GUARD)
// ============================================================================

interface BrowserDetectedFace {
  boundingBox: { x: number; y: number; width: number; height: number };
}

interface BrowserFaceDetectorLike {
  detect(image: HTMLCanvasElement | HTMLVideoElement): Promise<BrowserDetectedFace[]>;
}

function createNativeFaceDetector(): BrowserFaceDetectorLike | null {
  if (typeof window === 'undefined') return null;
  const ctor = (
    window as unknown as {
      FaceDetector?: new (opts?: { maxDetectedFaces?: number; fastMode?: boolean }) => BrowserFaceDetectorLike;
    }
  ).FaceDetector;
  if (!ctor) return null;
  try {
    return new ctor({ maxDetectedFaces: 3, fastMode: true });
  } catch {
    return null;
  }
}

/**
 * Real Frontal Frame Analyzer:
 * Evaluates actual video pixels on an offscreen canvas for:
 * 1) Frozen/duplicate video frame detection
 * 2) Luminance (lighting suitability)
 * 3) Laplacian gradient variance (focus/sharpness)
 * 4) Browser FaceDetector single-face centering & size checks (when supported)
 *
 * IMPORTANT: Does NOT fabricate neural face recognition or anti-spoofing identity.
 */
export class FrontalFrameAnalyzer {
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private prevSignature: Uint8Array | null = null;
  private prevBoundingBox: NormalizedBoundingBox | null = null;
  private identicalFrameCount = 0;
  private nativeDetector: BrowserFaceDetectorLike | null = null;

  constructor() {
    this.nativeDetector = createNativeFaceDetector();
  }

  public reset(): void {
    this.prevSignature = null;
    this.prevBoundingBox = null;
    this.identicalFrameCount = 0;
  }

  private ensureCanvas(width: number, height: number): CanvasRenderingContext2D | null {
    if (typeof document === 'undefined') return null;
    if (!this.canvas) {
      this.canvas = document.createElement('canvas');
      this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
    }
    if (this.canvas.width !== width || this.canvas.height !== height) {
      this.canvas.width = width;
      this.canvas.height = height;
    }
    return this.ctx;
  }

  public async analyze(video: HTMLVideoElement): Promise<FrameQualityAnalysis> {
    const nowMs = Date.now();
    if (!video || video.readyState < 2 || video.videoWidth <= 0 || video.videoHeight <= 0) {
      return {
        faceDetected: false,
        faceCount: 0,
        centered: false,
        sizeOk: false,
        lightingOk: false,
        sharpnessOk: false,
        frozenFrame: true,
        frontalPoseOk: false,
        occlusionSuspected: false,
        bboxStable: false,
        bboxDrift: 0,
        timestampMs: nowMs,
        diagnosticCode: 'CAMERA_BLOCKED',
        brightness: 0,
        sharpness: 0,
        detectionConfidence: 0,
        qualityScore: 0,
        guidance: 'Initializing camera feed...',
        boundingBox: null,
      };
    }

    const sampleW = 160;
    const sampleH = 120;
    const ctx = this.ensureCanvas(sampleW, sampleH);
    if (!ctx || !this.canvas) {
      return {
        faceDetected: false,
        faceCount: 0,
        centered: false,
        sizeOk: false,
        lightingOk: false,
        sharpnessOk: false,
        frozenFrame: false,
        frontalPoseOk: false,
        occlusionSuspected: false,
        bboxStable: false,
        bboxDrift: 0,
        timestampMs: nowMs,
        diagnosticCode: 'CAMERA_BLOCKED',
        brightness: 0,
        sharpness: 0,
        detectionConfidence: 0,
        qualityScore: 0,
        guidance: 'Canvas frame analyzer unavailable.',
        boundingBox: null,
      };
    }

    ctx.drawImage(video, 0, 0, sampleW, sampleH);
    const img = ctx.getImageData(0, 0, sampleW, sampleH);
    const data = img.data;

    // 1. Center ROI luminance & grayscale buffer for sharpness + frozen-frame check
    const gray = new Uint8Array(sampleW * sampleH);
    let lumSum = 0;
    let centerPixels = 0;
    const x0 = Math.floor(sampleW * 0.2);
    const x1 = Math.floor(sampleW * 0.8);
    const y0 = Math.floor(sampleH * 0.15);
    const y1 = Math.floor(sampleH * 0.85);

    for (let y = 0; y < sampleH; y++) {
      for (let x = 0; x < sampleW; x++) {
        const idx = y * sampleW + x;
        const p = idx * 4;
        const luma = Math.round(0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2]);
        gray[idx] = luma;
        if (x >= x0 && x < x1 && y >= y0 && y < y1) {
          lumSum += luma;
          centerPixels++;
        }
      }
    }
    const brightness = centerPixels > 0 ? lumSum / centerPixels : 0;

    // 2. Frozen frame detection via 16x12 coarse grid diff
    const sig = new Uint8Array(192);
    let si = 0;
    for (let y = 5; y < sampleH; y += 10) {
      for (let x = 5; x < sampleW; x += 10) {
        if (si < 192) sig[si++] = gray[y * sampleW + x];
      }
    }
    let meanDiff = 999;
    if (this.prevSignature) {
      let diffSum = 0;
      for (let i = 0; i < sig.length; i++) {
        diffSum += Math.abs(sig[i] - this.prevSignature[i]);
      }
      meanDiff = diffSum / sig.length;
    }
    this.prevSignature = sig;
    if (meanDiff < 0.35) {
      this.identicalFrameCount += 1;
    } else {
      this.identicalFrameCount = 0;
    }
    const frozenFrame = this.identicalFrameCount >= 8;

    // 3. Laplacian sharpness estimate in center ROI
    let lapSum = 0;
    let lapSqSum = 0;
    let lapCount = 0;
    for (let y = y0 + 1; y < y1 - 1; y++) {
      for (let x = x0 + 1; x < x1 - 1; x++) {
        const idx = y * sampleW + x;
        const lap =
          4 * gray[idx] -
          gray[idx - 1] -
          gray[idx + 1] -
          gray[idx - sampleW] -
          gray[idx + sampleW];
        lapSum += lap;
        lapSqSum += lap * lap;
        lapCount++;
      }
    }
    const lapMean = lapCount > 0 ? lapSum / lapCount : 0;
    const lapVariance = lapCount > 0 ? Math.max(0, lapSqSum / lapCount - lapMean * lapMean) : 0;

    const lightingOk = brightness >= 48 && brightness <= 225;
    const sharpnessOk = lapVariance >= 28;

    // 4. Native FaceDetector API when available in Chromium
    let faceCount = 0;
    let boundingBox: NormalizedBoundingBox | null = null;
    let centered = false;
    let sizeOk = false;
    let frontalPoseOk = false;
    let detectionConfidence = 0;

    if (this.nativeDetector) {
      try {
        const faces = await this.nativeDetector.detect(this.canvas);
        faceCount = faces.length;
        if (faceCount === 1) {
          const box = faces[0].boundingBox;
          boundingBox = {
            x: box.x / sampleW,
            y: box.y / sampleH,
            width: box.width / sampleW,
            height: box.height / sampleH,
          };
          const cx = boundingBox.x + boundingBox.width / 2;
          const cy = boundingBox.y + boundingBox.height / 2;
          centered = Math.abs(cx - 0.5) <= 0.22 && Math.abs(cy - 0.5) <= 0.24;
          sizeOk = boundingBox.width >= 0.18 && boundingBox.width <= 0.78;
          const aspect = boundingBox.height > 0 ? boundingBox.width / boundingBox.height : 0;
          frontalPoseOk = aspect >= 0.65 && aspect <= 1.25;
          detectionConfidence = centered && sizeOk && frontalPoseOk ? 0.92 : 0.75;
        }
      } catch {
        // Fallback below if Shape Detection is disabled on the host OS
      }
    }

    // 5. Bounding-box stability across consecutive frames & uniform lower-ROI occlusion heuristic
    let bboxDrift = 0;
    let bboxStable = true;
    if (boundingBox && this.prevBoundingBox) {
      const cx = boundingBox.x + boundingBox.width / 2;
      const cy = boundingBox.y + boundingBox.height / 2;
      const pcx = this.prevBoundingBox.x + this.prevBoundingBox.width / 2;
      const pcy = this.prevBoundingBox.y + this.prevBoundingBox.height / 2;
      bboxDrift = Math.max(
        Math.abs(cx - pcx),
        Math.abs(cy - pcy),
        Math.abs(boundingBox.width - this.prevBoundingBox.width)
      );
      bboxStable = bboxDrift <= 0.16;
    }
    this.prevBoundingBox = boundingBox;

    // Simple deterministic occlusion check: extremely flat zero-texture region covering the center ROI
    // (e.g. camera lens covered by hand/sticker/flat mask)
    const occlusionSuspected = lightingOk && lapVariance < 6 && brightness < 70;

    // Guidance & exact differentiated diagnostic code (NEVER left/right head-turn prompts!)
    let diagnosticCode: KioskDiagnosticCode = 'READY';
    let guidance = 'Look straight at the camera and hold still.';
    if (frozenFrame) {
      diagnosticCode = 'FROZEN_FRAME';
      guidance = 'Camera frame appears frozen. Please check your camera feed.';
    } else if (faceCount > 1) {
      diagnosticCode = 'MULTIPLE_FACES';
      guidance = 'Multiple faces detected — one person at a time.';
    } else if (this.nativeDetector && faceCount === 0) {
      diagnosticCode = 'NO_FACE';
      guidance = 'Position your face inside the green frame.';
    } else if (this.nativeDetector && !centered) {
      diagnosticCode = 'OCCLUSION_OR_POSE';
      guidance = 'Center your face inside the green frame.';
    } else if (this.nativeDetector && !sizeOk) {
      diagnosticCode = 'OCCLUSION_OR_POSE';
      guidance =
        boundingBox && boundingBox.width < 0.18 ? 'Move closer to the camera.' : 'Step slightly back from the camera.';
    } else if (this.nativeDetector && !bboxStable) {
      diagnosticCode = 'OCCLUSION_OR_POSE';
      guidance = 'Hold still — keep your face steady inside the frame.';
    } else if (!lightingOk) {
      diagnosticCode = 'LOW_LIGHT';
      guidance =
        brightness < 48 ? 'Lighting is too dark. Face a brighter light source.' : 'Lighting is too bright. Reduce direct glare.';
    } else if (occlusionSuspected) {
      diagnosticCode = 'OCCLUSION_OR_POSE';
      guidance = 'Camera view appears obstructed. Uncover your face and lens.';
    } else if (!sharpnessOk) {
      diagnosticCode = 'BLURRY_IMAGE';
      guidance = 'Hold still — camera image is blurry.';
    } else if (!this.nativeDetector) {
      diagnosticCode = 'READY';
      guidance = 'Look straight at the camera and hold still.';
    }

    const lightingScore = lightingOk ? Math.min(1, 1 - Math.abs(brightness - 135) / 140) : 0.35;
    const sharpnessScore = Math.min(1, lapVariance / 140);
    const qualityScore = Number(
      Math.max(0, Math.min(1, lightingScore * 0.45 + sharpnessScore * 0.55)).toFixed(3)
    );

    return {
      faceDetectionAvailable: Boolean(this.nativeDetector),
      faceDetected: faceCount === 1,
      faceCount,
      centered,
      sizeOk,
      lightingOk,
      sharpnessOk,
      frozenFrame,
      frontalPoseOk,
      occlusionSuspected,
      bboxStable,
      bboxDrift: Number(bboxDrift.toFixed(4)),
      timestampMs: nowMs,
      diagnosticCode,
      brightness: Number(brightness.toFixed(1)),
      sharpness: Number(lapVariance.toFixed(1)),
      detectionConfidence,
      qualityScore,
      guidance,
      boundingBox,
    };
  }
}

// ============================================================================
// 4. TENSOR PREPROCESSING PIPELINE (PAD, LIVENESS & RECOGNITION)
// ============================================================================

export interface PreprocessedTensor {
  modelKey: KioskModelKey;
  data: Float32Array;
  shape: readonly [number, number, number, number];
  layout: 'NHWC' | 'NCHW';
  colorOrder: 'RGB' | 'BGR';
  normalization: 'MINUS_ONE_TO_ONE' | 'ZERO_TO_ONE';
}

export interface FacePreprocessingBundle {
  padCrop: PixelCropBox;
  recognitionCrop: PixelCropBox;
  pad: PreprocessedTensor;
  liveness: PreprocessedTensor;
  recognition: PreprocessedTensor;
}

export interface DecodedClassifierResult {
  valid: boolean;
  liveProbability: number;
  probabilities: number[];
  wasAlreadyProbability: boolean;
  reason?: string;
}

/**
 * Computes a square, aspect-preserving, clamped pixel ROI centered on a detected face box.
 * When no bounding box is provided (e.g. browser without native FaceDetector), falls back to
 * the centered 60% frontal guide box matching the on-screen green face reticle.
 */
export function computeExpandedFaceCropBox(
  boundingBox: NormalizedBoundingBox | null,
  frameWidth: number,
  frameHeight: number,
  scale = 1.25
): PixelCropBox {
  const safeW = Math.max(1, Math.floor(frameWidth));
  const safeH = Math.max(1, Math.floor(frameHeight));

  const box: NormalizedBoundingBox = boundingBox ?? {
    x: 0.2,
    y: 0.15,
    width: 0.6,
    height: 0.7,
  };

  const rawX = box.x * safeW;
  const rawY = box.y * safeH;
  const rawW = Math.max(1, box.width * safeW);
  const rawH = Math.max(1, box.height * safeH);

  const cx = rawX + rawW / 2;
  const cy = rawY + rawH / 2;

  const baseSide = Math.max(rawW, rawH);
  const desiredSide = Math.min(Math.min(safeW, safeH), Math.max(16, baseSide * scale));

  let sx = Math.round(cx - desiredSide / 2);
  let sy = Math.round(cy - desiredSide / 2);
  const side = Math.max(1, Math.round(desiredSide));

  if (sx < 0) sx = 0;
  if (sy < 0) sy = 0;
  if (sx + side > safeW) sx = Math.max(0, safeW - side);
  if (sy + side > safeH) sy = Math.max(0, safeH - side);

  return {
    sx,
    sy,
    sw: Math.min(side, safeW - sx),
    sh: Math.min(side, safeH - sy),
  };
}

/**
 * MiniFASNetV1 Anti-Spoofing PAD tensor encoder:
 * float32 [1, 80, 80, 3] RGB NHWC, normalized via (px / 128.0) - 1.0
 */
export function preprocessPadTensor(
  rgbaPixels: Uint8ClampedArray | Uint8Array,
  width = 80,
  height = 80
): PreprocessedTensor {
  const expectedBytes = width * height * 4;
  if (rgbaPixels.length < expectedBytes) {
    throw new Error(`Expected RGBA buffer of at least ${expectedBytes} bytes for PAD ${width}x${height}.`);
  }
  const data = new Float32Array(width * height * 3);
  let dst = 0;
  for (let i = 0; i < expectedBytes; i += 4) {
    data[dst++] = rgbaPixels[i] / 128.0 - 1.0; // R
    data[dst++] = rgbaPixels[i + 1] / 128.0 - 1.0; // G
    data[dst++] = rgbaPixels[i + 2] / 128.0 - 1.0; // B
  }
  return {
    modelKey: 'anti_spoofing_pad',
    data,
    shape: [1, height, width, 3],
    layout: 'NHWC',
    colorOrder: 'RGB',
    normalization: 'MINUS_ONE_TO_ONE',
  };
}

/**
 * MiniFASNetV2 Passive Liveness Detection tensor encoder:
 * float32 [1, 3, 80, 80] BGR NCHW, normalized via px / 255.0
 */
export function preprocessLivenessTensor(
  rgbaPixels: Uint8ClampedArray | Uint8Array,
  width = 80,
  height = 80
): PreprocessedTensor {
  const planeSize = width * height;
  const expectedBytes = planeSize * 4;
  if (rgbaPixels.length < expectedBytes) {
    throw new Error(`Expected RGBA buffer of at least ${expectedBytes} bytes for Liveness ${width}x${height}.`);
  }
  const data = new Float32Array(planeSize * 3);
  for (let p = 0; p < planeSize; p++) {
    const base = p * 4;
    data[p] = rgbaPixels[base + 2] / 255.0; // Channel 0 = B
    data[planeSize + p] = rgbaPixels[base + 1] / 255.0; // Channel 1 = G
    data[planeSize * 2 + p] = rgbaPixels[base] / 255.0; // Channel 2 = R
  }
  return {
    modelKey: 'liveness_detection',
    data,
    shape: [1, 3, height, width],
    layout: 'NCHW',
    colorOrder: 'BGR',
    normalization: 'ZERO_TO_ONE',
  };
}

/**
 * MobileFaceNet Face Recognition tensor encoder:
 * float32 [1, 112, 112, 3] RGB NHWC, normalized via (px / 128.0) - 1.0
 */
export function preprocessRecognitionTensor(
  rgbaPixels: Uint8ClampedArray | Uint8Array,
  width = 112,
  height = 112
): PreprocessedTensor {
  const expectedBytes = width * height * 4;
  if (rgbaPixels.length < expectedBytes) {
    throw new Error(`Expected RGBA buffer of at least ${expectedBytes} bytes for Recognition ${width}x${height}.`);
  }
  const data = new Float32Array(width * height * 3);
  let dst = 0;
  for (let i = 0; i < expectedBytes; i += 4) {
    data[dst++] = rgbaPixels[i] / 128.0 - 1.0; // R
    data[dst++] = rgbaPixels[i + 1] / 128.0 - 1.0; // G
    data[dst++] = rgbaPixels[i + 2] / 128.0 - 1.0; // B
  }
  return {
    modelKey: 'face_recognition',
    data,
    shape: [1, height, width, 3],
    layout: 'NHWC',
    colorOrder: 'RGB',
    normalization: 'MINUS_ONE_TO_ONE',
  };
}

/**
 * Decodes a 3-class PAD / Liveness output vector:
 * - Rejects NaN / Infinity / invalid lengths fail-closed.
 * - Preserves already-normalized probability distributions (all in [0,1] and sum ~= 1.0).
 * - Applies numerically stabilized softmax to raw logits.
 */
export function decodeClassifierLiveScore(
  rawValues: ArrayLike<number>,
  liveClassIndex: number
): DecodedClassifierResult {
  if (!rawValues || rawValues.length !== 3) {
    return {
      valid: false,
      liveProbability: 0,
      probabilities: [],
      wasAlreadyProbability: false,
      reason: `Expected 3-class output vector, got length ${rawValues ? rawValues.length : 0}.`,
    };
  }
  if (liveClassIndex < 0 || liveClassIndex >= 3) {
    return {
      valid: false,
      liveProbability: 0,
      probabilities: [],
      wasAlreadyProbability: false,
      reason: `Invalid liveClassIndex ${liveClassIndex}.`,
    };
  }

  const values = [Number(rawValues[0]), Number(rawValues[1]), Number(rawValues[2])];
  if (values.some((v) => !Number.isFinite(v))) {
    return {
      valid: false,
      liveProbability: 0,
      probabilities: [],
      wasAlreadyProbability: false,
      reason: 'Model output contains NaN or Infinity (fail-closed).',
    };
  }

  const allInUnitRange = values.every((v) => v >= 0 && v <= 1);
  const sum = values[0] + values[1] + values[2];
  if (allInUnitRange && Math.abs(sum - 1.0) <= 0.015) {
    const normalized = values.map((v) => v / sum);
    return {
      valid: true,
      liveProbability: normalized[liveClassIndex],
      probabilities: normalized,
      wasAlreadyProbability: true,
    };
  }

  const maxVal = Math.max(...values);
  const exps = values.map((v) => Math.exp(v - maxVal));
  const expSum = exps[0] + exps[1] + exps[2];
  if (!Number.isFinite(expSum) || expSum <= 0) {
    return {
      valid: false,
      liveProbability: 0,
      probabilities: [],
      wasAlreadyProbability: false,
      reason: 'Softmax normalization overflowed (fail-closed).',
    };
  }
  const probs = exps.map((e) => e / expSum);
  return {
    valid: true,
    liveProbability: probs[liveClassIndex],
    probabilities: probs,
    wasAlreadyProbability: false,
  };
}

/**
 * L2-normalizes a 192-dimensional MobileFaceNet embedding vector.
 * Returns null fail-closed if length mismatches or any entry is non-finite / near-zero norm.
 */
export function l2NormalizeEmbedding(rawValues: ArrayLike<number>): Float32Array | null {
  if (!rawValues || rawValues.length !== KIOSK_EMBEDDING_DIMENSION) {
    return null;
  }
  let sumSq = 0;
  for (let i = 0; i < KIOSK_EMBEDDING_DIMENSION; i++) {
    const v = Number(rawValues[i]);
    if (!Number.isFinite(v)) return null;
    sumSq += v * v;
  }
  const norm = Math.sqrt(sumSq);
  if (!Number.isFinite(norm) || norm <= 1e-8) {
    return null;
  }
  const out = new Float32Array(KIOSK_EMBEDDING_DIMENSION);
  for (let i = 0; i < KIOSK_EMBEDDING_DIMENSION; i++) {
    out[i] = Number(rawValues[i]) / norm;
  }
  return out;
}

/**
 * Reusable offscreen-canvas preprocessor extracting aligned 80x80 PAD/Liveness and 112x112 Recognition tensors
 * directly from live HTMLVideoElement or HTMLCanvasElement frames.
 */
export class KioskTensorPreprocessor {
  private padCanvas: HTMLCanvasElement | null = null;
  private padCtx: CanvasRenderingContext2D | null = null;
  private recCanvas: HTMLCanvasElement | null = null;
  private recCtx: CanvasRenderingContext2D | null = null;

  private ensureCanvas(target: 'pad' | 'rec', width: number, height: number): CanvasRenderingContext2D {
    if (typeof document === 'undefined') {
      throw new Error('DOM canvas is required to crop video frames.');
    }
    if (target === 'pad') {
      if (!this.padCanvas) {
        this.padCanvas = document.createElement('canvas');
        this.padCanvas.width = width;
        this.padCanvas.height = height;
        this.padCtx = this.padCanvas.getContext('2d', { willReadFrequently: true });
      }
      if (!this.padCtx) throw new Error('Unable to acquire 2D context for 80x80 PAD/Liveness canvas.');
      return this.padCtx;
    }

    if (!this.recCanvas) {
      this.recCanvas = document.createElement('canvas');
      this.recCanvas.width = width;
      this.recCanvas.height = height;
      this.recCtx = this.recCanvas.getContext('2d', { willReadFrequently: true });
    }
    if (!this.recCtx) throw new Error('Unable to acquire 2D context for 112x112 Recognition canvas.');
    return this.recCtx;
  }

  public preprocessFrame(
    source: HTMLVideoElement | HTMLCanvasElement,
    boundingBox: NormalizedBoundingBox | null
  ): FacePreprocessingBundle {
    const frameWidth = 'videoWidth' in source ? source.videoWidth : source.width;
    const frameHeight = 'videoHeight' in source ? source.videoHeight : source.height;
    if (frameWidth <= 0 || frameHeight <= 0) {
      throw new Error('Video or canvas source has zero dimensions.');
    }

    // 1. 2.7x context crop resized to 80x80 for MiniFASNetV1 (PAD) & MiniFASNetV2 (Passive Liveness)
    const padCrop = computeExpandedFaceCropBox(
      boundingBox,
      frameWidth,
      frameHeight,
      KIOSK_MODEL_SPECS.anti_spoofing_pad.cropScale
    );
    const padCtx = this.ensureCanvas('pad', 80, 80);
    padCtx.clearRect(0, 0, 80, 80);
    padCtx.drawImage(source, padCrop.sx, padCrop.sy, padCrop.sw, padCrop.sh, 0, 0, 80, 80);
    const padRgba = padCtx.getImageData(0, 0, 80, 80).data;

    // 2. 1.25x tight frontal crop resized to 112x112 for MobileFaceNet Recognition
    const recognitionCrop = computeExpandedFaceCropBox(
      boundingBox,
      frameWidth,
      frameHeight,
      KIOSK_MODEL_SPECS.face_recognition.cropScale
    );
    const recCtx = this.ensureCanvas('rec', 112, 112);
    recCtx.clearRect(0, 0, 112, 112);
    recCtx.drawImage(
      source,
      recognitionCrop.sx,
      recognitionCrop.sy,
      recognitionCrop.sw,
      recognitionCrop.sh,
      0,
      0,
      112,
      112
    );
    const recRgba = recCtx.getImageData(0, 0, 112, 112).data;

    return {
      padCrop,
      recognitionCrop,
      pad: preprocessPadTensor(padRgba, 80, 80),
      liveness: preprocessLivenessTensor(padRgba, 80, 80),
      recognition: preprocessRecognitionTensor(recRgba, 112, 112),
    };
  }
}

// ============================================================================
// 5. TENSORFLOW LITE MODEL INTEGRITY & LOADING MANAGER
// ============================================================================

export type KioskModelLoadState =
  | 'UNLOADED'
  | 'LOADING'
  | 'VERIFIED_BUFFER_READY'
  | 'INTERPRETER_READY'
  | 'MISSING'
  | 'INVALID_HEADER'
  | 'HASH_MISMATCH'
  | 'ERROR';

export interface TfliteInterpreterLike {
  predict(tensor: Float32Array, shape: readonly number[]): Promise<Float32Array> | Float32Array;
  dispose?: () => void;
}

export type TfliteInterpreterFactory = (
  buffer: ArrayBuffer,
  spec: KioskModelSpec
) => Promise<TfliteInterpreterLike>;

export interface LoadedKioskModelRecord {
  key: KioskModelKey;
  spec: KioskModelSpec;
  state: KioskModelLoadState;
  url: string;
  sha256: string | null;
  sizeBytes: number | null;
  buffer: ArrayBuffer | null;
  interpreter: TfliteInterpreterLike | null;
  reason: string;
}

export interface KioskModelLoaderOptions {
  modelsDir?: string;
  apiBase?: string;
  fetchImpl?: typeof fetch;
  interpreterFactory?: TfliteInterpreterFactory;
}

/**
 * Verify a downloaded model ArrayBuffer against its pinned BUILD 20 SHA-256 and TFL3 FlatBuffers magic.
 */
export async function verifyModelBufferIntegrity(
  buffer: ArrayBuffer,
  expectedSha256: string
): Promise<{ valid: boolean; sha256: string; reason?: string; errorCode?: 'INVALID_HEADER' | 'HASH_MISMATCH' }> {
  const bytes = new Uint8Array(buffer);
  if (bytes.length < 8) {
    return {
      valid: false,
      sha256: '',
      errorCode: 'INVALID_HEADER',
      reason: 'Model file is truncated (< 8 bytes).',
    };
  }
  const magic = String.fromCharCode(bytes[4], bytes[5], bytes[6], bytes[7]);
  if (magic !== 'TFL3') {
    return {
      valid: false,
      sha256: '',
      errorCode: 'INVALID_HEADER',
      reason: `Invalid TFLite header "${magic}" (expected "TFL3").`,
    };
  }

  const subtle = globalThis.crypto?.subtle;
  if (!subtle) {
    return {
      valid: false,
      sha256: '',
      errorCode: 'HASH_MISMATCH',
      reason: 'WebCrypto SHA-256 unavailable in this runtime context.',
    };
  }

  const digest = await subtle.digest('SHA-256', buffer);
  const sha256 = Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  if (sha256 !== expectedSha256) {
    return {
      valid: false,
      sha256,
      errorCode: 'HASH_MISMATCH',
      reason: `SHA-256 mismatch (expected ${expectedSha256.slice(0, 12)}..., got ${sha256.slice(0, 12)}...).`,
    };
  }
  return { valid: true, sha256 };
}

/**
 * Manages TensorFlow Lite model status inspection, download from KIOSK_MODELS_DIR
 * (via static URL or verified Express endpoint), TFL3 + SHA-256 integrity validation,
 * and optional WASM interpreter instantiation.
 */
export class KioskTfliteModelLoader {
  private modelsDir: string;
  private apiBase: string;
  private fetchImpl: typeof fetch;
  private interpreterFactory?: TfliteInterpreterFactory;
  private lastStatusPayload: KioskModelsStatusPayload | null = null;
  private records: Record<KioskModelKey, LoadedKioskModelRecord>;

  constructor(options: KioskModelLoaderOptions = {}) {
    this.modelsDir = resolveKioskModelsDir(options.modelsDir);
    this.apiBase = (options.apiBase || '').replace(/\/+$/, '');
    this.fetchImpl = options.fetchImpl ?? globalThis.fetch.bind(globalThis);
    this.interpreterFactory = options.interpreterFactory;
    this.records = this.createInitialRecords();
  }

  private createInitialRecords(): Record<KioskModelKey, LoadedKioskModelRecord> {
    const build = (key: KioskModelKey): LoadedKioskModelRecord => {
      const spec = KIOSK_MODEL_SPECS[key];
      return {
        key,
        spec,
        state: 'UNLOADED',
        url: resolveModelArtifactUrl(spec.filename, this.modelsDir, this.apiBase),
        sha256: null,
        sizeBytes: null,
        buffer: null,
        interpreter: null,
        reason: 'Not loaded yet.',
      };
    };
    return {
      anti_spoofing_pad: build('anti_spoofing_pad'),
      liveness_detection: build('liveness_detection'),
      face_recognition: build('face_recognition'),
    };
  }

  public getModelsDir(): string {
    return this.modelsDir;
  }

  public getLastStatusPayload(): KioskModelsStatusPayload | null {
    return this.lastStatusPayload;
  }

  public getModelRecord(key: KioskModelKey): LoadedKioskModelRecord {
    return this.records[key];
  }

  public getAllModelRecords(): Record<KioskModelKey, LoadedKioskModelRecord> {
    return {
      anti_spoofing_pad: this.records.anti_spoofing_pad,
      liveness_detection: this.records.liveness_detection,
      face_recognition: this.records.face_recognition,
    };
  }

  public getLoadedBuffer(key: KioskModelKey): ArrayBuffer | null {
    return this.records[key].buffer;
  }

  public async fetchModelsStatus(): Promise<KioskModelsStatusPayload> {
    const res = await this.fetchImpl(`${this.apiBase}/api/kiosk/web/models/status`, {
      credentials: 'same-origin',
    });
    if (!res.ok) {
      throw new Error(`Failed to fetch kiosk model status (HTTP ${res.status}).`);
    }
    const payload = (await res.json()) as KioskModelsStatusPayload;
    this.lastStatusPayload = payload;
    if (payload.models_dir && payload.models_dir.trim()) {
      this.modelsDir = payload.models_dir.trim();
    }
    return payload;
  }

  public async loadModel(key: KioskModelKey): Promise<LoadedKioskModelRecord> {
    const spec = KIOSK_MODEL_SPECS[key];
    const url = resolveModelArtifactUrl(spec.filename, this.modelsDir, this.apiBase);

    this.records[key] = {
      ...this.records[key],
      url,
      state: 'LOADING',
      reason: `Fetching ${spec.filename}...`,
    };

    try {
      const res = await this.fetchImpl(url, { credentials: 'same-origin' });
      if (res.status === 404) {
        let serverReason = `Model binary "${spec.filename}" is missing from ${this.modelsDir}.`;
        try {
          const errBody = (await res.json()) as { error?: string };
          if (errBody?.error) serverReason = errBody.error;
        } catch {
          // non-JSON 404
        }
        this.records[key] = {
          ...this.records[key],
          state: 'MISSING',
          buffer: null,
          interpreter: null,
          sizeBytes: null,
          sha256: null,
          reason: serverReason,
        };
        return this.records[key];
      }

      if (!res.ok) {
        this.records[key] = {
          ...this.records[key],
          state: 'ERROR',
          buffer: null,
          interpreter: null,
          reason: `Failed to download "${spec.filename}" (HTTP ${res.status}).`,
        };
        return this.records[key];
      }

      const buffer = await res.arrayBuffer();
      const verification = await verifyModelBufferIntegrity(buffer, spec.expectedSha256);
      if (!verification.valid) {
        this.records[key] = {
          ...this.records[key],
          state: verification.errorCode ?? 'ERROR',
          buffer: null,
          interpreter: null,
          sizeBytes: buffer.byteLength,
          sha256: verification.sha256 || null,
          reason: verification.reason || 'Model integrity verification failed.',
        };
        return this.records[key];
      }

      let interpreter: TfliteInterpreterLike | null = null;
      if (this.interpreterFactory) {
        interpreter = await this.interpreterFactory(buffer, spec);
      }

      this.records[key] = {
        ...this.records[key],
        state: interpreter ? 'INTERPRETER_READY' : 'VERIFIED_BUFFER_READY',
        buffer,
        interpreter,
        sizeBytes: buffer.byteLength,
        sha256: verification.sha256,
        reason: interpreter
          ? 'Verified TFL3 model loaded into interpreter.'
          : 'Verified TFL3 model buffer ready (no browser TFLite WASM interpreter registered).',
      };
      return this.records[key];
    } catch (err) {
      this.records[key] = {
        ...this.records[key],
        state: 'ERROR',
        buffer: null,
        interpreter: null,
        reason: err instanceof Error ? err.message : `Unexpected error loading "${spec.filename}".`,
      };
      return this.records[key];
    }
  }

  public async loadAllModels(options: { inspectStatusFirst?: boolean } = {}): Promise<
    Record<KioskModelKey, LoadedKioskModelRecord>
  > {
    if (options.inspectStatusFirst !== false) {
      try {
        await this.fetchModelsStatus();
      } catch {
        // Proceed with configured KIOSK_MODELS_DIR fallback
      }
    }

    await Promise.all([
      this.loadModel('anti_spoofing_pad'),
      this.loadModel('liveness_detection'),
      this.loadModel('face_recognition'),
    ]);

    return this.getAllModelRecords();
  }

  public dispose(): void {
    for (const key of Object.keys(this.records) as KioskModelKey[]) {
      try {
        this.records[key].interpreter?.dispose?.();
      } catch {
        // ignore interpreter cleanup errors
      }
    }
    this.records = this.createInitialRecords();
  }
}

// ============================================================================
// 6. STRICT ATTENDANCE-ONLY VOICE ENGINE (SECTION 10)
// ============================================================================

/**
 * Offline, same-origin sound output for unattended full-screen kiosks.
 * Local MP3 cues are primary: Linux/Chromium installations often lack any
 * speechSynthesis voice pack. Browser TTS is a best-effort fallback ONLY.
 * Browser autoplay permission is separate from OS speaker/mixer configuration;
 * call prepareFromUserGesture() on the attendance start button. On fully
 * unattended managed kiosks configure Chromium's autoplay policy at launch.
 *
 * No enrollment, loading or idle-scanning voice announcements are emitted.
 */
export class KioskVoiceController {
  private lastSpokenAt = 0;
  private activeAudio: HTMLAudioElement | null = null;
  private playbackGeneration = 0;
  private gesturePrepared = false;

  /** Prime media permission on a real click/tap; never fabricate a user gesture. */
  public prepareFromUserGesture(): void {
    if (this.gesturePrepared || typeof Audio === 'undefined') return;
    this.gesturePrepared = true;
    try {
      const prime = new Audio('/audio/prime.mp3');
      prime.preload = 'auto';
      prime.volume = 0.01;
      // Intentionally silent. Browsers can reject playback on unmanaged
      // auto-start kiosks: that case is handled by the visible speaker test.
      void Promise.resolve(prime.play()).catch(() => {
        this.gesturePrepared = false;
      });
    } catch {
      this.gesturePrepared = false;
    }
  }

  private async playAsset(path: string, generation: number): Promise<boolean> {
    if (typeof Audio === 'undefined') return false;
    try {
      if (this.activeAudio) {
        this.activeAudio.pause();
        this.activeAudio.currentTime = 0;
      }
      const clip = new Audio(path);
      clip.preload = 'auto';
      clip.volume = 1;
      this.activeAudio = clip;
      // A disconnected Linux audio sink can leave play() pending indefinitely.
      // Bound diagnostics and fall back instead of hanging the kiosk controls.
      let timer: ReturnType<typeof setTimeout> | null = null;
      const result = await Promise.race([
        Promise.resolve(clip.play()).then(() => true, () => false),
        new Promise<boolean>((resolve) => {
          timer = setTimeout(() => resolve(false), 3500);
        }),
      ]);
      if (timer !== null) clearTimeout(timer);
      if (!result && this.activeAudio === clip) clip.pause();
      return result && generation === this.playbackGeneration;
    } catch {
      return false;
    }
  }

  /**
   * Admin-only hardware diagnostic: plays a tone, NOT an attendance voice cue.
   * Resolving play() establishes browser playback, not physical audibility.
   */
  public async testSpeaker(): Promise<boolean> {
    this.prepareFromUserGesture();
    const generation = ++this.playbackGeneration;
    return this.playAsset('/audio/speaker-test.mp3', generation);
  }

  public speakAttendanceResult(result: 'success' | 'failure', enabled: boolean): void {
    if (!enabled || typeof window === 'undefined') return;
    const now = Date.now();
    if (now - this.lastSpokenAt < 900) return;
    this.lastSpokenAt = now;
    const generation = ++this.playbackGeneration;
    const filename = result === 'success' ? '/audio/thank-you.mp3' : '/audio/try-again.mp3';
    void this.playAsset(filename, generation).then((played) => {
      if (!played && generation === this.playbackGeneration) {
        this.speakUsingBrowserEngine(result);
      }
    });
  }

  private speakUsingBrowserEngine(result: 'success' | 'failure'): void {
    if (
      typeof window === 'undefined' ||
      !('speechSynthesis' in window) ||
      typeof SpeechSynthesisUtterance === 'undefined'
    ) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(result === 'success' ? 'Thank you.' : 'Try again.');
      utterance.lang = 'en-US';
      utterance.rate = 0.98;
      utterance.pitch = 1;
      utterance.volume = 1;
      window.speechSynthesis.speak(utterance);
    } catch {
      // Never convert a blocked sound device into a successful attendance claim.
    }
  }

  public stop(): void {
    this.playbackGeneration++;
    if (this.activeAudio) {
      try {
        this.activeAudio.pause();
        this.activeAudio.currentTime = 0;
      } catch {
        // Audio output might have been detached by the browser or the OS.
      }
      this.activeAudio = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // No browser TTS engine available.
      }
    }
  }
}

// ============================================================================
// 7. UNIFIED KIOSK BIOMETRICS SERVICE FACADE
// ============================================================================

export interface KioskCameraState {
  active: boolean;
  error: CameraErrorInfo | null;
  stream: MediaStream | null;
}

export interface AnalyzedPreprocessedFrame {
  analysis: FrameQualityAnalysis;
  tensors: FacePreprocessingBundle | null;
}

/**
 * Unified service coordinating camera stream lifecycle, TFLite model loading from KIOSK_MODELS_DIR,
 * frontal face detection/quality checks, BUILD 20 tensor preprocessing, and attendance-only voice output.
 */
export class KioskBiometricsService {
  public readonly modelLoader: KioskTfliteModelLoader;
  public readonly frameAnalyzer: FrontalFrameAnalyzer;
  public readonly preprocessor: KioskTensorPreprocessor;
  public readonly voice: KioskVoiceController;

  private stream: MediaStream | null = null;
  private lastCameraError: CameraErrorInfo | null = null;

  constructor(options: KioskModelLoaderOptions = {}) {
    this.modelLoader = new KioskTfliteModelLoader(options);
    this.frameAnalyzer = new FrontalFrameAnalyzer();
    this.preprocessor = new KioskTensorPreprocessor();
    this.voice = new KioskVoiceController();
  }

  public getModelsDir(): string {
    return this.modelLoader.getModelsDir();
  }

  public getCameraState(): KioskCameraState {
    return {
      active: Boolean(this.stream && this.stream.getVideoTracks().some((t) => t.readyState === 'live')),
      error: this.lastCameraError,
      stream: this.stream,
    };
  }

  public async initializeCamera(
    videoElement?: HTMLVideoElement | null,
    options: CameraInitOptions = {}
  ): Promise<MediaStream> {
    this.stopCamera();
    this.lastCameraError = null;
    try {
      const stream = await startFrontCameraStream({
        ...options,
        onTrackEnded: () => {
          this.lastCameraError = {
            code: 'DISCONNECTED',
            message: 'The camera feed was disconnected. Reconnect the camera and retry.',
          };
          options.onTrackEnded?.();
        },
      });
      this.stream = stream;
      if (videoElement) {
        videoElement.srcObject = stream;
        videoElement.playsInline = true;
        videoElement.muted = true;
        await videoElement.play();
      }
      return stream;
    } catch (err) {
      this.lastCameraError = classifyCameraError(err);
      throw err;
    }
  }

  public stopCamera(videoElement?: HTMLVideoElement | null): void {
    stopMediaStream(this.stream);
    this.stream = null;
    this.frameAnalyzer.reset();
    if (videoElement) {
      videoElement.srcObject = null;
    }
  }

  public async fetchModelsStatus(): Promise<KioskModelsStatusPayload> {
    return this.modelLoader.fetchModelsStatus();
  }

  public async loadModels(inspectStatusFirst = true): Promise<Record<KioskModelKey, LoadedKioskModelRecord>> {
    return this.modelLoader.loadAllModels({ inspectStatusFirst });
  }

  public async analyzeFrame(video: HTMLVideoElement): Promise<FrameQualityAnalysis> {
    return this.frameAnalyzer.analyze(video);
  }

  public preprocessDetectedFace(
    source: HTMLVideoElement | HTMLCanvasElement,
    boundingBox: NormalizedBoundingBox | null
  ): FacePreprocessingBundle {
    return this.preprocessor.preprocessFrame(source, boundingBox);
  }

  public async analyzeAndPreprocessFrame(video: HTMLVideoElement): Promise<AnalyzedPreprocessedFrame> {
    const analysis = await this.frameAnalyzer.analyze(video);
    const frameUsable =
      !analysis.frozenFrame &&
      analysis.lightingOk &&
      analysis.sharpnessOk &&
      analysis.faceCount <= 1 &&
      video.readyState >= 2 &&
      video.videoWidth > 0 &&
      video.videoHeight > 0;

    const tensors = frameUsable ? this.preprocessor.preprocessFrame(video, analysis.boundingBox) : null;
    return { analysis, tensors };
  }

  public dispose(videoElement?: HTMLVideoElement | null): void {
    this.stopCamera(videoElement);
    this.voice.stop();
    this.modelLoader.dispose();
  }
}

// ============================================================================
// 8. FAIL-CLOSED MULTI-FRAME VERIFICATION STATE MACHINE (PROMPT 08/08)
// ============================================================================

export interface VerificationPolicyThresholds {
  requiredFrames: number;
  minInterFrameDeltaMs: number;
  maxFrameWindowMs: number;
  maxBboxDrift: number;
  padMinScore: number;
  livenessMinScore: number;
  padPerFrameFloor: number;
  livenessPerFrameFloor: number;
  maxInterFrameSpread: number;
  verificationTimeoutMs: number;
  maxConsecutiveFailures: number;
  cooldownMs: number;
}

export const DEFAULT_VERIFICATION_POLICY: VerificationPolicyThresholds = {
  requiredFrames: 3,
  minInterFrameDeltaMs: 80,
  maxFrameWindowMs: 4000,
  maxBboxDrift: 0.16,
  // Uncalibrated staging baselines — NEVER silently lowered!
  padMinScore: 0.80,
  livenessMinScore: 0.80,
  padPerFrameFloor: 0.72,
  livenessPerFrameFloor: 0.72,
  maxInterFrameSpread: 0.25,
  verificationTimeoutMs: 12_000,
  maxConsecutiveFailures: 3,
  cooldownMs: 4_000,
};

export interface VerificationFrameInput {
  /** Browser detector unavailable is UNKNOWN, not NO_FACE. */
  faceDetectionAvailable?: boolean;
  timestampMs: number;
  cameraReady: boolean;
  cameraErrorCode?: CameraErrorCode | null;
  modelsVerifiedOnDisk: boolean;
  serverInferenceAvailable: boolean;
  backendOnline: boolean;
  faceCount: number;
  centered: boolean;
  sizeOk: boolean;
  lightingOk: boolean;
  sharpnessOk: boolean;
  frozenFrame: boolean;
  occlusionSuspected?: boolean;
  boundingBox: NormalizedBoundingBox | null;
  detectionConfidence: number;
  qualityScore: number;
  /** Optional raw 3-class PAD output or decoded scalar from real TFLite interpreter */
  padRawOutput?: ArrayLike<number>;
  padScore?: number;
  /** Optional raw 3-class Liveness output or decoded scalar from real TFLite interpreter */
  livenessRawOutput?: ArrayLike<number>;
  livenessScore?: number;
}

export interface AcceptedVerificationFrame {
  timestamp_ms: number;
  face_count: number;
  detection_confidence: number;
  quality_score: number;
  lighting_ok: boolean;
  sharpness_ok: boolean;
  frozen_frame: boolean;
  occlusion_suspected: boolean;
  bounding_box: NormalizedBoundingBox | null;
  pad_score: number;
  liveness_score: number;
}

export interface VerificationStateSnapshot {
  stage: KioskVerificationStage;
  diagnosticCode: KioskDiagnosticCode;
  guidance: string;
  acceptedFrames: number;
  requiredFrames: number;
  consecutiveFailures: number;
  cooldownRemainingMs: number;
  canRunRecognition: boolean;
  indicators: {
    quality: KioskIndicatorStatus;
    pad: KioskIndicatorStatus;
    liveness: KioskIndicatorStatus;
    server: KioskIndicatorStatus;
  };
  verifiedFrames: AcceptedVerificationFrame[];
}

function medianOf(values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 1 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

/**
 * Deterministic fail-closed verification state machine:
 * WAITING_CAMERA_MODEL -> FACE_DETECTED -> QUALITY_CHECKS -> MULTI_FRAME_PAD_LIVENESS
 * -> IDENTITY_VERIFICATION -> BACKEND_VERIFICATION -> SERVER_CONFIRMED | FAILED_COOLDOWN.
 *
 * Guarantees:
 * - Never runs identity recognition before multi-frame PAD + passive liveness BOTH pass.
 * - Never averages unrelated frames (resets buffer on box jump, face-count change, freeze, or low frame).
 * - Enforces monotonic frame timestamps, explicit timeout, and bounded failure cooldown.
 * - Never exposes raw personal biometric score traces in public UI indicators.
 */
export class KioskVerificationStateMachine {
  private readonly policy: VerificationPolicyThresholds;
  private stage: KioskVerificationStage = 'WAITING_CAMERA_MODEL';
  private diagnosticCode: KioskDiagnosticCode = 'NO_FACE';
  private guidance = 'Waiting for camera and verified biometric models...';
  private acceptedWindow: AcceptedVerificationFrame[] = [];
  private attemptStartedAtMs: number | null = null;
  private consecutiveFailures = 0;
  private cooldownUntilMs = 0;

  constructor(policy: Partial<VerificationPolicyThresholds> = {}) {
    this.policy = { ...DEFAULT_VERIFICATION_POLICY, ...policy };
  }

  public startAttempt(nowMs: number = Date.now()): void {
    this.acceptedWindow = [];
    this.attemptStartedAtMs = nowMs;
    this.stage = 'WAITING_CAMERA_MODEL';
  }

  public cancel(): void {
    this.acceptedWindow = [];
    this.attemptStartedAtMs = null;
    this.stage = 'WAITING_CAMERA_MODEL';
    this.diagnosticCode = 'READY';
    this.guidance = 'Scan cancelled. Look straight at the camera when ready.';
  }

  public resetForRetry(): void {
    this.acceptedWindow = [];
    this.attemptStartedAtMs = null;
    this.consecutiveFailures = 0;
    this.cooldownUntilMs = 0;
    this.stage = 'WAITING_CAMERA_MODEL';
    this.diagnosticCode = 'READY';
    this.guidance = 'Look straight at the camera and hold still.';
  }

  public recordFailure(code: KioskDiagnosticCode, message: string, nowMs: number = Date.now()): VerificationStateSnapshot {
    this.acceptedWindow = [];
    this.attemptStartedAtMs = null;
    this.consecutiveFailures += 1;
    this.diagnosticCode = code;
    this.guidance = message;
    if (this.consecutiveFailures >= this.policy.maxConsecutiveFailures) {
      this.cooldownUntilMs = nowMs + this.policy.cooldownMs;
      this.stage = 'FAILED_COOLDOWN';
    } else {
      this.stage = 'WAITING_CAMERA_MODEL';
    }
    return this.getSnapshot(nowMs, { modelsReady: false, backendOnline: code !== 'BACKEND_UNAVAILABLE' });
  }

  public markBackendVerifying(): void {
    this.stage = 'BACKEND_VERIFICATION';
    this.guidance = 'Verifying identity with server...';
  }

  public markServerConfirmed(): void {
    this.acceptedWindow = [];
    this.attemptStartedAtMs = null;
    this.consecutiveFailures = 0;
    this.cooldownUntilMs = 0;
    this.stage = 'SERVER_CONFIRMED';
    this.diagnosticCode = 'READY';
    this.guidance = 'Attendance confirmed by server.';
  }

  public getSnapshot(
    nowMs: number = Date.now(),
    ctx: { modelsReady?: boolean; backendOnline?: boolean } = {}
  ): VerificationStateSnapshot {
    const cooldownRemainingMs = Math.max(0, this.cooldownUntilMs - nowMs);
    const modelsReady = Boolean(ctx.modelsReady);
    const backendOnline = ctx.backendOnline !== false;

    const quality: KioskIndicatorStatus =
      this.diagnosticCode === 'NO_FACE' ||
      this.diagnosticCode === 'MULTIPLE_FACES' ||
      this.diagnosticCode === 'LOW_LIGHT' ||
      this.diagnosticCode === 'BLURRY_IMAGE' ||
      this.diagnosticCode === 'OCCLUSION_OR_POSE' ||
      this.diagnosticCode === 'FROZEN_FRAME' ||
      this.diagnosticCode === 'CAMERA_BLOCKED'
        ? 'FAIL'
        : this.acceptedWindow.length > 0 || this.stage === 'IDENTITY_VERIFICATION' || this.stage === 'SERVER_CONFIRMED'
          ? 'PASS'
          : 'CHECKING';

    const pad: KioskIndicatorStatus = !modelsReady
      ? 'PENDING'
      : this.diagnosticCode === 'PAD_REJECTED' || this.diagnosticCode === 'MODEL_ERROR'
        ? 'FAIL'
        : this.stage === 'IDENTITY_VERIFICATION' || this.stage === 'BACKEND_VERIFICATION' || this.stage === 'SERVER_CONFIRMED'
          ? 'PASS'
          : 'CHECKING';

    const liveness: KioskIndicatorStatus = !modelsReady
      ? 'PENDING'
      : this.diagnosticCode === 'LIVENESS_UNVERIFIED' || this.diagnosticCode === 'MODEL_ERROR'
        ? 'FAIL'
        : this.stage === 'IDENTITY_VERIFICATION' || this.stage === 'BACKEND_VERIFICATION' || this.stage === 'SERVER_CONFIRMED'
          ? 'PASS'
          : 'CHECKING';

    const server: KioskIndicatorStatus = !backendOnline
      ? 'FAIL'
      : !modelsReady
        ? 'PENDING'
        : this.stage === 'BACKEND_VERIFICATION'
          ? 'CHECKING'
          : 'PASS';

    return {
      stage: cooldownRemainingMs > 0 ? 'FAILED_COOLDOWN' : this.stage,
      diagnosticCode: cooldownRemainingMs > 0 ? 'COOLDOWN_ACTIVE' : this.diagnosticCode,
      guidance:
        cooldownRemainingMs > 0
          ? `Please wait ${Math.ceil(cooldownRemainingMs / 1000)}s before retrying.`
          : this.guidance,
      acceptedFrames: this.acceptedWindow.length,
      requiredFrames: this.policy.requiredFrames,
      consecutiveFailures: this.consecutiveFailures,
      cooldownRemainingMs,
      canRunRecognition:
        cooldownRemainingMs === 0 &&
        this.stage === 'IDENTITY_VERIFICATION' &&
        this.acceptedWindow.length >= this.policy.requiredFrames,
      indicators: { quality, pad, liveness, server },
      verifiedFrames: [...this.acceptedWindow],
    };
  }

  public evaluateFrame(input: VerificationFrameInput): VerificationStateSnapshot {
    const nowMs = input.timestampMs;
    const modelsReady = input.modelsVerifiedOnDisk && input.serverInferenceAvailable;
    const snapCtx = { modelsReady, backendOnline: input.backendOnline };

    // 0. Cooldown gate prevents endless failure loops
    if (nowMs < this.cooldownUntilMs) {
      this.stage = 'FAILED_COOLDOWN';
      this.diagnosticCode = 'COOLDOWN_ACTIVE';
      return this.getSnapshot(nowMs, snapCtx);
    }

    // 1. Timeout check
    if (this.attemptStartedAtMs !== null && nowMs - this.attemptStartedAtMs > this.policy.verificationTimeoutMs) {
      return this.recordFailure('TIMEOUT', 'Verification timed out. Tap Try Again and look straight at the camera.', nowMs);
    }

    // 2. Camera, backend & model availability (fail-closed)
    if (!input.cameraReady || input.cameraErrorCode) {
      this.acceptedWindow = [];
      this.stage = 'WAITING_CAMERA_MODEL';
      this.diagnosticCode = 'CAMERA_BLOCKED';
      this.guidance = 'Camera is unavailable or blocked. Allow camera access and retry.';
      return this.getSnapshot(nowMs, snapCtx);
    }

    if (!input.backendOnline) {
      this.acceptedWindow = [];
      this.stage = 'WAITING_CAMERA_MODEL';
      this.diagnosticCode = 'BACKEND_UNAVAILABLE';
      this.guidance = 'Backend server is currently unreachable. Please check connection.';
      return this.getSnapshot(nowMs, snapCtx);
    }

    // 3. Frozen frame & face count checks
    if (input.frozenFrame) {
      this.acceptedWindow = [];
      this.stage = 'QUALITY_CHECKS';
      this.diagnosticCode = 'FROZEN_FRAME';
      this.guidance = 'Camera feed appears frozen. Check camera connection and retry.';
      return this.getSnapshot(nowMs, snapCtx);
    }

    if (input.faceDetectionAvailable === false) {
      // Chromium/FullPageOS may lack FaceDetector. Do not invent a detected face
      // or show FAIL without evidence; backend YuNet remains authoritative.
      this.acceptedWindow = [];
      this.stage = 'WAITING_CAMERA_MODEL';
      this.diagnosticCode = 'READY';
      this.guidance = 'Browser face detector unavailable; server will check the camera frames.';
      return this.getSnapshot(nowMs, snapCtx);
    }

    if (input.faceCount === 0) {
      this.acceptedWindow = [];
      this.stage = 'WAITING_CAMERA_MODEL';
      this.diagnosticCode = 'NO_FACE';
      this.guidance = 'Position your face inside the green frame.';
      return this.getSnapshot(nowMs, snapCtx);
    }

    if (input.faceCount > 1) {
      this.acceptedWindow = [];
      this.stage = 'QUALITY_CHECKS';
      this.diagnosticCode = 'MULTIPLE_FACES';
      this.guidance = 'Multiple faces detected — only one person at a time.';
      return this.getSnapshot(nowMs, snapCtx);
    }

    // 4. Single face detected -> strict quality checks
    this.stage = 'FACE_DETECTED';
    if (!input.lightingOk) {
      this.acceptedWindow = [];
      this.stage = 'QUALITY_CHECKS';
      this.diagnosticCode = 'LOW_LIGHT';
      this.guidance = 'Adjust lighting so your face is evenly illuminated.';
      return this.getSnapshot(nowMs, snapCtx);
    }
    if (!input.sharpnessOk) {
      this.acceptedWindow = [];
      this.stage = 'QUALITY_CHECKS';
      this.diagnosticCode = 'BLURRY_IMAGE';
      this.guidance = 'Image is blurry. Hold still while looking at the camera.';
      return this.getSnapshot(nowMs, snapCtx);
    }
    if (input.occlusionSuspected || !input.centered || !input.sizeOk) {
      this.acceptedWindow = [];
      this.stage = 'QUALITY_CHECKS';
      this.diagnosticCode = 'OCCLUSION_OR_POSE';
      this.guidance = 'Center your uncovered front face inside the green frame.';
      return this.getSnapshot(nowMs, snapCtx);
    }

    // 5. Monotonic timestamp & bounding-box stability against previous accepted frame
    const prev = this.acceptedWindow[this.acceptedWindow.length - 1];
    if (prev) {
      if (nowMs <= prev.timestamp_ms || nowMs - prev.timestamp_ms < this.policy.minInterFrameDeltaMs) {
        return this.getSnapshot(nowMs, snapCtx);
      }
      if (nowMs - this.acceptedWindow[0].timestamp_ms > this.policy.maxFrameWindowMs) {
        this.acceptedWindow = [];
      } else if (input.boundingBox && prev.bounding_box) {
        const cx = input.boundingBox.x + input.boundingBox.width / 2;
        const cy = input.boundingBox.y + input.boundingBox.height / 2;
        const pcx = prev.bounding_box.x + prev.bounding_box.width / 2;
        const pcy = prev.bounding_box.y + prev.bounding_box.height / 2;
        const drift = Math.max(
          Math.abs(cx - pcx),
          Math.abs(cy - pcy),
          Math.abs(input.boundingBox.width - prev.bounding_box.width)
        );
        if (drift > this.policy.maxBboxDrift) {
          this.acceptedWindow = [];
          this.stage = 'QUALITY_CHECKS';
          this.diagnosticCode = 'OCCLUSION_OR_POSE';
          this.guidance = 'Face moved abruptly. Hold still inside the green frame.';
          return this.getSnapshot(nowMs, snapCtx);
        }
      }
    }

    // 6. Real model availability check (fail-closed if TFLite models or server attestation are absent)
    if (!modelsReady) {
      this.acceptedWindow = [];
      this.stage = 'MULTI_FRAME_PAD_LIVENESS';
      this.diagnosticCode = 'MODEL_ERROR';
      this.guidance = input.modelsVerifiedOnDisk
        ? '3/3 AI models verified, but trusted server-side biometric verification is not active. Attendance is blocked.'
        : 'Required biometric model files are missing or invalid. Attendance is blocked.';
      return this.getSnapshot(nowMs, snapCtx);
    }

    // 7. Decode & validate PAD (live_class=0) and Passive Liveness (live_class=1) independently
    this.stage = 'MULTI_FRAME_PAD_LIVENESS';
    const padScore = this.resolveClassifierScore(input.padRawOutput, input.padScore, 0);
    if (padScore === null) {
      this.acceptedWindow = [];
      this.diagnosticCode = 'MODEL_ERROR';
      this.guidance = 'Anti-spoofing model returned invalid output.';
      return this.getSnapshot(nowMs, snapCtx);
    }

    const livenessScore = this.resolveClassifierScore(input.livenessRawOutput, input.livenessScore, 1);
    if (livenessScore === null) {
      this.acceptedWindow = [];
      this.diagnosticCode = 'MODEL_ERROR';
      this.guidance = 'Passive liveness model returned invalid output.';
      return this.getSnapshot(nowMs, snapCtx);
    }

    if (padScore < this.policy.padPerFrameFloor) {
      return this.recordFailure(
        'PAD_REJECTED',
        'Anti-spoofing check failed. Photos and screens are not accepted.',
        nowMs
      );
    }
    if (livenessScore < this.policy.livenessPerFrameFloor) {
      return this.recordFailure(
        'LIVENESS_UNVERIFIED',
        'Liveness could not be verified. Look directly at the camera with even lighting.',
        nowMs
      );
    }

    this.acceptedWindow.push({
      timestamp_ms: nowMs,
      face_count: input.faceCount,
      detection_confidence: input.detectionConfidence,
      quality_score: input.qualityScore,
      lighting_ok: input.lightingOk,
      sharpness_ok: input.sharpnessOk,
      frozen_frame: input.frozenFrame,
      occlusion_suspected: Boolean(input.occlusionSuspected),
      bounding_box: input.boundingBox,
      pad_score: padScore,
      liveness_score: livenessScore,
    });

    if (this.acceptedWindow.length < this.policy.requiredFrames) {
      this.diagnosticCode = 'READY';
      this.guidance = `Verifying live presence (${this.acceptedWindow.length}/${this.policy.requiredFrames})... Hold still.`;
      return this.getSnapshot(nowMs, snapCtx);
    }

    // 8. Final multi-frame anti-averaging check (median + spread) BEFORE allowing identity recognition
    const padArr = this.acceptedWindow.map((f) => f.pad_score);
    const livArr = this.acceptedWindow.map((f) => f.liveness_score);

    if (
      medianOf(padArr) < this.policy.padMinScore ||
      Math.max(...padArr) - Math.min(...padArr) > this.policy.maxInterFrameSpread
    ) {
      return this.recordFailure(
        'PAD_REJECTED',
        'Anti-spoofing check failed across frames. Please try again with a live frontal face.',
        nowMs
      );
    }

    if (
      medianOf(livArr) < this.policy.livenessMinScore ||
      Math.max(...livArr) - Math.min(...livArr) > this.policy.maxInterFrameSpread
    ) {
      return this.recordFailure(
        'LIVENESS_UNVERIFIED',
        'Passive liveness verification did not pass across frames. Look straight at the camera.',
        nowMs
      );
    }

    // PAD and Passive Liveness BOTH passed across fresh monotonic frames -> unlock identity recognition stage!
    this.stage = 'IDENTITY_VERIFICATION';
    this.diagnosticCode = 'READY';
    this.guidance = 'Live presence verified. Matching identity...';
    return this.getSnapshot(nowMs, snapCtx);
  }

  private resolveClassifierScore(
    rawOutput: ArrayLike<number> | undefined,
    scalar: number | undefined,
    liveClassIndex: number
  ): number | null {
    if (rawOutput && rawOutput.length > 0) {
      const decoded = decodeClassifierLiveScore(rawOutput, liveClassIndex);
      return decoded.valid ? decoded.liveProbability : null;
    }
    if (typeof scalar === 'number' && Number.isFinite(scalar) && scalar >= 0 && scalar <= 1) {
      return scalar;
    }
    return null;
  }
}
