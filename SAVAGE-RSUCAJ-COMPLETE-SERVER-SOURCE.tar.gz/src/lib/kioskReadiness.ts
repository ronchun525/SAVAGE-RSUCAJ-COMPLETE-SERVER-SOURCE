/** BUILD 41: Model files and production attestation are distinct readiness gates. */
export interface KioskReadinessInput {
  all_models_verified_on_disk: boolean;
  server_inference_available: boolean;
  production_attendance_ready: boolean;
  models: Record<string, { status: string }>;
}

export interface KioskReadinessNotice {
  kind: 'models_missing' | 'attestation_inactive' | 'not_certified';
  title: string;
  detail: string;
}

export function getKioskReadinessNotice(models: KioskReadinessInput, productionBlocked: boolean): KioskReadinessNotice | null {
  const count = Object.values(models.models).filter(model => model.status === 'VERIFIED_ON_DISK').length;
  if (!models.all_models_verified_on_disk || count !== 3) {
    return {
      kind: 'models_missing',
      title: `AI models verified: ${count}/3.`,
      detail: 'One or more model files are missing or invalid. Official face verification remains disabled.',
    };
  }
  if (!models.server_inference_available) {
    return {
      kind: 'attestation_inactive',
      title: 'All 3 biometric AI models are installed and verified.',
      detail: 'Trusted server-side face attestation is not integrated yet. Enrollment and official attendance remain disabled.',
    };
  }
  if (productionBlocked || !models.production_attendance_ready) {
    return {
      kind: 'not_certified',
      title: 'Biometric inference is available, but official attendance is not approved.',
      detail: 'Server attestation, real-camera tests and calibrated liveness/recognition thresholds must be validated.',
    };
  }
  return null;
}
