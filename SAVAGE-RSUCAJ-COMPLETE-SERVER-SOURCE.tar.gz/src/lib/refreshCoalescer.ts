/** Prevents overlapping attendance fetches and collapses event bursts into one trailing resync. */
export function createRefreshCoalescer(action: () => Promise<void>): () => Promise<void> {
  let active: Promise<void> | null = null;
  let pending = false;
  return () => {
    if (active) {
      pending = true;
      return active;
    }
    active = (async () => {
      do {
        pending = false;
        await action();
      } while (pending);
    })().finally(() => { active = null; });
    return active;
  };
}
