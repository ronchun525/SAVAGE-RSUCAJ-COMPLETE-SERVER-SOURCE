# SAVAGE-RSUCAJ BUILD 39 — Admin Login Cleanup (2026-11-23)

## Overview
BUILD 39 is an incremental UI-only update based on the latest available BUILD 38 full source. The Admin Login page now uses the **existing original transparent SAVAGE-RSUCAJ shield PNG** and no longer shows Google Sign-In, the Employee Portal button, or the “or” separator.

## Architecture
No authentication endpoint, data model, session, cookie, database, or reverse-proxy configuration was changed. The `/employee` route still exists in `src/App.tsx`. Google SSO server endpoints are **not removed** by this UI-only update.

## UI / UX
- Logo: `/assets/aistudio/Savage-Rsucaj_Attendance_Shield_bca5b40c.png` (the bundled original, already RGBA with transparent corners). Original branding, lettering, and internal design preserved.
- The shared `SavageLogo` component no longer wraps the sidebar logo in a white rectangle or uses a multiply blend mode.
- Admin Login: removed Google button, Employee Portal button, and “or” divider. Preserved local login, remember-me, password show/hide, form errors, and password-recovery modal.
- Employee Portal: remains independently reachable at `/employee`.

## Implementation: exact paths
- `src/components/LoginView.tsx` — remove Admin Login's Google SSO and employee navigation UI; retain auth config's SMTP field for password recovery and retain the optional callback in the props for compatibility with older App.tsx callers.
- `src/components/SavageLogo.tsx` — reference the original transparent PNG and remove the white-background wrapper and blend mode.
- `public/assets/aistudio/Savage-Rsucaj_Attendance_Shield_bca5b40c.png` — bundled original; unchanged, included with patch for standalone deployment.
- `tests/build39-admin-login.test.mjs` — regression tests.
- `deployment/hostinger-vps/build39-admin-login-deploy.sh` — backup / deploy / validate / automatic rollback helper for existing VPS.

## Error analysis
The old emblem was an RGB image containing an opaque near-white background. `mix-blend-multiply` could hide some white pixels visually but did not make the asset transparent. The dark sidebar also added a white background wrapper. This build selects the original transparent RGBA logo already bundled in the project instead of artificially removing colors from the white-background emblem.

## Actual testing in local container
- `node --test tests/build39-admin-login.test.mjs`: **5 passed, 0 failed**.
- TypeScript `transpileModule` syntactic checks for `LoginView.tsx`, `SavageLogo.tsx`, `App.tsx`: **3 passed**.
- Pillow inspection of original transparent asset: **RGBA (1214 × 1295), alpha range 0–255; corner alpha 0**, passed.
- Full `npm run lint`, `npm run build`, and browser integration checks: **not executed locally** because project dependencies are not installed in this environment.
- Hostinger / FullPageOS deployment: **not performed or verified**; must validate during staged deployment.

## Deployment
Use the small BUILD39 patch on top of the existing SAVAGE-RSUCAJ source. It changes only two TSX components and includes the original transparent PNG. Run `deployment/hostinger-vps/build39-admin-login-deploy.sh` as root on the VPS after uploading the patch. It backs up the originals and `dist`, runs tests/lint/build, restarts the service, and restores on failures. See the downloadable BUILD39 deployment guide.

## Final report
Completed: Admin Login button cleanup, transparent original logo display across admin views, regression tests, preservation of `/employee` route. Remaining: Full production build, deployment confirmation, actual browser screenshot/visual QA, and real kiosk hardware tests. Biometric attendance remains subject to the independent inference readiness blocker; this update does not modify biometric security.
