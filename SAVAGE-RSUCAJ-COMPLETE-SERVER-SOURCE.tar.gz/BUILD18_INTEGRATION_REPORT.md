# SAVAGE-RSUCAJ — BUILD 18 Android ↔ Admin Portal Integration

**Status: SOURCE INTEGRATION IMPLEMENTED, NOT VERIFIED END-TO-END, NOT PRODUCTION-READY**

## 1. Overview

This build continues the two uploaded source packages without recreating their UIs or replacing the attendance engine. Its aim is an Android-to-admin API adapter, encrypted template submission, and real device provisioning. Existing work in payroll, HR, schedules, role-based access, audit logs, attendance records and Android kiosk screens has been retained. Neither original ZIP was proof of actual production connectivity; this build also requires deployment, provisioned credentials and real-device acceptance testing.

## 2. Architecture

- Admin web portal: Express / TypeScript; React frontend; SQLite, `server/attendanceEngine.ts` canonical attendance engine.
- Android kiosk: Jetpack Compose; Retrofit/Moshi; CameraX and local TensorFlow Lite pipeline; SQLite offline queue.
- New adapter (`/api/v1/kiosk/*`): uses **the existing** `processKioskPunch` and stores results in existing attendance records and immutable events. Does not create a separate attendance table.
- Device authentication: provisioned bearer token linked to existing Admin > Devices device, numeric ID resolved by authenticated `/api/v1/kiosk/device-info`; device-name equality enforced.
- Transport integrity: Android sends a canonical SHA-256 digest and HMAC-SHA256 biometric metadata binding; the backend verifies event action, employee ID, device, timestamp and HMAC, and rejects unsigned/malformed requests.
- Enrollment: templates validated against canonical employee masterlist, Float32LE vector hash checked, AES-256-GCM encrypted with server-provisioned `KIOSK_TEMPLATE_ENCRYPTION_KEY`, stored in new table `kiosk_face_templates` (migration 010). The ciphertext and digest are never exposed by the directory endpoint.
- Attendance acknowledgements: backend response maps to Android RECORDED / ALREADY_TAKEN / REJECTED semantics. Duplicate action is accepted as ALREADY_TAKEN only if the backend's duplicate code matches the exact action. SSE broadcast is server-managed (no fabricated client delivery).

## 3. UI/UX Design

Kept the existing kiosk and admin portal screens. Added editable HTTPS origin, masked token input, provisioning button, token-provisioned indicator and PIN safety warning inside the **existing** Android Device Settings screen. Did not recreate the logo or replace the original colors or navigation. Pixel-perfect comparison with a separately uploaded approved design image was not performed.

## 4. Implementation — exact changed files

### Admin portal

- `server/androidBridge.ts` — token-authenticated Android API routes: device-info; employees; enroll-template; attendance; realtime event acknowledgement.
- `server/androidBridgeProtocol.ts` — independent canonical digest, Float32LE template hash and HMAC helpers.
- `server/api.ts` — mounts bridge BEFORE cookie/CSRF portal middleware using active database and existing real-time hub.
- `server/db.ts` — schema migration 010 for encrypted templates, includes it in canonical table catalog.
- `.env.example` — adds encryption-key variable; NO actual secret included.
- `tests/android-bridge-contract.test.mjs` — four standalone source/API protocol checks.
- `package.json` — `npm run test:bridge` script.

### Android

- `app/src/main/java/com/example/kiosk/data/AttendanceApiService.kt` — device-info handshake, HMAC envelope and integration mapping; safe Moshi reflective DTO adaptation; live-configurable adapter.
- `app/src/main/java/com/example/kiosk/platform/KioskCredentialVault.kt` — encrypts API token at rest with nonexportable AndroidKeystore AES-GCM key; no plaintext preference.
- `app/src/main/java/com/example/kiosk/platform/KioskSettingsStore.kt` — token provisioning with masked state; retain URL storage and existing PIN verification.
- `app/src/main/java/com/example/kiosk/ui/screens/DeviceSettingsAndStatusScreens.kt` — admin-only server URL/token provisioning controls.
- `app/src/main/java/com/example/kiosk/navigation/KioskNavGraph.kt` — wires working callbacks into state store.
- `app/src/main/java/com/example/MainActivity.kt` — uses configurable attendance repository so changes apply without reopening app.

## 5. Error Analysis / Corrective Actions

1. **API path mismatch**: Android originally targeted `/api/v1/kiosk/*` but admin only offered `/api/kiosk/*`. New bridge uses the Android paths without changing legacy kiosk APIs.
2. **Auth mismatch**: Android had no provisioned token in `MainActivity`; Admin expects registered kiosk secrets. App now provisions a token securely through the admin-gated settings UI and performs authenticated device-info check.
3. **Payload and response mismatch**: Canonical digest and biometric evidence envelope are now included; responses are adapted from server attendance engine to Android status DTOs.
4. **Enrollment integration missing**: New credential-authenticated directory and encrypted enrollment endpoint; server validates employee identity and Kotlin-compatible vector SHA-256.
5. **Configuration stale after edit**: Stable `ConfigurableAttendanceRepository` rebuilds its Retrofit delegate on settings change.
6. **Default setup PIN risk**: The existing PIN is still present for first-time setup. Live attendance is now **blocked until the PIN is changed**. PIN-based enrollment permission is still a separate operational security review item.
7. **Missing Android AI models**: No model binaries were added or fabricated. Liveness/recognition **cannot** be production-certified without compatible, licensed and device-tested TFLite models.
8. **Offline trust limitation**: Proof is currently signed at upload from stored values. Tamper-proof capture-time signatures and server-verifiable AI attestations are not provided; offline/replay physical attack testing is still required.

## 6. Testing — actual results only

| Test | Actual result |
|---|---|
| `node --experimental-strip-types --test tests/android-bridge-contract.test.mjs` | PASS 4/4: digest, binary hash, HMAC binding, API path matching |
| TypeScript source parser (`typescript.transpileModule`, four changed/new server TS files) | PASS 4/4 syntax checks (NOT semantic typecheck) |
| SQLite migration 010 standalone `CREATE TABLE` + FK and test INSERT | PASS, in-memory Python SQLite smoke test (NOT full server migration) |
| `npm install --ignore-scripts --prefer-offline` | BLOCKED: dependency fetching timed out, no installed dependencies or npm lockfile |
| Full `npm test`, `npm run lint`, `npm run build`, Express HTTP integration | NOT RUN: dependencies unavailable |
| Android Gradle build / unit tests / instrumentation | NOT RUN: Android SDK and Gradle wrapper JAR/executable unavailable |
| Real face enrollment / recognition / anti-spoofing / offline sync | NOT TESTED on Android hardware |
| End-to-end Android -> deployed admin backend | NOT TESTED; no live endpoint or actual kiosk token supplied |
| Full production security / payroll / release signoffs | NOT TESTED; previous release gates remain blocked |

Old `BUILD_REPORT.md` / `TEST_RESULTS.md` files in the admin directory are historical and **do not** certify BUILD 18.

## 7. Deployment — required operator setup

### Backend

1. Deploy Admin Portal on a Node.js-capable HTTPS host with persistent writable SQLite volume. Shared PHP-only hosting cannot run the Express server by itself. Backup the live DB safely before upgrading schema.
2. Set `.env` from `.env.example`, including production `NODE_ENV=production`, `APP_MODE=production`, strong `SESSION_SECRET`, explicit admin bootstrap secrets for a fresh database, production `DATABASE_PATH`, allowed CORS origins, and `KIOSK_TEMPLATE_ENCRYPTION_KEY` (generate securely with `openssl rand -hex 32`, never commit or include in ZIP).
3. Install npm dependencies (`npm install` / commit a verified generated lockfile), run `npm run db:migrate`, `npm run lint`, `npm run build`, `npm test`, `npm run release:gate`, and start with `npm start` only after successful checks.
4. Log into Admin > Devices; register an Android device, issue/copy its real token and note its **exact device name**. Do not paste tokens into source or public links. Rotate token if exposed.

### Android kiosk

1. Open `finalngfacerecogantion-main` in Android Studio with correct Gradle/AGP, Android SDK and JDK. Restore missing Gradle wrapper files using an official Gradle toolchain if needed, then build and run the app; this package does NOT contain a compiled APK.
2. Provide the three real compatible model assets under the expected app assets path (see TFLite source); verify model input/output compatibility and real liveness anti-spoof behavior.
3. Go to admin-gated Device Settings; **change the default setup PIN**, enter a kiosk terminal name matching Admin > Devices, set HTTPS origin URL (for example `https://your-backend.example`, NOT `/api` path), paste token into masked credential field and tap provision.
4. Confirm `/api/v1/kiosk/device-info` authenticates, employee list loads, three-angle enrollment uploads encrypted template, and live time-in/time-out is written exactly once and appears in admin attendance UI.
5. Validate clock drift, offline queue replay and reboots, duplicate punches, server rejection, token rotation/revocation, liveness adversarial samples, camera permissions, app updates and lost connectivity. Retain separate physical-hardware signoffs.

### Basic HTTP acceptance checks (not executed)

- `GET /api/health` -> database healthy.
- `GET /api/v1/kiosk/device-info` without token -> 401.
- With registered Bearer token and exact `X-Kiosk-Device-Id` -> registered numeric ID.
- `GET /api/v1/kiosk/employees` -> active employees from masterlist.
- `POST /api/v1/kiosk/attendance` -> missing/invalid HMAC rejected; real authenticated kiosk capture -> attendance engine decision.

## 8. Final Report

**Completed in source:** adapter endpoints, auth and integrity binding, encrypted enrollment metadata, duplicate status mapping, admin device provisioning UI, reactive repository, migration 010, protocol tests. Existing portal and Android UI preserved except required setting controls.

**Remaining blockers:** complete dependency installation, lockfile, Gradle wrapper and Android SDK build, real compatible face/PAD/liveness models, live deployment, offline capture-time attestation, full security hardening, real-camera E2E verification, acceptance signoffs, and the original admin portal production release gates. Source agreement is not the same as deployed connectivity.

**Release decision: NO-GO for production.** This is the next integration-stage source build, not an APK/AAB nor a certified production release.
