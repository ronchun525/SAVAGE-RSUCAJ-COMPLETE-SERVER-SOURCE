import crypto from 'node:crypto';
import type Database from 'better-sqlite3';
import type { Request, Response, NextFunction } from 'express';
import type { PermissionCode, RoleName } from './rbac.ts';
import { isPlaceholderValue } from './env.ts';
import { getClientIp, isRequestOriginAllowed } from './security.ts';

export const SESSION_COOKIE_NAME = 'savage_rsucaj_session';
export const CSRF_COOKIE_NAME = 'savage_rsucaj_csrf';

const SESSION_TTL_MS = 1000 * 60 * 60 * 12; // 12 hours
const REMEMBER_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 days (reduced from 14 for tighter security)

export class MissingSessionSecretError extends Error {
  constructor(message = 'SESSION_SECRET is missing or insecure. Configure a 32+ character secret.') {
    super(message);
    this.name = 'MissingSessionSecretError';
  }
}

export function getActiveSessionSecrets(): { primary: string; previous: string | null } {
  const primary = process.env.SESSION_SECRET?.trim() ?? '';
  if (!primary || primary.length < 32 || isPlaceholderValue(primary)) {
    throw new MissingSessionSecretError();
  }
  const prev = process.env.SESSION_SECRET_PREVIOUS?.trim() ?? '';
  const previous =
    prev && prev.length >= 32 && !isPlaceholderValue(prev) && prev !== primary ? prev : null;
  return { primary, previous };
}

export interface SessionUser {
  id: number;
  username: string;
  email: string;
  full_name: string;
  role: RoleName;
  department_id: number | null;
  employee_id: number | null;
  must_change_password: boolean;
  permissions: PermissionCode[];
}

export interface ActiveSession {
  sid: string;
  userId: number;
  csrfToken: string;
  expiresAt: number;
  verifiedWithPreviousSecret: boolean;
}

export interface AuthenticatedRequest extends Request {
  user?: SessionUser;
  session?: ActiveSession;
}

export function hashPassword(password: string, existingSalt?: string): { hash: string; salt: string } {
  const salt = existingSalt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { hash, salt };
}

export function verifyPassword(password: string, storedHash: string, storedSalt: string): boolean {
  const { hash } = hashPassword(password, storedSalt);
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(storedHash, 'hex');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

function signSessionId(sid: string, secret: string): string {
  const sig = crypto.createHmac('sha256', secret).update(sid).digest('base64url');
  return `${sid}.${sig}`;
}

export function verifySignedSessionCookie(
  cookieValue: string | undefined
): { sid: string; verifiedWithPreviousSecret: boolean } | null {
  if (!cookieValue || !cookieValue.includes('.')) return null;
  const parts = cookieValue.split('.');
  if (parts.length !== 2) return null;
  const [sid, signature] = parts;
  if (!sid || !signature || !/^[a-f0-9]{64}$/i.test(sid)) return null;

  const { primary, previous } = getActiveSessionSecrets();

  const matchesSecret = (secret: string): boolean => {
    const expected = crypto.createHmac('sha256', secret).update(sid).digest('base64url');
    const a = Buffer.from(signature);
    const b = Buffer.from(expected);
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  };

  if (matchesSecret(primary)) {
    return { sid, verifiedWithPreviousSecret: false };
  }
  if (previous && matchesSecret(previous)) {
    return { sid, verifiedWithPreviousSecret: true };
  }
  return null;
}

export function createUserSession(
  db: Database.Database,
  userId: number,
  options: { rememberMe?: boolean; ipAddress?: string; userAgent?: string; ttlMs?: number } = {}
): { signedCookieValue: string; sid: string; csrfToken: string; expiresAt: number } {
  const { primary } = getActiveSessionSecrets();
  const sid = crypto.randomBytes(32).toString('hex');
  const csrfToken = crypto.randomBytes(32).toString('hex');
  const ttlMs = options.ttlMs ?? (options.rememberMe ? REMEMBER_TTL_MS : SESSION_TTL_MS);
  const expiresAt = Date.now() + ttlMs;

  db.prepare(
    `INSERT INTO user_sessions (sid, user_id, csrf_token, expires_at, ip_address, user_agent)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(sid, userId, csrfToken, expiresAt, options.ipAddress || '', (options.userAgent || '').slice(0, 255));

  return {
    signedCookieValue: signSessionId(sid, primary),
    sid,
    csrfToken,
    expiresAt,
  };
}

export function revokeSessionById(db: Database.Database, sid: string, reason = 'logout'): void {
  db.prepare(
    `UPDATE user_sessions
     SET revoked_at = datetime('now', 'localtime'), revoked_reason = ?
     WHERE sid = ? AND revoked_at IS NULL`
  ).run(reason, sid);
}

export function revokeAllUserSessions(db: Database.Database, userId: number, reason = 'password_changed'): void {
  db.prepare(
    `UPDATE user_sessions
     SET revoked_at = datetime('now', 'localtime'), revoked_reason = ?
     WHERE user_id = ? AND revoked_at IS NULL`
  ).run(reason, userId);
}

export function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  const result: Record<string, string> = {};
  if (!cookieHeader) return result;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx > 0) {
      const key = part.slice(0, idx).trim();
      const val = part.slice(idx + 1).trim();
      try {
        result[key] = decodeURIComponent(val);
      } catch {
        result[key] = val;
      }
    }
  }
  return result;
}

function isHttpsRequest(req?: Request): boolean {
  if (!req) return false;
  if (req.secure) return true;
  const trustProxy = (process.env.TRUST_PROXY || '').trim().toLowerCase() === 'true';
  if (trustProxy || process.env.NODE_ENV === 'production') {
    const forwarded = req.headers['x-forwarded-proto'];
    const proto = Array.isArray(forwarded) ? forwarded[0] : forwarded;
    if (proto && proto.split(',')[0].trim().toLowerCase() === 'https') {
      return true;
    }
  }
  // Always honor x-forwarded-proto=https when behind cloud preview HTTPS proxies
  const forwarded = req.headers['x-forwarded-proto'];
  const proto = Array.isArray(forwarded) ? forwarded[0] : forwarded;
  return Boolean(proto && proto.split(',')[0].trim().toLowerCase() === 'https');
}

function buildCookieAttributes(req: Request | undefined, maxAgeSec: number, httpOnly: boolean): string[] {
  const secure = isHttpsRequest(req);
  const domain = process.env.COOKIE_DOMAIN?.trim();
  const attrs = [
    'Path=/',
    ...(domain ? [`Domain=${domain}`] : []),
    ...(httpOnly ? ['HttpOnly'] : []),
    secure ? 'SameSite=None' : 'SameSite=Lax',
    ...(secure ? ['Secure', 'Partitioned'] : []),
    `Max-Age=${maxAgeSec}`,
  ];
  return attrs;
}

export function setAuthCookies(
  res: Response,
  signedSessionValue: string,
  csrfToken: string,
  expiresAt: number,
  req?: Request
): void {
  const maxAgeSec = Math.max(1, Math.floor((expiresAt - Date.now()) / 1000));
  const sessionCookie = [
    `${SESSION_COOKIE_NAME}=${encodeURIComponent(signedSessionValue)}`,
    ...buildCookieAttributes(req, maxAgeSec, true),
  ].join('; ');
  const csrfCookie = [
    `${CSRF_COOKIE_NAME}=${encodeURIComponent(csrfToken)}`,
    ...buildCookieAttributes(req, maxAgeSec, false),
  ].join('; ');
  res.setHeader('Set-Cookie', [sessionCookie, csrfCookie]);
}

export function clearAuthCookies(res: Response, req?: Request): void {
  const sessionCookie = [`${SESSION_COOKIE_NAME}=`, ...buildCookieAttributes(req, 0, true)].join('; ');
  const csrfCookie = [`${CSRF_COOKIE_NAME}=`, ...buildCookieAttributes(req, 0, false)].join('; ');
  res.setHeader('Set-Cookie', [sessionCookie, csrfCookie]);
}

export function getRolePermissions(db: Database.Database, role: string): PermissionCode[] {
  const rows = db
    .prepare('SELECT permission_code FROM role_permissions WHERE role_name = ? ORDER BY permission_code ASC')
    .all(role) as Array<{ permission_code: PermissionCode }>;
  return rows.map((r) => r.permission_code);
}

export function loadActiveSessionFromRequest(
  db: Database.Database,
  req: Request
): { user: SessionUser; session: ActiveSession } | null {
  const cookies = parseCookies(req.headers.cookie);
  const rawSession = cookies[SESSION_COOKIE_NAME];
  const verified = verifySignedSessionCookie(rawSession);
  if (!verified) return null;

  const row = db
    .prepare(
      `SELECT s.sid, s.user_id, s.csrf_token, s.expires_at, s.revoked_at,
              u.id, u.username, u.email, u.full_name, u.role, u.department_id, u.employee_id,
              u.must_change_password, u.is_active
       FROM user_sessions s
       JOIN users u ON s.user_id = u.id
       WHERE s.sid = ?`
    )
    .get(verified.sid) as
    | {
        sid: string;
        user_id: number;
        csrf_token: string;
        expires_at: number;
        revoked_at: string | null;
        id: number;
        username: string;
        email: string;
        full_name: string;
        role: RoleName;
        department_id: number | null;
        employee_id: number | null;
        must_change_password: number;
        is_active: number;
      }
    | undefined;

  if (!row || row.revoked_at !== null || row.is_active !== 1 || row.expires_at <= Date.now()) {
    return null;
  }

  const permissions = getRolePermissions(db, row.role);

  return {
    user: {
      id: row.id,
      username: row.username,
      email: row.email,
      full_name: row.full_name,
      role: row.role,
      department_id: row.department_id ?? null,
      employee_id: row.employee_id ?? null,
      must_change_password: Boolean(row.must_change_password),
      permissions,
    },
    session: {
      sid: row.sid,
      userId: row.user_id,
      csrfToken: row.csrf_token,
      expiresAt: row.expires_at,
      verifiedWithPreviousSecret: verified.verifiedWithPreviousSecret,
    },
  };
}

export function createRequireAuth(dbOrGetter: Database.Database | (() => Database.Database)) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    const db = typeof dbOrGetter === 'function' ? dbOrGetter() : dbOrGetter;
    const active = loadActiveSessionFromRequest(db, req);
    if (!active) {
      res.status(401).json({ error: 'Authentication required. Please sign in.' });
      return;
    }

    // Seamless cookie re-signing during SESSION_SECRET_PREVIOUS rotation window
    if (active.session.verifiedWithPreviousSecret) {
      const { primary } = getActiveSessionSecrets();
      setAuthCookies(
        res,
        signSessionId(active.session.sid, primary),
        active.session.csrfToken,
        active.session.expiresAt,
        req
      );
    }

    req.user = active.user;
    req.session = active.session;
    next();
  };
}

const SAFE_HTTP_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

export function requireCsrf(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (SAFE_HTTP_METHODS.has(req.method.toUpperCase())) {
    next();
    return;
  }

  if (!isRequestOriginAllowed(req)) {
    res.status(403).json({
      error: 'Cross-origin request blocked by CSRF origin policy.',
      code: 'ORIGIN_DENIED',
    });
    return;
  }

  if (!req.session) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }

  const headerToken = typeof req.headers['x-csrf-token'] === 'string' ? req.headers['x-csrf-token'].trim() : '';
  if (!headerToken) {
    res.status(403).json({
      error: 'Missing CSRF token header (X-CSRF-Token).',
      code: 'CSRF_INVALID',
    });
    return;
  }

  const a = Buffer.from(headerToken);
  const b = Buffer.from(req.session.csrfToken);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    res.status(403).json({
      error: 'Invalid CSRF token.',
      code: 'CSRF_INVALID',
    });
    return;
  }

  next();
}

export function requirePasswordChanged(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.user?.must_change_password) {
    next();
    return;
  }
  const allowedPaths = new Set(['/auth/me', '/auth/csrf', '/auth/logout', '/auth/change-password']);
  if (allowedPaths.has(req.path)) {
    next();
    return;
  }
  res.status(403).json({
    error: 'Initial password change is required before accessing portal resources.',
    code: 'PASSWORD_CHANGE_REQUIRED',
  });
}

export function requirePermission(...required: PermissionCode[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const granted = new Set(req.user.permissions);
    const hasAny = required.some((perm) => granted.has(perm));
    if (!hasAny) {
      res.status(403).json({
        error: `Access denied for role "${req.user.role}". Required permission: ${required.join(' or ')}.`,
        code: 'FORBIDDEN',
      });
      return;
    }
    next();
  };
}

export function constantTimeEqualString(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

export function getAuthIp(req: Request): string {
  return getClientIp(req);
}
