import crypto from 'node:crypto';
import type Database from 'better-sqlite3';
import {
  addDaysIso,
  computeShiftWindow,
  getManilaDayCodeForIsoDate,
  parseManilaWallClockToUtcMs,
  toManilaParts,
  type AttendanceStatus,
  type ShiftDefinition,
} from './attendanceEngine.ts';
import { logAudit } from './auditHelpers.ts';

export type CorrectionRequestType = 'Time In' | 'Time Out' | 'Full Day';
export type LeaveDayPortion = 'FULL' | 'HALF_AM' | 'HALF_PM';

export interface ActorContext {
  userId: number;
  username: string;
  role: string;
  ipAddress: string;
}

export interface EngineOutcome {
  statusCode: number;
  body: Record<string, unknown>;
  realtimeAttendanceEvents?: Array<{
    employee_id: number;
    employee_code: string;
    department_id: number;
    shift_date: string;
    action: string;
    status?: string;
    time?: string | null;
    source: string;
  }>;
}

export interface LeavePolicyRow {
  id: number;
  leave_type: string;
  code: string;
  annual_entitlement: number;
  track_balance: number;
  allow_half_day: number;
  exclude_weekends_rest_days: number;
  exclude_holidays: number;
  allow_negative_balance: number;
  requires_document_after_days: number;
  attendance_status: 'On Leave' | 'OB';
  is_paid: number;
  is_active: number;
  updated_by: string;
  updated_at: string;
}

export interface ExcludedLeaveDay {
  date: string;
  reason: 'WEEKEND' | 'REST_DAY' | 'HOLIDAY';
  detail: string;
}

export interface EligibleLeaveDay {
  date: string;
  year: number;
  fraction: number;
  portion: LeaveDayPortion;
  has_valid_punch: boolean;
  existing_time_in: string | null;
  existing_time_out: string | null;
  existing_status: string | null;
}

export interface LeaveEvaluationResult {
  policy: LeavePolicyRow;
  start_date: string;
  end_date: string;
  day_portion: LeaveDayPortion;
  calendar_days: number;
  eligible_days: EligibleLeaveDay[];
  excluded_days: ExcludedLeaveDay[];
  total_eligible_credits: number;
  credits_by_year: Record<string, number>;
  conflicting_punch_dates: Array<{
    date: string;
    time_in: string | null;
    time_out: string | null;
    status: string | null;
  }>;
  overlapping_leaves: Array<{
    id: number;
    leave_type: string;
    start_date: string;
    end_date: string;
    day_portion: string;
    status: string;
  }>;
  balance_check: {
    sufficient: boolean;
    years: Array<{
      year: number;
      entitlement: number;
      approved_used: number;
      pending_requested: number;
      requested: number;
      remaining_after: number;
    }>;
  };
}

export const ALLOWED_ATTACHMENT_MIMES = new Set([
  'application/pdf',
  'image/png',
  'image/jpeg',
  'image/webp',
  'text/plain',
]);
export const MAX_ATTACHMENT_DATA_BYTES = 2 * 1024 * 1024; // 2MB base64 payload limit

function isIsoDate(val: unknown): val is string {
  return typeof val === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(val.trim());
}

/**
 * Strictly parses a 12-hour ("08:05 AM") or 24-hour ("08:05" / "17:10") wall-clock string
 * into minutes from midnight + canonical 12-hour display format ("08:05 AM").
 */
export function parseStrictWallClockTime(raw: unknown): { minutes: number; formatted12: string } | null {
  if (typeof raw !== 'string') return null;
  const trimmed = raw.trim().toUpperCase();
  const m12 = trimmed.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/);
  if (m12) {
    const h = Number(m12[1]);
    const min = Number(m12[2]);
    const mer = m12[3];
    if (h < 1 || h > 12 || min < 0 || min > 59) return null;
    let h24 = h % 12;
    if (mer === 'PM') h24 += 12;
    const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
    return {
      minutes: h24 * 60 + min,
      formatted12: `${String(h12).padStart(2, '0')}:${String(min).padStart(2, '0')} ${mer}`,
    };
  }

  const m24 = trimmed.match(/^(\d{1,2}):(\d{2})$/);
  if (m24) {
    const h24 = Number(m24[1]);
    const min = Number(m24[2]);
    if (h24 < 0 || h24 > 23 || min < 0 || min > 59) return null;
    const mer = h24 >= 12 ? 'PM' : 'AM';
    const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
    return {
      minutes: h24 * 60 + min,
      formatted12: `${String(h12).padStart(2, '0')}:${String(min).padStart(2, '0')} ${mer}`,
    };
  }
  return null;
}

function formatDurationMinutes(totalMinutes: number): string {
  const safe = Math.max(0, Math.round(totalMinutes));
  const h = Math.floor(safe / 60);
  const m = safe % 60;
  return `${h}h ${String(m).padStart(2, '0')}m`;
}

function validateAttachmentPayload(input: {
  attachment_name?: unknown;
  attachment_mime?: unknown;
  attachment_data?: unknown;
  document_reference?: unknown;
}):
  | {
      ok: true;
      attachmentName: string;
      attachmentMime: string;
      attachmentData: string;
      documentReference: string;
      hasDocumentation: boolean;
      summaryRef: string;
    }
  | { ok: false; error: string; code: string } {
  const attachmentName = typeof input.attachment_name === 'string' ? input.attachment_name.trim().slice(0, 160) : '';
  const attachmentMime = typeof input.attachment_mime === 'string' ? input.attachment_mime.trim().toLowerCase().slice(0, 80) : '';
  const attachmentData = typeof input.attachment_data === 'string' ? input.attachment_data.trim() : '';
  const documentReference =
    typeof input.document_reference === 'string' ? input.document_reference.trim().slice(0, 240) : '';

  if (attachmentData) {
    if (!attachmentName) {
      return { ok: false, error: 'Attachment filename is required when uploading a document.', code: 'INVALID_ATTACHMENT' };
    }
    if (attachmentMime && !ALLOWED_ATTACHMENT_MIMES.has(attachmentMime)) {
      return {
        ok: false,
        error: 'Unsupported attachment type. Allowed: PDF, PNG, JPEG, WEBP, or TXT.',
        code: 'INVALID_ATTACHMENT_TYPE',
      };
    }
    if (Buffer.byteLength(attachmentData, 'utf8') > MAX_ATTACHMENT_DATA_BYTES) {
      return {
        ok: false,
        error: 'Supporting attachment exceeds the 2MB size limit.',
        code: 'ATTACHMENT_TOO_LARGE',
      };
    }
  }

  const hasDocumentation = Boolean(documentReference || (attachmentName && attachmentData));
  const summaryRef = [documentReference, attachmentName ? `file:${attachmentName}` : ''].filter(Boolean).join(' · ');
  return {
    ok: true,
    attachmentName,
    attachmentMime,
    attachmentData,
    documentReference,
    hasDocumentation,
    summaryRef,
  };
}

function readSettingValue(db: Database.Database, key: string, fallback: string): string {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as { value: string } | undefined;
  return row ? row.value : fallback;
}

function loadEmployeeWithShift(
  db: Database.Database,
  employeeId: number
):
  | {
      id: number;
      employee_code: string;
      full_name: string;
      department_id: number;
      status: string;
      shift: ShiftDefinition;
    }
  | undefined {
  const row = db
    .prepare(
      `SELECT e.id, e.employee_code, e.full_name, e.department_id, e.status,
              s.id as shift_id, s.name as shift_name, s.time_in as shift_time_in,
              s.time_out as shift_time_out, s.grace_minutes, s.status as shift_status,
              COALESCE(s.rest_days, '') as rest_days
       FROM employees e
       JOIN shifts s ON e.shift_id = s.id
       WHERE e.id = ?`
    )
    .get(employeeId) as
    | {
        id: number;
        employee_code: string;
        full_name: string;
        department_id: number;
        status: string;
        shift_id: number;
        shift_name: string;
        shift_time_in: string;
        shift_time_out: string;
        grace_minutes: number;
        shift_status: string;
        rest_days: string;
      }
    | undefined;

  if (!row) return undefined;
  return {
    id: row.id,
    employee_code: row.employee_code,
    full_name: row.full_name,
    department_id: row.department_id,
    status: row.status,
    shift: {
      id: row.shift_id,
      name: row.shift_name,
      time_in: row.shift_time_in,
      time_out: row.shift_time_out,
      grace_minutes: row.grace_minutes,
      status: row.shift_status,
      rest_days: row.rest_days,
    },
  };
}

function recordGeneralAudit(
  db: Database.Database,
  username: string,
  activity: string,
  module: string,
  status: 'Success' | 'Warning' | 'Error',
  ipAddress: string
): void {
  logAudit(db, username, activity, module, status, ipAddress);
}

// ============================================================================
// PART 1: AUDIT-SAFE ATTENDANCE CORRECTIONS ENGINE (BUILD 11)
// ============================================================================

interface AttendanceSnapshot {
  existed: boolean;
  time_in: string | null;
  time_out: string | null;
  time_in_utc: string | null;
  time_out_utc: string | null;
  work_hours: string;
  late_minutes: number;
  undertime_minutes: number;
  overtime_minutes: number;
  status: AttendanceStatus;
  device_name: string;
  remarks: string;
}

function readAttendanceSnapshot(
  db: Database.Database,
  employeeId: number,
  date: string
): AttendanceSnapshot | null {
  const row = db
    .prepare('SELECT * FROM attendance_records WHERE employee_id = ? AND date = ?')
    .get(employeeId, date) as
    | {
        time_in: string | null;
        time_out: string | null;
        time_in_utc: string | null;
        time_out_utc: string | null;
        work_hours: string;
        late_minutes: number | null;
        undertime_minutes: number | null;
        overtime_minutes: number | null;
        status: AttendanceStatus;
        device_name: string;
        remarks: string;
      }
    | undefined;
  if (!row) return null;
  return {
    existed: true,
    time_in: row.time_in ?? null,
    time_out: row.time_out ?? null,
    time_in_utc: row.time_in_utc ?? null,
    time_out_utc: row.time_out_utc ?? null,
    work_hours: row.work_hours || '-',
    late_minutes: Number(row.late_minutes) || 0,
    undertime_minutes: Number(row.undertime_minutes) || 0,
    overtime_minutes: Number(row.overtime_minutes) || 0,
    status: row.status,
    device_name: row.device_name || '-',
    remarks: row.remarks || '',
  };
}

function formatOriginalSummary(snap: AttendanceSnapshot | null): string {
  if (!snap) return 'No attendance record (Time In: None, Time Out: None)';
  return `Time In: ${snap.time_in || 'None'} | Time Out: ${snap.time_out || 'None'} | Status: ${snap.status}`;
}

/**
 * Evaluates corrected Time In / Time Out against the employee's real shift schedule
 * WITHOUT EVER fabricating a missing counterpart punch.
 */
function computeCorrectedAttendanceMetrics(params: {
  shiftDate: string;
  shift: ShiftDefinition;
  timeInStr: string | null;
  timeOutStr: string | null;
  nowMs: number;
}): {
  ok: true;
  timeInFormatted: string | null;
  timeOutFormatted: string | null;
  timeInUtcIso: string | null;
  timeOutUtcIso: string | null;
  workHours: string;
  lateMinutes: number;
  undertimeMinutes: number;
  overtimeMinutes: number;
  status: AttendanceStatus;
} | { ok: false; error: string; code: string } {
  const parsedIn = params.timeInStr ? parseStrictWallClockTime(params.timeInStr) : null;
  const parsedOut = params.timeOutStr ? parseStrictWallClockTime(params.timeOutStr) : null;

  if (params.timeInStr && !parsedIn) {
    return { ok: false, error: `Invalid Time In format: "${params.timeInStr}". Use HH:MM AM/PM or HH:MM.`, code: 'INVALID_TIME_FORMAT' };
  }
  if (params.timeOutStr && !parsedOut) {
    return { ok: false, error: `Invalid Time Out format: "${params.timeOutStr}". Use HH:MM AM/PM or HH:MM.`, code: 'INVALID_TIME_FORMAT' };
  }

  const window = computeShiftWindow(params.shiftDate, params.shift);

  const inUtcMs = parsedIn ? parseManilaWallClockToUtcMs(params.shiftDate, parsedIn.minutes) : null;
  let outUtcMs: number | null = null;
  if (parsedOut) {
    let outDate = params.shiftDate;
    if (window.isOvernight && parsedOut.minutes <= window.shiftEndMin + 240) {
      outDate = addDaysIso(params.shiftDate, 1);
    } else if (parsedIn && parsedOut.minutes <= parsedIn.minutes) {
      // Allow past-midnight time out up to 03:00 AM next day on day shift
      if (parsedOut.minutes <= 180) {
        outDate = addDaysIso(params.shiftDate, 1);
      } else {
        return {
          ok: false,
          error: `Approved Time Out (${parsedOut.formatted12}) cannot be earlier than or equal to Time In (${parsedIn.formatted12}).`,
          code: 'INVALID_TIME_RANGE',
        };
      }
    }
    outUtcMs = parseManilaWallClockToUtcMs(outDate, parsedOut.minutes);
  }

  // Case 1: Only Time Out exists (unpaired scan — Missing Time In; NEVER fabricate 08:00 AM!)
  if (!parsedIn && parsedOut) {
    return {
      ok: true,
      timeInFormatted: null,
      timeOutFormatted: parsedOut.formatted12,
      timeInUtcIso: null,
      timeOutUtcIso: new Date(outUtcMs!).toISOString(),
      workHours: 'Incomplete',
      lateMinutes: 0,
      undertimeMinutes: 0,
      overtimeMinutes: 0,
      status: 'Missing Time In',
    };
  }

  // Case 2: Only Time In exists (unpaired scan — Missing Time Out if past cutoff; NEVER fabricate 05:00 PM!)
  if (parsedIn && !parsedOut) {
    const lateMin =
      inUtcMs! > window.graceDeadlineUtc ? Math.round((inUtcMs! - window.scheduledStartUtc) / 60_000) : 0;
    const isPastCutoff = params.nowMs > window.finalTimeOutCutoffUtc;
    const status: AttendanceStatus = isPastCutoff
      ? 'Missing Time Out'
      : lateMin > 0
        ? 'Late'
        : 'Present';
    return {
      ok: true,
      timeInFormatted: parsedIn.formatted12,
      timeOutFormatted: null,
      timeInUtcIso: new Date(inUtcMs!).toISOString(),
      timeOutUtcIso: null,
      workHours: isPastCutoff ? 'Incomplete' : '-',
      lateMinutes: lateMin,
      undertimeMinutes: 0,
      overtimeMinutes: 0,
      status,
    };
  }

  // Case 3: Neither Time In nor Time Out
  if (!parsedIn && !parsedOut) {
    return { ok: false, error: 'At least one valid punch time is required.', code: 'MISSING_TIME' };
  }

  // Case 4: Complete pair (Time In + Time Out)
  const workedMinutes = Math.round((outUtcMs! - inUtcMs!) / 60_000);
  if (workedMinutes <= 0) {
    return {
      ok: false,
      error: 'Time Out must be strictly after Time In.',
      code: 'INVALID_TIME_RANGE',
    };
  }

  const lateMin =
    inUtcMs! > window.graceDeadlineUtc ? Math.round((inUtcMs! - window.scheduledStartUtc) / 60_000) : 0;
  const undertimeMin =
    outUtcMs! < window.scheduledEndUtc ? Math.round((window.scheduledEndUtc - outUtcMs!) / 60_000) : 0;
  const overtimeMin =
    outUtcMs! > window.scheduledEndUtc ? Math.round((outUtcMs! - window.scheduledEndUtc) / 60_000) : 0;

  let status: AttendanceStatus = 'Present';
  if (lateMin > 0) status = 'Late';
  else if (undertimeMin > 0) status = 'Undertime';

  return {
    ok: true,
    timeInFormatted: parsedIn!.formatted12,
    timeOutFormatted: parsedOut!.formatted12,
    timeInUtcIso: new Date(inUtcMs!).toISOString(),
    timeOutUtcIso: new Date(outUtcMs!).toISOString(),
    workHours: formatDurationMinutes(workedMinutes),
    lateMinutes: lateMin,
    undertimeMinutes: undertimeMin,
    overtimeMinutes: overtimeMin,
    status,
  };
}

export function createCorrectionRequest(
  db: Database.Database,
  input: {
    employee_id: number;
    attendance_date: string;
    request_type: string;
    requested_time: string;
    requested_time_out?: string;
    reason: string;
    attachment_name?: string;
    attachment_mime?: string;
    attachment_data?: string;
    document_reference?: string;
    actor: ActorContext;
    nowMs: number;
  }
): EngineOutcome {
  if (!isIsoDate(input.attendance_date)) {
    return { statusCode: 400, body: { error: 'Valid attendance_date (YYYY-MM-DD) is required.', code: 'INVALID_DATE' } };
  }

  const reqType = (input.request_type || 'Time In').trim() as CorrectionRequestType;
  if (!['Time In', 'Time Out', 'Full Day'].includes(reqType)) {
    return {
      statusCode: 400,
      body: { error: 'request_type must be Time In, Time Out, or Full Day.', code: 'INVALID_REQUEST_TYPE' },
    };
  }

  const reason = (input.reason || '').trim();
  if (reason.length < 5) {
    return {
      statusCode: 400,
      body: {
        error: 'A descriptive reason (at least 5 characters) is mandatory for attendance correction requests.',
        code: 'REASON_REQUIRED',
      },
    };
  }

  const docCheck = validateAttachmentPayload(input);
  if (!docCheck.ok) {
    return { statusCode: 400, body: { error: docCheck.error, code: docCheck.code } };
  }

  const requireDocSetting = readSettingValue(db, 'correction_require_document', 'false').toLowerCase() === 'true';
  if ((requireDocSetting || reqType === 'Full Day') && !docCheck.hasDocumentation) {
    return {
      statusCode: 400,
      body: {
        error:
          reqType === 'Full Day'
            ? 'Supporting documentation (document reference or attachment) is required for Full Day corrections.'
            : 'Supporting documentation is required by campus HR policy.',
        code: 'DOCUMENTATION_REQUIRED',
      },
    };
  }

  let normalizedTime = '';
  let normalizedTimeOut: string | null = null;

  if (reqType === 'Full Day') {
    // Support either explicit requested_time + requested_time_out OR "08:00 AM - 05:00 PM"
    let rawIn = (input.requested_time || '').trim();
    let rawOut = (input.requested_time_out || '').trim();
    if (!rawOut && rawIn.includes('-')) {
      const parts = rawIn.split(/\s*[-–]\s*/);
      if (parts.length === 2) {
        rawIn = parts[0].trim();
        rawOut = parts[1].trim();
      }
    }
    const parsedIn = parseStrictWallClockTime(rawIn);
    const parsedOut = parseStrictWallClockTime(rawOut);
    if (!parsedIn || !parsedOut) {
      return {
        statusCode: 400,
        body: {
          error:
            'Full Day corrections require BOTH explicit Time In and Time Out values (no automatic 08:00 AM / 05:00 PM fabrication).',
          code: 'FULL_DAY_BOTH_TIMES_REQUIRED',
        },
      };
    }
    normalizedTime = parsedIn.formatted12;
    normalizedTimeOut = parsedOut.formatted12;
  } else {
    const parsedSingle = parseStrictWallClockTime(input.requested_time);
    if (!parsedSingle) {
      return {
        statusCode: 400,
        body: {
          error: 'Requested time must be a valid clock time (e.g. 08:05 AM or 17:10).',
          code: 'INVALID_TIME_FORMAT',
        },
      };
    }
    normalizedTime = parsedSingle.formatted12;
  }

  const emp = loadEmployeeWithShift(db, input.employee_id);
  if (!emp) {
    return { statusCode: 404, body: { error: 'Employee not found.', code: 'EMPLOYEE_NOT_FOUND' } };
  }

  const manilaNow = toManilaParts(input.nowMs);
  if (input.attendance_date > manilaNow.isoDate) {
    return {
      statusCode: 400,
      body: {
        error: `Attendance corrections cannot be filed for future dates (selected ${input.attendance_date}, today is ${manilaNow.isoDate} PHT).`,
        code: 'FUTURE_DATE_NOT_ALLOWED',
      },
    };
  }

  const serverIso = new Date(input.nowMs).toISOString();
  const requestedValueStr =
    reqType === 'Full Day'
      ? `Full Day: Time In ${normalizedTime}, Time Out ${normalizedTimeOut}`
      : `${reqType}: ${normalizedTime}`;

  const tx = db.transaction((): EngineOutcome => {
    const existingPending = db
      .prepare(
        `SELECT id, request_type, requested_time, requested_time_out
         FROM corrections
         WHERE employee_id = ? AND attendance_date = ? AND status = 'Pending'
           AND (request_type = ? OR request_type = 'Full Day' OR ? = 'Full Day')
         LIMIT 1`
      )
      .get(emp.id, input.attendance_date, reqType, reqType) as
      | { id: number; request_type: string; requested_time: string; requested_time_out: string | null }
      | undefined;

    if (existingPending) {
      return {
        statusCode: 409,
        body: {
          error: `A pending ${existingPending.request_type} correction (#${existingPending.id}) already exists for ${input.attendance_date}. Please wait for HR review instead of submitting a duplicate request.`,
          code: 'DUPLICATE_PENDING_CORRECTION',
          existing_correction_id: existingPending.id,
        },
      };
    }

    const origSnap = readAttendanceSnapshot(db, emp.id, input.attendance_date);
    const info = db
      .prepare(
        `INSERT INTO corrections
          (employee_id, attendance_date, request_type, requested_time, requested_time_out,
           reason, status, original_time_in, original_time_out, original_status,
           original_work_hours, original_device_name, original_remarks,
           attachment_name, attachment_mime, attachment_data, document_reference,
           created_by_user_id, created_by_username)
         VALUES (?, ?, ?, ?, ?, ?, 'Pending', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        emp.id,
        input.attendance_date,
        reqType,
        normalizedTime,
        normalizedTimeOut,
        reason,
        origSnap?.time_in ?? null,
        origSnap?.time_out ?? null,
        origSnap?.status ?? null,
        origSnap?.work_hours ?? null,
        origSnap?.device_name ?? null,
        origSnap?.remarks ?? null,
        docCheck.attachmentName,
        docCheck.attachmentMime,
        docCheck.attachmentData,
        docCheck.documentReference,
        input.actor.userId,
        input.actor.username
      );
    const correctionId = Number(info.lastInsertRowid);

    db.prepare(
      `INSERT INTO correction_audit_log
        (correction_id, employee_id, attendance_date, action, original_value, requested_value, approved_value,
         reason, document_ref, reviewer_notes, actor_user_id, actor_username, actor_role, acted_at_utc, acted_at_manila, ip_address)
       VALUES (?, ?, ?, 'CREATED', ?, ?, '', ?, ?, '', ?, ?, ?, ?, ?, ?)`
    ).run(
      correctionId,
      emp.id,
      input.attendance_date,
      formatOriginalSummary(origSnap),
      requestedValueStr,
      reason,
      docCheck.summaryRef,
      input.actor.userId,
      input.actor.username,
      input.actor.role,
      serverIso,
      manilaNow.isoTimestamp,
      input.actor.ipAddress
    );

    db.prepare(
      `INSERT INTO notifications (title, message, category, priority, is_read, action_module, action_entity_id)
       VALUES (?, ?, 'Attendance Alerts', 'Medium', 0, 'corrections', ?)`
    ).run(
      'Attendance correction pending approval',
      `${emp.full_name} requested ${requestedValueStr} for ${input.attendance_date}.`,
      correctionId
    );

    recordGeneralAudit(
      db,
      input.actor.username,
      `Filed ${reqType} correction #${correctionId} for ${emp.full_name} (${input.attendance_date})`,
      'Corrections',
      'Success',
      input.actor.ipAddress
    );

    return {
      statusCode: 201,
      body: {
        id: correctionId,
        status: 'Pending',
        request_type: reqType,
        requested_time: normalizedTime,
        requested_time_out: normalizedTimeOut,
        original_time_in: origSnap?.time_in ?? null,
        original_time_out: origSnap?.time_out ?? null,
        original_status: origSnap?.status ?? null,
      },
    };
  });

  return tx.immediate();
}

export function reviewCorrectionRequest(
  db: Database.Database,
  input: {
    correctionId: number;
    status: 'Approved' | 'Rejected';
    approved_time?: string;
    approved_time_out?: string;
    reviewer_notes?: string;
    actor: ActorContext;
    departmentScopeId: number | null;
    nowMs: number;
  }
): EngineOutcome {
  const reviewerNotes = (input.reviewer_notes || '').trim().slice(0, 500);
  const manilaNow = toManilaParts(input.nowMs);
  const serverIso = new Date(input.nowMs).toISOString();

  const tx = db.transaction((): EngineOutcome => {
    const corr = db
      .prepare(
        `SELECT c.*, e.employee_code, e.full_name as employee_name, e.department_id
         FROM corrections c JOIN employees e ON c.employee_id = e.id
         WHERE c.id = ?`
      )
      .get(input.correctionId) as
      | {
          id: number;
          employee_id: number;
          employee_code: string;
          employee_name: string;
          department_id: number;
          attendance_date: string;
          request_type: CorrectionRequestType;
          requested_time: string;
          requested_time_out: string | null;
          reason: string;
          status: string;
          document_reference: string;
          attachment_name: string;
        }
      | undefined;

    if (!corr) {
      return { statusCode: 404, body: { error: 'Correction request not found.', code: 'NOT_FOUND' } };
    }

    if (input.departmentScopeId !== null && input.departmentScopeId !== corr.department_id) {
      return {
        statusCode: 403,
        body: {
          error: 'Access denied: Department Heads can only review corrections for their own department.',
          code: 'FORBIDDEN',
        },
      };
    }

    // Atomic duplicate approval/rejection prevention
    if (corr.status !== 'Pending') {
      return {
        statusCode: 409,
        body: {
          error: `Correction #${corr.id} has already been ${corr.status} and cannot be reviewed again.`,
          code: 'ALREADY_REVIEWED',
          current_status: corr.status,
        },
      };
    }

    const emp = loadEmployeeWithShift(db, corr.employee_id);
    if (!emp) {
      return { statusCode: 404, body: { error: 'Linked employee record not found.', code: 'EMPLOYEE_NOT_FOUND' } };
    }

    const preSnap = readAttendanceSnapshot(db, corr.employee_id, corr.attendance_date);
    const origValueSummary = formatOriginalSummary(preSnap);
    const reqValueSummary =
      corr.request_type === 'Full Day'
        ? `Full Day: Time In ${corr.requested_time}, Time Out ${corr.requested_time_out || 'Missing'}`
        : `${corr.request_type}: ${corr.requested_time}`;
    const docSummary = [corr.document_reference, corr.attachment_name ? `file:${corr.attachment_name}` : '']
      .filter(Boolean)
      .join(' · ');

    if (input.status === 'Rejected') {
      const upd = db
        .prepare(
          `UPDATE corrections
           SET status = 'Rejected',
               reviewed_by = ?,
               reviewed_by_user_id = ?,
               reviewed_at = ?,
               reviewed_at_utc = ?,
               reviewer_notes = ?
           WHERE id = ? AND status = 'Pending'`
        )
        .run(
          input.actor.username,
          input.actor.userId,
          `${manilaNow.isoDate} ${manilaNow.time24}`,
          serverIso,
          reviewerNotes,
          corr.id
        );
      if (upd.changes === 0) {
        return {
          statusCode: 409,
          body: { error: 'Correction was concurrently reviewed by another session.', code: 'ALREADY_REVIEWED' },
        };
      }

      db.prepare(
        `INSERT INTO correction_audit_log
          (correction_id, employee_id, attendance_date, action, original_value, requested_value, approved_value,
           reason, document_ref, reviewer_notes, actor_user_id, actor_username, actor_role, acted_at_utc, acted_at_manila, ip_address)
         VALUES (?, ?, ?, 'REJECTED', ?, ?, 'REJECTED (No attendance change)', ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        corr.id,
        corr.employee_id,
        corr.attendance_date,
        origValueSummary,
        reqValueSummary,
        corr.reason,
        docSummary,
        reviewerNotes,
        input.actor.userId,
        input.actor.username,
        input.actor.role,
        serverIso,
        manilaNow.isoTimestamp,
        input.actor.ipAddress
      );

      recordGeneralAudit(
        db,
        input.actor.username,
        `Rejected attendance correction #${corr.id} for ${corr.employee_name} (${corr.attendance_date})`,
        'Corrections',
        'Success',
        input.actor.ipAddress
      );

      return {
        statusCode: 200,
        body: {
          success: true,
          id: corr.id,
          status: 'Rejected',
          reviewed_by: input.actor.username,
          reviewed_at_utc: serverIso,
        },
      };
    }

    // APPROVED PATH — Strictly NO invented 08:00 AM / 05:00 PM counterpart punches!
    const effReqTimeInRaw =
      corr.request_type === 'Time In' || corr.request_type === 'Full Day'
        ? input.approved_time?.trim() || corr.requested_time
        : null;
    const effReqTimeOutRaw =
      corr.request_type === 'Time Out'
        ? input.approved_time?.trim() || corr.requested_time
        : corr.request_type === 'Full Day'
          ? input.approved_time_out?.trim() || corr.requested_time_out
          : null;

    if (corr.request_type === 'Full Day' && (!effReqTimeInRaw || !effReqTimeOutRaw)) {
      return {
        statusCode: 400,
        body: {
          error: 'Full Day approval requires both explicit Time In and Time Out values.',
          code: 'FULL_DAY_BOTH_TIMES_REQUIRED',
        },
      };
    }

    const candidateTimeIn =
      corr.request_type === 'Time In' || corr.request_type === 'Full Day'
        ? effReqTimeInRaw
        : preSnap?.time_in ?? null;
    const candidateTimeOut =
      corr.request_type === 'Time Out' || corr.request_type === 'Full Day'
        ? effReqTimeOutRaw
        : preSnap?.time_out ?? null;

    const metrics = computeCorrectedAttendanceMetrics({
      shiftDate: corr.attendance_date,
      shift: emp.shift,
      timeInStr: candidateTimeIn,
      timeOutStr: candidateTimeOut,
      nowMs: input.nowMs,
    });
    if (!metrics.ok) {
      return { statusCode: 400, body: { error: metrics.error, code: metrics.code } };
    }

    const approvedTimeStored =
      corr.request_type === 'Time Out' ? metrics.timeOutFormatted! : metrics.timeInFormatted!;
    const approvedTimeOutStored = corr.request_type === 'Full Day' ? metrics.timeOutFormatted : null;
    const approvedValueSummary =
      `Time In: ${metrics.timeInFormatted || 'None'} | Time Out: ${metrics.timeOutFormatted || 'None'} | Status: ${metrics.status} | Hours: ${metrics.workHours}`;

    const remarkNote = `Approved correction #${corr.id} (${corr.request_type}) by ${input.actor.username}`;
    const postSnapshot: AttendanceSnapshot = {
      existed: true,
      time_in: metrics.timeInFormatted,
      time_out: metrics.timeOutFormatted,
      time_in_utc: metrics.timeInUtcIso,
      time_out_utc: metrics.timeOutUtcIso,
      work_hours: metrics.workHours,
      late_minutes: metrics.lateMinutes,
      undertime_minutes: metrics.undertimeMinutes,
      overtime_minutes: metrics.overtimeMinutes,
      status: metrics.status,
      device_name: preSnap?.device_name && preSnap.device_name !== '-' ? preSnap.device_name : 'Correction Approved',
      remarks: remarkNote,
    };

    const upd = db
      .prepare(
        `UPDATE corrections
         SET status = 'Approved',
             approved_time = ?,
             approved_time_out = ?,
             reviewed_by = ?,
             reviewed_by_user_id = ?,
             reviewed_at = ?,
             reviewed_at_utc = ?,
             reviewer_notes = ?,
             original_time_in = COALESCE(original_time_in, ?),
             original_time_out = COALESCE(original_time_out, ?),
             original_status = COALESCE(original_status, ?),
             pre_snapshot_json = ?,
             post_snapshot_json = ?
         WHERE id = ? AND status = 'Pending'`
      )
      .run(
        approvedTimeStored,
        approvedTimeOutStored,
        input.actor.username,
        input.actor.userId,
        `${manilaNow.isoDate} ${manilaNow.time24}`,
        serverIso,
        reviewerNotes,
        preSnap?.time_in ?? null,
        preSnap?.time_out ?? null,
        preSnap?.status ?? null,
        JSON.stringify(preSnap),
        JSON.stringify(postSnapshot),
        corr.id
      );

    if (upd.changes === 0) {
      return {
        statusCode: 409,
        body: { error: 'Correction was concurrently reviewed by another session.', code: 'ALREADY_REVIEWED' },
      };
    }

    if (preSnap) {
      db.prepare(
        `UPDATE attendance_records
         SET time_in = ?, time_out = ?, time_in_utc = ?, time_out_utc = ?,
             work_hours = ?, late_minutes = ?, undertime_minutes = ?, overtime_minutes = ?,
             status = ?, remarks = ?
         WHERE employee_id = ? AND date = ?`
      ).run(
        postSnapshot.time_in,
        postSnapshot.time_out,
        postSnapshot.time_in_utc,
        postSnapshot.time_out_utc,
        postSnapshot.work_hours,
        postSnapshot.late_minutes,
        postSnapshot.undertime_minutes,
        postSnapshot.overtime_minutes,
        postSnapshot.status,
        postSnapshot.remarks,
        corr.employee_id,
        corr.attendance_date
      );
    } else {
      db.prepare(
        `INSERT INTO attendance_records
          (employee_id, date, time_in, time_out, time_in_utc, time_out_utc,
           work_hours, late_minutes, undertime_minutes, overtime_minutes,
           status, device_name, remarks)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        corr.employee_id,
        corr.attendance_date,
        postSnapshot.time_in,
        postSnapshot.time_out,
        postSnapshot.time_in_utc,
        postSnapshot.time_out_utc,
        postSnapshot.work_hours,
        postSnapshot.late_minutes,
        postSnapshot.undertime_minutes,
        postSnapshot.overtime_minutes,
        postSnapshot.status,
        postSnapshot.device_name,
        postSnapshot.remarks
      );
    }

    // Append immutable event to attendance_events (preserves all original kiosk captures intact!)
    db.prepare(
      `INSERT INTO attendance_events
        (event_uid, employee_id, device_id, device_name, attendance_date, punch_type, punch_time,
         server_timestamp_utc, manila_timestamp, decision, decision_code, decision_reason, source)
       VALUES (?, ?, NULL, ?, ?, 'correction', ?, ?, ?, 'ACCEPTED', 'CORRECTION_APPROVED', ?, 'corrections')`
    ).run(
      `cor-${corr.id}-apr-${crypto.randomBytes(4).toString('hex')}`,
      corr.employee_id,
      `Correction Approved (${input.actor.username})`,
      corr.attendance_date,
      approvedTimeStored,
      serverIso,
      manilaNow.isoTimestamp,
      `Correction #${corr.id} (${corr.request_type}): Original [${origValueSummary}] -> Requested [${reqValueSummary}] -> Approved [${approvedValueSummary}]`
    );

    // Append immutable entry to correction_audit_log
    db.prepare(
      `INSERT INTO correction_audit_log
        (correction_id, employee_id, attendance_date, action, original_value, requested_value, approved_value,
         reason, document_ref, reviewer_notes, actor_user_id, actor_username, actor_role, acted_at_utc, acted_at_manila, ip_address)
       VALUES (?, ?, ?, 'APPROVED', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      corr.id,
      corr.employee_id,
      corr.attendance_date,
      origValueSummary,
      reqValueSummary,
      approvedValueSummary,
      corr.reason,
      docSummary,
      reviewerNotes,
      input.actor.userId,
      input.actor.username,
      input.actor.role,
      serverIso,
      manilaNow.isoTimestamp,
      input.actor.ipAddress
    );

    recordGeneralAudit(
      db,
      input.actor.username,
      `Approved ${corr.request_type} correction #${corr.id} for ${corr.employee_name} (${corr.attendance_date}) -> ${approvedValueSummary}`,
      'Corrections',
      'Success',
      input.actor.ipAddress
    );

    return {
      statusCode: 200,
      body: {
        success: true,
        id: corr.id,
        status: 'Approved',
        approved_time: approvedTimeStored,
        approved_time_out: approvedTimeOutStored,
        attendance_status: postSnapshot.status,
        time_in: postSnapshot.time_in,
        time_out: postSnapshot.time_out,
        resulting_status: postSnapshot.status,
        resulting_time_in: postSnapshot.time_in,
        resulting_time_out: postSnapshot.time_out,
        incomplete_punch_warning:
          postSnapshot.status === 'Missing Time Out' || postSnapshot.status === 'Missing Time In'
            ? `Unpaired punch approved: attendance status is '${postSnapshot.status}' until the counterpart punch is recorded.`
            : null,
        work_hours: postSnapshot.work_hours,
        reviewed_by: input.actor.username,
        reviewed_at_utc: serverIso,
      },
      realtimeAttendanceEvents: [
        {
          employee_id: corr.employee_id,
          employee_code: corr.employee_code,
          department_id: corr.department_id,
          shift_date: corr.attendance_date,
          action: 'CORRECTION_APPROVED',
          status: postSnapshot.status,
          time: approvedTimeStored,
          source: 'corrections',
        },
      ],
    };
  });

  return tx.immediate();
}

export function reverseCorrectionRequest(
  db: Database.Database,
  input: {
    correctionId: number;
    reversal_reason: string;
    actor: ActorContext;
    departmentScopeId: number | null;
    nowMs: number;
  }
): EngineOutcome {
  const reversalReason = (input.reversal_reason || '').trim();
  if (reversalReason.length < 5) {
    return {
      statusCode: 400,
      body: { error: 'A reversal reason (at least 5 characters) is mandatory.', code: 'REVERSAL_REASON_REQUIRED' },
    };
  }

  const manilaNow = toManilaParts(input.nowMs);
  const serverIso = new Date(input.nowMs).toISOString();

  const tx = db.transaction((): EngineOutcome => {
    const corr = db
      .prepare(
        `SELECT c.*, e.employee_code, e.full_name as employee_name, e.department_id
         FROM corrections c JOIN employees e ON c.employee_id = e.id
         WHERE c.id = ?`
      )
      .get(input.correctionId) as
      | {
          id: number;
          employee_id: number;
          employee_code: string;
          employee_name: string;
          department_id: number;
          attendance_date: string;
          request_type: CorrectionRequestType;
          requested_time: string;
          requested_time_out: string | null;
          approved_time: string | null;
          approved_time_out: string | null;
          reason: string;
          status: string;
          pre_snapshot_json: string | null;
          post_snapshot_json: string | null;
          document_reference: string;
          attachment_name: string;
          reviewed_at_utc: string | null;
        }
      | undefined;

    if (!corr) {
      return { statusCode: 404, body: { error: 'Correction request not found.', code: 'NOT_FOUND' } };
    }
    if (input.departmentScopeId !== null && input.departmentScopeId !== corr.department_id) {
      return {
        statusCode: 403,
        body: { error: 'Access denied: cannot reverse corrections outside your department.', code: 'FORBIDDEN' },
      };
    }
    if (corr.status !== 'Approved') {
      return {
        statusCode: 409,
        body: {
          error: `Only Approved corrections can be reversed (current status: ${corr.status}).`,
          code: 'INVALID_REVERSAL_STATE',
        },
      };
    }

    const preSnap: AttendanceSnapshot | null = corr.pre_snapshot_json
      ? (JSON.parse(corr.pre_snapshot_json) as AttendanceSnapshot | null)
      : null;

    // Check if newer kiosk punches arrived after the correction was approved so we NEVER destroy genuine kiosk captures
    const newerKioskEvent = corr.reviewed_at_utc
      ? (db
          .prepare(
            `SELECT id FROM attendance_events
             WHERE employee_id = ? AND attendance_date = ? AND source IN ('kiosk', 'kiosk_offline')
               AND decision = 'ACCEPTED' AND server_timestamp_utc > ?
             LIMIT 1`
          )
          .get(corr.employee_id, corr.attendance_date, corr.reviewed_at_utc) as { id: number } | undefined)
      : undefined;

    const currentSnap = readAttendanceSnapshot(db, corr.employee_id, corr.attendance_date);
    let restoredSummary = '';

    if (preSnap) {
      if (newerKioskEvent && currentSnap) {
        // Restore only the corrected field(s) while preserving the newer kiosk punch
        const emp = loadEmployeeWithShift(db, corr.employee_id);
        const restoredIn =
          corr.request_type === 'Time In' || corr.request_type === 'Full Day'
            ? preSnap.time_in
            : currentSnap.time_in;
        const restoredOut =
          corr.request_type === 'Time Out' || corr.request_type === 'Full Day'
            ? preSnap.time_out
            : currentSnap.time_out;
        if (!restoredIn && !restoredOut) {
          db.prepare(
            `UPDATE attendance_records SET time_in = NULL, time_out = NULL, work_hours = '-', status = ?, remarks = ? WHERE employee_id = ? AND date = ?`
          ).run(preSnap.status, `Reversed correction #${corr.id}`, corr.employee_id, corr.attendance_date);
          restoredSummary = `Restored status ${preSnap.status} (both times cleared)`;
        } else if (emp) {
          const recomputed = computeCorrectedAttendanceMetrics({
            shiftDate: corr.attendance_date,
            shift: emp.shift,
            timeInStr: restoredIn,
            timeOutStr: restoredOut,
            nowMs: input.nowMs,
          });
          if (recomputed.ok) {
            db.prepare(
              `UPDATE attendance_records
               SET time_in = ?, time_out = ?, time_in_utc = ?, time_out_utc = ?,
                   work_hours = ?, late_minutes = ?, undertime_minutes = ?, overtime_minutes = ?,
                   status = ?, remarks = ?
               WHERE employee_id = ? AND date = ?`
            ).run(
              recomputed.timeInFormatted,
              recomputed.timeOutFormatted,
              recomputed.timeInUtcIso,
              recomputed.timeOutUtcIso,
              recomputed.workHours,
              recomputed.lateMinutes,
              recomputed.undertimeMinutes,
              recomputed.overtimeMinutes,
              recomputed.status,
              `Reversed correction #${corr.id} (preserved subsequent kiosk capture)`,
              corr.employee_id,
              corr.attendance_date
            );
            restoredSummary = `Time In: ${recomputed.timeInFormatted || 'None'} | Time Out: ${recomputed.timeOutFormatted || 'None'} | Status: ${recomputed.status}`;
          }
        }
      } else {
        db.prepare(
          `UPDATE attendance_records
           SET time_in = ?, time_out = ?, time_in_utc = ?, time_out_utc = ?,
               work_hours = ?, late_minutes = ?, undertime_minutes = ?, overtime_minutes = ?,
               status = ?, device_name = ?, remarks = ?
           WHERE employee_id = ? AND date = ?`
        ).run(
          preSnap.time_in,
          preSnap.time_out,
          preSnap.time_in_utc,
          preSnap.time_out_utc,
          preSnap.work_hours,
          preSnap.late_minutes,
          preSnap.undertime_minutes,
          preSnap.overtime_minutes,
          preSnap.status,
          preSnap.device_name,
          preSnap.remarks || `Restored prior state after reversing correction #${corr.id}`,
          corr.employee_id,
          corr.attendance_date
        );
        restoredSummary = formatOriginalSummary(preSnap);
      }
    } else if (!newerKioskEvent) {
      db.prepare('DELETE FROM attendance_records WHERE employee_id = ? AND date = ?').run(
        corr.employee_id,
        corr.attendance_date
      );
      restoredSummary = 'Removed correction-only attendance row (no prior attendance existed)';
    } else {
      restoredSummary = 'Preserved subsequent kiosk punch; marked correction reversed';
    }

    const upd = db
      .prepare(
        `UPDATE corrections
         SET status = 'Reversed', reversed_by = ?, reversed_at_utc = ?, reversal_reason = ?
         WHERE id = ? AND status = 'Approved'`
      )
      .run(input.actor.username, serverIso, reversalReason, corr.id);

    if (upd.changes === 0) {
      return { statusCode: 409, body: { error: 'Correction was concurrently modified.', code: 'INVALID_REVERSAL_STATE' } };
    }

    db.prepare(
      `INSERT INTO attendance_events
        (event_uid, employee_id, device_id, device_name, attendance_date, punch_type, punch_time,
         server_timestamp_utc, manila_timestamp, decision, decision_code, decision_reason, source)
       VALUES (?, ?, NULL, ?, ?, 'correction', ?, ?, ?, 'ACCEPTED', 'CORRECTION_REVERSED', ?, 'corrections')`
    ).run(
      `cor-${corr.id}-rev-${crypto.randomBytes(4).toString('hex')}`,
      corr.employee_id,
      `Correction Reversed (${input.actor.username})`,
      corr.attendance_date,
      manilaNow.time12,
      serverIso,
      manilaNow.isoTimestamp,
      `Reversed correction #${corr.id}: ${reversalReason} -> ${restoredSummary}`
    );

    db.prepare(
      `INSERT INTO correction_audit_log
        (correction_id, employee_id, attendance_date, action, original_value, requested_value, approved_value,
         reason, document_ref, reviewer_notes, actor_user_id, actor_username, actor_role, acted_at_utc, acted_at_manila, ip_address)
       VALUES (?, ?, ?, 'REVERSED', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      corr.id,
      corr.employee_id,
      corr.attendance_date,
      formatOriginalSummary(currentSnap),
      `${corr.request_type}: ${corr.requested_time}`,
      `REVERSED -> ${restoredSummary}`,
      reversalReason,
      [corr.document_reference, corr.attachment_name ? `file:${corr.attachment_name}` : ''].filter(Boolean).join(' · '),
      reversalReason,
      input.actor.userId,
      input.actor.username,
      input.actor.role,
      serverIso,
      manilaNow.isoTimestamp,
      input.actor.ipAddress
    );

    recordGeneralAudit(
      db,
      input.actor.username,
      `Reversed approved correction #${corr.id} for ${corr.employee_name} (${corr.attendance_date}): ${reversalReason}`,
      'Corrections',
      'Warning',
      input.actor.ipAddress
    );

    return {
      statusCode: 200,
      body: {
        success: true,
        id: corr.id,
        status: 'Reversed',
        reversed_by: input.actor.username,
        reversed_at_utc: serverIso,
        restored_summary: restoredSummary,
        restored_time_in: preSnap ? preSnap.time_in : null,
        restored_time_out: preSnap ? preSnap.time_out : null,
        restored_status: preSnap ? preSnap.status : null,
      },
      realtimeAttendanceEvents: [
        {
          employee_id: corr.employee_id,
          employee_code: corr.employee_code,
          department_id: corr.department_id,
          shift_date: corr.attendance_date,
          action: 'CORRECTION_REVERSED',
          status: preSnap?.status,
          source: 'corrections',
        },
      ],
    };
  });

  return tx.immediate();
}

// ============================================================================
// PART 2: HR-POLICY DRIVEN LEAVE ENGINE (BUILD 11)
// ============================================================================

export function getLeavePolicies(db: Database.Database): LeavePolicyRow[] {
  return db.prepare('SELECT * FROM leave_policies WHERE is_active = 1 ORDER BY id ASC').all() as LeavePolicyRow[];
}

export function getLeavePolicyByType(db: Database.Database, leaveType: string): LeavePolicyRow | undefined {
  return db
    .prepare('SELECT * FROM leave_policies WHERE LOWER(leave_type) = LOWER(?) AND is_active = 1 LIMIT 1')
    .get(leaveType.trim()) as LeavePolicyRow | undefined;
}

function getEffectiveRestDaySet(db: Database.Database, shiftRestDays: string | null | undefined): Set<string> {
  const configured = (shiftRestDays || '').trim();
  const source = configured || readSettingValue(db, 'leave_weekend_days', 'Sat,Sun');
  return new Set(
    source
      .split(',')
      .map((s) => s.trim().slice(0, 3).toLowerCase())
      .filter(Boolean)
  );
}

function getYearLeaveUsage(
  db: Database.Database,
  employeeId: number,
  leaveType: string,
  year: number,
  excludeLeaveId?: number
): { approvedUsed: number; pendingRequested: number } {
  const params: unknown[] = [employeeId, leaveType, year];
  let excludeSql = '';
  if (excludeLeaveId !== undefined) {
    excludeSql = 'AND l.id != ?';
    params.push(excludeLeaveId);
  }
  const row = db
    .prepare(
      `SELECT
         COALESCE(SUM(CASE WHEN l.status = 'Approved' AND a.conflict_preserved = 0 THEN a.day_fraction ELSE 0 END), 0) as approved_used,
         COALESCE(SUM(CASE WHEN l.status = 'Pending' THEN a.day_fraction ELSE 0 END), 0) as pending_requested
       FROM leave_day_allocations a
       JOIN leaves l ON a.leave_id = l.id
       WHERE a.employee_id = ? AND LOWER(l.leave_type) = LOWER(?) AND a.leave_year = ? ${excludeSql}`
    )
    .get(...params) as { approved_used: number; pending_requested: number };

  return {
    approvedUsed: Math.round((Number(row?.approved_used) || 0) * 100) / 100,
    pendingRequested: Math.round((Number(row?.pending_requested) || 0) * 100) / 100,
  };
}

export function evaluateLeaveRequestDates(
  db: Database.Database,
  params: {
    employeeId: number;
    leaveType: string;
    startDate: string;
    endDate: string;
    dayPortion: LeaveDayPortion;
    excludeLeaveId?: number;
  }
): { ok: true; evaluation: LeaveEvaluationResult } | { ok: false; statusCode: number; error: string; code: string } {
  if (!isIsoDate(params.startDate) || !isIsoDate(params.endDate)) {
    return {
      ok: false,
      statusCode: 400,
      error: 'Valid start_date and end_date (YYYY-MM-DD) are required.',
      code: 'INVALID_DATES',
    };
  }
  if (params.endDate < params.startDate) {
    return { ok: false, statusCode: 400, error: 'End date must be on or after start date.', code: 'INVALID_DATE_RANGE' };
  }

  const emp = loadEmployeeWithShift(db, params.employeeId);
  if (!emp) {
    return { ok: false, statusCode: 404, error: 'Employee not found.', code: 'EMPLOYEE_NOT_FOUND' };
  }

  const policy = getLeavePolicyByType(db, params.leaveType);
  if (!policy) {
    return {
      ok: false,
      statusCode: 400,
      error: `Unsupported or inactive leave type "${params.leaveType}".`,
      code: 'INVALID_LEAVE_TYPE',
    };
  }

  const portion: LeaveDayPortion = params.dayPortion || 'FULL';
  if (!['FULL', 'HALF_AM', 'HALF_PM'].includes(portion)) {
    return { ok: false, statusCode: 400, error: 'day_portion must be FULL, HALF_AM, or HALF_PM.', code: 'INVALID_DAY_PORTION' };
  }
  if (portion !== 'FULL') {
    if (params.startDate !== params.endDate) {
      return {
        ok: false,
        statusCode: 400,
        error: 'Half-day leave (AM/PM) is only allowed for single-day leave requests.',
        code: 'INVALID_HALF_DAY',
      };
    }
    if (!policy.allow_half_day) {
      return {
        ok: false,
        statusCode: 400,
        error: `${policy.leave_type} does not allow half-day requests under current HR policy.`,
        code: 'HALF_DAY_NOT_ALLOWED',
      };
    }
  }

  // Span guard (max 366 days)
  const startUtc = Date.parse(`${params.startDate}T00:00:00Z`);
  const endUtc = Date.parse(`${params.endDate}T00:00:00Z`);
  const calendarDays = Math.round((endUtc - startUtc) / 86_400_000) + 1;
  if (calendarDays > 366) {
    return {
      ok: false,
      statusCode: 400,
      error: 'Leave range cannot exceed 366 calendar days in a single application.',
      code: 'DATE_RANGE_TOO_LONG',
    };
  }

  const holidays = db
    .prepare('SELECT date, name, type FROM holidays WHERE date >= ? AND date <= ?')
    .all(params.startDate, params.endDate) as Array<{ date: string; name: string; type: string }>;
  const holidayMap = new Map(holidays.map((h) => [h.date, h]));

  const existingAtt = db
    .prepare(
      `SELECT date, time_in, time_out, status
       FROM attendance_records
       WHERE employee_id = ? AND date >= ? AND date <= ?`
    )
    .all(params.employeeId, params.startDate, params.endDate) as Array<{
    date: string;
    time_in: string | null;
    time_out: string | null;
    status: string;
  }>;
  const attMap = new Map(existingAtt.map((a) => [a.date, a]));

  const restDays = getEffectiveRestDaySet(db, emp.shift.rest_days);
  const eligibleDays: EligibleLeaveDay[] = [];
  const excludedDays: ExcludedLeaveDay[] = [];
  const creditsByYear: Record<string, number> = {};
  const conflictingPunchDates: Array<{
    date: string;
    time_in: string | null;
    time_out: string | null;
    status: string | null;
  }> = [];

  const fraction = portion === 'FULL' ? 1.0 : 0.5;
  let cursor = params.startDate;

  for (let i = 0; i < calendarDays; i++) {
    const dayCode = getManilaDayCodeForIsoDate(cursor);
    const holiday = holidayMap.get(cursor);

    if (policy.exclude_holidays && holiday) {
      excludedDays.push({
        date: cursor,
        reason: 'HOLIDAY',
        detail: `${holiday.type} Holiday: ${holiday.name}`,
      });
    } else if (policy.exclude_weekends_rest_days && restDays.has(dayCode.toLowerCase())) {
      excludedDays.push({
        date: cursor,
        reason: emp.shift.rest_days?.trim() ? 'REST_DAY' : 'WEEKEND',
        detail: `Scheduled non-working day (${dayCode})`,
      });
    } else {
      const yr = Number(cursor.slice(0, 4));
      const att = attMap.get(cursor);
      const hasValidPunch = Boolean(att && (att.time_in || att.time_out));
      eligibleDays.push({
        date: cursor,
        year: yr,
        fraction,
        portion,
        has_valid_punch: hasValidPunch,
        existing_time_in: att?.time_in ?? null,
        existing_time_out: att?.time_out ?? null,
        existing_status: att?.status ?? null,
      });
      creditsByYear[String(yr)] = Math.round(((creditsByYear[String(yr)] || 0) + fraction) * 100) / 100;
      if (hasValidPunch) {
        conflictingPunchDates.push({
          date: cursor,
          time_in: att!.time_in,
          time_out: att!.time_out,
          status: att!.status,
        });
      }
    }
    cursor = addDaysIso(cursor, 1);
  }

  if (eligibleDays.length === 0) {
    return {
      ok: false,
      statusCode: 400,
      error:
        'Selected date range contains 0 eligible working days (all selected dates fall on weekends/rest days or campus holidays).',
      code: 'NO_ELIGIBLE_LEAVE_DAYS',
    };
  }

  // Check overlapping Pending/Approved leaves (allowing non-overlapping HALF_AM + HALF_PM on the same day)
  const overlapParams: unknown[] = [params.employeeId, params.endDate, params.startDate];
  let excludeSql = '';
  if (params.excludeLeaveId !== undefined) {
    excludeSql = 'AND id != ?';
    overlapParams.push(params.excludeLeaveId);
  }
  const rawOverlaps = db
    .prepare(
      `SELECT id, leave_type, start_date, end_date, day_portion, status
       FROM leaves
       WHERE employee_id = ? AND status IN ('Pending', 'Approved')
         AND start_date <= ? AND end_date >= ? ${excludeSql}`
    )
    .all(...overlapParams) as Array<{
    id: number;
    leave_type: string;
    start_date: string;
    end_date: string;
    day_portion: string;
    status: string;
  }>;

  const overlappingLeaves = rawOverlaps.filter((ov) => {
    const ovPortion = ov.day_portion || 'FULL';
    if (
      portion !== 'FULL' &&
      ovPortion !== 'FULL' &&
      ovPortion !== portion &&
      params.startDate === params.endDate &&
      ov.start_date === ov.end_date
    ) {
      // Complementary HALF_AM + HALF_PM on the same date is allowed
      return false;
    }
    return true;
  });

  // Per-year balance evaluation (handles cross-year ranges accurately!)
  const yearBreakdown = Object.entries(creditsByYear)
    .sort(([a], [b]) => Number(a) - Number(b))
    .map(([yrStr, requested]) => {
      const year = Number(yrStr);
      const usage = getYearLeaveUsage(db, params.employeeId, policy.leave_type, year, params.excludeLeaveId);
      const remainingAfter = Math.round((policy.annual_entitlement - usage.approvedUsed - requested) * 100) / 100;
      return {
        year,
        entitlement: policy.annual_entitlement,
        approved_used: usage.approvedUsed,
        pending_requested: usage.pendingRequested,
        requested,
        remaining_after: remainingAfter,
      };
    });

  const sufficient =
    !policy.track_balance ||
    Boolean(policy.allow_negative_balance) ||
    yearBreakdown.every((y) => y.remaining_after >= -1e-9);

  const totalEligibleCredits = Math.round(eligibleDays.reduce((acc, d) => acc + d.fraction, 0) * 100) / 100;

  return {
    ok: true,
    evaluation: {
      policy,
      start_date: params.startDate,
      end_date: params.endDate,
      day_portion: portion,
      calendar_days: calendarDays,
      eligible_days: eligibleDays,
      excluded_days: excludedDays,
      total_eligible_credits: totalEligibleCredits,
      credits_by_year: creditsByYear,
      conflicting_punch_dates: conflictingPunchDates,
      overlapping_leaves: overlappingLeaves,
      balance_check: {
        sufficient,
        years: yearBreakdown,
      },
    },
  };
}

export function computeEmployeeLeaveBalances(
  db: Database.Database,
  options: {
    year: number;
    departmentId?: number | null;
    employeeId?: number | null;
  }
) {
  const policies = getLeavePolicies(db);
  const policyByCode = new Map(policies.map((p) => [p.code.toUpperCase(), p]));
  const vlEnt = policyByCode.get('VL')?.annual_entitlement ?? 15;
  const slEnt = policyByCode.get('SL')?.annual_entitlement ?? 15;
  const elEnt = policyByCode.get('EL')?.annual_entitlement ?? 5;

  const empWhere: string[] = ["e.status = 'Active'"];
  const empParams: unknown[] = [];
  if (options.employeeId !== null && options.employeeId !== undefined) {
    empWhere.push('e.id = ?');
    empParams.push(options.employeeId);
  } else if (options.departmentId !== null && options.departmentId !== undefined) {
    empWhere.push('e.department_id = ?');
    empParams.push(options.departmentId);
  }

  const emps = db
    .prepare(
      `SELECT e.id as employee_id, e.employee_code, e.full_name as employee_name, d.code as department_code
       FROM employees e
       JOIN departments d ON e.department_id = d.id
       WHERE ${empWhere.join(' AND ')}
       ORDER BY e.employee_code ASC`
    )
    .all(...empParams) as Array<{
    employee_id: number;
    employee_code: string;
    employee_name: string;
    department_code: string;
  }>;

  const usageRows = db
    .prepare(
      `SELECT a.employee_id, l.leave_type, l.status,
              COALESCE(SUM(CASE WHEN a.conflict_preserved = 0 THEN a.day_fraction ELSE 0 END), 0) as total_days
       FROM leave_day_allocations a
       JOIN leaves l ON a.leave_id = l.id
       WHERE a.leave_year = ? AND l.status IN ('Approved', 'Pending')
       GROUP BY a.employee_id, l.leave_type, l.status`
    )
    .all(options.year) as Array<{
    employee_id: number;
    leave_type: string;
    status: string;
    total_days: number;
  }>;

  const usageMap = new Map<string, number>();
  for (const r of usageRows) {
    usageMap.set(`${r.employee_id}|${r.leave_type.toLowerCase()}|${r.status}`, Math.round(Number(r.total_days) * 100) / 100);
  }

  const round2 = (n: number) => Math.round(n * 100) / 100;

  return emps.map((emp) => {
    const vlUsed = usageMap.get(`${emp.employee_id}|vacation leave|Approved`) ?? 0;
    const vlPending = usageMap.get(`${emp.employee_id}|vacation leave|Pending`) ?? 0;
    const slUsed = usageMap.get(`${emp.employee_id}|sick leave|Approved`) ?? 0;
    const slPending = usageMap.get(`${emp.employee_id}|sick leave|Pending`) ?? 0;
    const elUsed = usageMap.get(`${emp.employee_id}|emergency leave|Approved`) ?? 0;
    const elPending = usageMap.get(`${emp.employee_id}|emergency leave|Pending`) ?? 0;
    const obDays = usageMap.get(`${emp.employee_id}|official business|Approved`) ?? 0;

    return {
      ...emp,
      year: options.year,
      vl_entitlement: vlEnt,
      vl_used: vlUsed,
      vl_pending: vlPending,
      vl_remaining: round2(Math.max(0, vlEnt - vlUsed)),
      sl_entitlement: slEnt,
      sl_used: slUsed,
      sl_pending: slPending,
      sl_remaining: round2(Math.max(0, slEnt - slUsed)),
      el_entitlement: elEnt,
      el_used: elUsed,
      el_pending: elPending,
      el_remaining: round2(Math.max(0, elEnt - elUsed)),
      ob_days: obDays,
    };
  });
}

export function createLeaveRequest(
  db: Database.Database,
  input: {
    employee_id: number;
    leave_type: string;
    start_date: string;
    end_date: string;
    day_portion?: LeaveDayPortion;
    reason: string;
    attachment_name?: string;
    attachment_mime?: string;
    attachment_data?: string;
    document_reference?: string;
    actor: ActorContext;
    nowMs: number;
  }
): EngineOutcome {
  const reason = (input.reason || '').trim();
  if (reason.length < 5) {
    return {
      statusCode: 400,
      body: { error: 'A descriptive reason (at least 5 characters) is mandatory for leave applications.', code: 'REASON_REQUIRED' },
    };
  }

  const docCheck = validateAttachmentPayload(input);
  if (!docCheck.ok) {
    return { statusCode: 400, body: { error: docCheck.error, code: docCheck.code } };
  }

  const manilaNow = toManilaParts(input.nowMs);
  const serverIso = new Date(input.nowMs).toISOString();

  const tx = db.transaction((): EngineOutcome => {
    const evalRes = evaluateLeaveRequestDates(db, {
      employeeId: input.employee_id,
      leaveType: input.leave_type,
      startDate: input.start_date,
      endDate: input.end_date,
      dayPortion: input.day_portion || 'FULL',
    });

    if (!evalRes.ok) {
      return { statusCode: evalRes.statusCode, body: { error: evalRes.error, code: evalRes.code } };
    }
    const ev = evalRes.evaluation;

    // Enforce HR-approved supporting documentation threshold (e.g., Sick Leave >= 3 days, Maternity/Paternity >= 1 day)
    if (
      ev.policy.requires_document_after_days > 0 &&
      ev.total_eligible_credits >= ev.policy.requires_document_after_days &&
      !docCheck.hasDocumentation
    ) {
      return {
        statusCode: 400,
        body: {
          error: `${ev.policy.leave_type} of ${ev.total_eligible_credits} day(s) requires supporting documentation (policy threshold: ${ev.policy.requires_document_after_days} day(s)).`,
          code: 'DOCUMENTATION_REQUIRED',
          threshold_days: ev.policy.requires_document_after_days,
        },
      };
    }

    if (ev.overlapping_leaves.length > 0) {
      return {
        statusCode: 409,
        body: {
          error: `Leave dates overlap with an existing ${ev.overlapping_leaves[0].status} ${ev.overlapping_leaves[0].leave_type} (${ev.overlapping_leaves[0].start_date} – ${ev.overlapping_leaves[0].end_date}).`,
          code: 'OVERLAPPING_LEAVE',
          overlapping_leaves: ev.overlapping_leaves,
        },
      };
    }

    if (!ev.balance_check.sufficient) {
      const deficit = ev.balance_check.years.find((y) => y.remaining_after < 0)!;
      return {
        statusCode: 409,
        body: {
          error: `Insufficient ${ev.policy.leave_type} balance for ${deficit.year}: requested ${deficit.requested}d, remaining ${Math.max(0, deficit.entitlement - deficit.approved_used)}d of ${deficit.entitlement}d.`,
          code: 'INSUFFICIENT_LEAVE_BALANCE',
          balance_check: ev.balance_check,
        },
      };
    }

    const emp = loadEmployeeWithShift(db, input.employee_id)!;
    const info = db
      .prepare(
        `INSERT INTO leaves
          (employee_id, leave_type, start_date, end_date, days_count, day_portion, calendar_days,
           excluded_days_json, eligible_dates_json, reason, status,
           attachment_name, attachment_mime, attachment_data, document_reference,
           created_by_user_id, created_by_username)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?, ?, ?, ?, ?)`
      )
      .run(
        emp.id,
        ev.policy.leave_type,
        ev.start_date,
        ev.end_date,
        ev.total_eligible_credits,
        ev.day_portion,
        ev.calendar_days,
        JSON.stringify(ev.excluded_days),
        JSON.stringify(ev.eligible_days.map((d) => ({ date: d.date, year: d.year, fraction: d.fraction }))),
        reason,
        docCheck.attachmentName,
        docCheck.attachmentMime,
        docCheck.attachmentData,
        docCheck.documentReference,
        input.actor.userId,
        input.actor.username
      );
    const leaveId = Number(info.lastInsertRowid);

    const insAlloc = db.prepare(`
      INSERT INTO leave_day_allocations
        (leave_id, employee_id, leave_date, leave_year, day_fraction, day_portion, attendance_applied, conflict_preserved, conflict_note)
      VALUES (?, ?, ?, ?, ?, ?, 0, 0, '')
    `);
    for (const day of ev.eligible_days) {
      insAlloc.run(leaveId, emp.id, day.date, day.year, day.fraction, day.portion);
    }

    db.prepare(
      `INSERT INTO leave_audit_log
        (leave_id, employee_id, action, previous_status, new_status, days_affected, applied_dates_json,
         reason, notes, actor_user_id, actor_username, actor_role, acted_at_utc, acted_at_manila, ip_address)
       VALUES (?, ?, 'CREATED', '', 'Pending', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      leaveId,
      emp.id,
      ev.total_eligible_credits,
      JSON.stringify(ev.eligible_days.map((d) => d.date)),
      reason,
      docCheck.summaryRef,
      input.actor.userId,
      input.actor.username,
      input.actor.role,
      serverIso,
      manilaNow.isoTimestamp,
      input.actor.ipAddress
    );

    db.prepare(
      `INSERT INTO notifications (title, message, category, priority, is_read, action_module, action_entity_id)
       VALUES (?, ?, 'Attendance Alerts', 'Medium', 0, 'leaves', ?)`
    ).run(
      `New leave request submitted by ${emp.full_name}`,
      `${ev.policy.leave_type} (${ev.start_date} – ${ev.end_date}, ${ev.total_eligible_credits} eligible day${ev.total_eligible_credits === 1 ? '' : 's'}) awaiting approval.`,
      leaveId
    );

    recordGeneralAudit(
      db,
      input.actor.username,
      `Filed ${ev.policy.leave_type} #${leaveId} for ${emp.full_name} (${ev.start_date} – ${ev.end_date}, ${ev.total_eligible_credits}d)`,
      'Leaves',
      'Success',
      input.actor.ipAddress
    );

    return {
      statusCode: 201,
      body: {
        id: leaveId,
        status: 'Pending',
        days_count: ev.total_eligible_credits,
        calendar_days: ev.calendar_days,
        day_portion: ev.day_portion,
        eligible_dates: ev.eligible_days.map((d) => d.date),
        excluded_days: ev.excluded_days,
        credits_by_year: ev.credits_by_year,
        conflicting_punch_dates: ev.conflicting_punch_dates,
      },
    };
  });

  return tx.immediate();
}

export function reviewLeaveRequest(
  db: Database.Database,
  input: {
    leaveId: number;
    status: 'Approved' | 'Rejected';
    reviewer_notes?: string;
    conflict_resolution?: 'BLOCK' | 'PRESERVE_PUNCHES';
    actor: ActorContext;
    departmentScopeId: number | null;
    nowMs: number;
  }
): EngineOutcome {
  const reviewerNotes = (input.reviewer_notes || '').trim().slice(0, 500);
  const conflictResolution = input.conflict_resolution || 'BLOCK';
  const manilaNow = toManilaParts(input.nowMs);
  const serverIso = new Date(input.nowMs).toISOString();

  const tx = db.transaction((): EngineOutcome => {
    const leave = db
      .prepare(
        `SELECT l.*, e.employee_code, e.full_name as employee_name, e.department_id
         FROM leaves l JOIN employees e ON l.employee_id = e.id
         WHERE l.id = ?`
      )
      .get(input.leaveId) as
      | {
          id: number;
          employee_id: number;
          employee_code: string;
          employee_name: string;
          department_id: number;
          leave_type: string;
          start_date: string;
          end_date: string;
          days_count: number;
          day_portion: LeaveDayPortion;
          reason: string;
          status: string;
        }
      | undefined;

    if (!leave) {
      return { statusCode: 404, body: { error: 'Leave request not found.', code: 'NOT_FOUND' } };
    }
    if (input.departmentScopeId !== null && input.departmentScopeId !== leave.department_id) {
      return {
        statusCode: 403,
        body: {
          error: 'Access denied: Department Heads can only review leaves for their own department.',
          code: 'FORBIDDEN',
        },
      };
    }

    // Prevent duplicate approvals / rejections
    if (leave.status !== 'Pending') {
      return {
        statusCode: 409,
        body: {
          error: `Leave request #${leave.id} is already ${leave.status} and cannot be reviewed again.`,
          code: 'ALREADY_REVIEWED',
          current_status: leave.status,
        },
      };
    }

    if (input.status === 'Rejected') {
      const upd = db
        .prepare(
          `UPDATE leaves
           SET status = 'Rejected', reviewed_by = ?, reviewed_by_user_id = ?,
               reviewed_at = ?, reviewed_at_utc = ?, reviewer_notes = ?
           WHERE id = ? AND status = 'Pending'`
        )
        .run(
          input.actor.username,
          input.actor.userId,
          `${manilaNow.isoDate} ${manilaNow.time24}`,
          serverIso,
          reviewerNotes,
          leave.id
        );
      if (upd.changes === 0) {
        return {
          statusCode: 409,
          body: { error: 'Leave request was concurrently reviewed.', code: 'ALREADY_REVIEWED' },
        };
      }

      db.prepare(
        `INSERT INTO leave_audit_log
          (leave_id, employee_id, action, previous_status, new_status, days_affected, applied_dates_json,
           reason, notes, actor_user_id, actor_username, actor_role, acted_at_utc, acted_at_manila, ip_address)
         VALUES (?, ?, 'REJECTED', 'Pending', 'Rejected', 0, '[]', ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        leave.id,
        leave.employee_id,
        leave.reason,
        reviewerNotes,
        input.actor.userId,
        input.actor.username,
        input.actor.role,
        serverIso,
        manilaNow.isoTimestamp,
        input.actor.ipAddress
      );

      recordGeneralAudit(
        db,
        input.actor.username,
        `Rejected ${leave.leave_type} #${leave.id} for ${leave.employee_name}`,
        'Leaves',
        'Success',
        input.actor.ipAddress
      );

      return {
        statusCode: 200,
        body: {
          success: true,
          id: leave.id,
          status: 'Rejected',
          reviewed_by: input.actor.username,
          reviewed_at_utc: serverIso,
        },
      };
    }

    // APPROVED PATH — Re-evaluate fresh inside IMMEDIATE transaction for race-free balance, overlap & punch conflict integrity
    const evalRes = evaluateLeaveRequestDates(db, {
      employeeId: leave.employee_id,
      leaveType: leave.leave_type,
      startDate: leave.start_date,
      endDate: leave.end_date,
      dayPortion: leave.day_portion || 'FULL',
      excludeLeaveId: leave.id,
    });
    if (!evalRes.ok) {
      return { statusCode: evalRes.statusCode, body: { error: evalRes.error, code: evalRes.code } };
    }
    const ev = evalRes.evaluation;

    // Re-check overlap against other Approved leaves
    const approvedOverlaps = ev.overlapping_leaves.filter((o) => o.status === 'Approved');
    if (approvedOverlaps.length > 0) {
      return {
        statusCode: 409,
        body: {
          error: `Cannot approve: overlaps with already Approved ${approvedOverlaps[0].leave_type} (${approvedOverlaps[0].start_date} – ${approvedOverlaps[0].end_date}).`,
          code: 'OVERLAPPING_LEAVE',
          overlapping_leaves: approvedOverlaps,
        },
      };
    }

    // Re-check conflicting valid punches for FULL non-OB leave
    const isOb = ev.policy.attendance_status === 'OB';
    const isHalfDay = ev.day_portion === 'HALF_AM' || ev.day_portion === 'HALF_PM';
    if (!isOb && !isHalfDay && ev.conflicting_punch_dates.length > 0 && conflictResolution !== 'PRESERVE_PUNCHES') {
      return {
        statusCode: 409,
        body: {
          error: `Conflicting verified attendance punches exist on ${ev.conflicting_punch_dates.map((c) => c.date).join(', ')}. Reject or re-submit with conflict_resolution="PRESERVE_PUNCHES" to keep valid punches intact.`,
          code: 'CONFLICTING_VALID_PUNCHES',
          conflicting_punch_dates: ev.conflicting_punch_dates,
        },
      };
    }

    // Compute final credits actually charged (excluding conflict-preserved dates when PRESERVE_PUNCHES is used)
    const chargedDays = ev.eligible_days.filter(
      (d) => !(conflictResolution === 'PRESERVE_PUNCHES' && !isOb && !isHalfDay && d.has_valid_punch)
    );
    if (chargedDays.length === 0) {
      return {
        statusCode: 409,
        body: {
          error: 'All eligible dates already have verified attendance punches; no leave days can be applied.',
          code: 'CONFLICTING_VALID_PUNCHES',
          conflicting_punch_dates: ev.conflicting_punch_dates,
        },
      };
    }

    // Re-check per-year balance underflow atomically inside IMMEDIATE tx
    if (ev.policy.track_balance && !ev.policy.allow_negative_balance) {
      const chargedByYear: Record<number, number> = {};
      for (const d of chargedDays) {
        chargedByYear[d.year] = Math.round(((chargedByYear[d.year] || 0) + d.fraction) * 100) / 100;
      }
      for (const [yrStr, reqCredits] of Object.entries(chargedByYear)) {
        const yr = Number(yrStr);
        const usage = getYearLeaveUsage(db, leave.employee_id, ev.policy.leave_type, yr, leave.id);
        const rem = Math.round((ev.policy.annual_entitlement - usage.approvedUsed - reqCredits) * 100) / 100;
        if (rem < -1e-9) {
          return {
            statusCode: 409,
            body: {
              error: `Insufficient ${ev.policy.leave_type} balance in ${yr}: needs ${reqCredits}d, only ${Math.max(0, ev.policy.annual_entitlement - usage.approvedUsed)}d remaining.`,
              code: 'INSUFFICIENT_LEAVE_BALANCE',
              year: yr,
              requested: reqCredits,
              remaining: Math.max(0, ev.policy.annual_entitlement - usage.approvedUsed),
            },
          };
        }
      }
    }

    const totalChargedCredits = Math.round(chargedDays.reduce((acc, d) => acc + d.fraction, 0) * 100) / 100;

    // Replace per-day allocations with authoritative approval-time breakdown + pre-snapshots
    db.prepare('DELETE FROM leave_day_allocations WHERE leave_id = ?').run(leave.id);
    const insAlloc = db.prepare(`
      INSERT INTO leave_day_allocations
        (leave_id, employee_id, leave_date, leave_year, day_fraction, day_portion,
         attendance_applied, conflict_preserved, conflict_note, pre_snapshot_json)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const appliedDates: string[] = [];
    const preservedConflictDates: string[] = [];
    const realtimeEvents: NonNullable<EngineOutcome['realtimeAttendanceEvents']> = [];

    for (const day of ev.eligible_days) {
      const preSnap = readAttendanceSnapshot(db, leave.employee_id, day.date);
      const shouldPreservePunch = !isOb && !isHalfDay && day.has_valid_punch && conflictResolution === 'PRESERVE_PUNCHES';

      if (shouldPreservePunch) {
        preservedConflictDates.push(day.date);
        insAlloc.run(
          leave.id,
          leave.employee_id,
          day.date,
          day.year,
          0,
          day.portion,
          0,
          1,
          `Preserved verified punch (${preSnap?.time_in || '-'} / ${preSnap?.time_out || '-'})`,
          JSON.stringify(preSnap)
        );
        continue;
      }

      appliedDates.push(day.date);
      insAlloc.run(
        leave.id,
        leave.employee_id,
        day.date,
        day.year,
        day.fraction,
        day.portion,
        1,
        0,
        '',
        JSON.stringify(preSnap)
      );

      const attStatus: AttendanceStatus = isOb ? 'OB' : 'On Leave';
      const portionLabel =
        day.portion === 'HALF_AM' ? 'Half-Day (AM) ' : day.portion === 'HALF_PM' ? 'Half-Day (PM) ' : '';
      const remark = `Approved ${portionLabel}${ev.policy.leave_type} (#${leave.id})`;

      if (preSnap) {
        if (isHalfDay && day.has_valid_punch) {
          // Preserve worked half-day punches intact while annotating approved half-day leave
          const combinedRemarks = preSnap.remarks ? `${preSnap.remarks} · ${remark}` : remark;
          db.prepare('UPDATE attendance_records SET remarks = ? WHERE employee_id = ? AND date = ?').run(
            combinedRemarks,
            leave.employee_id,
            day.date
          );
        } else if (isOb) {
          db.prepare(
            `UPDATE attendance_records
             SET status = 'OB', remarks = ?
             WHERE employee_id = ? AND date = ?`
          ).run(remark, leave.employee_id, day.date);
        } else {
          db.prepare(
            `UPDATE attendance_records
             SET time_in = NULL, time_out = NULL, work_hours = '-', status = ?, device_name = 'Leave Approved', remarks = ?
             WHERE employee_id = ? AND date = ?`
          ).run(attStatus, remark, leave.employee_id, day.date);
        }
      } else {
        db.prepare(
          `INSERT INTO attendance_records
            (employee_id, date, time_in, time_out, work_hours, status, device_name, remarks)
           VALUES (?, ?, NULL, NULL, '-', ?, 'Leave Approved', ?)`
        ).run(leave.employee_id, day.date, attStatus, remark);
      }

      db.prepare(
        `INSERT INTO attendance_events
          (event_uid, employee_id, device_id, device_name, attendance_date, punch_type, punch_time,
           server_timestamp_utc, manila_timestamp, decision, decision_code, decision_reason, source)
         VALUES (?, ?, NULL, ?, ?, 'reconcile', ?, ?, ?, 'ACCEPTED', 'LEAVE_APPROVED', ?, 'leaves')`
      ).run(
        `lv-${leave.id}-${day.date}-${crypto.randomBytes(4).toString('hex')}`,
        leave.employee_id,
        `Leave Approved (${input.actor.username})`,
        day.date,
        manilaNow.time12,
        serverIso,
        manilaNow.isoTimestamp,
        `${remark} (${day.fraction}d)`
      );

      realtimeEvents.push({
        employee_id: leave.employee_id,
        employee_code: leave.employee_code,
        department_id: leave.department_id,
        shift_date: day.date,
        action: 'LEAVE_APPROVED',
        status: attStatus,
        source: 'leaves',
      });
    }

    const upd = db
      .prepare(
        `UPDATE leaves
         SET status = 'Approved',
             days_count = ?,
             excluded_days_json = ?,
             eligible_dates_json = ?,
             reviewed_by = ?,
             reviewed_by_user_id = ?,
             reviewed_at = ?,
             reviewed_at_utc = ?,
             reviewer_notes = ?
         WHERE id = ? AND status = 'Pending'`
      )
      .run(
        totalChargedCredits,
        JSON.stringify(ev.excluded_days),
        JSON.stringify(appliedDates),
        input.actor.username,
        input.actor.userId,
        `${manilaNow.isoDate} ${manilaNow.time24}`,
        serverIso,
        reviewerNotes,
        leave.id
      );

    if (upd.changes === 0) {
      return { statusCode: 409, body: { error: 'Leave request was concurrently reviewed.', code: 'ALREADY_REVIEWED' } };
    }

    db.prepare(
      `INSERT INTO leave_audit_log
        (leave_id, employee_id, action, previous_status, new_status, days_affected, applied_dates_json,
         reason, notes, actor_user_id, actor_username, actor_role, acted_at_utc, acted_at_manila, ip_address)
       VALUES (?, ?, 'APPROVED', 'Pending', 'Approved', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      leave.id,
      leave.employee_id,
      totalChargedCredits,
      JSON.stringify(appliedDates),
      leave.reason,
      [reviewerNotes, preservedConflictDates.length > 0 ? `Preserved punched dates: ${preservedConflictDates.join(', ')}` : '']
        .filter(Boolean)
        .join(' · '),
      input.actor.userId,
      input.actor.username,
      input.actor.role,
      serverIso,
      manilaNow.isoTimestamp,
      input.actor.ipAddress
    );

    recordGeneralAudit(
      db,
      input.actor.username,
      `Approved ${ev.policy.leave_type} #${leave.id} for ${leave.employee_name} across ${appliedDates.length} eligible date(s) (${totalChargedCredits}d)`,
      'Leaves',
      'Success',
      input.actor.ipAddress
    );

    return {
      statusCode: 200,
      body: {
        success: true,
        id: leave.id,
        status: 'Approved',
        days_count: totalChargedCredits,
        charged_days: totalChargedCredits,
        applied_dates: appliedDates,
        excluded_days: ev.excluded_days,
        preserved_conflict_dates: preservedConflictDates,
        preserved_punch_dates: preservedConflictDates,
        reviewed_by: input.actor.username,
        reviewed_at_utc: serverIso,
      },
      realtimeAttendanceEvents: realtimeEvents,
    };
  });

  return tx.immediate();
}

export function cancelLeaveRequest(
  db: Database.Database,
  input: {
    leaveId: number;
    cancel_reason: string;
    canCancelApproved: boolean;
    employeeSelfId: number | null;
    departmentScopeId: number | null;
    actor: ActorContext;
    nowMs: number;
  }
): EngineOutcome {
  const cancelReason = (input.cancel_reason || '').trim();
  if (cancelReason.length < 5) {
    return {
      statusCode: 400,
      body: { error: 'A cancellation reason (at least 5 characters) is required.', code: 'CANCEL_REASON_REQUIRED' },
    };
  }

  const manilaNow = toManilaParts(input.nowMs);
  const serverIso = new Date(input.nowMs).toISOString();

  const tx = db.transaction((): EngineOutcome => {
    const leave = db
      .prepare(
        `SELECT l.*, e.employee_code, e.full_name as employee_name, e.department_id
         FROM leaves l JOIN employees e ON l.employee_id = e.id
         WHERE l.id = ?`
      )
      .get(input.leaveId) as
      | {
          id: number;
          employee_id: number;
          employee_code: string;
          employee_name: string;
          department_id: number;
          leave_type: string;
          start_date: string;
          end_date: string;
          days_count: number;
          status: string;
          reviewed_at_utc: string | null;
        }
      | undefined;

    if (!leave) {
      return { statusCode: 404, body: { error: 'Leave request not found.', code: 'NOT_FOUND' } };
    }

    if (input.employeeSelfId !== null && leave.employee_id !== input.employeeSelfId) {
      return { statusCode: 403, body: { error: 'Access denied: cannot cancel another employee’s leave.', code: 'FORBIDDEN' } };
    }
    if (input.departmentScopeId !== null && input.departmentScopeId !== leave.department_id) {
      return { statusCode: 403, body: { error: 'Access denied: leave is outside your department.', code: 'FORBIDDEN' } };
    }

    if (leave.status === 'Rejected' || leave.status === 'Cancelled') {
      return {
        statusCode: 409,
        body: { error: `Leave #${leave.id} is already ${leave.status}.`, code: 'INVALID_CANCEL_STATE' },
      };
    }

    if (leave.status === 'Approved' && !input.canCancelApproved) {
      return {
        statusCode: 403,
        body: {
          error: 'Only authorized HR / Administrators / Department Heads may cancel an already Approved leave.',
          code: 'FORBIDDEN',
        },
      };
    }

    const previousStatus = leave.status;
    const restoredDates: string[] = [];
    const realtimeEvents: NonNullable<EngineOutcome['realtimeAttendanceEvents']> = [];

    if (previousStatus === 'Approved') {
      const allocs = db
        .prepare('SELECT * FROM leave_day_allocations WHERE leave_id = ? AND attendance_applied = 1')
        .all(leave.id) as Array<{
        id: number;
        leave_date: string;
        pre_snapshot_json: string | null;
      }>;

      for (const alloc of allocs) {
        const preSnap: AttendanceSnapshot | null = alloc.pre_snapshot_json
          ? (JSON.parse(alloc.pre_snapshot_json) as AttendanceSnapshot | null)
          : null;

        // Check if a genuine kiosk punch occurred on that date after approval
        const newerKiosk = leave.reviewed_at_utc
          ? (db
              .prepare(
                `SELECT id FROM attendance_events
                 WHERE employee_id = ? AND attendance_date = ? AND source IN ('kiosk', 'kiosk_offline')
                   AND decision = 'ACCEPTED' AND server_timestamp_utc > ?
                 LIMIT 1`
              )
              .get(leave.employee_id, alloc.leave_date, leave.reviewed_at_utc) as { id: number } | undefined)
          : undefined;

        if (!newerKiosk) {
          if (preSnap) {
            db.prepare(
              `UPDATE attendance_records
               SET time_in = ?, time_out = ?, time_in_utc = ?, time_out_utc = ?,
                   work_hours = ?, late_minutes = ?, undertime_minutes = ?, overtime_minutes = ?,
                   status = ?, device_name = ?, remarks = ?
               WHERE employee_id = ? AND date = ?`
            ).run(
              preSnap.time_in,
              preSnap.time_out,
              preSnap.time_in_utc,
              preSnap.time_out_utc,
              preSnap.work_hours,
              preSnap.late_minutes,
              preSnap.undertime_minutes,
              preSnap.overtime_minutes,
              preSnap.status,
              preSnap.device_name,
              preSnap.remarks || `Restored after cancelling leave #${leave.id}`,
              leave.employee_id,
              alloc.leave_date
            );
          } else {
            db.prepare(
              `DELETE FROM attendance_records
               WHERE employee_id = ? AND date = ? AND device_name = 'Leave Approved'`
            ).run(leave.employee_id, alloc.leave_date);
          }
          restoredDates.push(alloc.leave_date);
        }

        db.prepare('UPDATE leave_day_allocations SET attendance_applied = 0 WHERE id = ?').run(alloc.id);

        db.prepare(
          `INSERT INTO attendance_events
            (event_uid, employee_id, device_id, device_name, attendance_date, punch_type, punch_time,
             server_timestamp_utc, manila_timestamp, decision, decision_code, decision_reason, source)
           VALUES (?, ?, NULL, ?, ?, 'reconcile', ?, ?, ?, 'ACCEPTED', 'LEAVE_CANCELLED', ?, 'leaves')`
        ).run(
          `lv-${leave.id}-can-${alloc.leave_date}-${crypto.randomBytes(4).toString('hex')}`,
          leave.employee_id,
          `Leave Cancelled (${input.actor.username})`,
          alloc.leave_date,
          manilaNow.time12,
          serverIso,
          manilaNow.isoTimestamp,
          `Cancelled ${leave.leave_type} #${leave.id}: ${cancelReason}`
        );

        realtimeEvents.push({
          employee_id: leave.employee_id,
          employee_code: leave.employee_code,
          department_id: leave.department_id,
          shift_date: alloc.leave_date,
          action: 'LEAVE_CANCELLED',
          status: preSnap?.status,
          source: 'leaves',
        });
      }
    }

    db.prepare(
      `UPDATE leaves
       SET status = 'Cancelled', cancelled_by = ?, cancelled_at_utc = ?, cancel_reason = ?
       WHERE id = ?`
    ).run(input.actor.username, serverIso, cancelReason, leave.id);

    db.prepare(
      `INSERT INTO leave_audit_log
        (leave_id, employee_id, action, previous_status, new_status, days_affected, applied_dates_json,
         reason, notes, actor_user_id, actor_username, actor_role, acted_at_utc, acted_at_manila, ip_address)
       VALUES (?, ?, 'CANCELLED', ?, 'Cancelled', ?, ?, ?, '', ?, ?, ?, ?, ?, ?)`
    ).run(
      leave.id,
      leave.employee_id,
      previousStatus,
      previousStatus === 'Approved' ? leave.days_count : 0,
      JSON.stringify(restoredDates),
      cancelReason,
      input.actor.userId,
      input.actor.username,
      input.actor.role,
      serverIso,
      manilaNow.isoTimestamp,
      input.actor.ipAddress
    );

    recordGeneralAudit(
      db,
      input.actor.username,
      `Cancelled ${previousStatus} ${leave.leave_type} #${leave.id} for ${leave.employee_name}: ${cancelReason}`,
      'Leaves',
      'Warning',
      input.actor.ipAddress
    );

    return {
      statusCode: 200,
      body: {
        success: true,
        id: leave.id,
        status: 'Cancelled',
        previous_status: previousStatus,
        restored_dates: restoredDates,
        cancelled_by: input.actor.username,
        cancelled_at_utc: serverIso,
      },
      realtimeAttendanceEvents: realtimeEvents,
    };
  });

  return tx.immediate();
}
