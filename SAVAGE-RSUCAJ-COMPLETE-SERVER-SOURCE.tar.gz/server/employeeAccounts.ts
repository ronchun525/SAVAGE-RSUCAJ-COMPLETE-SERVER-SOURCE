import type Database from 'better-sqlite3';

export interface EmployeeAccountIdentity {
  id: number;
  employee_code: string;
  full_name: string;
  department_id: number;
  status: string;
}

export type EmployeeAccountLinkResult =
  | { ok: true; employee: EmployeeAccountIdentity }
  | { ok: false; status: 400 | 404 | 409; code: string; error: string };

/** A portal account cannot claim an arbitrary employee ID or link to two identities. */
export function resolveEmployeeAccountLink(
  db: Pick<Database.Database, 'prepare'>,
  rawEmployeeId: unknown,
  excludeUserId = 0,
): EmployeeAccountLinkResult {
  const id = typeof rawEmployeeId === 'number' || typeof rawEmployeeId === 'string'
    ? Number(rawEmployeeId) : NaN;
  if (!Number.isSafeInteger(id) || id <= 0) {
    return { ok: false, status: 400, code: 'EMPLOYEE_LINK_REQUIRED', error: 'Select a valid employee profile before creating an Employee account.' };
  }
  const employee = db.prepare('SELECT id, employee_code, full_name, department_id, status FROM employees WHERE id = ?')
    .get(id) as EmployeeAccountIdentity | undefined;
  if (!employee) {
    return { ok: false, status: 404, code: 'EMPLOYEE_NOT_FOUND', error: 'Linked employee profile not found.' };
  }
  if (employee.status !== 'Active') {
    return { ok: false, status: 400, code: 'EMPLOYEE_INACTIVE', error: 'Only active employees can receive a portal account.' };
  }
  const linked = db.prepare("SELECT id FROM users WHERE employee_id = ? AND id != ?")
    .get(id, excludeUserId) as { id: number } | undefined;
  if (linked) {
    return { ok: false, status: 409, code: 'EMPLOYEE_ACCOUNT_EXISTS', error: 'This employee already has a portal account. Reactivate or manage the existing account in System Settings.' };
  }
  return { ok: true, employee };
}
