/**
 * BUILD 18 — Android -> existing portal attendance engine compatibility bridge.
 * This is NOT an independent attendance store. Requests end in processKioskPunch,
 * so HR reports, duplicate policy and immutable attendance_events stay canonical.
 * A device HMAC proves possession of its provisioned credential and binds event
 * metadata, NOT independent hardware attestation or server-side facial inference.
 */
import crypto from 'node:crypto';
import type { Router, Request, Response, RequestHandler } from 'express';
import type Database from 'better-sqlite3';
import { getClientIp } from './security.ts';
import { logAudit } from './db.ts';
import { processKioskPunch } from './attendanceEngine.ts';
import { verifyBiometricEvidenceEnvelope } from './kioskOfflineQueue.ts';
import type { StoredDeviceRow } from './api.ts';
import type { RealtimeHub } from './realtimeHub.ts';
import { validateAndroidPunch, validateAndroidEnrollment } from './androidBridgeProtocol.ts';

interface BridgeConfig {
  db: () => Database.Database;
  findDevice: (token: string) => StoredDeviceRow | null;
  nowMs: () => number;
  realtimeHub: RealtimeHub;
  rateLimit: RequestHandler;
}

function bearerToken(req: Request): string {
  const bearer = /^Bearer\s+([^\s]+)$/i.exec(req.header('Authorization') || '');
  return bearer?.[1] || (typeof req.headers['x-kiosk-token'] === 'string' ? req.headers['x-kiosk-token'] : '');
}

function authenticatedDevice(req: Request, res: Response, config: BridgeConfig): StoredDeviceRow | null {
  const token = bearerToken(req);
  if (!token) {
    res.status(401).json({ code: 'MISSING_TOKEN', message: 'Kiosk token has not been provisioned.' });
    return null;
  }
  const device = config.findDevice(token);
  if (!device || device.is_revoked === 1) {
    res.status(403).json({ code: 'INVALID_OR_REVOKED_DEVICE', message: 'Device token is invalid or revoked.' });
    return null;
  }
  const suppliedName = req.header('X-Kiosk-Device-Id');
  if (suppliedName !== device.name) {
    res.status(403).json({ code: 'DEVICE_ID_MISMATCH', message: 'Device ID does not match provisioned credential.' });
    return null;
  }
  return device;
}

function enrollmentKey(): Buffer | null {
  const raw = process.env.KIOSK_TEMPLATE_ENCRYPTION_KEY?.trim();
  return raw && /^[a-f0-9]{64}$/i.test(raw) ? Buffer.from(raw, 'hex') : null;
}

export function registerAndroidBridgeRoutes(router: Router, config: BridgeConfig): void {
  router.get('/v1/kiosk/device-info', config.rateLimit, (req, res) => {
    const device = authenticatedDevice(req, res, config);
    if (!device) return;
    res.json({
      device_id: device.id,
      device_name: device.name,
      server_time_utc: new Date(config.nowMs()).toISOString(),
      bridge_contract: 'SAVAGE_ANDROID_V1',
    });
  });

  router.get('/v1/kiosk/employees', config.rateLimit, (req, res) => {
    const device = authenticatedDevice(req, res, config);
    if (!device) return;
    const q = typeof req.query.q === 'string' ? req.query.q.trim() : '';
    if (q.length > 100) {
      res.status(400).json({ code: 'INVALID_QUERY', message: 'Search query too long.' });
      return;
    }
    const rows = config.db().prepare(`
      SELECT e.employee_code AS employee_id, e.full_name AS employee_name,
             d.name AS department, p.name AS role,
             CASE WHEN t.employee_id IS NULL THEN 0 ELSE 1 END AS is_face_enrolled
      FROM employees e
      JOIN departments d ON d.id=e.department_id
      JOIN positions p ON p.id=e.position_id
      LEFT JOIN kiosk_face_templates t ON t.employee_id=e.id
      WHERE e.status='Active'
        AND (? = '' OR e.employee_code LIKE ? OR e.full_name LIKE ?)
      ORDER BY e.full_name LIMIT 500
    `).all(q, `%${q}%`, `%${q}%`) as Array<Record<string, unknown>>;
    res.json({ employees: rows.map((row) => ({ ...row, is_face_enrolled: row.is_face_enrolled === 1 })) });
  });

  router.post('/v1/kiosk/employees/enroll-template', config.rateLimit, (req, res) => {
    const device = authenticatedDevice(req, res, config);
    if (!device) return;
    const key = enrollmentKey();
    if (!key) {
      res.status(503).json({ code: 'ENROLLMENT_ENCRYPTION_UNCONFIGURED', message: 'Server-side encrypted enrollment is disabled until its encryption key is configured.' });
      return;
    }
    const body = req.body ?? {};
    const { employee_id, employee_name, embedding_sha256, composite_embedding, enrolled_at_ms } = body;
    const enrollmentValidation = validateAndroidEnrollment(body, req.header('Idempotency-Key'), device.name, config.nowMs());
    if (!enrollmentValidation.valid) {
      res.status(422).json({ code: enrollmentValidation.code, message: 'Enrollment payload or binding is invalid.' });
      return;
    }
    const db = config.db();
    const emp = db.prepare("SELECT id, full_name FROM employees WHERE employee_code = ? AND status = 'Active'")
      .get(employee_id) as { id: number; full_name: string } | undefined;
    if (!emp || employee_name !== emp.full_name) {
      res.status(404).json({ code: 'EMPLOYEE_MISMATCH', message: 'No matching active employee in admin masterlist.' });
      return;
    }
    // Kotlin enrollment hash: UTF-8 employeeId + NUL + fullName + NUL + Float32LE embedding.
    const embeddingBuffer = Buffer.allocUnsafe(composite_embedding.length * 4);
    composite_embedding.forEach((x: number, i: number) => embeddingBuffer.writeFloatLE(x, i * 4));
    const computedHash = embedding_sha256.toLowerCase();
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
    cipher.setAAD(Buffer.from(employee_id, 'utf8'));
    const ciphertext = Buffer.concat([cipher.update(embeddingBuffer), cipher.final()]);
    const authTag = cipher.getAuthTag();
    db.prepare(`INSERT INTO kiosk_face_templates
      (employee_id, template_sha256, encrypted_embedding, iv_hex, tag_hex, device_id, enrolled_at_utc)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(employee_id) DO UPDATE SET
        template_sha256=excluded.template_sha256, encrypted_embedding=excluded.encrypted_embedding,
        iv_hex=excluded.iv_hex, tag_hex=excluded.tag_hex, device_id=excluded.device_id,
        enrolled_at_utc=excluded.enrolled_at_utc`)
      .run(emp.id, computedHash, ciphertext.toString('base64'), iv.toString('hex'), authTag.toString('hex'), device.id, new Date(enrolled_at_ms).toISOString());
    logAudit(db, device.name, `Encrypted face template enrollment for ${employee_id}`, 'Biometrics', 'Success', getClientIp(req));
    res.status(201).json({ status: 'ENROLLED', message: 'Encrypted template securely accepted by admin backend.' });
  });

  router.post('/v1/kiosk/attendance', config.rateLimit, (req, res) => {
    const device = authenticatedDevice(req, res, config);
    if (!device) return;
    const input = req.body ?? {};
    const { event_id, employee_id, action, kiosk_device_id, captured_at_ms,
      biometric_confidence, liveness_score, anti_spoofing_score, offline_queued, biometric_evidence } = input;
    const validation = validateAndroidPunch(input, {
      idempotencyKey: req.header('Idempotency-Key'),
      eventTimestamp: req.header('X-Event-Timestamp-Ms'),
      digest: req.header('X-Payload-Digest'),
    }, device.name, config.nowMs());
    if (!validation.valid) {
      res.status(422).json({
        status: 'REJECTED', code: validation.code,
        message: validation.code === 'OFFLINE_CAPTURE_ATTESTATION_REQUIRED'
          ? 'Offline punch retained on device for authorized review; capture-time biometric attestation is not available.'
          : 'Invalid or unverified attendance request.',
      });
      return;
    }
    const capturedAtUtc = new Date(captured_at_ms).toISOString();
    // HMAC binding is mandatory, including online punches. It is NOT remote AI attestation.
    const verified = verifyBiometricEvidenceEnvelope(device.api_token, {
      deviceId: device.id, eventUid: event_id, employeeCode: employee_id,
      punchType: action, capturedAtUtc,
    }, biometric_evidence);
    if (!verified.valid || biometric_evidence?.liveness_verified !== true || biometric_evidence?.match_verified !== true) {
      res.status(422).json({ status: 'REJECTED', code: 'BIOMETRIC_EVIDENCE_INVALID', message: verified.reason || 'Positive liveness and identity verification are required.' });
      return;
    }
    const db = config.db();
    const outcome = processKioskPunch(db, {
      device, employeeCode: employee_id, actionRaw: action, eventUid: event_id,
      deviceTimestamp: capturedAtUtc, offlineReplay: offline_queued === true,
      clientIp: getClientIp(req), serverNowUtc: config.nowMs(),
      monotonicSeq: biometric_evidence.monotonic_seq,
      deviceBootId: biometric_evidence.device_boot_id,
      biometricEvidenceHash: verified.evidenceHash ?? null, biometricBound: true,
      captureMetadataJson: JSON.stringify({ bridge: 'android-v1', device_id: device.id, captured_at_utc: capturedAtUtc }),
    });
    const body = outcome.body as Record<string, unknown>;
    const employee = db.prepare('SELECT id, full_name, employee_code, department_id FROM employees WHERE employee_code=?')
      .get(employee_id) as { id: number; full_name: string; employee_code: string; department_id: number } | undefined;
    const period = String(body.shift_date || '');
    const accepted = outcome.statusCode === 200 || outcome.statusCode === 201;
    const idempotentReplay = body.action === 'duplicate_ignored';
    const originalAccepted = !idempotentReplay || body.original_decision === 'ACCEPTED';
    const duplicateAction = outcome.statusCode === 409 && body.code === `DUPLICATE_${action}`;
    const attendanceRow = employee && period ? db.prepare('SELECT id FROM attendance_records WHERE employee_id = ? AND date = ?')
      .get(employee.id, period) as { id: number } | undefined : undefined;
    if (accepted && originalAccepted) {
      if (!idempotentReplay && employee) {
        config.realtimeHub.emitAttendanceUpdated({
          event_uid: event_id, employee_id: employee.id, employee_code: employee_id,
          department_id: employee.department_id, shift_date: period, action,
          status: typeof body.status === 'string' ? body.status : undefined,
          time: typeof body.time === 'string' ? body.time : null,
          source: offline_queued === true ? 'kiosk_offline' : 'kiosk', offline_replay: offline_queued === true,
        });
      }
      res.status(200).json({
        status: 'RECORDED', record_id: attendanceRow ? String(attendanceRow.id) : event_id,
        employee_id, employee_name: employee?.full_name || employee_id,
        action, recorded_date: period, recorded_time: body.time || '',
        realtime_dispatched: !idempotentReplay, idempotent_replay: idempotentReplay,
      });
      return;
    }
    if (duplicateAction) {
      res.status(409).json({ status: 'ALREADY_TAKEN', employee_id,
        employee_name: employee?.full_name || employee_id, action,
        recorded_time: body.existing_time_in || body.existing_time_out || '',
        attendance_period: period,
        message: body.error || 'Same attendance action already completed.' });
      return;
    }
    res.status(accepted ? 409 : outcome.statusCode).json({ status: 'REJECTED', code: body.code || 'ATTENDANCE_REJECTED',
      message: body.error || 'Attendance was rejected by the canonical backend.' });
  });

  // The backend already broadcasts attendance on successful /attendance above.
  // A client may request an acknowledgement but MUST NOT double-publish the event.
  router.post('/v1/kiosk/realtime/attendance-events', config.rateLimit, (req, res) => {
    const device = authenticatedDevice(req, res, config);
    if (!device) return;
    const eventId = req.body?.event_id;
    if (typeof eventId !== 'string' || req.header('Idempotency-Key') !== eventId) {
      res.status(422).json({ acknowledged: false, code: 'INVALID_EVENT_ID' });
      return;
    }
    const event = config.db().prepare('SELECT decision FROM attendance_events WHERE event_uid=? AND device_id=?')
      .get(eventId, device.id) as { decision: string } | undefined;
    if (!event || event.decision !== 'ACCEPTED') {
      res.status(404).json({ acknowledged: false, code: 'ATTENDANCE_EVENT_NOT_FOUND' });
      return;
    }
    res.json({ acknowledged: true, channels: ['server-managed-sse'] });
  });
}
