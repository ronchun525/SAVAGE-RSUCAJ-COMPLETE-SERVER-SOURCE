/** BUILD 42: bounded server-side image analysis bridge, no client biometrics trusted. */
import { spawn } from 'node:child_process';
import path from 'node:path';
import { resolveModelsDirectory } from './webKioskBiometrics.ts';

export interface CameraFrame { jpeg_b64: string; captured_at_ms: number }
export interface AttestationFrame {
  timestamp_ms: number; face_count: number; detection_confidence: number;
  quality_score: number; lighting_ok: boolean; sharpness_ok: boolean;
  frozen_frame: boolean; occlusion_suspected: boolean;
  bounding_box: { x: number; y: number; width: number; height: number };
  pad_score: number; liveness_score: number;
}
export type AttestationResult =
  | { ok: true; mode: 'probe'; frames?: never; embedding?: never }
  | { ok: true; mode: 'infer'; frames: AttestationFrame[]; embedding: number[] }
  | { ok: false; code: string; error: string };

const MAX_FRAMES = 5;
const MAX_BYTES = 1_950_000;
const MAX_OUTPUT = 30_000;
const MAX_PARALLEL = 2;
let inFlight = 0;

export function validateCameraFrames(value: unknown): value is CameraFrame[] {
  if (!Array.isArray(value) || value.length < 3 || value.length > MAX_FRAMES) return false;
  let prev = -Infinity;
  for (const frame of value) {
    if (!frame || typeof frame !== 'object' || Array.isArray(frame)) return false;
    if (Object.keys(frame).sort().join(',') !== 'captured_at_ms,jpeg_b64') return false;
    const { captured_at_ms, jpeg_b64 } = frame as Record<string, unknown>;
    if (typeof captured_at_ms !== 'number' || !Number.isSafeInteger(captured_at_ms) || captured_at_ms - prev < 80 ||
        typeof jpeg_b64 !== 'string' || jpeg_b64.length < 150 || jpeg_b64.length > 773_340 ||
        !/^[A-Za-z0-9+/]+={0,2}$/.test(jpeg_b64)) return false;
    const buffer = Buffer.from(jpeg_b64, 'base64');
    if (buffer.length < 100 || buffer.length > 580_000 ||
        buffer[0] !== 0xff || buffer[1] !== 0xd8 || buffer[2] !== 0xff ||
        buffer[buffer.length - 2] !== 0xff || buffer[buffer.length - 1] !== 0xd9 ||
        buffer.toString('base64') !== jpeg_b64) return false;
    prev = captured_at_ms as number;
  }
  return value[value.length - 1].captured_at_ms - value[0].captured_at_ms <= 4000;
}

function validAttestationOutput(data: any, mode: 'probe' | 'infer'): data is Extract<AttestationResult, { ok: true }> {
  if (!data || data.ok !== true || data.mode !== mode ||
      data.server_owned_inference !== true || data.face_detector_ready !== true ||
      !Array.isArray(data.models_executed) ||
      !['anti_spoofing_pad', 'liveness_detection', 'face_recognition'].every(k => data.models_executed.includes(k))) return false;
  if (mode === 'probe') return true;
  if (!Array.isArray(data.frames) || ![3, 4, 5].includes(data.frames.length) ||
      !Array.isArray(data.embedding) || data.embedding.length !== 192 ||
      !data.embedding.every((x: unknown) => typeof x === 'number' && Number.isFinite(x))) return false;
  const norm = Math.hypot(...data.embedding);
  if (Math.abs(norm - 1) > 0.05) return false;
  // Diagnostics must expose genuine, even low, scores for calibration. Acceptance
  // decisions are enforced separately by webKioskPolicy inside trusted routes.
  return data.frames.every((f: any) => f && f.face_count === 1 &&
    Number.isSafeInteger(f.timestamp_ms) &&
    [f.detection_confidence, f.quality_score, f.pad_score, f.liveness_score].every(
      (n: unknown) => typeof n === 'number' && Number.isFinite(n) && n >= 0 && n <= 1
    ) && f.bounding_box &&
    [f.bounding_box.x, f.bounding_box.y, f.bounding_box.width, f.bounding_box.height].every(
      (n: unknown) => typeof n === 'number' && Number.isFinite(n) && n >= 0 && n <= 1
    ));
}

export async function runWebKioskAttestation(
  mode: 'probe' | 'infer',
  frames?: unknown,
  overrides: { python?: string; script?: string; detector?: string; modelsDir?: string; timeoutMs?: number } = {},
): Promise<AttestationResult> {
  if (mode === 'infer' && !validateCameraFrames(frames)) {
    return { ok: false, code: 'INVALID_FRAMES', error: 'At least 3 fresh JPEG camera frames are required.' };
  }
  const body = mode === 'infer' ? JSON.stringify({ frames }) : '';
  if (Buffer.byteLength(body) > MAX_BYTES) return { ok: false, code: 'INVALID_FRAMES', error: 'Camera frame bundle too large.' };
  if (inFlight >= MAX_PARALLEL) return { ok: false, code: 'ENGINE_BUSY', error: 'AI engine busy; please try again.' };
  inFlight++;
  try {
    const python = overrides.python || process.env.KIOSK_PYTHON_BINARY || '/opt/savage-rsucaj/venv/bin/python';
    const script = overrides.script || path.resolve(process.cwd(), 'deployment/hostinger-vps/kiosk_attestation_worker.py');
    const detector = overrides.detector || process.env.KIOSK_FACE_DETECTOR || '/opt/savage-rsucaj/models/face_detection_yunet_2023mar.onnx';
    const modelsDir = overrides.modelsDir || resolveModelsDirectory();
    return await new Promise<AttestationResult>((resolve) => {
      const proc = spawn(python, [script, '--mode', mode, '--models-dir', modelsDir, '--detector', detector], {
        shell: false, stdio: ['pipe', 'pipe', 'pipe'], env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' },
      });
      let result = ''; let bytes = 0; let done = false;
      const finish = (value: AttestationResult) => {
        if (done) return;
        done = true;
        clearTimeout(timeout);
        resolve(value);
      };
      const timeout = setTimeout(() => {
        proc.kill('SIGKILL');
        finish({ ok: false, code: 'INFERENCE_TIMEOUT', error: 'Server face verification timed out.' });
      }, overrides.timeoutMs || (mode === 'probe' ? 20_000 : 28_000));
      proc.stdout.on('data', (chunk: Buffer) => {
        bytes += chunk.length;
        if (bytes > MAX_OUTPUT) { proc.kill('SIGKILL'); return; }
        result += chunk.toString('utf8');
      });
      proc.stderr.on('data', () => {}); // Never persist images, scores, embeddings, or Python tracebacks.
      proc.on('error', () => finish({ ok: false, code: 'ENGINE_UNAVAILABLE', error: 'Cannot start server AI worker.' }));
      proc.on('close', (exitCode) => {
        if (done) return;
        if (bytes > MAX_OUTPUT) return finish({ ok: false, code: 'ENGINE_OUTPUT_INVALID', error: 'AI worker output too large.' });
        let data: any;
        try { data = JSON.parse(result.trim()); }
        catch { return finish({ ok: false, code: 'ENGINE_OUTPUT_INVALID', error: 'AI worker did not produce valid JSON.' }); }
        if (exitCode !== 0 || data?.ok !== true) {
          const safeCode = typeof data?.code === 'string' && /^[A-Z_]{3,40}$/.test(data.code) ? data.code : 'INFERENCE_FAILED';
          const safeError = typeof data?.error === 'string' ? data.error.slice(0, 180) : 'Unable to verify camera face.';
          return finish({ ok: false, code: safeCode, error: safeError });
        }
        if (!validAttestationOutput(data, mode)) {
          return finish({ ok: false, code: 'UNVERIFIED_RESULT', error: 'Server AI scores did not meet biometric verification policy.' });
        }
        // The validator accepts the union of probe and infer results. Narrow
        // the discriminant before accessing infer-only payload fields.
        if (mode === 'probe' && data.mode === 'probe') {
          finish({ ok: true, mode: 'probe' });
          return;
        }
        if (mode === 'infer' && data.mode === 'infer') {
          finish({ ok: true, mode: 'infer', frames: data.frames, embedding: data.embedding });
          return;
        }
        finish({ ok: false, code: 'UNVERIFIED_RESULT', error: 'Server AI worker returned an unexpected result mode.' });
      });
      proc.stdin.on('error', () => {});
      proc.stdin.end(body);
    });
  } finally {
    inFlight--;
  }
}
