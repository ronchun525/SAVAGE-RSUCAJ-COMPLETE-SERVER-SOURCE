/**
 * SAVAGE-RSUCAJ BUILD 36 (PROMPT 08/08) — Server-Side Biometric Verification Policy,
 * Anti-Averaging Multi-Frame PAD/Liveness Validator & Calibration Governance Engine.
 *
 * MANDATORY HONESTY & FAIL-CLOSED RULES:
 * 1. Existing 0.80 PAD / 0.80 Liveness thresholds are UNCALIBRATED staging baselines — NEVER certified.
 * 2. Never silently lower PAD or Liveness cutoffs to accept users.
 * 3. Never accept naive averages of unrelated frames; enforce monotonic timestamps, single-face
 *    bounding-box stability, per-frame floor, median cutoff, and bounded score spread.
 * 4. Always fail closed in APP_MODE=production until verified .tflite binaries AND independently
 *    trusted server-side biometric inference/attestation are deployed.
 */
import { decodeClassifierLiveScore, KIOSK_MODEL_SPECS } from './webKioskBiometrics.ts';

export type KioskBiometricReasonCode =
  | 'NO_FACE'
  | 'MULTIPLE_FACES'
  | 'CAMERA_BLOCKED'
  | 'LOW_LIGHT'
  | 'BLURRY_IMAGE'
  | 'OCCLUSION_OR_POSE'
  | 'FROZEN_FRAME'
  | 'LIVENESS_UNVERIFIED'
  | 'PAD_REJECTED'
  | 'UNKNOWN_FACE'
  | 'NOT_ENROLLED'
  | 'MODEL_ERROR'
  | 'BACKEND_UNAVAILABLE'
  | 'SESSION_EXPIRED'
  | 'UNAUTHORIZED_BYPASS'
  | 'REPLAY_REJECTED'
  | 'ALREADY_TAKEN';

export const WEB_KIOSK_POLICY = {
  calibration_status: 'UNCALIBRATED_STAGING_ONLY' as const,
  certified_for_production: false as const,
  calibration_notice:
    'PAD (>=0.80) and Passive Liveness (>=0.80) thresholds are uncalibrated staging baselines, not certified production cutoffs. Do not promote without controlled bona-fide and presentation-attack evaluation.',
  thresholds: {
    face_detection_min_confidence: 0.80,
    face_quality_min_score: 0.72,
    pad_min_score: 0.80,
    liveness_min_score: 0.80,
    pad_per_frame_floor: 0.72,
    liveness_per_frame_floor: 0.72,
    max_inter_frame_spread: 0.25,
    recognition_min_similarity: 0.62,
    duplicate_identity_min_similarity: 0.68,
  },
  multi_frame: {
    min_required_frames: 3,
    max_required_frames: 7,
    min_inter_frame_delta_ms: 80,
    max_frame_window_ms: 4000,
    max_bbox_drift: 0.16,
    aggregation_rule: 'PER_FRAME_FLOOR_AND_MEDIAN_WITH_BOUNDED_SPREAD',
  },
  resilience: {
    verification_timeout_ms: 12_000,
    max_consecutive_failures_before_cooldown: 3,
    cooldown_ms: 4_000,
  },
} as const;

export interface BiometricFrameEvidence {
  timestamp_ms: number;
  face_count: number;
  detection_confidence: number;
  quality_score: number;
  lighting_ok?: boolean;
  sharpness_ok?: boolean;
  frozen_frame?: boolean;
  occlusion_suspected?: boolean;
  bounding_box?: { x: number; y: number; width: number; height: number } | null;
  /** Either raw 3-class PAD model output [c0,c1,c2] OR pre-decoded finite scalar in [0,1] */
  pad_output?: number[];
  pad_score?: number;
  /** Either raw 3-class Passive Liveness model output [c0,c1,c2] OR pre-decoded finite scalar in [0,1] */
  liveness_output?: number[];
  liveness_score?: number;
}

export interface MultiFrameEvaluationResult {
  ok: boolean;
  code?: KioskBiometricReasonCode;
  error?: string;
  frame_count: number;
  median_pad_score: number;
  median_liveness_score: number;
  min_pad_score: number;
  min_liveness_score: number;
  median_quality_score: number;
  median_detection_confidence: number;
  max_bbox_drift: number;
}

function median(values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  if (sorted.length % 2 === 1) return sorted[mid];
  return (sorted[mid - 1] + sorted[mid]) / 2;
}

function resolveFrameClassifierScore(
  rawOutput: unknown,
  scalarScore: unknown,
  liveClassIndex: number,
  label: 'PAD' | 'Liveness'
): { ok: true; score: number } | { ok: false; code: 'MODEL_ERROR'; error: string } {
  if (Array.isArray(rawOutput)) {
    const decoded = decodeClassifierLiveScore(rawOutput, liveClassIndex);
    if (!decoded.valid || !Number.isFinite(decoded.liveProbability)) {
      return {
        ok: false,
        code: 'MODEL_ERROR',
        error: `${label} model output is malformed or non-finite: ${decoded.reason || 'invalid tensor'}`,
      };
    }
    return { ok: true, score: decoded.liveProbability };
  }

  const num = Number(scalarScore);
  if (!Number.isFinite(num) || num < 0 || num > 1) {
    return {
      ok: false,
      code: 'MODEL_ERROR',
      error: `${label} score must be a finite probability in [0, 1] or a valid 3-class model output tensor.`,
    };
  }
  return { ok: true, score: num };
}

/**
 * Evaluates a multi-frame frontal biometric capture bundle fail-closed.
 * - Rejects insufficient, non-monotonic, frozen, or time-stale frames.
 * - Rejects frames with 0 faces (NO_FACE), >1 faces (MULTIPLE_FACES), low light, blur, or occlusion.
 * - Rejects unstable bounding-box jumps across frames (prevents mixing unrelated frames).
 * - Decodes raw 3-class outputs using BUILD 20 live class indices (PAD=0, Liveness=1).
 * - Enforces BOTH per-frame minimum floor AND median threshold AND bounded spread (no naive averaging).
 */
export function evaluateMultiFrameBiometricEvidence(
  frames: BiometricFrameEvidence[],
  options: { enforceLiveness: boolean }
): MultiFrameEvaluationResult {
  const emptyFail = (code: KioskBiometricReasonCode, error: string): MultiFrameEvaluationResult => ({
    ok: false,
    code,
    error,
    frame_count: Array.isArray(frames) ? frames.length : 0,
    median_pad_score: 0,
    median_liveness_score: 0,
    min_pad_score: 0,
    min_liveness_score: 0,
    median_quality_score: 0,
    median_detection_confidence: 0,
    max_bbox_drift: 0,
  });

  if (!Array.isArray(frames) || frames.length < WEB_KIOSK_POLICY.multi_frame.min_required_frames) {
    return emptyFail(
      'FROZEN_FRAME',
      `At least ${WEB_KIOSK_POLICY.multi_frame.min_required_frames} fresh monotonic frames are required.`
    );
  }
  if (frames.length > WEB_KIOSK_POLICY.multi_frame.max_required_frames) {
    return emptyFail(
      'MODEL_ERROR',
      `Too many frames submitted (max ${WEB_KIOSK_POLICY.multi_frame.max_required_frames}).`
    );
  }

  const padScores: number[] = [];
  const livenessScores: number[] = [];
  const qualityScores: number[] = [];
  const detectionScores: number[] = [];

  let prevTs = -Infinity;
  let firstTs = Number.NaN;
  let prevCenter: { cx: number; cy: number; w: number } | null = null;
  let maxDrift = 0;

  for (let i = 0; i < frames.length; i++) {
    const f = frames[i];
    if (!f || typeof f !== 'object') {
      return emptyFail('MODEL_ERROR', `Frame ${i + 1} is malformed.`);
    }

    const ts = Number(f.timestamp_ms);
    if (!Number.isFinite(ts) || ts <= prevTs) {
      return emptyFail('FROZEN_FRAME', 'Duplicate or non-monotonic frame timestamps detected (frozen camera feed rejected).');
    }
    if (i > 0 && ts - prevTs < WEB_KIOSK_POLICY.multi_frame.min_inter_frame_delta_ms) {
      return emptyFail(
        'FROZEN_FRAME',
        `Frames captured too rapidly (< ${WEB_KIOSK_POLICY.multi_frame.min_inter_frame_delta_ms}ms delta); fresh sequential frames required.`
      );
    }
    if (i === 0) firstTs = ts;
    prevTs = ts;

    if (f.frozen_frame === true) {
      return emptyFail('FROZEN_FRAME', 'Camera feed appears frozen. Please check the camera and retry.');
    }

    const faceCount = Number(f.face_count);
    if (!Number.isInteger(faceCount) || faceCount <= 0) {
      return emptyFail('NO_FACE', 'No face detected in frame. Look straight at the camera.');
    }
    if (faceCount > 1) {
      return emptyFail('MULTIPLE_FACES', 'Multiple faces detected. Only one person may stand in front of the kiosk.');
    }
    if (f.lighting_ok === false) {
      return emptyFail('LOW_LIGHT', 'Lighting is outside acceptable range. Ensure even lighting on your face.');
    }
    if (f.sharpness_ok === false) {
      return emptyFail('BLURRY_IMAGE', 'Image is too blurry. Hold still while scanning.');
    }
    if (f.occlusion_suspected === true) {
      return emptyFail('OCCLUSION_OR_POSE', 'Face appears partially occluded or misaligned. Remove obstructions and face forward.');
    }

    if (f.bounding_box) {
      const { x, y, width, height } = f.bounding_box;
      if (![x, y, width, height].every((v) => Number.isFinite(v)) || width <= 0 || height <= 0) {
        return emptyFail('MODEL_ERROR', 'Bounding box coordinates are non-finite or invalid.');
      }
      const center = { cx: x + width / 2, cy: y + height / 2, w: width };
      if (prevCenter) {
        const drift = Math.max(
          Math.abs(center.cx - prevCenter.cx),
          Math.abs(center.cy - prevCenter.cy),
          Math.abs(center.w - prevCenter.w)
        );
        if (drift > maxDrift) maxDrift = drift;
        if (drift > WEB_KIOSK_POLICY.multi_frame.max_bbox_drift) {
          return emptyFail(
            'OCCLUSION_OR_POSE',
            'Face position jumped abruptly between frames. Hold still in the center of the frame.'
          );
        }
      }
      prevCenter = center;
    }

    const det = Number(f.detection_confidence);
    if (!Number.isFinite(det) || det < WEB_KIOSK_POLICY.thresholds.face_detection_min_confidence) {
      return emptyFail('NO_FACE', 'Frontal face detection confidence below required threshold.');
    }
    detectionScores.push(det);

    const qual = Number(f.quality_score);
    if (!Number.isFinite(qual) || qual < WEB_KIOSK_POLICY.thresholds.face_quality_min_score) {
      return emptyFail('BLURRY_IMAGE', 'Face quality (sharpness/lighting/alignment) below required threshold.');
    }
    qualityScores.push(qual);

    if (options.enforceLiveness) {
      const padRes = resolveFrameClassifierScore(
        f.pad_output,
        f.pad_score,
        KIOSK_MODEL_SPECS.anti_spoofing_pad.liveClassIndex ?? 0,
        'PAD'
      );
      if (!padRes.ok) {
        return emptyFail(padRes.code, padRes.error);
      }
      padScores.push(padRes.score);

      const livRes = resolveFrameClassifierScore(
        f.liveness_output,
        f.liveness_score,
        KIOSK_MODEL_SPECS.liveness_detection.liveClassIndex ?? 1,
        'Liveness'
      );
      if (!livRes.ok) {
        return emptyFail(livRes.code, livRes.error);
      }
      livenessScores.push(livRes.score);
    }
  }

  if (prevTs - firstTs > WEB_KIOSK_POLICY.multi_frame.max_frame_window_ms) {
    return emptyFail(
      'FROZEN_FRAME',
      `Captured frames spanned more than ${WEB_KIOSK_POLICY.multi_frame.max_frame_window_ms}ms; unrelated stale frames rejected.`
    );
  }

  if (options.enforceLiveness) {
    const minPad = Math.min(...padScores);
    const maxPad = Math.max(...padScores);
    const medPad = median(padScores);

    if (
      minPad < WEB_KIOSK_POLICY.thresholds.pad_per_frame_floor ||
      medPad < WEB_KIOSK_POLICY.thresholds.pad_min_score ||
      maxPad - minPad > WEB_KIOSK_POLICY.thresholds.max_inter_frame_spread
    ) {
      return {
        ok: false,
        code: 'PAD_REJECTED',
        error: 'Anti-spoofing (PAD) verification rejected this capture. Photos, screens, and unstable presentations are not allowed.',
        frame_count: frames.length,
        median_pad_score: Number(medPad.toFixed(4)),
        median_liveness_score: Number(median(livenessScores).toFixed(4)),
        min_pad_score: Number(minPad.toFixed(4)),
        min_liveness_score: Number(Math.min(...livenessScores).toFixed(4)),
        median_quality_score: Number(median(qualityScores).toFixed(4)),
        median_detection_confidence: Number(median(detectionScores).toFixed(4)),
        max_bbox_drift: Number(maxDrift.toFixed(4)),
      };
    }

    const minLiv = Math.min(...livenessScores);
    const maxLiv = Math.max(...livenessScores);
    const medLiv = median(livenessScores);

    if (
      minLiv < WEB_KIOSK_POLICY.thresholds.liveness_per_frame_floor ||
      medLiv < WEB_KIOSK_POLICY.thresholds.liveness_min_score ||
      maxLiv - minLiv > WEB_KIOSK_POLICY.thresholds.max_inter_frame_spread
    ) {
      return {
        ok: false,
        code: 'LIVENESS_UNVERIFIED',
        error: 'Passive liveness verification did not pass across consecutive frames. Look directly at the camera with even lighting.',
        frame_count: frames.length,
        median_pad_score: Number(medPad.toFixed(4)),
        median_liveness_score: Number(medLiv.toFixed(4)),
        min_pad_score: Number(minPad.toFixed(4)),
        min_liveness_score: Number(minLiv.toFixed(4)),
        median_quality_score: Number(median(qualityScores).toFixed(4)),
        median_detection_confidence: Number(median(detectionScores).toFixed(4)),
        max_bbox_drift: Number(maxDrift.toFixed(4)),
      };
    }

    return {
      ok: true,
      frame_count: frames.length,
      median_pad_score: Number(medPad.toFixed(4)),
      median_liveness_score: Number(medLiv.toFixed(4)),
      min_pad_score: Number(minPad.toFixed(4)),
      min_liveness_score: Number(minLiv.toFixed(4)),
      median_quality_score: Number(median(qualityScores).toFixed(4)),
      median_detection_confidence: Number(median(detectionScores).toFixed(4)),
      max_bbox_drift: Number(maxDrift.toFixed(4)),
    };
  }

  return {
    ok: true,
    frame_count: frames.length,
    median_pad_score: 0,
    median_liveness_score: 0,
    min_pad_score: 0,
    min_liveness_score: 0,
    median_quality_score: Number(median(qualityScores).toFixed(4)),
    median_detection_confidence: Number(median(detectionScores).toFixed(4)),
    max_bbox_drift: Number(maxDrift.toFixed(4)),
  };
}

// ============================================================================
// CONTROLLED DATASET CALIBRATION & CONFUSION MATRIX EVALUATOR
// (ISO/IEC 30107-3 APCER / BPCER / ACER — NEVER FABRICATES DATA)
// ============================================================================

export type PresentationGroundTruth = 'bona_fide' | 'printed_photo' | 'phone_screen' | 'video_replay' | 'mask_or_other';

export interface CalibrationSample {
  ground_truth: PresentationGroundTruth;
  pad_score: number;
  liveness_score: number;
  environment_tag?: string;
}

export interface CalibrationReport {
  total_samples: number;
  bona_fide_count: number;
  attack_count: number;
  pad_threshold: number;
  liveness_threshold: number;
  confusion_matrix: {
    true_accept_bona_fide: number;
    false_reject_bona_fide: number;
    false_accept_attack: number;
    true_reject_attack: number;
  };
  bpcer: number | null;
  apcer: number | null;
  acer: number | null;
  apcer_by_attack_species: Record<string, { total: number; accepted: number; apcer: number }>;
  certifiable: boolean;
  blocking_reasons: string[];
}

export function computeBiometricCalibrationMetrics(
  samples: CalibrationSample[],
  padThreshold: number = WEB_KIOSK_POLICY.thresholds.pad_min_score,
  livenessThreshold: number = WEB_KIOSK_POLICY.thresholds.liveness_min_score
): CalibrationReport {
  let tp = 0;
  let fn = 0;
  let fp = 0;
  let tn = 0;
  const speciesMap: Record<string, { total: number; accepted: number }> = {};

  for (const s of samples) {
    const validScores = Number.isFinite(s.pad_score) && Number.isFinite(s.liveness_score);
    const accepted = validScores && s.pad_score >= padThreshold && s.liveness_score >= livenessThreshold;

    if (s.ground_truth === 'bona_fide') {
      if (accepted) tp += 1;
      else fn += 1;
    } else {
      if (!speciesMap[s.ground_truth]) speciesMap[s.ground_truth] = { total: 0, accepted: 0 };
      speciesMap[s.ground_truth].total += 1;
      if (accepted) {
        fp += 1;
        speciesMap[s.ground_truth].accepted += 1;
      } else {
        tn += 1;
      }
    }
  }

  const bonaFideTotal = tp + fn;
  const attackTotal = fp + tn;
  const bpcer = bonaFideTotal > 0 ? Number((fn / bonaFideTotal).toFixed(4)) : null;

  const apcerBySpecies: Record<string, { total: number; accepted: number; apcer: number }> = {};
  let worstSpeciesApcer: number | null = null;
  for (const [species, stats] of Object.entries(speciesMap)) {
    const rate = stats.total > 0 ? Number((stats.accepted / stats.total).toFixed(4)) : 0;
    apcerBySpecies[species] = { ...stats, apcer: rate };
    if (worstSpeciesApcer === null || rate > worstSpeciesApcer) {
      worstSpeciesApcer = rate;
    }
  }

  // ISO/IEC 30107-3 defines overall APCER as the worst-case (maximum) APCER across tested PAI species
  const apcer = attackTotal > 0 ? (worstSpeciesApcer ?? Number((fp / attackTotal).toFixed(4))) : null;
  const acer = bpcer !== null && apcer !== null ? Number(((bpcer + apcer) / 2).toFixed(4)) : null;

  const blockingReasons: string[] = [];
  if (bonaFideTotal < 30) blockingReasons.push('Insufficient bona-fide human samples (minimum 30 required for calibration).');
  if (!speciesMap.printed_photo || speciesMap.printed_photo.total < 10) {
    blockingReasons.push('Missing printed-photo presentation attack trials.');
  }
  if (!speciesMap.phone_screen || speciesMap.phone_screen.total < 10) {
    blockingReasons.push('Missing phone-screen presentation attack trials.');
  }
  if (!speciesMap.video_replay || speciesMap.video_replay.total < 10) {
    blockingReasons.push('Missing video-replay presentation attack trials.');
  }

  return {
    total_samples: samples.length,
    bona_fide_count: bonaFideTotal,
    attack_count: attackTotal,
    pad_threshold: padThreshold,
    liveness_threshold: livenessThreshold,
    confusion_matrix: {
      true_accept_bona_fide: tp,
      false_reject_bona_fide: fn,
      false_accept_attack: fp,
      true_reject_attack: tn,
    },
    bpcer,
    apcer,
    acer,
    apcer_by_attack_species: apcerBySpecies,
    certifiable: blockingReasons.length === 0,
    blocking_reasons: blockingReasons,
  };
}
