import crypto from 'node:crypto';
import type express from 'express';
import type { PermissionCode, RoleName } from './rbac.ts';

export type RealtimeEventType =
  | 'connected'
  | 'attendance:updated'
  | 'device:telemetry'
  | 'notification:created'
  | 'employee:notification'
  | 'resync:required'
  | 'heartbeat:ping';

export interface RealtimeAttendancePayload {
  event_uid?: string;
  employee_id: number;
  employee_code?: string;
  department_id?: number | null;
  shift_date: string;
  action: string;
  status?: string;
  time?: string | null;
  source: string;
  offline_replay?: boolean;
}

export interface RealtimeDeviceTelemetryPayload {
  device_id: number;
  name: string;
  status: 'Online' | 'Offline';
  connectivity: 'Online' | 'Stale' | 'Offline' | 'Revoked';
  last_heartbeat: string;
  last_heartbeat_utc: string | null;
  last_sync_utc: string | null;
  pending_queue_count: number;
  stale_warning: boolean;
  last_clock_drift_seconds: number | null;
  last_sync_status: string;
  last_sync_error: string;
  is_revoked: number;
}

export interface RealtimeNotificationPayload {
  id?: number;
  title: string;
  category: string;
  priority: string;
  action_module?: string | null;
}

export interface RealtimeClientAuth {
  userId: number;
  username: string;
  role: RoleName;
  departmentId: number | null;
  employeeId: number | null;
  permissions: Set<PermissionCode>;
}

interface SseClient {
  id: string;
  res: express.Response;
  auth: RealtimeClientAuth;
  channels: Set<string>;
  queue: string[];
  draining: boolean;
  droppedCount: number;
  connectedAtMs: number;
  isSessionActive?: () => boolean;
}

export interface RealtimeHubOptions {
  maxClients?: number;
  maxClientQueue?: number;
  keepaliveIntervalMs?: number;
  nowProvider?: () => number;
}

/**
 * Authenticated & RBAC-authorized Server-Sent Events (SSE) broker.
 * Enforces server-side scope filtering, zero secret leakage, bounded per-client
 * backpressure queues, keepalive heartbeats, and clean shutdown teardown.
 */
export class RealtimeHub {
  private readonly clients = new Map<string, SseClient>();
  private readonly maxClients: number;
  private readonly maxClientQueue: number;
  private readonly keepaliveIntervalMs: number;
  private readonly getNowMs: () => number;
  private keepaliveTimer: NodeJS.Timeout | null = null;
  private streamSeq = 0;

  constructor(options: RealtimeHubOptions = {}) {
    this.maxClients = Math.max(1, options.maxClients ?? 200);
    this.maxClientQueue = Math.max(8, options.maxClientQueue ?? 64);
    this.keepaliveIntervalMs = Math.max(5_000, options.keepaliveIntervalMs ?? 25_000);
    this.getNowMs = options.nowProvider ?? (() => Date.now());
  }

  private ensureKeepaliveRunning(): void {
    if (this.keepaliveTimer) return;
    this.keepaliveTimer = setInterval(() => {
      if (this.clients.size === 0) {
        this.stopKeepalive();
        return;
      }
      const frame = this.formatFrame('heartbeat:ping', {
        active_clients: this.clients.size,
      });
      for (const client of this.clients.values()) {
        // Even backpressured clients must lose access after session revocation.
        try {
          if (client.isSessionActive && !client.isSessionActive()) {
            this.removeClient(client.id);
            continue;
          }
        } catch {
          this.removeClient(client.id);
          continue;
        }
        if (!client.draining && client.queue.length === 0) {
          this.enqueueFrame(client, frame, false);
        }
      }
    }, this.keepaliveIntervalMs);
    this.keepaliveTimer.unref();
  }

  private stopKeepalive(): void {
    if (this.keepaliveTimer) {
      clearInterval(this.keepaliveTimer);
      this.keepaliveTimer = null;
    }
  }

  private formatFrame(type: RealtimeEventType, data: Record<string, unknown>): string {
    this.streamSeq += 1;
    const seq = this.streamSeq;
    const envelope = {
      seq,
      type,
      server_emitted_utc: new Date(this.getNowMs()).toISOString(),
      data,
    };
    return `id: ${seq}\nevent: ${type}\ndata: ${JSON.stringify(envelope)}\n\n`;
  }

  private enqueueFrame(client: SseClient, frame: string, isCritical = true): void {
    // Re-check long-lived session authorization before every write, including heartbeat.
    // Logout, administrator revocation, role/link changes and expiration close the stream.
    try {
      if (client.isSessionActive && !client.isSessionActive()) {
        this.removeClient(client.id);
        return;
      }
    } catch {
      this.removeClient(client.id);
      return;
    }
    if (client.res.writableEnded || client.res.destroyed) {
      this.removeClient(client.id);
      return;
    }

    if (client.draining || client.queue.length > 0) {
      if (client.queue.length >= this.maxClientQueue) {
        if (!isCritical) return;
        // Drop oldest frame under backpressure and mark resync needed
        client.queue.shift();
        client.droppedCount += 1;
      }
      client.queue.push(frame);
      return;
    }

    this.writeNow(client, frame);
  }

  private writeNow(client: SseClient, frame: string): void {
    try {
      const ok = client.res.write(frame);
      if (!ok) {
        client.draining = true;
      }
    } catch {
      this.removeClient(client.id);
    }
  }

  private flushClientQueue(client: SseClient): void {
    // A queued message may outlive its original authorization. Revalidate before draining.
    try {
      if (client.isSessionActive && !client.isSessionActive()) {
        this.removeClient(client.id);
        return;
      }
    } catch {
      this.removeClient(client.id);
      return;
    }
    client.draining = false;
    if (client.droppedCount > 0) {
      const dropped = client.droppedCount;
      client.droppedCount = 0;
      client.queue.unshift(
        this.formatFrame('resync:required', {
          reason: 'backpressure_coalesced',
          dropped_events: dropped,
        })
      );
    }
    while (client.queue.length > 0 && !client.draining) {
      const next = client.queue.shift()!;
      this.writeNow(client, next);
    }
  }

  private removeClient(id: string): void {
    const client = this.clients.get(id);
    if (!client) return;
    this.clients.delete(id);
    try {
      if (!client.res.writableEnded) {
        client.res.end();
      }
    } catch {
      // ignore socket already closed
    }
    if (this.clients.size === 0) {
      this.stopKeepalive();
    }
  }

  attachClient(
    req: express.Request,
    res: express.Response,
    auth: RealtimeClientAuth,
    requestedChannels?: string[],
    isSessionActive?: () => boolean
  ): { accepted: boolean; clientId?: string } {
    if (this.clients.size >= this.maxClients) {
      return { accepted: false };
    }

    const clientId = crypto.randomBytes(10).toString('hex');
    const normalizedChannels = new Set<string>(
      (requestedChannels && requestedChannels.length > 0
        ? requestedChannels
        : ['attendance:updated', 'device:telemetry', 'notification:created']
      ).map((c) => c.trim())
    );

    res.status(200);
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-store, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    if (typeof res.flushHeaders === 'function') {
      res.flushHeaders();
    }

    const client: SseClient = {
      id: clientId,
      res,
      auth,
      channels: normalizedChannels,
      queue: [],
      draining: false,
      droppedCount: 0,
      connectedAtMs: this.getNowMs(),
      isSessionActive,
    };

    this.clients.set(clientId, client);
    this.ensureKeepaliveRunning();

    res.on('drain', () => {
      if (this.clients.has(clientId)) {
        this.flushClientQueue(client);
      }
    });

    // An incoming HTTP request can emit 'close' once its request body is consumed,
    // while the SSE response is still open. Only the RESPONSE closing means
    // that this subscriber has disconnected.
    res.on('close', () => {
      this.removeClient(clientId);
    });

    res.on('error', () => {
      this.removeClient(clientId);
    });

    // Advise EventSource reconnect base retry interval (ms)
    this.enqueueFrame(client, 'retry: 3000\n\n', false);
    this.enqueueFrame(
      client,
      this.formatFrame('connected', {
        client_id: clientId,
        role: auth.role,
        scoped_employee_id: auth.role === 'Employee' ? auth.employeeId : null,
        scoped_department_id: auth.role === 'Department Head' ? auth.departmentId : null,
      }),
      true
    );

    return { accepted: true, clientId };
  }

  emitAttendanceUpdated(payload: RealtimeAttendancePayload): number {
    let delivered = 0;
    const frame = this.formatFrame('attendance:updated', {
      event_uid: payload.event_uid ?? null,
      employee_id: payload.employee_id,
      employee_code: payload.employee_code ?? null,
      department_id: payload.department_id ?? null,
      shift_date: payload.shift_date,
      action: payload.action,
      status: payload.status ?? null,
      time: payload.time ?? null,
      source: payload.source,
      offline_replay: payload.offline_replay === true,
    });

    for (const client of this.clients.values()) {
      if (!client.channels.has('attendance:updated')) continue;
      const perms = client.auth.permissions;
      let authorized = false;

      if (client.auth.role === 'Employee') {
        authorized =
          perms.has('attendance:read_self') &&
          client.auth.employeeId !== null &&
          client.auth.employeeId === payload.employee_id;
      } else if (client.auth.role === 'Department Head') {
        authorized =
          (perms.has('attendance:read') || perms.has('dashboard:read')) &&
          client.auth.departmentId !== null &&
          payload.department_id !== null &&
          payload.department_id !== undefined &&
          client.auth.departmentId === payload.department_id;
      } else {
        authorized = perms.has('attendance:read') || perms.has('dashboard:read');
      }

      if (authorized) {
        this.enqueueFrame(client, frame, true);
        // A session may be revoked between channel authorization and enqueue.
        // Do not report a delivery to a disconnected/unauthorized subscriber.
        if (this.clients.has(client.id)) delivered += 1;
      }
    }
    return delivered;
  }

  emitDeviceTelemetry(payload: RealtimeDeviceTelemetryPayload): number {
    let delivered = 0;
    // Explicitly construct sanitized object so api_token or secrets can NEVER be transmitted over SSE
    const safePayload = {
      device_id: payload.device_id,
      name: payload.name,
      status: payload.status,
      connectivity: payload.connectivity,
      last_heartbeat: payload.last_heartbeat,
      last_heartbeat_utc: payload.last_heartbeat_utc,
      last_sync_utc: payload.last_sync_utc,
      pending_queue_count: payload.pending_queue_count,
      stale_warning: payload.stale_warning,
      last_clock_drift_seconds: payload.last_clock_drift_seconds,
      last_sync_status: payload.last_sync_status,
      last_sync_error: payload.last_sync_error,
      is_revoked: payload.is_revoked,
    };
    const frame = this.formatFrame('device:telemetry', safePayload);

    for (const client of this.clients.values()) {
      if (!client.channels.has('device:telemetry')) continue;
      const perms = client.auth.permissions;
      if (perms.has('devices:read') || perms.has('dashboard:read')) {
        this.enqueueFrame(client, frame, true);
        // A session may be revoked between channel authorization and enqueue.
        // Do not report a delivery to a disconnected/unauthorized subscriber.
        if (this.clients.has(client.id)) delivered += 1;
      }
    }
    return delivered;
  }

  emitNotificationCreated(payload: RealtimeNotificationPayload): number {
    let delivered = 0;
    const frame = this.formatFrame('notification:created', {
      id: payload.id ?? null,
      title: payload.title,
      category: payload.category,
      priority: payload.priority,
      action_module: payload.action_module ?? null,
    });

    for (const client of this.clients.values()) {
      if (!client.channels.has('notification:created')) continue;
      if (client.auth.permissions.has('notifications:read')) {
        this.enqueueFrame(client, frame, true);
        // A session may be revoked between channel authorization and enqueue.
        // Do not report a delivery to a disconnected/unauthorized subscriber.
        if (this.clients.has(client.id)) delivered += 1;
      }
    }
    return delivered;
  }

  emitEmployeeNotification(
    employeeId: number,
    payload: { type: string; title: string; ref?: string }
  ): number {
    let delivered = 0;
    const frame = this.formatFrame('employee:notification', {
      employee_id: employeeId,
      category: payload.type,
      title: payload.title,
      ref: payload.ref ?? null,
    });

    for (const client of this.clients.values()) {
      if (!client.channels.has('employee:notification')) continue;
      if (
        client.auth.role === 'Employee' &&
        client.auth.permissions.has('attendance:read_self') &&
        client.auth.employeeId !== null &&
        client.auth.employeeId === employeeId
      ) {
        this.enqueueFrame(client, frame, true);
        if (this.clients.has(client.id)) delivered += 1;
      }
    }
    return delivered;
  }

  clientCount(): number {
    return this.clients.size;
  }

  closeAll(): void {
    this.stopKeepalive();
    for (const id of [...this.clients.keys()]) {
      this.removeClient(id);
    }
  }
}
