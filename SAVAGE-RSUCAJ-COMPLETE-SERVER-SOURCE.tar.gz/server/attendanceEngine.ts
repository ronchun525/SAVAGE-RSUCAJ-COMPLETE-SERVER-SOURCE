import crypto from 'node:crypto';
import type Database from 'better-sqlite3';
import { logAudit } from './auditHelpers.ts';

export const MANILA_TIMEZONE = 'Asia/Manila';
export const MANILA_OFFSET_MINUTES = 8 * 60;
export const MANILA_OFFSET_MS = MANILA_OFFSET_MINUTES * 60 * 1000;

/** Approved next-day cutoff for final Time Out on day shifts: 03:00 Asia/Manila */
export const NEXT_DAY_TIMEOUT_CUTOFF_MINUTES = 3 * 60;
/** Approved live kiosk clock-drift tolerance (±120 seconds) */
export const DEFAULT_MAX_CLOCK_DRIFT_SECONDS = 120;
/** Approved maximum age for offline-queued kiosk replays (72 hours) */
export const DEFAULT_MAX_OFFLINE_REPLAY_HOURS = 72;

export const APPROVED_ATTENDANCE_ACTIONS = [
  'TIME_IN',
  'BREAK_OUT',
  'BREAK_IN',
  'TIME_OUT',
  'OVERTIME_OUT',
] as const;

export type AttendanceAction = (typeof APPROVED_ATTENDANCE_ACTIONS)[number];

export const APPROVED_ATTENDANCE_STATUSES = [
  'Present',
  'Late',
  'Absent',
  'Undertime',
  'On Leave',
  'OB',
  'Rest Day',
  'Holiday',
  'Missing Time Out',
  'Missing Time In',
  'No Schedule',
] as const;

export type AttendanceStatus = (typeof APPROVED_ATTENDANCE_STATUSES)[number];

export type AttendanceEventDecision = 'ACCEPTED' | 'DUPLICATE_IGNORED' | 'REJECTED' | 'ESCALATED';

const DAY_CODES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] as const;
export type DayCode = (typeof DAY_CODES)[number];

export interface ManilaDateTimeParts {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  second: number;
  dayOfWeek: number;
  dayCode: DayCode;
  minutesFromMidnight: number;
  isoDate: string;
  time12: string;
  time24: string;
  isoTimestamp: string;
}

export interface ShiftDefinition {
  id: number;
  name: string;
  time_in: string;
  time_out: string;
  grace_minutes: number;
  status: string;
  rest_days?: string | null;
}

export interface ShiftWindow {
  shiftDate: string;
  isOvernight: boolean;
  shiftStartMin: number;
  shiftEndMin: number;
  scheduledStartUtc: number;
  scheduledEndUtc: number;
  graceDeadlineUtc: number;
  finalTimeOutCutoffUtc: number;
}

export interface KioskPunchInput {
  device: { id: number; name: string; status: string };
  employeeCode: string;
  actionRaw: unknown;
  eventUid?: string;
  deviceTimestamp?: string;
  offlineReplay?: boolean;
  /** Ignored as proof of time; inspected only to log attempted untrusted overrides */
  untrustedClientPunchTime?: string;
  clientIp: string;
  /** Authoritative server clock epoch ms (injectable for deterministic testing) */
  serverNowUtc?: number;
  maxClockDriftSeconds?: number;
  maxOfflineReplayHours?: number;
  /** BUILD 10: Kiosk offline sync & cryptographic capture binding forensic fields */
  monotonicSeq?: number;
  deviceBootId?: string;
  biometricEvidenceHash?: string | null;
  biometricBound?: boolean;
  captureMetadataJson?: string | null;
}

export interface KioskPunchOutcome {
  statusCode: number;
  body: Record<string, unknown>;
}

export interface ReconcileDateOptions {
  serverNowUtc?: number;
  actorUsername: string;
  clientIp?: string;
  /** Only intended for explicit HR end-of-period close on dates already past shift end */
  forcePastShiftEnd?: boolean;
}

export interface ReconcileDateResult {
  date: string;
  evaluatedEmployees: number;
  markedMissingTimeOut: number;
  markedAbsent: number;
  markedOnLeave: number;
  markedOb: number;
  markedHoliday: number;
  markedRestDay: number;
  markedNoSchedule: number;
  skippedOpenOrComplete: number;
}

/**
 * Converts a UTC Date or epoch ms to exact Asia/Manila (UTC+08:00, no DST) components.
 * Completely independent of host OS timezone.
 */
export function toManilaParts(input: Date | number = Date.now()): ManilaDateTimeParts {
  const utcMs = typeof input === 'number' ? input : input.getTime();
  const shifted = new Date(utcMs + MANILA_OFFSET_MS);

  const year = shifted.getUTCFullYear();
  const month = shifted.getUTCMonth() + 1;
  const day = shifted.getUTCDate();
  const hour = shifted.getUTCHours();
  const minute = shifted.getUTCMinutes();
  const second = shifted.getUTCSeconds();
  const dayOfWeek = shifted.getUTCDay();
  const dayCode = DAY_CODES[dayOfWeek];

  const isoDate = `${String(year).padStart(4, '0')}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  const time24 = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
  const h12 = hour % 12 === 0 ? 12 : hour % 12;
  const meridiem = hour >= 12 ? 'PM' : 'AM';
  const time12 = `${String(h12).padStart(2, '0')}:${String(minute).padStart(2, '0')} ${meridiem}`;
  const isoTimestamp = `${isoDate}T${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}:${String(second).padStart(2, '0')}+08:00`;

  return {
    year,
    month,
    day,
    hour,
    minute,
    second,
    dayOfWeek,
    dayCode,
    minutesFromMidnight: hour * 60 + minute,
    isoDate,
    time12,
    time24,
    isoTimestamp,
  };
}

export function getManilaDateString(input: Date | number = Date.now()): string {
  return toManilaParts(input).isoDate;
}

export function addDaysIso(isoDate: string, deltaDays: number): string {
  const m = isoDate.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) throw new Error(`Invalid ISO date: ${isoDate}`);
  const ms = Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]) + deltaDays);
  const d = new Date(ms);
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}

export function getManilaDayCodeForIsoDate(isoDate: string): DayCode {
  const m = isoDate.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) throw new Error(`Invalid ISO date: ${isoDate}`);
  const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])));
  return DAY_CODES[d.getUTCDay()];
}

/**
 * Converts an Asia/Manila wall-clock date + minutes from midnight (supports >= 1440 for next day)
 * into exact UTC epoch milliseconds.
 */
export function parseManilaWallClockToUtcMs(isoDate: string, minutesFromMidnight: number, seconds = 0): number {
  const m = isoDate.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) throw new Error(`Invalid ISO date: ${isoDate}`);
  const midnightManilaUtc = Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])) - MANILA_OFFSET_MS;
  return midnightManilaUtc + minutesFromMidnight * 60 * 1000 + seconds * 1000;
}

/**
 * Parses an ISO-8601 timestamp that MUST include an explicit timezone offset (e.g. `Z` or `+08:00`).
 * Rejects timezone-naive strings so clients cannot inject ambiguous local timestamps.
 */
export function parseExplicitIsoTimestampToUtcMs(raw: string | null | undefined): number | null {
  if (!raw || typeof raw !== 'string') return null;
  const trimmed = raw.trim();
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d{1,3})?)?(Z|[+-]\d{2}:\d{2})$/.test(trimmed)) {
    return null;
  }
  const ms = Date.parse(trimmed);
  return Number.isNaN(ms) ? null : ms;
}

export function parseTimeToMinutes(timeStr: string | null | undefined): number | null {
  if (!timeStr) return null;
  const trimmed = timeStr.trim().toUpperCase();
  const match12 = trimmed.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/);
  if (match12) {
    let hours = parseInt(match12[1], 10);
    const mins = parseInt(match12[2], 10);
    const meridiem = match12[3];
    if (hours < 1 || hours > 12 || mins < 0 || mins > 59) return null;
    if (meridiem === 'PM' && hours !== 12) hours += 12;
    if (meridiem === 'AM' && hours === 12) hours = 0;
    return hours * 60 + mins;
  }
  const match24 = trimmed.match(/^(\d{1,2}):(\d{2})$/);
  if (match24) {
    const hours = parseInt(match24[1], 10);
    const mins = parseInt(match24[2], 10);
    if (hours < 0 || hours > 23 || mins < 0 || mins > 59) return null;
    return hours * 60 + mins;
  }
  return null;
}

export function formatDurationMinutes(totalMinutes: number): string {
  const safe = Math.max(0, Math.floor(totalMinutes));
  const hours = Math.floor(safe / 60);
  const mins = safe % 60;
  return `${hours}h ${String(mins).padStart(2, '0')}m`;
}

export function computeWorkHoursFromStrings(timeIn: string | null, timeOut: string | null): string {
  const inMin = parseTimeToMinutes(timeIn);
  const outMin = parseTimeToMinutes(timeOut);
  if (inMin === null || outMin === null) return timeIn ? 'In Shift' : '-';
  let diff = outMin - inMin;
  if (diff < 0) diff += 24 * 60;
  return formatDurationMinutes(diff);
}

export function normalizeAttendanceAction(raw: unknown): AttendanceAction | null {
  if (typeof raw !== 'string') return null;
  const norm = raw.trim().toUpperCase().replace(/[\s-]+/g, '_');
  if ((APPROVED_ATTENDANCE_ACTIONS as readonly string[]).includes(norm)) {
    return norm as AttendanceAction;
  }
  return null;
}

export function isApprovedAttendanceStatus(status: unknown): status is AttendanceStatus {
  return typeof status === 'string' && (APPROVED_ATTENDANCE_STATUSES as readonly string[]).includes(status);
}

export function isRestDayForShift(shiftDate: string, restDaysRaw: string | null | undefined): boolean {
  if (!restDaysRaw || !restDaysRaw.trim()) return false;
  const dayCode = getManilaDayCodeForIsoDate(shiftDate).toLowerCase();
  const tokens = restDaysRaw
    .split(/[,;\s]+/)
    .map((s) => s.trim().toLowerCase().slice(0, 3))
    .filter(Boolean);
  return tokens.includes(dayCode);
}

/**
 * Computes exact Asia/Manila shift window and final Time Out cutoff in UTC epoch ms.
 * Policy:
 *  - Day shifts (shiftEndMin > shiftStartMin): final Time Out permitted until exact 03:00:00 Asia/Manila
 *    on the next calendar day (`shiftDate + 1`).
 *  - Overnight shifts (shiftEndMin <= shiftStartMin, e.g. 10:00 PM - 07:00 AM):
 *    scheduled end is on `shiftDate + 1`; if shift ends at or before 03:00 AM, cutoff is 03:00:00 Asia/Manila,
 *    otherwise cutoff is `scheduledEndUtc + 4 hours` (capped 2 hours before the next shift's start).
 */
export function computeShiftWindow(shiftDate: string, shift: ShiftDefinition): ShiftWindow {
  const shiftStartMin = parseTimeToMinutes(shift.time_in) ?? 8 * 60;
  const shiftEndMin = parseTimeToMinutes(shift.time_out) ?? 17 * 60;
  const graceMinutes = Math.max(0, Number(shift.grace_minutes) || 0);
  const isOvernight = shiftEndMin <= shiftStartMin;

  const scheduledStartUtc = parseManilaWallClockToUtcMs(shiftDate, shiftStartMin);
  const nextDate = addDaysIso(shiftDate, 1);
  const scheduledEndUtc = isOvernight
    ? parseManilaWallClockToUtcMs(nextDate, shiftEndMin)
    : parseManilaWallClockToUtcMs(shiftDate, shiftEndMin);
  const graceDeadlineUtc = scheduledStartUtc + graceMinutes * 60 * 1000;

  const nextDayThreeAmUtc = parseManilaWallClockToUtcMs(nextDate, NEXT_DAY_TIMEOUT_CUTOFF_MINUTES);

  let finalTimeOutCutoffUtc: number;
  if (!isOvernight) {
    finalTimeOutCutoffUtc = nextDayThreeAmUtc;
  } else if (shiftEndMin <= NEXT_DAY_TIMEOUT_CUTOFF_MINUTES) {
    finalTimeOutCutoffUtc = nextDayThreeAmUtc;
  } else {
    const nextShiftStartUtc = parseManilaWallClockToUtcMs(nextDate, shiftStartMin);
    const maxBeforeNextShift = nextShiftStartUtc - 2 * 60 * 60 * 1000;
    finalTimeOutCutoffUtc = Math.min(scheduledEndUtc + 4 * 60 * 60 * 1000, maxBeforeNextShift);
  }

  return {
    shiftDate,
    isOvernight,
    shiftStartMin,
    shiftEndMin,
    scheduledStartUtc,
    scheduledEndUtc,
    graceDeadlineUtc,
    finalTimeOutCutoffUtc,
  };
}

function getHolidayOnDate(db: Database.Database, isoDate: string): { id: number; name: string; type: string } | undefined {
  return db.prepare('SELECT id, name, type FROM holidays WHERE date = ? LIMIT 1').get(isoDate) as
    | { id: number; name: string; type: string }
    | undefined;
}

function getApprovedLeaveOnDate(
  db: Database.Database,
  employeeId: number,
  isoDate: string
): { id: number; leave_type: string; day_portion?: string } | undefined {
  // Prefer explicit BUILD 11 per-day allocation when present (excludes holidays/weekends & conflict-preserved days)
  const alloc = db
    .prepare(
      `SELECT l.id, l.leave_type, a.day_portion
       FROM leave_day_allocations a
       JOIN leaves l ON a.leave_id = l.id
       WHERE a.employee_id = ? AND a.leave_date = ? AND l.status = 'Approved' AND a.conflict_preserved = 0
       ORDER BY l.id DESC LIMIT 1`
    )
    .get(employeeId, isoDate) as { id: number; leave_type: string; day_portion?: string } | undefined;
  if (alloc) return alloc;

  // Fallback for legacy leaves without allocations
  return db
    .prepare(
      `SELECT l.id, l.leave_type
       FROM leaves l
       WHERE l.employee_id = ? AND l.status = 'Approved' AND l.start_date <= ? AND l.end_date >= ?
         AND NOT EXISTS (SELECT 1 FROM leave_day_allocations a WHERE a.leave_id = l.id)
       ORDER BY l.id DESC LIMIT 1`
    )
    .get(employeeId, isoDate, isoDate) as { id: number; leave_type: string } | undefined;
}

function isOfficialBusinessType(leaveType: string): boolean {
  const norm = leaveType.trim().toLowerCase();
  return norm === 'ob' || norm === 'official business' || norm.startsWith('official business');
}

function recordImmutableEvent(
  db: Database.Database,
  params: {
    eventUid: string;
    employeeId: number;
    deviceId: number | null;
    deviceName: string;
    attendanceDate: string;
    punchType: string;
    punchTime: string;
    serverTimestampUtc: string;
    manilaTimestamp: string;
    deviceTimestampUtc: string | null;
    clockDriftSeconds: number | null;
    offlineReplay: boolean;
    decision: AttendanceEventDecision;
    decisionCode: string;
    decisionReason: string;
    source: string;
    monotonicSeq?: number | null;
    deviceBootId?: string | null;
    biometricEvidenceHash?: string | null;
    biometricBound?: boolean;
    captureMetadataJson?: string | null;
  }
): void {
  db.prepare(
    `INSERT INTO attendance_events
      (event_uid, employee_id, device_id, device_name, attendance_date, punch_type, punch_time,
       server_timestamp_utc, manila_timestamp, device_timestamp_utc, clock_drift_seconds,
       offline_replay, decision, decision_code, decision_reason, source,
       monotonic_seq, device_boot_id, biometric_evidence_hash, biometric_bound, capture_metadata_json)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    params.eventUid,
    params.employeeId,
    params.deviceId,
    params.deviceName,
    params.attendanceDate,
    params.punchType,
    params.punchTime,
    params.serverTimestampUtc,
    params.manilaTimestamp,
    params.deviceTimestampUtc,
    params.clockDriftSeconds,
    params.offlineReplay ? 1 : 0,
    params.decision,
    params.decisionCode,
    params.decisionReason,
    params.source,
    params.monotonicSeq ?? null,
    params.deviceBootId ?? null,
    params.biometricEvidenceHash ?? null,
    params.biometricBound ? 1 : 0,
    params.captureMetadataJson ?? null
  );
}

function recordAudit(
  db: Database.Database,
  username: string,
  activity: string,
  module: string,
  status: 'Success' | 'Warning' | 'Error',
  ipAddress: string
): void {
  logAudit(db, username, activity, module, status, ipAddress, {
    actionType: 'KIOSK_EVENT',
    targetType: 'attendance',
  });
}

function escalateToHr(
  db: Database.Database,
  params: {
    employeeId: number;
    employeeName: string;
    shiftDate: string;
    requestType: 'Time In' | 'Time Out' | 'Full Day';
    requestedTime: string;
    title: string;
    reason: string;
    createCorrection: boolean;
  }
): { correctionId: number | null } {
  let correctionId: number | null = null;
  if (params.createCorrection) {
    const info = db
      .prepare(
        `INSERT INTO corrections (employee_id, attendance_date, request_type, requested_time, reason, status)
         VALUES (?, ?, ?, ?, ?, 'Pending')`
      )
      .run(params.employeeId, params.shiftDate, params.requestType, params.requestedTime, params.reason);
    correctionId = Number(info.lastInsertRowid);
  }
  db.prepare(
    `INSERT INTO notifications (title, message, category, priority, is_read, action_module, action_entity_id, target_roles, event_type)
     VALUES (?, ?, 'Attendance Alerts', 'High', 0, ?, ?, 'Administrator,HR Officer,Department Head', 'attendance_exception')`
  ).run(
    params.title,
    `${params.employeeName} (${params.shiftDate}): ${params.reason}`,
    correctionId ? 'corrections' : 'attendance',
    correctionId
  );
  return { correctionId };
}

interface StoredAttendanceRow {
  id: number;
  employee_id: number;
  date: string;
  time_in: string | null;
  time_out: string | null;
  break_out: string | null;
  break_in: string | null;
  overtime_out: string | null;
  time_in_utc: string | null;
  break_out_utc: string | null;
  break_in_utc: string | null;
  time_out_utc: string | null;
  overtime_out_utc: string | null;
  late_minutes: number;
  undertime_minutes: number;
  overtime_minutes: number;
  work_hours: string;
  status: AttendanceStatus;
  device_name: string;
  remarks: string;
}

function getEffectiveUtcFromRow(utcCol: string | null, dateStr: string, displayTime: string | null, shift: ShiftDefinition): number | null {
  if (utcCol) {
    const parsed = Date.parse(utcCol);
    if (!Number.isNaN(parsed)) return parsed;
  }
  const mins = parseTimeToMinutes(displayTime);
  if (mins === null) return null;
  const shiftStartMin = parseTimeToMinutes(shift.time_in) ?? 480;
  const isOvernight = (parseTimeToMinutes(shift.time_out) ?? 1020) <= shiftStartMin;
  if (isOvernight && mins < shiftStartMin - 180) {
    return parseManilaWallClockToUtcMs(addDaysIso(dateStr, 1), mins);
  }
  return parseManilaWallClockToUtcMs(dateStr, mins);
}

/**
 * Resolves the authoritative work/shift date in Asia/Manila for a TIME_IN action.
 * - For day shifts (`shiftEndMin > shiftStartMin`): the Manila calendar date of the punch.
 *   (11:59 PM on Day D => Day D; 12:01 AM on Day D+1 => Day D+1.)
 * - For overnight shifts (`shiftEndMin <= shiftStartMin`, e.g. 10:00 PM - 07:00 AM):
 *   a punch between 00:00 and `shiftEndMin` on Day D+1 belongs to Day D's overnight shift.
 */
export function resolveShiftDateForTimeIn(effectiveUtcMs: number, shift: ShiftDefinition): string {
  const manila = toManilaParts(effectiveUtcMs);
  const shiftStartMin = parseTimeToMinutes(shift.time_in) ?? 8 * 60;
  const shiftEndMin = parseTimeToMinutes(shift.time_out) ?? 17 * 60;
  const isOvernight = shiftEndMin <= shiftStartMin;

  if (isOvernight && manila.minutesFromMidnight <= shiftEndMin) {
    return addDaysIso(manila.isoDate, -1);
  }
  return manila.isoDate;
}

/**
 * Authoritative BUILD 08 Kiosk Attendance Punch Processor.
 * Runs inside a SQLite IMMEDIATE transaction for atomic parallel-request safety.
 */
export function processKioskPunch(db: Database.Database, input: KioskPunchInput): KioskPunchOutcome {
  const serverNowUtc = input.serverNowUtc ?? Date.now();
  const serverNowIso = new Date(serverNowUtc).toISOString();
  const maxDriftSec = input.maxClockDriftSeconds ?? DEFAULT_MAX_CLOCK_DRIFT_SECONDS;
  const maxOfflineHours = input.maxOfflineReplayHours ?? DEFAULT_MAX_OFFLINE_REPLAY_HOURS;
  const offlineReplay = input.offlineReplay === true;

  const emp = db
    .prepare(
      `SELECT e.id, e.employee_code, e.full_name, e.department_id, e.status as emp_status,
              s.id as shift_id, s.name as shift_name, s.time_in as shift_time_in,
              s.time_out as shift_time_out, s.grace_minutes, s.status as shift_status,
              COALESCE(s.rest_days, '') as rest_days
       FROM employees e
       JOIN shifts s ON e.shift_id = s.id
       WHERE e.employee_code = ? AND e.status = 'Active'`
    )
    .get(input.employeeCode.trim()) as
    | {
        id: number;
        employee_code: string;
        full_name: string;
        department_id: number;
        emp_status: string;
        shift_id: number;
        shift_name: string;
        shift_time_in: string;
        shift_time_out: string;
        grace_minutes: number;
        shift_status: string;
        rest_days: string;
      }
    | undefined;

  if (!emp) {
    return {
      statusCode: 404,
      body: { error: `Active employee ${input.employeeCode} not found.`, code: 'EMPLOYEE_NOT_FOUND' },
    };
  }

  const shift: ShiftDefinition = {
    id: emp.shift_id,
    name: emp.shift_name,
    time_in: emp.shift_time_in,
    time_out: emp.shift_time_out,
    grace_minutes: emp.grace_minutes,
    status: emp.shift_status,
    rest_days: emp.rest_days,
  };

  const serverManila = toManilaParts(serverNowUtc);
  const rawUid = typeof input.eventUid === 'string' ? input.eventUid.trim().slice(0, 128) : '';

  // Strict action validation — NEVER guess or convert repeated TIME_IN into TIME_OUT
  const action = normalizeAttendanceAction(input.actionRaw);
  if (!action) {
    const rejectUid = rawUid || `rej-${input.device.id}-${emp.id}-${crypto.randomBytes(6).toString('hex')}`;
    const existingDup = db
      .prepare('SELECT event_uid, decision, decision_code, attendance_date, punch_type, punch_time FROM attendance_events WHERE event_uid = ?')
      .get(rejectUid) as
      | { event_uid: string; decision: string; decision_code: string; attendance_date: string; punch_type: string; punch_time: string }
      | undefined;
    if (existingDup) {
      return {
        statusCode: 200,
        body: {
          ok: true,
          action: 'duplicate_ignored',
          event_uid: existingDup.event_uid,
          original_decision: existingDup.decision,
          original_code: existingDup.decision_code,
          shift_date: existingDup.attendance_date,
          time: existingDup.punch_time,
        },
      };
    }
    recordAudit(
      db,
      input.device.name,
      `Rejected kiosk punch for ${emp.full_name} (${emp.employee_code}): invalid or missing action "${String(input.actionRaw ?? '')}"`,
      'Attendance',
      'Warning',
      input.clientIp
    );
    return {
      statusCode: 400,
      body: {
        error: `Explicit valid punch_type is required (${APPROVED_ATTENDANCE_ACTIONS.join(', ')}). Implicit action conversion is disabled.`,
        code: 'INVALID_ACTION',
        allowed_actions: APPROVED_ATTENDANCE_ACTIONS,
      },
    };
  }

  if (offlineReplay && !rawUid) {
    return {
      statusCode: 400,
      body: {
        error: 'Offline replay events require an explicit unique event_uid idempotency key.',
        code: 'EVENT_UID_REQUIRED',
      },
    };
  }

  const eventUid = rawUid || `ksk-${input.device.id}-${emp.id}-${serverManila.isoDate}-${crypto.randomBytes(6).toString('hex')}`;

  // Run inside IMMEDIATE transaction to guarantee serialization across parallel duplicate HTTP requests
  const tx = db.transaction((): KioskPunchOutcome => {
    // 1. Idempotency check FIRST
    const priorEvent = db
      .prepare(
        `SELECT event_uid, attendance_date, punch_type, punch_time, decision, decision_code, decision_reason, manila_timestamp
         FROM attendance_events WHERE event_uid = ?`
      )
      .get(eventUid) as
      | {
          event_uid: string;
          attendance_date: string;
          punch_type: string;
          punch_time: string;
          decision: AttendanceEventDecision;
          decision_code: string;
          decision_reason: string;
          manila_timestamp: string;
        }
      | undefined;

    if (priorEvent) {
      return {
        statusCode: 200,
        body: {
          ok: true,
          action: 'duplicate_ignored',
          event_uid: priorEvent.event_uid,
          original_action: priorEvent.punch_type,
          original_decision: priorEvent.decision,
          original_code: priorEvent.decision_code,
          shift_date: priorEvent.attendance_date,
          employee: emp.full_name,
          time: priorEvent.punch_time,
          manila_timestamp: priorEvent.manila_timestamp,
        },
      };
    }

    // 2. Authoritative Clock & Drift Validation
    let deviceTimestampUtcIso: string | null = null;
    let clockDriftSeconds: number | null = null;
    let effectiveUtcMs = serverNowUtc;

    if (offlineReplay) {
      const parsedDeviceMs = parseExplicitIsoTimestampToUtcMs(input.deviceTimestamp);
      if (parsedDeviceMs === null) {
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: serverManila.isoDate,
          punchType: action,
          punchTime: serverManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: serverManila.isoTimestamp,
          deviceTimestampUtc: input.deviceTimestamp || null,
          clockDriftSeconds: null,
          offlineReplay: true,
          decision: 'REJECTED',
          decisionCode: 'INVALID_OFFLINE_TIMESTAMP',
          decisionReason: 'Offline replay requires an ISO-8601 device_timestamp with explicit timezone offset.',
          source: 'kiosk_offline',
        });
        recordAudit(db, input.device.name, `Rejected offline replay (${action}) for ${emp.employee_code}: invalid device_timestamp`, 'Attendance', 'Warning', input.clientIp);
        return {
          statusCode: 400,
          body: {
            error: 'Offline replay requires a valid ISO-8601 device_timestamp with explicit timezone offset (e.g. +08:00 or Z).',
            code: 'INVALID_OFFLINE_TIMESTAMP',
            event_uid: eventUid,
          },
        };
      }

      deviceTimestampUtcIso = new Date(parsedDeviceMs).toISOString();
      clockDriftSeconds = Math.round((parsedDeviceMs - serverNowUtc) / 1000);

      // Offline timestamp cannot be in the future past drift tolerance
      if (clockDriftSeconds > maxDriftSec) {
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: serverManila.isoDate,
          punchType: action,
          punchTime: toManilaParts(parsedDeviceMs).time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: toManilaParts(parsedDeviceMs).isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay: true,
          decision: 'REJECTED',
          decisionCode: 'CLOCK_DRIFT_EXCEEDED',
          decisionReason: `Offline device timestamp is ${clockDriftSeconds}s ahead of server clock (max +${maxDriftSec}s).`,
          source: 'kiosk_offline',
        });
        recordAudit(db, input.device.name, `Rejected future offline punch (${action}) for ${emp.employee_code}: drift +${clockDriftSeconds}s`, 'Attendance', 'Warning', input.clientIp);
        return {
          statusCode: 422,
          body: {
            error: `Device clock drift exceeded (+${clockDriftSeconds}s ahead of server time; tolerance ±${maxDriftSec}s).`,
            code: 'CLOCK_DRIFT_EXCEEDED',
            clock_drift_seconds: clockDriftSeconds,
            event_uid: eventUid,
          },
        };
      }

      const ageMs = serverNowUtc - parsedDeviceMs;
      if (ageMs > maxOfflineHours * 60 * 60 * 1000) {
        const offlineManila = toManilaParts(parsedDeviceMs);
        const reason = `Offline replay (${action}) at ${offlineManila.isoTimestamp} exceeds ${maxOfflineHours}-hour replay window; escalated for HR review.`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: offlineManila.isoDate,
          punchType: action,
          punchTime: offlineManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: offlineManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay: true,
          decision: 'ESCALATED',
          decisionCode: 'OFFLINE_REPLAY_EXPIRED',
          decisionReason: reason,
          source: 'kiosk_offline',
        });
        const esc = escalateToHr(db, {
          employeeId: emp.id,
          employeeName: emp.full_name,
          shiftDate: offlineManila.isoDate,
          requestType: action === 'TIME_OUT' || action === 'OVERTIME_OUT' ? 'Time Out' : 'Time In',
          requestedTime: offlineManila.time12,
          title: 'Expired offline kiosk punch escalated',
          reason,
          createCorrection: true,
        });
        recordAudit(db, input.device.name, `Escalated expired offline replay (${action}) for ${emp.employee_code}`, 'Attendance', 'Warning', input.clientIp);
        return {
          statusCode: 422,
          body: {
            error: reason,
            code: 'OFFLINE_REPLAY_EXPIRED',
            escalated: true,
            correction_id: esc.correctionId,
            event_uid: eventUid,
          },
        };
      }

      effectiveUtcMs = parsedDeviceMs;
    } else {
      // Live punch: authoritative timestamp is ALWAYS serverNowUtc.
      // Validate optional device_timestamp strictly against drift tolerance.
      if (input.deviceTimestamp !== undefined && input.deviceTimestamp !== '') {
        const parsedDeviceMs = parseExplicitIsoTimestampToUtcMs(input.deviceTimestamp);
        if (parsedDeviceMs === null) {
          recordImmutableEvent(db, {
            eventUid,
            employeeId: emp.id,
            deviceId: input.device.id,
            deviceName: input.device.name,
            attendanceDate: serverManila.isoDate,
            punchType: action,
            punchTime: serverManila.time12,
            serverTimestampUtc: serverNowIso,
            manilaTimestamp: serverManila.isoTimestamp,
            deviceTimestampUtc: String(input.deviceTimestamp),
            clockDriftSeconds: null,
            offlineReplay: false,
            decision: 'REJECTED',
            decisionCode: 'INVALID_DEVICE_TIMESTAMP',
            decisionReason: 'Malformed device_timestamp (ISO-8601 with timezone offset required).',
            source: 'kiosk',
          });
          return {
            statusCode: 400,
            body: {
              error: 'device_timestamp must be ISO-8601 with an explicit timezone offset.',
              code: 'INVALID_DEVICE_TIMESTAMP',
              event_uid: eventUid,
            },
          };
        }
        deviceTimestampUtcIso = new Date(parsedDeviceMs).toISOString();
        clockDriftSeconds = Math.round((parsedDeviceMs - serverNowUtc) / 1000);
        if (Math.abs(clockDriftSeconds) > maxDriftSec) {
          const reason = `Device clock drift ${clockDriftSeconds}s exceeds approved live tolerance (±${maxDriftSec}s). Synchronize kiosk NTP clock.`;
          recordImmutableEvent(db, {
            eventUid,
            employeeId: emp.id,
            deviceId: input.device.id,
            deviceName: input.device.name,
            attendanceDate: serverManila.isoDate,
            punchType: action,
            punchTime: serverManila.time12,
            serverTimestampUtc: serverNowIso,
            manilaTimestamp: serverManila.isoTimestamp,
            deviceTimestampUtc: deviceTimestampUtcIso,
            clockDriftSeconds,
            offlineReplay: false,
            decision: 'REJECTED',
            decisionCode: 'CLOCK_DRIFT_EXCEEDED',
            decisionReason: reason,
            source: 'kiosk',
          });
          recordAudit(db, input.device.name, `Rejected kiosk punch (${action}) for ${emp.employee_code}: ${reason}`, 'Attendance', 'Warning', input.clientIp);
          return {
            statusCode: 422,
            body: {
              error: reason,
              code: 'CLOCK_DRIFT_EXCEEDED',
              clock_drift_seconds: clockDriftSeconds,
              max_clock_drift_seconds: maxDriftSec,
              event_uid: eventUid,
            },
          };
        }
      }
      effectiveUtcMs = serverNowUtc;
    }

    const effectiveManila = toManilaParts(effectiveUtcMs);
    const effectiveUtcIso = new Date(effectiveUtcMs).toISOString();
    const sourceTag = offlineReplay ? 'kiosk_offline' : 'kiosk';
    const forensicMeta = {
      monotonicSeq: input.monotonicSeq ?? null,
      deviceBootId: input.deviceBootId ?? null,
      biometricEvidenceHash: input.biometricEvidenceHash ?? null,
      biometricBound: input.biometricBound === true,
      captureMetadataJson: input.captureMetadataJson ?? null,
    };
    const touchDeviceHeartbeat = () => {
      const displayHeartbeat = `${serverManila.isoDate} ${serverManila.time24}`;
      db.prepare(
        `UPDATE devices
         SET status = 'Online',
             last_heartbeat = ?,
             last_heartbeat_utc = ?,
             last_clock_drift_seconds = COALESCE(?, last_clock_drift_seconds),
             last_monotonic_seq = CASE WHEN ? IS NOT NULL AND ? > last_monotonic_seq THEN ? ELSE last_monotonic_seq END,
             device_boot_id = CASE WHEN ? IS NOT NULL AND ? != '' THEN ? ELSE device_boot_id END
         WHERE id = ?`
      ).run(
        displayHeartbeat,
        serverNowIso,
        clockDriftSeconds,
        input.monotonicSeq ?? null,
        input.monotonicSeq ?? null,
        input.monotonicSeq ?? null,
        input.deviceBootId ?? null,
        input.deviceBootId ?? null,
        input.deviceBootId ?? null,
        input.device.id
      );
    };

    // 3. Handle TIME_IN
    if (action === 'TIME_IN') {
      const shiftDate = resolveShiftDateForTimeIn(effectiveUtcMs, shift);
      const window = computeShiftWindow(shiftDate, shift);

      const existing = db
        .prepare('SELECT * FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(emp.id, shiftDate) as StoredAttendanceRow | undefined;

      // NEVER overwrite a valid TIME_IN and NEVER implicitly convert repeated TIME_IN into TIME_OUT!
      if (existing && existing.time_in) {
        const reason = `Duplicate TIME_IN rejected for shift date ${shiftDate}; existing TIME_IN (${existing.time_in}) preserved without implicit TIME_OUT conversion.`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: shiftDate,
          punchType: 'TIME_IN',
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'REJECTED',
          decisionCode: 'DUPLICATE_TIME_IN',
          decisionReason: reason,
          source: sourceTag,
          ...forensicMeta,
        });
        if (offlineReplay) {
          escalateToHr(db, {
            employeeId: emp.id,
            employeeName: emp.full_name,
            shiftDate,
            requestType: 'Time In',
            requestedTime: effectiveManila.time12,
            title: 'Offline TIME_IN conflict preserved original punch',
            reason,
            createCorrection: false,
          });
        }
        touchDeviceHeartbeat();
        recordAudit(db, input.device.name, `Rejected duplicate TIME_IN for ${emp.full_name} (${emp.employee_code}) on ${shiftDate}`, 'Attendance', 'Warning', input.clientIp);
        return {
          statusCode: 409,
          body: {
            error: reason,
            code: 'DUPLICATE_TIME_IN',
            conflict_preserved: true,
            shift_date: shiftDate,
            existing_time_in: existing.time_in,
            event_uid: eventUid,
          },
        };
      }

      // Check approved leave (block non-OB leave; allow OB as 'OB')
      const approvedLeave = getApprovedLeaveOnDate(db, emp.id, shiftDate);
      if (approvedLeave && !isOfficialBusinessType(approvedLeave.leave_type)) {
        const reason = `TIME_IN rejected: employee has approved ${approvedLeave.leave_type} on ${shiftDate}. Contact HR to revoke leave first.`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: shiftDate,
          punchType: 'TIME_IN',
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'REJECTED',
          decisionCode: 'ON_APPROVED_LEAVE',
          decisionReason: reason,
          source: sourceTag,
        });
        return {
          statusCode: 409,
          body: { error: reason, code: 'ON_APPROVED_LEAVE', shift_date: shiftDate, event_uid: eventUid },
        };
      }

      const holiday = getHolidayOnDate(db, shiftDate);
      const isRestDay = isRestDayForShift(shiftDate, shift.rest_days);

      let lateMinutes = 0;
      let status: AttendanceStatus;
      const remarkParts: string[] = [];

      if (shift.status !== 'Active') {
        status = 'No Schedule';
        remarkParts.push(`Inactive shift schedule (${shift.name})`);
      } else if (holiday) {
        status = 'Holiday';
        remarkParts.push(`Worked on ${holiday.type} Holiday: ${holiday.name}`);
      } else if (isRestDay) {
        status = 'Rest Day';
        remarkParts.push(`Worked on Rest Day (${getManilaDayCodeForIsoDate(shiftDate)})`);
      } else if (approvedLeave && isOfficialBusinessType(approvedLeave.leave_type)) {
        status = 'OB';
        remarkParts.push(`Official Business (${approvedLeave.leave_type})`);
      } else if (effectiveUtcMs > window.graceDeadlineUtc) {
        lateMinutes = Math.max(1, Math.ceil((effectiveUtcMs - window.scheduledStartUtc) / 60000));
        status = 'Late';
        remarkParts.push(`Late by ${lateMinutes}m (grace ${shift.grace_minutes}m)`);
      } else {
        status = 'Present';
        remarkParts.push(offlineReplay ? 'Kiosk offline-replayed punch' : 'Kiosk verified punch');
      }

      if (input.untrustedClientPunchTime) {
        remarkParts.push('Server clock authoritative');
      }
      const remarks = remarkParts.join(' · ');

      recordImmutableEvent(db, {
        eventUid,
        employeeId: emp.id,
        deviceId: input.device.id,
        deviceName: input.device.name,
        attendanceDate: shiftDate,
        punchType: 'TIME_IN',
        punchTime: effectiveManila.time12,
        serverTimestampUtc: serverNowIso,
        manilaTimestamp: effectiveManila.isoTimestamp,
        deviceTimestampUtc: deviceTimestampUtcIso,
        clockDriftSeconds,
        offlineReplay,
        decision: 'ACCEPTED',
        decisionCode: 'OK',
        decisionReason: `Accepted TIME_IN for shift ${shiftDate} (${status})`,
        source: sourceTag,
        ...forensicMeta,
      });

      if (existing) {
        // Fill previously unpunched pre-reconciled row (e.g. Holiday/Rest Day row with null time_in)
        db.prepare(
          `UPDATE attendance_records
           SET time_in = ?, time_in_utc = ?, work_hours = 'In Shift', late_minutes = ?,
               status = ?, device_name = ?, remarks = ?
           WHERE id = ?`
        ).run(effectiveManila.time12, effectiveUtcIso, lateMinutes, status, input.device.name, remarks, existing.id);
      } else {
        db.prepare(
          `INSERT INTO attendance_records
            (employee_id, date, time_in, time_in_utc, time_out, work_hours, late_minutes, undertime_minutes, overtime_minutes, status, device_name, remarks)
           VALUES (?, ?, ?, ?, NULL, 'In Shift', ?, 0, 0, ?, ?, ?)`
        ).run(emp.id, shiftDate, effectiveManila.time12, effectiveUtcIso, lateMinutes, status, input.device.name, remarks);
      }

      touchDeviceHeartbeat();
      recordAudit(
        db,
        input.device.name,
        `Kiosk TIME_IN logged for ${emp.full_name} (${emp.employee_code}) on shift ${shiftDate} at ${effectiveManila.time12} PHT (${status})`,
        'Attendance',
        'Success',
        input.clientIp
      );

      return {
        statusCode: 201,
        body: {
          ok: true,
          action: 'TIME_IN',
          event_uid: eventUid,
          employee_id: emp.id,
          department_id: emp.department_id,
          employee: emp.full_name,
          shift_date: shiftDate,
          status,
          late_minutes: lateMinutes,
          time: effectiveManila.time12,
          manila_timestamp: effectiveManila.isoTimestamp,
          server_timestamp_utc: serverNowIso,
          clock_drift_seconds: clockDriftSeconds,
          offline_replay: offlineReplay,
        },
      };
    }

    // 4. Resolve target attendance record for BREAK_OUT / BREAK_IN / TIME_OUT / OVERTIME_OUT
    const todayIso = effectiveManila.isoDate;
    const yesterdayIso = addDaysIso(todayIso, -1);

    const todayRow = db
      .prepare('SELECT * FROM attendance_records WHERE employee_id = ? AND date = ?')
      .get(emp.id, todayIso) as StoredAttendanceRow | undefined;
    const yesterdayRow = db
      .prepare('SELECT * FROM attendance_records WHERE employee_id = ? AND date = ?')
      .get(emp.id, yesterdayIso) as StoredAttendanceRow | undefined;

    // Helper: pick active open row (today open preferred, else yesterday open)
    const openRow: StoredAttendanceRow | undefined =
      todayRow && todayRow.time_in && !todayRow.time_out
        ? todayRow
        : yesterdayRow && yesterdayRow.time_in && !yesterdayRow.time_out
          ? yesterdayRow
          : undefined;

    // 4a. Handle OVERTIME_OUT (requires completed TIME_OUT, never overwrites TIME_OUT)
    if (action === 'OVERTIME_OUT') {
      const closedRow: StoredAttendanceRow | undefined =
        todayRow && todayRow.time_in && todayRow.time_out
          ? todayRow
          : yesterdayRow && yesterdayRow.time_in && yesterdayRow.time_out
            ? yesterdayRow
            : undefined;

      if (!closedRow) {
        const reason = `OVERTIME_OUT rejected: no completed TIME_IN/TIME_OUT shift found on ${todayIso} or ${yesterdayIso}.`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: todayIso,
          punchType: 'OVERTIME_OUT',
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'REJECTED',
          decisionCode: 'UNMATCHED_OVERTIME_OUT',
          decisionReason: reason,
          source: sourceTag,
        });
        return {
          statusCode: 409,
          body: { error: reason, code: 'UNMATCHED_OVERTIME_OUT', event_uid: eventUid },
        };
      }

      if (closedRow.overtime_out) {
        const reason = `Duplicate OVERTIME_OUT rejected for shift ${closedRow.date}; existing OVERTIME_OUT (${closedRow.overtime_out}) preserved.`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: closedRow.date,
          punchType: 'OVERTIME_OUT',
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'REJECTED',
          decisionCode: 'DUPLICATE_OVERTIME_OUT',
          decisionReason: reason,
          source: sourceTag,
        });
        return {
          statusCode: 409,
          body: { error: reason, code: 'DUPLICATE_OVERTIME_OUT', shift_date: closedRow.date, event_uid: eventUid },
        };
      }

      const window = computeShiftWindow(closedRow.date, shift);
      const timeOutUtc = getEffectiveUtcFromRow(closedRow.time_out_utc, closedRow.date, closedRow.time_out, shift);
      const timeInUtc = getEffectiveUtcFromRow(closedRow.time_in_utc, closedRow.date, closedRow.time_in, shift);

      if (timeOutUtc !== null && effectiveUtcMs <= timeOutUtc) {
        const reason = `OVERTIME_OUT (${effectiveManila.time12}) must be later than recorded TIME_OUT (${closedRow.time_out}).`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: closedRow.date,
          punchType: 'OVERTIME_OUT',
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'REJECTED',
          decisionCode: 'OUT_OF_ORDER_TIMESTAMP',
          decisionReason: reason,
          source: sourceTag,
        });
        return { statusCode: 409, body: { error: reason, code: 'OUT_OF_ORDER_TIMESTAMP', event_uid: eventUid } };
      }

      if (effectiveUtcMs > window.finalTimeOutCutoffUtc) {
        const cutoffManila = toManilaParts(window.finalTimeOutCutoffUtc);
        const reason = `OVERTIME_OUT at ${effectiveManila.isoTimestamp} exceeds final shift cutoff (${cutoffManila.isoTimestamp}); escalated for HR review.`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: closedRow.date,
          punchType: 'OVERTIME_OUT',
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'ESCALATED',
          decisionCode: 'CUTOFF_EXCEEDED_ESCALATED',
          decisionReason: reason,
          source: sourceTag,
        });
        const esc = escalateToHr(db, {
          employeeId: emp.id,
          employeeName: emp.full_name,
          shiftDate: closedRow.date,
          requestType: 'Time Out',
          requestedTime: effectiveManila.time12,
          title: 'Late OVERTIME_OUT past 03:00 Asia/Manila cutoff',
          reason,
          createCorrection: true,
        });
        return {
          statusCode: 422,
          body: { error: reason, code: 'CUTOFF_EXCEEDED_ESCALATED', escalated: true, correction_id: esc.correctionId, event_uid: eventUid },
        };
      }

      const breakMs =
        closedRow.break_out_utc && closedRow.break_in_utc
          ? Math.max(0, Date.parse(closedRow.break_in_utc) - Date.parse(closedRow.break_out_utc))
          : 0;
      const totalMins = timeInUtc !== null ? Math.max(0, Math.floor((effectiveUtcMs - timeInUtc - breakMs) / 60000)) : 0;
      const otBaseUtc = Math.max(window.scheduledEndUtc, timeOutUtc ?? window.scheduledEndUtc);
      const overtimeMinutes = Math.max(0, Math.floor((effectiveUtcMs - otBaseUtc) / 60000));
      const workHours = formatDurationMinutes(totalMins);

      recordImmutableEvent(db, {
        eventUid,
        employeeId: emp.id,
        deviceId: input.device.id,
        deviceName: input.device.name,
        attendanceDate: closedRow.date,
        punchType: 'OVERTIME_OUT',
        punchTime: effectiveManila.time12,
        serverTimestampUtc: serverNowIso,
        manilaTimestamp: effectiveManila.isoTimestamp,
        deviceTimestampUtc: deviceTimestampUtcIso,
        clockDriftSeconds,
        offlineReplay,
        decision: 'ACCEPTED',
        decisionCode: 'OK',
        decisionReason: `Accepted OVERTIME_OUT (+${overtimeMinutes}m OT) without modifying TIME_OUT`,
        source: sourceTag,
        ...forensicMeta,
      });

      db.prepare(
        `UPDATE attendance_records
         SET overtime_out = ?, overtime_out_utc = ?, overtime_minutes = ?, work_hours = ?,
             remarks = CASE WHEN remarks = '' THEN ? ELSE remarks || ' · ' || ? END
         WHERE id = ?`
      ).run(
        effectiveManila.time12,
        effectiveUtcIso,
        overtimeMinutes,
        workHours,
        `OT Out ${effectiveManila.time12} (${overtimeMinutes}m)`,
        `OT Out ${effectiveManila.time12} (${overtimeMinutes}m)`,
        closedRow.id
      );

      touchDeviceHeartbeat();
      recordAudit(db, input.device.name, `Kiosk OVERTIME_OUT logged for ${emp.full_name} (${emp.employee_code}) on shift ${closedRow.date}`, 'Attendance', 'Success', input.clientIp);
      return {
        statusCode: 200,
        body: {
          ok: true,
          action: 'OVERTIME_OUT',
          event_uid: eventUid,
          employee_id: emp.id,
          department_id: emp.department_id,
          employee: emp.full_name,
          shift_date: closedRow.date,
          time: effectiveManila.time12,
          time_out: closedRow.time_out,
          overtime_minutes: overtimeMinutes,
          work_hours: workHours,
          manila_timestamp: effectiveManila.isoTimestamp,
        },
      };
    }

    // 4b. Handle BREAK_OUT and BREAK_IN
    if (action === 'BREAK_OUT' || action === 'BREAK_IN') {
      if (!openRow) {
        const closedExists = (todayRow && todayRow.time_out) || (yesterdayRow && yesterdayRow.time_out);
        const code = closedExists ? 'SHIFT_ALREADY_CLOSED' : action === 'BREAK_OUT' ? 'UNMATCHED_BREAK_OUT' : 'UNMATCHED_BREAK_IN';
        const reason = closedExists
          ? `${action} rejected: shift is already closed with TIME_OUT.`
          : `${action} rejected: no open TIME_IN shift found on ${todayIso} or ${yesterdayIso}.`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: todayIso,
          punchType: action,
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'REJECTED',
          decisionCode: code,
          decisionReason: reason,
          source: sourceTag,
        });
        return { statusCode: 409, body: { error: reason, code, event_uid: eventUid } };
      }

      const window = computeShiftWindow(openRow.date, shift);
      if (effectiveUtcMs > window.finalTimeOutCutoffUtc) {
        const reason = `${action} rejected: timestamp exceeds shift cutoff for ${openRow.date}.`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: openRow.date,
          punchType: action,
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'REJECTED',
          decisionCode: 'CUTOFF_EXCEEDED',
          decisionReason: reason,
          source: sourceTag,
        });
        return { statusCode: 422, body: { error: reason, code: 'CUTOFF_EXCEEDED', event_uid: eventUid } };
      }

      const timeInUtc = getEffectiveUtcFromRow(openRow.time_in_utc, openRow.date, openRow.time_in, shift);
      if (timeInUtc !== null && effectiveUtcMs < timeInUtc) {
        const reason = `${action} timestamp cannot precede TIME_IN (${openRow.time_in}).`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: openRow.date,
          punchType: action,
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'REJECTED',
          decisionCode: 'OUT_OF_ORDER_TIMESTAMP',
          decisionReason: reason,
          source: sourceTag,
        });
        return { statusCode: 409, body: { error: reason, code: 'OUT_OF_ORDER_TIMESTAMP', event_uid: eventUid } };
      }

      if (action === 'BREAK_OUT') {
        if (openRow.break_out) {
          const reason = `Duplicate BREAK_OUT rejected for shift ${openRow.date}; existing BREAK_OUT (${openRow.break_out}) preserved.`;
          recordImmutableEvent(db, {
            eventUid,
            employeeId: emp.id,
            deviceId: input.device.id,
            deviceName: input.device.name,
            attendanceDate: openRow.date,
            punchType: 'BREAK_OUT',
            punchTime: effectiveManila.time12,
            serverTimestampUtc: serverNowIso,
            manilaTimestamp: effectiveManila.isoTimestamp,
            deviceTimestampUtc: deviceTimestampUtcIso,
            clockDriftSeconds,
            offlineReplay,
            decision: 'REJECTED',
            decisionCode: 'DUPLICATE_BREAK_OUT',
            decisionReason: reason,
            source: sourceTag,
          });
          return { statusCode: 409, body: { error: reason, code: 'DUPLICATE_BREAK_OUT', event_uid: eventUid } };
        }

        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: openRow.date,
          punchType: 'BREAK_OUT',
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'ACCEPTED',
          decisionCode: 'OK',
          decisionReason: `Accepted BREAK_OUT for shift ${openRow.date}`,
          source: sourceTag,
          ...forensicMeta,
        });
        db.prepare('UPDATE attendance_records SET break_out = ?, break_out_utc = ? WHERE id = ?').run(
          effectiveManila.time12,
          effectiveUtcIso,
          openRow.id
        );
        touchDeviceHeartbeat();
        recordAudit(db, input.device.name, `Kiosk BREAK_OUT logged for ${emp.full_name} on shift ${openRow.date}`, 'Attendance', 'Success', input.clientIp);
        return {
          statusCode: 200,
          body: {
            ok: true,
            action: 'BREAK_OUT',
            event_uid: eventUid,
            employee_id: emp.id,
            department_id: emp.department_id,
            employee: emp.full_name,
            shift_date: openRow.date,
            time: effectiveManila.time12,
            manila_timestamp: effectiveManila.isoTimestamp,
          },
        };
      }

      // BREAK_IN
      if (!openRow.break_out) {
        const reason = `BREAK_IN rejected for shift ${openRow.date}: no prior BREAK_OUT recorded.`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: openRow.date,
          punchType: 'BREAK_IN',
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'REJECTED',
          decisionCode: 'UNMATCHED_BREAK_IN',
          decisionReason: reason,
          source: sourceTag,
        });
        return { statusCode: 409, body: { error: reason, code: 'UNMATCHED_BREAK_IN', event_uid: eventUid } };
      }
      if (openRow.break_in) {
        const reason = `Duplicate BREAK_IN rejected for shift ${openRow.date}; existing BREAK_IN (${openRow.break_in}) preserved.`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: openRow.date,
          punchType: 'BREAK_IN',
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'REJECTED',
          decisionCode: 'DUPLICATE_BREAK_IN',
          decisionReason: reason,
          source: sourceTag,
        });
        return { statusCode: 409, body: { error: reason, code: 'DUPLICATE_BREAK_IN', event_uid: eventUid } };
      }
      const breakOutUtc = getEffectiveUtcFromRow(openRow.break_out_utc, openRow.date, openRow.break_out, shift);
      if (breakOutUtc !== null && effectiveUtcMs < breakOutUtc) {
        const reason = `BREAK_IN timestamp cannot precede BREAK_OUT (${openRow.break_out}).`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: openRow.date,
          punchType: 'BREAK_IN',
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'REJECTED',
          decisionCode: 'OUT_OF_ORDER_TIMESTAMP',
          decisionReason: reason,
          source: sourceTag,
        });
        return { statusCode: 409, body: { error: reason, code: 'OUT_OF_ORDER_TIMESTAMP', event_uid: eventUid } };
      }

      recordImmutableEvent(db, {
        eventUid,
        employeeId: emp.id,
        deviceId: input.device.id,
        deviceName: input.device.name,
        attendanceDate: openRow.date,
        punchType: 'BREAK_IN',
        punchTime: effectiveManila.time12,
        serverTimestampUtc: serverNowIso,
        manilaTimestamp: effectiveManila.isoTimestamp,
        deviceTimestampUtc: deviceTimestampUtcIso,
        clockDriftSeconds,
        offlineReplay,
        decision: 'ACCEPTED',
        decisionCode: 'OK',
        decisionReason: `Accepted BREAK_IN for shift ${openRow.date}`,
        source: sourceTag,
        ...forensicMeta,
      });
      db.prepare('UPDATE attendance_records SET break_in = ?, break_in_utc = ? WHERE id = ?').run(
        effectiveManila.time12,
        effectiveUtcIso,
        openRow.id
      );
      touchDeviceHeartbeat();
      recordAudit(db, input.device.name, `Kiosk BREAK_IN logged for ${emp.full_name} on shift ${openRow.date}`, 'Attendance', 'Success', input.clientIp);
      return {
        statusCode: 200,
        body: {
          ok: true,
          action: 'BREAK_IN',
          event_uid: eventUid,
          employee_id: emp.id,
          department_id: emp.department_id,
          employee: emp.full_name,
          shift_date: openRow.date,
          time: effectiveManila.time12,
          manila_timestamp: effectiveManila.isoTimestamp,
        },
      };
    }

    // 4c. Handle TIME_OUT
    if (!openRow) {
      // Check if shift already has a valid TIME_OUT (duplicate TIME_OUT — NEVER overwrite!)
      const alreadyClosed =
        todayRow && todayRow.time_in && todayRow.time_out
          ? todayRow
          : yesterdayRow &&
              yesterdayRow.time_in &&
              yesterdayRow.time_out &&
              effectiveUtcMs <= computeShiftWindow(yesterdayRow.date, shift).finalTimeOutCutoffUtc
            ? yesterdayRow
            : undefined;

      if (alreadyClosed) {
        const reason = `Duplicate TIME_OUT rejected for shift ${alreadyClosed.date}; existing TIME_OUT (${alreadyClosed.time_out}) preserved.`;
        recordImmutableEvent(db, {
          eventUid,
          employeeId: emp.id,
          deviceId: input.device.id,
          deviceName: input.device.name,
          attendanceDate: alreadyClosed.date,
          punchType: 'TIME_OUT',
          punchTime: effectiveManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: effectiveManila.isoTimestamp,
          deviceTimestampUtc: deviceTimestampUtcIso,
          clockDriftSeconds,
          offlineReplay,
          decision: 'REJECTED',
          decisionCode: 'DUPLICATE_TIME_OUT',
          decisionReason: reason,
          source: sourceTag,
          ...forensicMeta,
        });
        if (offlineReplay) {
          escalateToHr(db, {
            employeeId: emp.id,
            employeeName: emp.full_name,
            shiftDate: alreadyClosed.date,
            requestType: 'Time Out',
            requestedTime: effectiveManila.time12,
            title: 'Offline TIME_OUT conflict preserved original punch',
            reason,
            createCorrection: false,
          });
        }
        touchDeviceHeartbeat();
        recordAudit(db, input.device.name, `Rejected duplicate TIME_OUT for ${emp.full_name} on shift ${alreadyClosed.date}`, 'Attendance', 'Warning', input.clientIp);
        return {
          statusCode: 409,
          body: {
            error: reason,
            code: 'DUPLICATE_TIME_OUT',
            conflict_preserved: true,
            shift_date: alreadyClosed.date,
            existing_time_out: alreadyClosed.time_out,
            event_uid: eventUid,
          },
        };
      }

      // Unmatched TIME_OUT (no TIME_IN exists) — NEVER fabricate TIME_IN; reject & escalate!
      const reason = `Unmatched TIME_OUT at ${effectiveManila.time12} PHT with no prior TIME_IN on ${todayIso} or ${yesterdayIso}. Escalated to HR.`;
      recordImmutableEvent(db, {
        eventUid,
        employeeId: emp.id,
        deviceId: input.device.id,
        deviceName: input.device.name,
        attendanceDate: todayIso,
        punchType: 'TIME_OUT',
        punchTime: effectiveManila.time12,
        serverTimestampUtc: serverNowIso,
        manilaTimestamp: effectiveManila.isoTimestamp,
        deviceTimestampUtc: deviceTimestampUtcIso,
        clockDriftSeconds,
        offlineReplay,
        decision: 'ESCALATED',
        decisionCode: 'UNMATCHED_TIME_OUT',
        decisionReason: reason,
        source: sourceTag,
      });
      const esc = escalateToHr(db, {
        employeeId: emp.id,
        employeeName: emp.full_name,
        shiftDate: todayIso,
        requestType: 'Time Out',
        requestedTime: effectiveManila.time12,
        title: 'Unmatched TIME_OUT without TIME_IN',
        reason,
        createCorrection: true,
      });
      touchDeviceHeartbeat();
      recordAudit(db, input.device.name, `Escalated unmatched TIME_OUT for ${emp.full_name} (${emp.employee_code})`, 'Attendance', 'Warning', input.clientIp);
      return {
        statusCode: 409,
        body: {
          error: reason,
          code: 'UNMATCHED_TIME_OUT',
          escalated: true,
          correction_id: esc.correctionId,
          event_uid: eventUid,
        },
      };
    }

    // Validate open shift TIME_OUT against ordering and 03:00 Asia/Manila cutoff
    const window = computeShiftWindow(openRow.date, shift);
    const timeInUtc = getEffectiveUtcFromRow(openRow.time_in_utc, openRow.date, openRow.time_in, shift);

    if (timeInUtc !== null && effectiveUtcMs < timeInUtc) {
      const reason = `Out-of-order TIME_OUT (${effectiveManila.isoTimestamp}) precedes recorded TIME_IN (${openRow.time_in}).`;
      recordImmutableEvent(db, {
        eventUid,
        employeeId: emp.id,
        deviceId: input.device.id,
        deviceName: input.device.name,
        attendanceDate: openRow.date,
        punchType: 'TIME_OUT',
        punchTime: effectiveManila.time12,
        serverTimestampUtc: serverNowIso,
        manilaTimestamp: effectiveManila.isoTimestamp,
        deviceTimestampUtc: deviceTimestampUtcIso,
        clockDriftSeconds,
        offlineReplay,
        decision: 'REJECTED',
        decisionCode: 'OUT_OF_ORDER_TIMESTAMP',
        decisionReason: reason,
        source: sourceTag,
      });
      recordAudit(db, input.device.name, `Rejected out-of-order TIME_OUT for ${emp.full_name} on ${openRow.date}`, 'Attendance', 'Warning', input.clientIp);
      return {
        statusCode: 409,
        body: { error: reason, code: 'OUT_OF_ORDER_TIMESTAMP', shift_date: openRow.date, event_uid: eventUid },
      };
    }

    if (effectiveUtcMs > window.finalTimeOutCutoffUtc) {
      const cutoffManila = toManilaParts(window.finalTimeOutCutoffUtc);
      const reason = `TIME_OUT at ${effectiveManila.isoTimestamp} exceeds allowed cutoff (${cutoffManila.isoTimestamp} Asia/Manila) for shift ${openRow.date}; escalated for HR approval.`;
      recordImmutableEvent(db, {
        eventUid,
        employeeId: emp.id,
        deviceId: input.device.id,
        deviceName: input.device.name,
        attendanceDate: openRow.date,
        punchType: 'TIME_OUT',
        punchTime: effectiveManila.time12,
        serverTimestampUtc: serverNowIso,
        manilaTimestamp: effectiveManila.isoTimestamp,
        deviceTimestampUtc: deviceTimestampUtcIso,
        clockDriftSeconds,
        offlineReplay,
        decision: 'ESCALATED',
        decisionCode: 'CUTOFF_EXCEEDED_ESCALATED',
        decisionReason: reason,
        source: sourceTag,
      });
      const esc = escalateToHr(db, {
        employeeId: emp.id,
        employeeName: emp.full_name,
        shiftDate: openRow.date,
        requestType: 'Time Out',
        requestedTime: effectiveManila.time12,
        title: 'TIME_OUT past 03:00 Asia/Manila cutoff escalated',
        reason,
        createCorrection: true,
      });
      touchDeviceHeartbeat();
      recordAudit(db, input.device.name, `Escalated late TIME_OUT past cutoff for ${emp.full_name} (${openRow.date})`, 'Attendance', 'Warning', input.clientIp);
      return {
        statusCode: 422,
        body: {
          error: reason,
          code: 'CUTOFF_EXCEEDED_ESCALATED',
          shift_date: openRow.date,
          cutoff_manila: cutoffManila.isoTimestamp,
          escalated: true,
          correction_id: esc.correctionId,
          event_uid: eventUid,
        },
      };
    }

    // Valid TIME_OUT within shift cutoff -> compute exact elapsed hours, undertime, overtime & final status
    const breakMs =
      openRow.break_out_utc && openRow.break_in_utc
        ? Math.max(0, Date.parse(openRow.break_in_utc) - Date.parse(openRow.break_out_utc))
        : 0;
    const workedMinutes =
      timeInUtc !== null ? Math.max(0, Math.floor((effectiveUtcMs - timeInUtc - breakMs) / 60000)) : 0;
    const workHours = formatDurationMinutes(workedMinutes);

    const isSpecialDay =
      openRow.status === 'Holiday' ||
      openRow.status === 'Rest Day' ||
      openRow.status === 'OB' ||
      openRow.status === 'No Schedule';

    const undertimeMinutes =
      !isSpecialDay && effectiveUtcMs < window.scheduledEndUtc
        ? Math.max(1, Math.ceil((window.scheduledEndUtc - effectiveUtcMs) / 60000))
        : 0;
    const overtimeMinutes =
      effectiveUtcMs > window.scheduledEndUtc
        ? Math.floor((effectiveUtcMs - window.scheduledEndUtc) / 60000)
        : 0;

    let finalStatus: AttendanceStatus = openRow.status;
    if (!isSpecialDay) {
      if (undertimeMinutes > 0) {
        finalStatus = 'Undertime';
      } else if (openRow.late_minutes > 0 || openRow.status === 'Late') {
        finalStatus = 'Late';
      } else {
        finalStatus = 'Present';
      }
    }

    const updatedRemarkParts = openRow.remarks ? [openRow.remarks] : [];
    if (undertimeMinutes > 0) {
      updatedRemarkParts.push(`Early departure: ${undertimeMinutes}m undertime`);
    }
    if (effectiveManila.isoDate !== openRow.date) {
      updatedRemarkParts.push(`Next-day Time Out (${effectiveManila.isoDate} ${effectiveManila.time12} PHT)`);
    }
    const finalRemarks = updatedRemarkParts.join(' · ');

    recordImmutableEvent(db, {
      eventUid,
      employeeId: emp.id,
      deviceId: input.device.id,
      deviceName: input.device.name,
      attendanceDate: openRow.date,
      punchType: 'TIME_OUT',
      punchTime: effectiveManila.time12,
      serverTimestampUtc: serverNowIso,
      manilaTimestamp: effectiveManila.isoTimestamp,
      deviceTimestampUtc: deviceTimestampUtcIso,
      clockDriftSeconds,
      offlineReplay,
      decision: 'ACCEPTED',
      decisionCode: 'OK',
      decisionReason: `Accepted TIME_OUT for shift ${openRow.date} (${finalStatus}, ${workHours})`,
      source: sourceTag,
      ...forensicMeta,
    });

    db.prepare(
      `UPDATE attendance_records
       SET time_out = ?, time_out_utc = ?, work_hours = ?, undertime_minutes = ?, overtime_minutes = ?,
           status = ?, device_name = ?, remarks = ?
       WHERE id = ?`
    ).run(
      effectiveManila.time12,
      effectiveUtcIso,
      workHours,
      undertimeMinutes,
      overtimeMinutes,
      finalStatus,
      input.device.name,
      finalRemarks,
      openRow.id
    );

    touchDeviceHeartbeat();
    recordAudit(
      db,
      input.device.name,
      `Kiosk TIME_OUT logged for ${emp.full_name} (${emp.employee_code}) on shift ${openRow.date} at ${effectiveManila.time12} PHT (${finalStatus}, ${workHours})`,
      'Attendance',
      'Success',
      input.clientIp
    );

    return {
      statusCode: 200,
      body: {
        ok: true,
        action: 'TIME_OUT',
        event_uid: eventUid,
        employee_id: emp.id,
        department_id: emp.department_id,
        employee: emp.full_name,
        shift_date: openRow.date,
        status: finalStatus,
        work_hours: workHours,
        late_minutes: openRow.late_minutes,
        undertime_minutes: undertimeMinutes,
        overtime_minutes: overtimeMinutes,
        time: effectiveManila.time12,
        manila_timestamp: effectiveManila.isoTimestamp,
        server_timestamp_utc: serverNowIso,
        offline_replay: offlineReplay,
      },
    };
  });

  return tx.immediate();
}

/**
 * Separate Attendance Reconciliation Engine (BUILD 08).
 * Evaluates a shift date without fabricating any punches or overwriting valid completed punches:
 *  - Open shifts (`time_in` present, `time_out` null) past their cutoff => `Missing Time Out`
 *  - Employees with no attendance record:
 *      1. Inactive shift => `No Schedule`
 *      2. Approved Leave => `OB` (if Official Business) or `On Leave`
 *      3. Holiday => `Holiday`
 *      4. Shift Rest Day => `Rest Day`
 *      5. Past shift cutoff => `Absent`
 */
export function reconcileAttendanceForDate(
  db: Database.Database,
  shiftDate: string,
  options: ReconcileDateOptions
): ReconcileDateResult {
  const serverNowUtc = options.serverNowUtc ?? Date.now();
  const serverNowIso = new Date(serverNowUtc).toISOString();
  const serverManila = toManilaParts(serverNowUtc);
  const clientIp = options.clientIp || '127.0.0.1';

  const result: ReconcileDateResult = {
    date: shiftDate,
    evaluatedEmployees: 0,
    markedMissingTimeOut: 0,
    markedAbsent: 0,
    markedOnLeave: 0,
    markedOb: 0,
    markedHoliday: 0,
    markedRestDay: 0,
    markedNoSchedule: 0,
    skippedOpenOrComplete: 0,
  };

  const tx = db.transaction(() => {
    const activeEmps = db
      .prepare(
        `SELECT e.id, e.employee_code, e.full_name,
                s.id as shift_id, s.name as shift_name, s.time_in as shift_time_in,
                s.time_out as shift_time_out, s.grace_minutes, s.status as shift_status,
                COALESCE(s.rest_days, '') as rest_days
         FROM employees e
         JOIN shifts s ON e.shift_id = s.id
         WHERE e.status = 'Active'
         ORDER BY e.id ASC`
      )
      .all() as Array<{
      id: number;
      employee_code: string;
      full_name: string;
      shift_id: number;
      shift_name: string;
      shift_time_in: string;
      shift_time_out: string;
      grace_minutes: number;
      shift_status: string;
      rest_days: string;
    }>;

    const holiday = getHolidayOnDate(db, shiftDate);

    for (const emp of activeEmps) {
      result.evaluatedEmployees++;
      const shift: ShiftDefinition = {
        id: emp.shift_id,
        name: emp.shift_name,
        time_in: emp.shift_time_in,
        time_out: emp.shift_time_out,
        grace_minutes: emp.grace_minutes,
        status: emp.shift_status,
        rest_days: emp.rest_days,
      };
      const window = computeShiftWindow(shiftDate, shift);
      const isPastCutoff = serverNowUtc > window.finalTimeOutCutoffUtc;
      const isPastShiftEnd = options.forcePastShiftEnd && serverNowUtc > window.scheduledEndUtc;

      const existing = db
        .prepare('SELECT * FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(emp.id, shiftDate) as StoredAttendanceRow | undefined;

      if (existing) {
        // Open shift with TIME_IN but missing TIME_OUT past the 03:00 Asia/Manila (or overnight) cutoff
        if (existing.time_in && !existing.time_out && isPastCutoff && existing.status !== 'Missing Time Out') {
          const remark = existing.remarks
            ? `${existing.remarks} · Missing Time Out past cutoff`
            : 'Missing Time Out past cutoff (reconciled without fabricated punch)';
          db.prepare(
            `UPDATE attendance_records
             SET status = 'Missing Time Out', work_hours = 'Incomplete', remarks = ?, reconciled_at = ?
             WHERE id = ?`
          ).run(remark, serverNowIso, existing.id);

          recordImmutableEvent(db, {
            eventUid: `rec-mto-${emp.id}-${shiftDate}-${crypto.randomBytes(4).toString('hex')}`,
            employeeId: emp.id,
            deviceId: null,
            deviceName: 'Attendance Reconciliation',
            attendanceDate: shiftDate,
            punchType: 'reconcile',
            punchTime: serverManila.time12,
            serverTimestampUtc: serverNowIso,
            manilaTimestamp: serverManila.isoTimestamp,
            deviceTimestampUtc: null,
            clockDriftSeconds: null,
            offlineReplay: false,
            decision: 'ACCEPTED',
            decisionCode: 'RECONCILED_MISSING_TIME_OUT',
            decisionReason: `Marked Missing Time Out after cutoff ${toManilaParts(window.finalTimeOutCutoffUtc).isoTimestamp}`,
            source: 'reconciliation',
          });

          db.prepare(
            `INSERT INTO notifications (title, message, category, priority, is_read, action_module, action_entity_id)
             VALUES (?, ?, 'Attendance Alerts', 'Medium', 0, 'attendance', ?)`
          ).run(
            'Missing Time Out flagged',
            `${emp.full_name} (${emp.employee_code}) has TIME_IN (${existing.time_in}) on ${shiftDate} with no TIME_OUT past cutoff.`,
            existing.id
          );
          result.markedMissingTimeOut++;
        } else {
          result.skippedOpenOrComplete++;
        }
        continue;
      }

      // No attendance record exists for this employee on shiftDate
      let resolvedStatus: AttendanceStatus | null = null;
      let remark = '';

      const approvedLeave = getApprovedLeaveOnDate(db, emp.id, shiftDate);
      if (shift.status !== 'Active') {
        resolvedStatus = 'No Schedule';
        remark = `No active shift schedule (${shift.name})`;
        result.markedNoSchedule++;
      } else if (approvedLeave) {
        if (isOfficialBusinessType(approvedLeave.leave_type)) {
          resolvedStatus = 'OB';
          remark = `Approved ${approvedLeave.leave_type}`;
          result.markedOb++;
        } else {
          resolvedStatus = 'On Leave';
          remark = `Approved ${approvedLeave.leave_type}`;
          result.markedOnLeave++;
        }
      } else if (holiday) {
        resolvedStatus = 'Holiday';
        remark = `${holiday.type} Holiday: ${holiday.name}`;
        result.markedHoliday++;
      } else if (isRestDayForShift(shiftDate, shift.rest_days)) {
        resolvedStatus = 'Rest Day';
        remark = `Scheduled Rest Day (${getManilaDayCodeForIsoDate(shiftDate)})`;
        result.markedRestDay++;
      } else if (isPastCutoff || isPastShiftEnd) {
        resolvedStatus = 'Absent';
        remark = 'No check-in logged past shift cutoff (reconciled)';
        result.markedAbsent++;
      } else {
        result.skippedOpenOrComplete++;
      }

      if (resolvedStatus) {
        db.prepare(
          `INSERT INTO attendance_records
            (employee_id, date, time_in, time_out, work_hours, status, device_name, remarks, reconciled_at)
           VALUES (?, ?, NULL, NULL, '-', ?, 'Attendance Reconciliation', ?, ?)`
        ).run(emp.id, shiftDate, resolvedStatus, remark, serverNowIso);

        recordImmutableEvent(db, {
          eventUid: `rec-${resolvedStatus.toLowerCase().replace(/\s+/g, '_')}-${emp.id}-${shiftDate}-${crypto.randomBytes(4).toString('hex')}`,
          employeeId: emp.id,
          deviceId: null,
          deviceName: 'Attendance Reconciliation',
          attendanceDate: shiftDate,
          punchType: 'reconcile',
          punchTime: serverManila.time12,
          serverTimestampUtc: serverNowIso,
          manilaTimestamp: serverManila.isoTimestamp,
          deviceTimestampUtc: null,
          clockDriftSeconds: null,
          offlineReplay: false,
          decision: 'ACCEPTED',
          decisionCode: `RECONCILED_${resolvedStatus.toUpperCase().replace(/\s+/g, '_')}`,
          decisionReason: remark,
          source: 'reconciliation',
        });
      }
    }

    recordAudit(
      db,
      options.actorUsername,
      `Reconciled attendance for ${shiftDate} (MissingOut=${result.markedMissingTimeOut}, Absent=${result.markedAbsent}, OnLeave=${result.markedOnLeave}, OB=${result.markedOb}, Holiday=${result.markedHoliday}, RestDay=${result.markedRestDay}, NoSchedule=${result.markedNoSchedule})`,
      'Attendance',
      'Success',
      clientIp
    );
  });

  tx.immediate();
  return result;
}
