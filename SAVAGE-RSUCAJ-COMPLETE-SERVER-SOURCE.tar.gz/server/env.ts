import path from 'node:path';

export type NodeEnvironment = 'development' | 'production' | 'test';
export type AppMode = 'production' | 'staging' | 'demo' | 'test';
export type LogFormat = 'json' | 'pretty';

export interface EnvValidationOptions {
  /** Require initial admin bootstrap env vars (true on fresh empty DB or --strict checks). */
  requireInitialAdmin?: boolean;
  strict?: boolean;
}

export interface RuntimeEnvConfig {
  nodeEnv: NodeEnvironment;
  appMode: AppMode;
  port: number;
  databasePath: string;
  backupDir: string;
  backupEncryptionConfigured: boolean;
  backupRetentionCount: number;
  sqliteBusyTimeoutMs: number;
  sqliteWalAutocheckpoint: number;
  disableHmr: boolean;
  trustProxy: boolean;
  sessionSecretConfigured: boolean;
  sessionSecretPreviousConfigured: boolean;
  allowedOrigins: string[];
  cookieDomain: string | undefined;
  maxFailedLoginAttempts: number;
  lockoutDurationMinutes: number;
  loginRateLimitMax: number;
  adminInitialUsername: string;
  adminInitialEmail: string;
  adminInitialPasswordConfigured: boolean;
  googleSsoConfigured: boolean;
  smtpConfigured: boolean;
  logFormat: LogFormat;
  stagingPublicUrl: string | undefined;
  stagingImpairmentEnabled: boolean;
  stagingLogFile: string | undefined;
}

export interface EnvValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  config: RuntimeEnvConfig;
}

const KNOWN_PLACEHOLDER_PATTERNS = [
  /^change[_-]?me/i,
  /^your[_-]?/i,
  /^replace[_-]?me/i,
  /^placeholder$/i,
  /^secret$/i,
  /^password$/i,
  /^default$/i,
  /^admin@2025$/i,
];

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const EPHEMERAL_DIR_SEGMENTS = new Set(['dist', 'build', 'node_modules', '.git']);

export function isPlaceholderValue(value: string): boolean {
  const trimmed = value.trim();
  return KNOWN_PLACEHOLDER_PATTERNS.some((pattern) => pattern.test(trimmed));
}

export function isPathInsideEphemeralBuildDir(targetPath: string): boolean {
  const normalized = targetPath.replace(/\\/g, '/');
  const segments = normalized.split('/').filter(Boolean);
  return segments.some((seg) => EPHEMERAL_DIR_SEGMENTS.has(seg.toLowerCase()));
}

export function isAbsoluteCrossPlatformPath(targetPath: string): boolean {
  return path.isAbsolute(targetPath) || /^[A-Za-z]:[\\/]/.test(targetPath);
}

export function validatePasswordStrength(password: string): string | null {
  if (!password || password.length < 10) {
    return 'Password must be at least 10 characters long.';
  }
  if (isPlaceholderValue(password)) {
    return 'Password must not use a known default or placeholder value.';
  }
  if (!/[A-Z]/.test(password)) {
    return 'Password must include at least one uppercase letter.';
  }
  if (!/[a-z]/.test(password)) {
    return 'Password must include at least one lowercase letter.';
  }
  if (!/[0-9]/.test(password)) {
    return 'Password must include at least one digit.';
  }
  if (!/[^A-Za-z0-9]/.test(password)) {
    return 'Password must include at least one special character.';
  }
  return null;
}

function parseBooleanFlag(
  raw: string | undefined,
  defaultValue: boolean,
  name: string,
  errors: string[]
): boolean {
  if (raw === undefined || raw.trim() === '') return defaultValue;
  const normalized = raw.trim().toLowerCase();
  if (normalized === 'true') return true;
  if (normalized === 'false') return false;
  errors.push(`${name} must be "true" or "false" when set.`);
  return defaultValue;
}

function parsePositiveInt(
  raw: string | undefined,
  defaultValue: number,
  min: number,
  max: number,
  name: string,
  errors: string[]
): number {
  if (raw === undefined || raw.trim() === '') return defaultValue;
  const parsed = Number(raw.trim());
  if (!Number.isInteger(parsed) || parsed < min || parsed > max) {
    errors.push(`${name} must be an integer between ${min} and ${max} (received "${raw.trim()}").`);
    return defaultValue;
  }
  return parsed;
}

export function validateEnv(
  env: Record<string, string | undefined> = process.env,
  options: EnvValidationOptions = {}
): EnvValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // NODE_ENV
  const rawNodeEnv = (env.NODE_ENV ?? 'development').trim();
  let nodeEnv: NodeEnvironment = 'development';
  if (rawNodeEnv === 'development' || rawNodeEnv === 'production' || rawNodeEnv === 'test') {
    nodeEnv = rawNodeEnv;
  } else {
    errors.push(`NODE_ENV must be one of "development", "production", or "test" (received "${rawNodeEnv}").`);
  }

  // APP_MODE — explicit separation between PRODUCTION, STAGING, DEMO, and TEST
  const defaultAppMode: AppMode = nodeEnv === 'test' ? 'test' : 'production';
  const rawAppMode = (env.APP_MODE ?? defaultAppMode).trim().toLowerCase();
  let appMode: AppMode = defaultAppMode;
  if (rawAppMode === 'production' || rawAppMode === 'staging' || rawAppMode === 'demo' || rawAppMode === 'test') {
    appMode = rawAppMode;
  } else {
    errors.push(`APP_MODE must be one of "production", "staging", "demo", or "test" (received "${rawAppMode}").`);
  }

  if (nodeEnv === 'production' && appMode !== 'production' && appMode !== 'staging') {
    errors.push(
      `APP_MODE="${appMode}" is strictly forbidden when NODE_ENV=production. Production hosts must run with APP_MODE=production (or isolated APP_MODE=staging) and zero demo seeding.`
    );
  }

  // PORT
  const port = parsePositiveInt(env.PORT, 3000, 1, 65535, 'PORT', errors);

  // Boolean flags
  const disableHmr = parseBooleanFlag(env.DISABLE_HMR, false, 'DISABLE_HMR', errors);
  const trustProxy = parseBooleanFlag(env.TRUST_PROXY, false, 'TRUST_PROXY', errors);

  // SQLite Durability & Backup settings
  const sqliteBusyTimeoutMs = parsePositiveInt(
    env.SQLITE_BUSY_TIMEOUT_MS,
    5000,
    1000,
    60000,
    'SQLITE_BUSY_TIMEOUT_MS',
    errors
  );
  const sqliteWalAutocheckpoint = parsePositiveInt(
    env.SQLITE_WAL_AUTOCHECKPOINT,
    1000,
    100,
    10000,
    'SQLITE_WAL_AUTOCHECKPOINT',
    errors
  );
  const backupRetentionCount = parsePositiveInt(
    env.BACKUP_RETENTION_COUNT,
    14,
    1,
    365,
    'BACKUP_RETENTION_COUNT',
    errors
  );

  // Lockout / Rate Limit settings
  const maxFailedLoginAttempts = parsePositiveInt(
    env.MAX_FAILED_LOGIN_ATTEMPTS,
    5,
    3,
    20,
    'MAX_FAILED_LOGIN_ATTEMPTS',
    errors
  );
  const lockoutDurationMinutes = parsePositiveInt(
    env.LOCKOUT_DURATION_MINUTES,
    15,
    1,
    1440,
    'LOCKOUT_DURATION_MINUTES',
    errors
  );
  const loginRateLimitMax = parsePositiveInt(
    env.LOGIN_RATE_LIMIT_MAX,
    20,
    5,
    500,
    'LOGIN_RATE_LIMIT_MAX',
    errors
  );

  // DATABASE_PATH — Production requires explicit absolute persistent path outside build directories
  const trimmedDbPath = env.DATABASE_PATH?.trim() ?? '';
  const databasePath =
    trimmedDbPath === '' ? path.resolve(process.cwd(), 'data', 'savage_rsucaj.db') : trimmedDbPath;

  if (nodeEnv === 'production') {
    if (!trimmedDbPath) {
      errors.push(
        'DATABASE_PATH is required in production and must point to an absolute persistent storage path (e.g., /var/lib/savage-rsucaj/savage_rsucaj.db).'
      );
    } else if (trimmedDbPath === ':memory:') {
      errors.push('DATABASE_PATH=":memory:" is forbidden in production. Configure a persistent filesystem path.');
    } else if (!isAbsoluteCrossPlatformPath(trimmedDbPath)) {
      errors.push(
        `DATABASE_PATH must be an absolute path on persistent storage in production (received relative path "${trimmedDbPath}").`
      );
    } else if (isPathInsideEphemeralBuildDir(trimmedDbPath)) {
      errors.push(
        `DATABASE_PATH must not reside inside ephemeral build/dependency directories (dist, build, node_modules, .git): "${trimmedDbPath}".`
      );
    }
  } else if (trimmedDbPath && trimmedDbPath !== ':memory:' && isPathInsideEphemeralBuildDir(trimmedDbPath)) {
    errors.push(
      `DATABASE_PATH must not reside inside ephemeral build/dependency directories (dist, build, node_modules, .git): "${trimmedDbPath}".`
    );
  }

  // BACKUP_DIR
  const trimmedBackupDir = env.BACKUP_DIR?.trim() ?? '';
  const backupDir =
    trimmedBackupDir !== ''
      ? trimmedBackupDir
      : databasePath === ':memory:'
        ? path.resolve(process.cwd(), 'data', 'backups')
        : path.resolve(path.dirname(databasePath), 'backups');

  if (isPathInsideEphemeralBuildDir(backupDir)) {
    errors.push(
      `BACKUP_DIR must not reside inside ephemeral build/dependency directories (dist, build, node_modules, .git): "${backupDir}".`
    );
  }

  // BACKUP_ENCRYPTION_KEY — Optional AES-256-GCM passphrase for encrypted offsite archival
  const rawBackupKey = env.BACKUP_ENCRYPTION_KEY?.trim() ?? '';
  const backupEncryptionConfigured = rawBackupKey.length > 0;
  if (backupEncryptionConfigured) {
    if (isPlaceholderValue(rawBackupKey)) {
      errors.push('BACKUP_ENCRYPTION_KEY must not use a placeholder value.');
    } else if (rawBackupKey.length < 32) {
      errors.push('BACKUP_ENCRYPTION_KEY must be at least 32 characters long when set.');
    }
  } else if (nodeEnv === 'production') {
    warnings.push(
      'BACKUP_ENCRYPTION_KEY is not set; online SQLite backups will be stored locally unencrypted until an offsite encryption passphrase is configured.'
    );
  }

  // SESSION_SECRET — REQUIRED unconditionally (fail-secure; zero default fallback secret)
  const rawSecret = env.SESSION_SECRET?.trim() ?? '';
  const sessionSecretConfigured = rawSecret.length > 0;
  if (!sessionSecretConfigured) {
    errors.push(
      'SESSION_SECRET is required (minimum 32 random characters). Generate with: node -e "console.log(require(\'crypto\').randomBytes(48).toString(\'hex\'))"'
    );
  } else if (isPlaceholderValue(rawSecret)) {
    errors.push('SESSION_SECRET must not use a placeholder value.');
  } else if (rawSecret.length < 32) {
    errors.push('SESSION_SECRET must be at least 32 characters long.');
  }

  // SESSION_SECRET_PREVIOUS — Optional key-rotation window secret
  const rawPrevSecret = env.SESSION_SECRET_PREVIOUS?.trim() ?? '';
  const sessionSecretPreviousConfigured = rawPrevSecret.length > 0;
  if (sessionSecretPreviousConfigured) {
    if (isPlaceholderValue(rawPrevSecret)) {
      errors.push('SESSION_SECRET_PREVIOUS must not use a placeholder value.');
    } else if (rawPrevSecret.length < 32) {
      errors.push('SESSION_SECRET_PREVIOUS must be at least 32 characters long when set.');
    } else if (rawPrevSecret === rawSecret) {
      warnings.push('SESSION_SECRET_PREVIOUS is identical to SESSION_SECRET; remove it after rotation completes.');
    }
  }

  // ALLOWED_ORIGINS — Optional comma-separated origin allowlist
  const allowedOrigins: string[] = [];
  if (env.ALLOWED_ORIGINS && env.ALLOWED_ORIGINS.trim() !== '') {
    for (const entry of env.ALLOWED_ORIGINS.split(',')) {
      const origin = entry.trim();
      if (!origin) continue;
      try {
        const parsed = new URL(origin);
        allowedOrigins.push(parsed.origin);
      } catch {
        errors.push(`ALLOWED_ORIGINS contains invalid URL origin: "${origin}".`);
      }
    }
  }

  // COOKIE_DOMAIN — Optional cookie domain constraint
  const rawCookieDomain = env.COOKIE_DOMAIN?.trim() || undefined;
  if (rawCookieDomain && /[\s;,]/.test(rawCookieDomain)) {
    errors.push('COOKIE_DOMAIN must not contain whitespace, semicolons, or commas.');
  }

  // Initial Admin Credentials (required on fresh empty DB or --strict mode; ZERO hardcoded fallback)
  const requireInitialAdmin = Boolean(options.requireInitialAdmin || options.strict);
  const adminInitialUsername = env.ADMIN_INITIAL_USERNAME?.trim() ?? '';
  const adminInitialEmail = env.ADMIN_INITIAL_EMAIL?.trim() ?? '';
  const rawAdminPass = env.ADMIN_INITIAL_PASSWORD?.trim() ?? '';
  const adminInitialPasswordConfigured = rawAdminPass.length > 0;

  if (adminInitialUsername) {
    if (adminInitialUsername.length < 3 || /\s/.test(adminInitialUsername)) {
      errors.push('ADMIN_INITIAL_USERNAME must be at least 3 characters with no whitespace.');
    }
  } else if (requireInitialAdmin) {
    errors.push('ADMIN_INITIAL_USERNAME is required for initial administrator bootstrap.');
  }

  if (adminInitialEmail) {
    if (!EMAIL_PATTERN.test(adminInitialEmail)) {
      errors.push(`ADMIN_INITIAL_EMAIL must be a valid email address (received "${adminInitialEmail}").`);
    }
  } else if (requireInitialAdmin) {
    errors.push('ADMIN_INITIAL_EMAIL is required for initial administrator bootstrap.');
  }

  if (adminInitialPasswordConfigured) {
    const pwErr = validatePasswordStrength(rawAdminPass);
    if (pwErr) {
      errors.push(`ADMIN_INITIAL_PASSWORD invalid: ${pwErr}`);
    }
  } else if (requireInitialAdmin) {
    errors.push(
      'ADMIN_INITIAL_PASSWORD is required for initial administrator bootstrap (min 10 chars with upper, lower, digit, and symbol).'
    );
  }

  const googleSsoConfigured = Boolean(env.GOOGLE_OAUTH_CLIENT_ID?.trim());
  const smtpConfigured = Boolean(env.SMTP_HOST?.trim());

  // LOG_FORMAT
  const rawLogFormat = (env.LOG_FORMAT ?? (nodeEnv === 'production' || appMode === 'staging' ? 'json' : 'pretty'))
    .trim()
    .toLowerCase();
  let logFormat: LogFormat = 'pretty';
  if (rawLogFormat === 'json' || rawLogFormat === 'pretty') {
    logFormat = rawLogFormat;
  } else {
    errors.push(`LOG_FORMAT must be "json" or "pretty" (received "${rawLogFormat}").`);
  }

  // STAGING_PUBLIC_URL (optional HTTPS staging host metadata)
  const rawStagingUrl = env.STAGING_PUBLIC_URL?.trim() || undefined;
  let stagingPublicUrl: string | undefined;
  if (rawStagingUrl) {
    try {
      const parsed = new URL(rawStagingUrl);
      if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
        errors.push(`STAGING_PUBLIC_URL must use http:// or https:// (received "${rawStagingUrl}").`);
      } else {
        stagingPublicUrl = parsed.origin;
      }
    } catch {
      errors.push(`STAGING_PUBLIC_URL must be a valid URL (received "${rawStagingUrl}").`);
    }
  }

  // STAGING_IMPAIRMENT_ENABLED — strictly forbidden in APP_MODE=production
  const stagingImpairmentEnabled = parseBooleanFlag(
    env.STAGING_IMPAIRMENT_ENABLED,
    false,
    'STAGING_IMPAIRMENT_ENABLED',
    errors
  );
  if (stagingImpairmentEnabled && appMode === 'production') {
    errors.push(
      'STAGING_IMPAIRMENT_ENABLED="true" is strictly forbidden when APP_MODE=production. Network impairment is permitted only in staging/test.'
    );
  }

  const rawStagingLogFile = env.STAGING_LOG_FILE?.trim() || undefined;
  if (rawStagingLogFile && isPathInsideEphemeralBuildDir(rawStagingLogFile)) {
    errors.push(`STAGING_LOG_FILE must not reside inside ephemeral build directories: "${rawStagingLogFile}".`);
  }

  if (!googleSsoConfigured) {
    warnings.push('Google SSO OAuth is not configured (GOOGLE_OAUTH_CLIENT_ID unset); button is disabled.');
  }
  if (!smtpConfigured) {
    warnings.push('Outbound SMTP email reset is not configured (SMTP_HOST unset); self-service email reset is disabled.');
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    config: {
      nodeEnv,
      appMode,
      port,
      databasePath,
      backupDir,
      backupEncryptionConfigured,
      backupRetentionCount,
      sqliteBusyTimeoutMs,
      sqliteWalAutocheckpoint,
      disableHmr,
      trustProxy,
      sessionSecretConfigured,
      sessionSecretPreviousConfigured,
      allowedOrigins,
      cookieDomain: rawCookieDomain,
      maxFailedLoginAttempts,
      lockoutDurationMinutes,
      loginRateLimitMax,
      adminInitialUsername,
      adminInitialEmail,
      adminInitialPasswordConfigured,
      googleSsoConfigured,
      smtpConfigured,
      logFormat,
      stagingPublicUrl,
      stagingImpairmentEnabled,
      stagingLogFile: rawStagingLogFile,
    },
  };
}

export function formatEnvValidationReport(result: EnvValidationResult): string {
  const lines: string[] = [
    'SAVAGE-RSUCAJ Environment Configuration Check (BUILD 16)',
    `  NODE_ENV:                     ${result.config.nodeEnv}`,
    `  APP_MODE:                     ${result.config.appMode}`,
    `  PORT:                         ${result.config.port}`,
    `  DATABASE_PATH:                ${result.config.databasePath}`,
    `  SQLITE_BUSY_TIMEOUT_MS:       ${result.config.sqliteBusyTimeoutMs}`,
    `  SQLITE_WAL_AUTOCHECKPOINT:    ${result.config.sqliteWalAutocheckpoint}`,
    `  BACKUP_DIR:                   ${result.config.backupDir}`,
    `  BACKUP_ENCRYPTION_KEY:        ${result.config.backupEncryptionConfigured ? '[SET - REDACTED]' : '[NOT SET]'}`,
    `  BACKUP_RETENTION_COUNT:       ${result.config.backupRetentionCount}`,
    `  DISABLE_HMR:                  ${result.config.disableHmr}`,
    `  TRUST_PROXY:                  ${result.config.trustProxy}`,
    `  LOG_FORMAT:                   ${result.config.logFormat}`,
    `  STAGING_PUBLIC_URL:           ${result.config.stagingPublicUrl || '[NOT SET]'}`,
    `  STAGING_IMPAIRMENT_ENABLED:   ${result.config.stagingImpairmentEnabled}`,
    `  STAGING_LOG_FILE:             ${result.config.stagingLogFile || '[NOT SET]'}`,
    `  SESSION_SECRET:               ${result.config.sessionSecretConfigured ? '[SET - REDACTED]' : '[MISSING - REQUIRED]'}`,
    `  SESSION_SECRET_PREVIOUS:      ${result.config.sessionSecretPreviousConfigured ? '[SET - REDACTED]' : '[NOT SET]'}`,
    `  ALLOWED_ORIGINS:              ${result.config.allowedOrigins.length > 0 ? result.config.allowedOrigins.join(', ') : '[SAME-ORIGIN DEFAULT]'}`,
    `  COOKIE_DOMAIN:                ${result.config.cookieDomain || '[HOST-ONLY DEFAULT]'}`,
    `  MAX_FAILED_LOGIN_ATTEMPTS:    ${result.config.maxFailedLoginAttempts}`,
    `  LOCKOUT_DURATION_MINUTES:     ${result.config.lockoutDurationMinutes}`,
    `  LOGIN_RATE_LIMIT_MAX:         ${result.config.loginRateLimitMax}`,
    `  ADMIN_INITIAL_USERNAME:       ${result.config.adminInitialUsername || '[NOT SET]'}`,
    `  ADMIN_INITIAL_EMAIL:          ${result.config.adminInitialEmail || '[NOT SET]'}`,
    `  ADMIN_INITIAL_PASSWORD:       ${result.config.adminInitialPasswordConfigured ? '[SET - REDACTED]' : '[NOT SET]'}`,
    `  GOOGLE_SSO_CONFIGURED:        ${result.config.googleSsoConfigured}`,
    `  SMTP_CONFIGURED:              ${result.config.smtpConfigured}`,
  ];

  if (result.warnings.length > 0) {
    lines.push('', 'Notices / Warnings:');
    for (const warning of result.warnings) {
      lines.push(`  - [WARN] ${warning}`);
    }
  }

  if (result.errors.length > 0) {
    lines.push('', 'Errors:');
    for (const err of result.errors) {
      lines.push(`  - [ERROR] ${err}`);
    }
  }

  lines.push('', `Status: ${result.valid ? 'VALID' : 'INVALID'}`);
  return lines.join('\n');
}
