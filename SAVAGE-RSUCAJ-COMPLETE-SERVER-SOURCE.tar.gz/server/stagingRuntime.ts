import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { NextFunction, Request, Response } from 'express';
import { getClientIp } from './security.ts';
import { redactSensitiveText } from './auditHelpers.ts';
import { toManilaParts } from './attendanceEngine.ts';
import type { AppMode } from './env.ts';

export interface StructuredLogEntry {
  timestamp_utc: string;
  timestamp_manila: string;
  request_id: string;
  app_mode: AppMode;
  method: string;
  path: string;
  status_code: number;
  duration_ms: number;
  client_ip: string;
  actor: string | null;
  role: string | null;
  impaired: string | null;
  error_code: string | null;
}

export interface StagingImpairmentState {
  enabled: boolean;
  latencyMs: number;
  jitterMs: number;
  dropRatePercent: number;
  targetPrefixes: string[];
  updatedAtUtc: string | null;
  updatedBy: string | null;
  expiresAtUtc: string | null;
}

export interface StagingImpairmentUpdate {
  enabled?: boolean;
  latencyMs?: number;
  jitterMs?: number;
  dropRatePercent?: number;
  targetPrefixes?: string[];
  ttlSeconds?: number;
}

const PROTECTED_IMPAIRMENT_EXCLUSIONS = ['/api/health', '/api/staging/'];
const DEFAULT_MAX_LOG_RING = 500;
const MAX_IMPAIRMENT_TTL_SECONDS = 1800;

export function sanitizePathForLog(rawUrl: string): string {
  const [pathname, query] = rawUrl.split('?');
  if (!query) return redactSensitiveText(pathname || '/');
  const params = new URLSearchParams(query);
  const safePairs: string[] = [];
  for (const [k, v] of params.entries()) {
    if (/(token|secret|password|key|cookie|auth|credential|session)/i.test(k)) {
      safePairs.push(`${k}=[REDACTED]`);
    } else {
      safePairs.push(`${k}=${redactSensitiveText(v).slice(0, 80)}`);
    }
  }
  return `${pathname}?${safePairs.join('&')}`;
}

export function computePercentile(sortedValues: number[], percentile: number): number {
  if (sortedValues.length === 0) return 0;
  const idx = Math.min(
    sortedValues.length - 1,
    Math.max(0, Math.ceil((percentile / 100) * sortedValues.length) - 1)
  );
  return Number(sortedValues[idx].toFixed(2));
}

export class StructuredLogStore {
  private readonly entries: StructuredLogEntry[] = [];
  private readonly maxEntries: number;
  private readonly logFilePath: string | null;
  private readonly emitStdout: boolean;

  constructor(options: { maxEntries?: number; logFilePath?: string | null; emitStdout?: boolean } = {}) {
    this.maxEntries = Math.max(50, options.maxEntries ?? DEFAULT_MAX_LOG_RING);
    this.logFilePath = options.logFilePath?.trim() || null;
    this.emitStdout = options.emitStdout ?? false;
    if (this.logFilePath) {
      const dir = path.dirname(this.logFilePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true, mode: 0o750 });
      }
    }
  }

  record(entry: StructuredLogEntry): void {
    this.entries.push(entry);
    if (this.entries.length > this.maxEntries) {
      this.entries.splice(0, this.entries.length - this.maxEntries);
    }
    const line = JSON.stringify(entry);
    if (this.emitStdout) {
      process.stdout.write(`${line}\n`);
    }
    if (this.logFilePath) {
      try {
        fs.appendFileSync(this.logFilePath, `${line}\n`, { encoding: 'utf8', mode: 0o640 });
      } catch {
        // never crash request path on optional log file append error
      }
    }
  }

  list(limit = 100): StructuredLogEntry[] {
    const safeLimit = Math.min(this.maxEntries, Math.max(1, limit));
    return this.entries.slice(-safeLimit).reverse();
  }

  getMetrics(): {
    totalRecorded: number;
    errorCount5xx: number;
    errorCount4xx: number;
    p50Ms: number;
    p95Ms: number;
    p99Ms: number;
    maxMs: number;
  } {
    const durations = this.entries.map((e) => e.duration_ms).sort((a, b) => a - b);
    const errorCount5xx = this.entries.filter((e) => e.status_code >= 500).length;
    const errorCount4xx = this.entries.filter((e) => e.status_code >= 400 && e.status_code < 500).length;
    return {
      totalRecorded: this.entries.length,
      errorCount5xx,
      errorCount4xx,
      p50Ms: computePercentile(durations, 50),
      p95Ms: computePercentile(durations, 95),
      p99Ms: computePercentile(durations, 99),
      maxMs: durations.length > 0 ? Number(durations[durations.length - 1].toFixed(2)) : 0,
    };
  }
}

export class StagingImpairmentController {
  private readonly appMode: AppMode;
  private readonly allowImpairment: boolean;
  private readonly nowProvider: () => number;
  private state: StagingImpairmentState = {
    enabled: false,
    latencyMs: 0,
    jitterMs: 0,
    dropRatePercent: 0,
    targetPrefixes: ['/api/kiosk/'],
    updatedAtUtc: null,
    updatedBy: null,
    expiresAtUtc: null,
  };

  constructor(appMode: AppMode, allowImpairment = false, nowProvider: () => number = () => Date.now()) {
    this.appMode = appMode;
    // STRICT HARD GUARD: Impairment can NEVER be enabled in production mode.
    this.allowImpairment = appMode !== 'production' && allowImpairment;
    this.nowProvider = nowProvider;
  }

  isAllowed(): boolean {
    return this.allowImpairment;
  }

  getState(nowMs = this.nowProvider()): StagingImpairmentState {
    if (this.state.enabled && this.state.expiresAtUtc) {
      const exp = Date.parse(this.state.expiresAtUtc);
      if (!Number.isNaN(exp) && exp <= nowMs) {
        this.state = {
          ...this.state,
          enabled: false,
          expiresAtUtc: null,
        };
      }
    }
    return {
      ...this.state,
      targetPrefixes: [...this.state.targetPrefixes],
    };
  }

  update(patch: StagingImpairmentUpdate, actor: string, nowMs = Date.now()): StagingImpairmentState {
    if (!this.allowImpairment) {
      throw new Error('Staging network impairment is disabled or forbidden in production mode.');
    }

    const enabled = patch.enabled !== undefined ? Boolean(patch.enabled) : this.state.enabled;
    const latencyMs =
      patch.latencyMs !== undefined
        ? Math.max(0, Math.min(10000, Math.floor(Number(patch.latencyMs))))
        : this.state.latencyMs;
    const jitterMs =
      patch.jitterMs !== undefined
        ? Math.max(0, Math.min(5000, Math.floor(Number(patch.jitterMs))))
        : this.state.jitterMs;
    const dropRatePercent =
      patch.dropRatePercent !== undefined
        ? Math.max(0, Math.min(100, Number(patch.dropRatePercent)))
        : this.state.dropRatePercent;

    if (!Number.isFinite(latencyMs) || !Number.isFinite(jitterMs) || !Number.isFinite(dropRatePercent)) {
      throw new Error('Impairment latencyMs, jitterMs, and dropRatePercent must be finite numbers.');
    }

    let targetPrefixes = this.state.targetPrefixes;
    if (patch.targetPrefixes !== undefined) {
      if (!Array.isArray(patch.targetPrefixes)) {
        throw new Error('targetPrefixes must be an array of API path prefixes.');
      }
      const cleaned = patch.targetPrefixes
        .map((p) => (typeof p === 'string' ? p.trim() : ''))
        .filter((p) => p.startsWith('/api/') && !PROTECTED_IMPAIRMENT_EXCLUSIONS.some((ex) => p.startsWith(ex)));
      targetPrefixes = cleaned.length > 0 ? Array.from(new Set(cleaned)) : ['/api/kiosk/'];
    }

    const ttlSeconds = Math.max(
      10,
      Math.min(MAX_IMPAIRMENT_TTL_SECONDS, Math.floor(Number(patch.ttlSeconds ?? 300)))
    );

    this.state = {
      enabled,
      latencyMs,
      jitterMs,
      dropRatePercent,
      targetPrefixes,
      updatedAtUtc: new Date(nowMs).toISOString(),
      updatedBy: actor,
      expiresAtUtc: enabled ? new Date(nowMs + ttlSeconds * 1000).toISOString() : null,
    };

    return this.getState(nowMs);
  }

  middleware() {
    return (req: Request, res: Response, next: NextFunction): void => {
      if (!this.allowImpairment) {
        next();
        return;
      }

      const fullPath = `${req.baseUrl || ''}${req.path || ''}`;
      if (PROTECTED_IMPAIRMENT_EXCLUSIONS.some((ex) => fullPath.startsWith(ex))) {
        next();
        return;
      }

      const current = this.getState(this.nowProvider());
      if (!current.enabled) {
        next();
        return;
      }

      const matches = current.targetPrefixes.some((prefix) => fullPath.startsWith(prefix));
      if (!matches) {
        next();
        return;
      }

      const totalDelay =
        current.latencyMs + (current.jitterMs > 0 ? Math.floor(Math.random() * (current.jitterMs + 1)) : 0);

      const finish = () => {
        if (current.dropRatePercent > 0 && Math.random() * 100 < current.dropRatePercent) {
          const requestId = (res.locals.requestId as string) || 'unknown';
          res.locals.stagingImpaired = 'drop';
          res.setHeader('X-Staging-Impaired', 'drop');
          res.status(503).json({
            error: 'Staging controllable network impairment injected a transient service drop.',
            code: 'STAGING_IMPAIRMENT_DROP',
            request_id: requestId,
            retryable: true,
          });
          return;
        }
        if (totalDelay > 0) {
          res.locals.stagingImpaired = `delay-${totalDelay}ms`;
          res.setHeader('X-Staging-Impaired', `delay-${totalDelay}ms`);
        }
        next();
      };

      if (totalDelay > 0) {
        setTimeout(finish, totalDelay);
      } else {
        finish();
      }
    };
  }
}

export function createStructuredLoggerMiddleware(options: {
  appMode: AppMode;
  store: StructuredLogStore;
}) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const incomingId = typeof req.headers['x-request-id'] === 'string' ? req.headers['x-request-id'].trim() : '';
    const safeIncoming = /^[A-Za-z0-9_.-]{6,64}$/.test(incomingId) ? incomingId : '';
    const requestId = safeIncoming || `req_${crypto.randomBytes(8).toString('hex')}`;
    const startHr = process.hrtime.bigint();

    res.locals.requestId = requestId;
    res.setHeader('X-Request-Id', requestId);

    res.on('finish', () => {
      const elapsedMs = Number(process.hrtime.bigint() - startHr) / 1_000_000;
      const nowMs = Date.now();
      const manila = toManilaParts(nowMs);
      const authUser = (req as Request & { user?: { username?: string; role?: string } }).user;

      options.store.record({
        timestamp_utc: new Date(nowMs).toISOString(),
        timestamp_manila: manila.isoTimestamp,
        request_id: requestId,
        app_mode: options.appMode,
        method: req.method,
        path: sanitizePathForLog(req.originalUrl || req.url || '/'),
        status_code: res.statusCode,
        duration_ms: Number(elapsedMs.toFixed(2)),
        client_ip: getClientIp(req),
        actor: authUser?.username ?? null,
        role: authUser?.role ?? null,
        impaired: typeof res.locals.stagingImpaired === 'string' ? res.locals.stagingImpaired : null,
        error_code: typeof res.locals.errorCode === 'string' ? res.locals.errorCode : null,
      });
    });

    next();
  };
}
