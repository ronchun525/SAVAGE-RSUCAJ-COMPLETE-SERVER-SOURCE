import crypto from 'node:crypto';
import type Database from 'better-sqlite3';

export type AuditStatus = 'Success' | 'Warning' | 'Error';

export interface LogAuditOptions {
  actionType?: string;
  targetType?: string;
  targetId?: string | number | null;
  before?: unknown;
  after?: unknown;
  isSecurityEvent?: boolean;
  timestamp?: string;
}

export interface AuditHashVerificationResult {
  valid: boolean;
  checkedCount: number;
  brokenRowId: number | null;
  reason: string | null;
  genesisHash: string;
  latestHash: string;
}

const SENSITIVE_KEY_PATTERN =
  /^(password|passphrase|new_password|current_password|salt|password_hash|secret|api_token|kiosk_token|token|csrf|csrf_token|cookie|authorization|private_key|attestation_hmac|backup_encryption_key|session_secret|smtp_pass)$/i;

const SENSITIVE_KEY_SUBSTRING_PATTERN =
  /(password|passphrase|secret|api_token|kiosk_token|private_key|csrf_token|session_secret)/i;

export function redactSensitiveText(input: string): string {
  if (!input) return input;
  return input
    .replace(/\bksk_[a-f0-9]{12,}\b/gi, 'ksk_***REDACTED***')
    .replace(/\bBearer\s+[A-Za-z0-9\-._~+/]+=*/gi, 'Bearer ***REDACTED***')
    .replace(/(password|api_token|kiosk_token|secret)\s*[:=]\s*([^\s,;]+)/gi, '$1=***REDACTED***');
}

export function redactSensitiveValue(value: unknown, depth = 0): unknown {
  if (depth > 8) return '[Truncated]';
  if (value === null || value === undefined) return value;
  if (typeof value === 'string') return redactSensitiveText(value);
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  if (Array.isArray(value)) {
    return value.map((item) => redactSensitiveValue(item, depth + 1));
  }
  if (typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (SENSITIVE_KEY_PATTERN.test(k) || SENSITIVE_KEY_SUBSTRING_PATTERN.test(k)) {
        out[k] = typeof v === 'string' && v.length === 0 ? '' : '***REDACTED***';
      } else {
        out[k] = redactSensitiveValue(v, depth + 1);
      }
    }
    return out;
  }
  return String(value);
}

export function serializeRedactedJson(value: unknown): string {
  if (value === undefined || value === null || value === '') return '';
  try {
    return JSON.stringify(redactSensitiveValue(value));
  } catch {
    return JSON.stringify({ note: '[Unserializable metadata]' });
  }
}

export function formatManilaDateTime(epochMs = Date.now()): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Manila',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).formatToParts(new Date(epochMs));

  const map: Record<string, string> = {};
  for (const p of parts) {
    map[p.type] = p.value;
  }
  const hour = map.hour === '24' ? '00' : map.hour || '00';
  return `${map.year}-${map.month}-${map.day} ${hour}:${map.minute}:${map.second}`;
}

export interface AuditHashInput {
  timestamp: string;
  username: string;
  activity: string;
  module: string;
  status: string;
  ip_address: string;
  action_type: string;
  target_type: string;
  target_id: string;
  before_json: string;
  after_json: string;
  is_security_event: number;
}

export function computeAuditEntryHash(row: AuditHashInput, prevHash: string): string {
  const canonical = JSON.stringify([
    prevHash,
    row.timestamp,
    row.username,
    row.activity,
    row.module,
    row.status,
    row.ip_address,
    row.action_type,
    row.target_type,
    row.target_id,
    row.before_json,
    row.after_json,
    Number(row.is_security_event) ? 1 : 0,
  ]);
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

function hasTamperEvidentAuditColumns(db: Database.Database): boolean {
  const cols = db.prepare('PRAGMA table_info(audit_logs)').all() as Array<{ name: string }>;
  const names = new Set(cols.map((c) => c.name));
  return names.has('prev_hash') && names.has('entry_hash') && names.has('before_json');
}

const SECURITY_MODULES = new Set(['Security', 'Authentication', 'Devices', 'Settings']);

export function logAudit(
  db: Database.Database,
  username: string,
  activity: string,
  module: string,
  status: AuditStatus = 'Success',
  ipAddress = '127.0.0.1',
  options: LogAuditOptions = {}
): number {
  const safeActivity = redactSensitiveText(activity);

  if (!hasTamperEvidentAuditColumns(db)) {
    const info = db
      .prepare(
        `INSERT INTO audit_logs (timestamp, username, activity, module, status, ip_address)
         VALUES (?, ?, ?, ?, ?, ?)`
      )
      .run(options.timestamp || formatManilaDateTime(), username, safeActivity, module, status, ipAddress);
    return Number(info.lastInsertRowid);
  }

  const timestamp = options.timestamp || formatManilaDateTime();
  const actionType = (options.actionType || 'EVENT').trim() || 'EVENT';
  const targetType = (options.targetType || '').trim();
  const targetId =
    options.targetId === null || options.targetId === undefined ? '' : String(options.targetId);
  const beforeJson = serializeRedactedJson(options.before);
  const afterJson = serializeRedactedJson(options.after);
  const isSecurityEvent =
    options.isSecurityEvent !== undefined
      ? options.isSecurityEvent
        ? 1
        : 0
      : SECURITY_MODULES.has(module)
        ? 1
        : 0;

  const prevRow = db
    .prepare('SELECT entry_hash FROM audit_logs ORDER BY id DESC LIMIT 1')
    .get() as { entry_hash?: string } | undefined;
  const prevHash = prevRow?.entry_hash && prevRow.entry_hash.length > 0 ? prevRow.entry_hash : 'GENESIS';

  const entryHash = computeAuditEntryHash(
    {
      timestamp,
      username,
      activity: safeActivity,
      module,
      status,
      ip_address: ipAddress,
      action_type: actionType,
      target_type: targetType,
      target_id: targetId,
      before_json: beforeJson,
      after_json: afterJson,
      is_security_event: isSecurityEvent,
    },
    prevHash
  );

  const info = db
    .prepare(
      `INSERT INTO audit_logs
        (timestamp, username, activity, module, status, ip_address,
         action_type, target_type, target_id, before_json, after_json, prev_hash, entry_hash, is_security_event)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      timestamp,
      username,
      safeActivity,
      module,
      status,
      ipAddress,
      actionType,
      targetType,
      targetId,
      beforeJson,
      afterJson,
      prevHash,
      entryHash,
      isSecurityEvent
    );
  return Number(info.lastInsertRowid);
}

export function backfillAuditLogHashChain(db: Database.Database): number {
  if (!hasTamperEvidentAuditColumns(db)) return 0;

  const rows = db
    .prepare(
      `SELECT id, timestamp, username, activity, module, status, ip_address,
              action_type, target_type, target_id, before_json, after_json, prev_hash, entry_hash, is_security_event
       FROM audit_logs
       ORDER BY id ASC`
    )
    .all() as Array<
    AuditHashInput & {
      id: number;
      prev_hash: string;
      entry_hash: string;
    }
  >;

  let updated = 0;
  let runningPrev = 'GENESIS';
  const stmt = db.prepare('UPDATE audit_logs SET prev_hash = ?, entry_hash = ?, is_security_event = ? WHERE id = ?');

  for (const row of rows) {
    const isSec = Number(row.is_security_event) ? 1 : SECURITY_MODULES.has(row.module) ? 1 : 0;
    const expectedHash = computeAuditEntryHash(
      {
        timestamp: row.timestamp,
        username: row.username,
        activity: row.activity,
        module: row.module,
        status: row.status,
        ip_address: row.ip_address,
        action_type: row.action_type || 'EVENT',
        target_type: row.target_type || '',
        target_id: row.target_id || '',
        before_json: row.before_json || '',
        after_json: row.after_json || '',
        is_security_event: isSec,
      },
      runningPrev
    );

    if (!row.entry_hash || row.prev_hash !== runningPrev || row.entry_hash !== expectedHash) {
      stmt.run(runningPrev, expectedHash, isSec, row.id);
      updated += 1;
      runningPrev = expectedHash;
    } else {
      runningPrev = row.entry_hash;
    }
  }

  return updated;
}

export function verifyAuditLogChain(db: Database.Database): AuditHashVerificationResult {
  if (!hasTamperEvidentAuditColumns(db)) {
    return {
      valid: false,
      checkedCount: 0,
      brokenRowId: null,
      reason: 'Audit log tamper-evident hash columns are missing (schema upgrade required).',
      genesisHash: 'GENESIS',
      latestHash: 'GENESIS',
    };
  }

  const rows = db
    .prepare(
      `SELECT id, timestamp, username, activity, module, status, ip_address,
              action_type, target_type, target_id, before_json, after_json, prev_hash, entry_hash, is_security_event
       FROM audit_logs
       ORDER BY id ASC`
    )
    .all() as Array<
    AuditHashInput & {
      id: number;
      prev_hash: string;
      entry_hash: string;
    }
  >;

  let expectedPrev = 'GENESIS';
  let latestHash = 'GENESIS';

  for (const row of rows) {
    if (!row.entry_hash) {
      return {
        valid: false,
        checkedCount: rows.length,
        brokenRowId: row.id,
        reason: `Audit entry #${row.id} is missing its SHA-256 chain hash.`,
        genesisHash: 'GENESIS',
        latestHash,
      };
    }
    if (row.prev_hash !== expectedPrev) {
      return {
        valid: false,
        checkedCount: rows.length,
        brokenRowId: row.id,
        reason: `Audit chain break at entry #${row.id}: prev_hash mismatch (expected ${expectedPrev.slice(0, 12)}, found ${String(row.prev_hash || '').slice(0, 12)}).`,
        genesisHash: 'GENESIS',
        latestHash,
      };
    }
    const recomputed = computeAuditEntryHash(
      {
        timestamp: row.timestamp,
        username: row.username,
        activity: row.activity,
        module: row.module,
        status: row.status,
        ip_address: row.ip_address,
        action_type: row.action_type || 'EVENT',
        target_type: row.target_type || '',
        target_id: row.target_id || '',
        before_json: row.before_json || '',
        after_json: row.after_json || '',
        is_security_event: Number(row.is_security_event) ? 1 : 0,
      },
      expectedPrev
    );
    if (recomputed !== row.entry_hash) {
      return {
        valid: false,
        checkedCount: rows.length,
        brokenRowId: row.id,
        reason: `Tampered or altered content detected at audit entry #${row.id} (SHA-256 digest mismatch).`,
        genesisHash: 'GENESIS',
        latestHash,
      };
    }
    expectedPrev = row.entry_hash;
    latestHash = row.entry_hash;
  }

  return {
    valid: true,
    checkedCount: rows.length,
    brokenRowId: null,
    reason: null,
    genesisHash: 'GENESIS',
    latestHash,
  };
}
