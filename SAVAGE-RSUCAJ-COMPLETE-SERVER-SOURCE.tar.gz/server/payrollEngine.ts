import crypto from 'node:crypto';
import type Database from 'better-sqlite3';
import { addDaysIso, getManilaDayCodeForIsoDate, toManilaParts } from './attendanceEngine.ts';

export const PAYROLL_ENGINE_VERSION = 'BUILD12-v1.0';

export type PayFrequency = 'SEMI_MONTHLY' | 'MONTHLY' | 'BI_WEEKLY';
export type ProrationBasis =
  | 'SCHEDULED_WORKING_DAYS_IN_MONTH'
  | 'CALENDAR_DAYS_IN_MONTH'
  | 'FIXED_WORKING_DAYS_PER_MONTH';
export type AllowanceProrationMode =
  | 'PRORATE_BY_SCHEDULED_DAYS'
  | 'HALF_FOR_SEMI_MONTHLY'
  | 'FULL_PER_PERIOD';
export type RoundingMode = 'HALF_UP' | 'HALF_EVEN';
export type PolicyApprovalStatus = 'DRAFT_NOT_APPROVED' | 'APPROVED_BY_FINANCE' | 'SUPERSEDED';

export interface EmployeeTypePayrollRule {
  payBasis: 'MONTHLY' | 'DAILY' | 'HOURLY';
  overtimeEligible: boolean;
  holidayPayEligible: boolean;
  statutoryEligible: boolean;
  taxEligible: boolean;
  paidLeaveEligible: boolean;
  allowanceEligible: boolean;
}

export interface StatutoryContributionRule {
  code: string;
  name: string;
  basis: 'MONTHLY_SALARY' | 'PRORATED_BASIC' | 'GROSS_PAY';
  mode: 'PERCENTAGE' | 'FIXED_PER_PERIOD' | 'BRACKET_TABLE';
  ratePercent?: number;
  fixedAmount?: number;
  minSalaryCap?: number | null;
  maxSalaryCap?: number | null;
  /** Divisor applied when basis is MONTHLY_SALARY (e.g., 2 for semi-monthly split, 1 for monthly). */
  periodDivisor?: number;
  brackets?: Array<{
    min: number;
    max: number | null;
    employeeShare: number;
  }>;
}

export interface TaxBracketRule {
  min: number;
  max: number | null;
  baseTax: number;
  excessRatePercent: number;
}

export interface PayrollSpecialExceptionRule {
  employeeCode: string;
  adjustmentType: 'EARNING' | 'DEDUCTION';
  label: string;
  amount: number;
  taxable: boolean;
  effectiveFrom?: string;
  effectiveTo?: string;
}

export interface PayrollPolicyRules {
  payFrequency: PayFrequency;
  standardWorkHoursPerDay: number;
  prorationBasis: ProrationBasis;
  fixedWorkingDaysPerMonth?: number | null;
  allowanceProrationMode: AllowanceProrationMode;
  employeeTypes: Record<string, EmployeeTypePayrollRule>;
  tardiness: {
    enabled: boolean;
    roundingIncrementMinutes: number;
    rateMultiplier: number;
  };
  undertime: {
    enabled: boolean;
    roundingIncrementMinutes: number;
    rateMultiplier: number;
  };
  absences: {
    deductPerDayMultiplier: number;
    deductMissingRecordAsAbsent: boolean;
  };
  leaves: {
    paidLeaveRateMultiplier: number;
    unpaidLeaveDeductionMultiplier: number;
  };
  overtime: {
    enabled: boolean;
    minimumOvertimeMinutes: number;
    ordinaryDayMultiplier: number;
    restDayMultiplier: number;
    specialHolidayMultiplier: number;
    regularHolidayMultiplier: number;
  };
  holidaysAndRestDays: {
    regularHolidayWorkedPremiumMultiplier: number;
    specialHolidayUnworkedPaid: boolean;
    specialHolidayWorkedPremiumMultiplier: number;
    restDayWorkedMultiplier: number;
  };
  statutoryContributions: StatutoryContributionRule[];
  withholdingTax: {
    enabled: boolean;
    taxExemptAllowances: boolean;
    brackets: TaxBracketRule[];
  };
  rounding: {
    currencyDecimals: number;
    mode: RoundingMode;
  };
  specialExceptions: PayrollSpecialExceptionRule[];
}

export interface StoredPayrollPolicy {
  id: number;
  policy_code: string;
  policy_name: string;
  effective_from: string;
  effective_to: string | null;
  approval_status: PolicyApprovalStatus;
  approval_reference: string;
  finance_approved_by: string | null;
  finance_approved_by_user_id: number | null;
  finance_approved_at_utc: string | null;
  rules_json: string;
  notes: string;
  created_by_user_id: number | null;
  created_by: string;
  created_at: string;
  updated_by: string;
  updated_at: string;
}

export interface PayrollActor {
  userId: number;
  username: string;
  role: string;
  ipAddress: string;
}

export class PayrollDomainError extends Error {
  status: number;
  code: string;
  details?: Record<string, unknown>;

  constructor(status: number, code: string, message: string, details?: Record<string, unknown>) {
    super(message);
    this.name = 'PayrollDomainError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

/**
 * Returns an unapproved Policy Input Template for Finance / HR sign-off.
 * Intentionally contains ZERO invented statutory percentages or placeholder tax brackets.
 */
export function getPayrollPolicyTemplate() {
  return {
    templateVersion: PAYROLL_ENGINE_VERSION,
    status: 'TEMPLATE_REQUIRES_FINANCE_INPUT',
    warning:
      'NO HARDCODED INSTITUTIONAL RATES ARE ASSUMED. Finance & HR must supply written, signed-off RSU Cajidiocan rates, statutory tables, and withholding brackets before approving this policy for live payroll release.',
    fields: {
      policy_code: 'RSU-CAJ-PAY-2026-V1',
      policy_name: 'RSU Cajidiocan Institutional Payroll Policy (Draft — Pending Finance Sign-Off)',
      effective_from: '2026-01-01',
      effective_to: null,
      notes: 'Attach Board Resolution / Finance Memo reference prior to clicking Finance Approve.',
      rules: {
        payFrequency: 'SEMI_MONTHLY',
        standardWorkHoursPerDay: 8,
        prorationBasis: 'SCHEDULED_WORKING_DAYS_IN_MONTH',
        fixedWorkingDaysPerMonth: null,
        allowanceProrationMode: 'PRORATE_BY_SCHEDULED_DAYS',
        employeeTypes: {
          Regular: {
            payBasis: 'MONTHLY',
            overtimeEligible: true,
            holidayPayEligible: true,
            statutoryEligible: true,
            taxEligible: true,
            paidLeaveEligible: true,
            allowanceEligible: true,
          },
          Contractual: {
            payBasis: 'MONTHLY',
            overtimeEligible: true,
            holidayPayEligible: true,
            statutoryEligible: true,
            taxEligible: true,
            paidLeaveEligible: false,
            allowanceEligible: true,
          },
          'Part-Time': {
            payBasis: 'MONTHLY',
            overtimeEligible: false,
            holidayPayEligible: false,
            statutoryEligible: false,
            taxEligible: true,
            paidLeaveEligible: false,
            allowanceEligible: false,
          },
        },
        tardiness: {
          enabled: true,
          roundingIncrementMinutes: 1,
          rateMultiplier: 1.0,
        },
        undertime: {
          enabled: true,
          roundingIncrementMinutes: 1,
          rateMultiplier: 1.0,
        },
        absences: {
          deductPerDayMultiplier: 1.0,
          deductMissingRecordAsAbsent: true,
        },
        leaves: {
          paidLeaveRateMultiplier: 1.0,
          unpaidLeaveDeductionMultiplier: 1.0,
        },
        overtime: {
          enabled: true,
          minimumOvertimeMinutes: 30,
          ordinaryDayMultiplier: 1.25,
          restDayMultiplier: 1.69,
          specialHolidayMultiplier: 1.69,
          regularHolidayMultiplier: 2.6,
        },
        holidaysAndRestDays: {
          regularHolidayWorkedPremiumMultiplier: 1.0,
          specialHolidayUnworkedPaid: false,
          specialHolidayWorkedPremiumMultiplier: 0.3,
          restDayWorkedMultiplier: 1.3,
        },
        statutoryContributions: [
          // Finance must populate official GSIS / SSS, PhilHealth, and Pag-IBIG tables before approval
        ],
        withholdingTax: {
          enabled: false,
          taxExemptAllowances: true,
          brackets: [
            // Finance must populate official BIR TRAIN withholding tax brackets per pay frequency before approval
          ],
        },
        rounding: {
          currencyDecimals: 2,
          mode: 'HALF_UP',
        },
        specialExceptions: [],
      } as PayrollPolicyRules,
    },
  };
}

export function roundAmount(value: number, decimals = 2, mode: RoundingMode = 'HALF_UP'): number {
  if (!Number.isFinite(value)) return 0;
  const factor = Math.pow(10, decimals);
  const scaled = value * factor;
  const sign = scaled < 0 ? -1 : 1;
  const absScaled = Math.abs(scaled);
  // Epsilon mitigates IEEE-754 representation drift like 1.005 * 100 = 100.49999999999999
  const eps = 1e-9;

  if (mode === 'HALF_EVEN') {
    const floor = Math.floor(absScaled + eps);
    const diff = absScaled - floor;
    let rounded: number;
    if (Math.abs(diff - 0.5) <= 1e-7) {
      rounded = floor % 2 === 0 ? floor : floor + 1;
    } else {
      rounded = Math.round(absScaled + eps);
    }
    return (sign * rounded) / factor;
  }

  return (sign * Math.floor(absScaled + 0.5 + eps)) / factor;
}

export function validatePayrollPolicyRules(raw: unknown): { valid: boolean; errors: string[]; rules?: PayrollPolicyRules } {
  const errors: string[] = [];
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { valid: false, errors: ['Policy rules must be a JSON object.'] };
  }
  const r = raw as Partial<PayrollPolicyRules>;

  if (!['SEMI_MONTHLY', 'MONTHLY', 'BI_WEEKLY'].includes(String(r.payFrequency))) {
    errors.push('payFrequency must be SEMI_MONTHLY, MONTHLY, or BI_WEEKLY.');
  }
  if (typeof r.standardWorkHoursPerDay !== 'number' || r.standardWorkHoursPerDay <= 0 || r.standardWorkHoursPerDay > 24) {
    errors.push('standardWorkHoursPerDay must be a number between 1 and 24.');
  }
  if (
    !['SCHEDULED_WORKING_DAYS_IN_MONTH', 'CALENDAR_DAYS_IN_MONTH', 'FIXED_WORKING_DAYS_PER_MONTH'].includes(
      String(r.prorationBasis)
    )
  ) {
    errors.push(
      'prorationBasis must be SCHEDULED_WORKING_DAYS_IN_MONTH, CALENDAR_DAYS_IN_MONTH, or FIXED_WORKING_DAYS_PER_MONTH.'
    );
  }
  if (r.prorationBasis === 'FIXED_WORKING_DAYS_PER_MONTH') {
    if (
      typeof r.fixedWorkingDaysPerMonth !== 'number' ||
      !Number.isFinite(r.fixedWorkingDaysPerMonth) ||
      r.fixedWorkingDaysPerMonth <= 0 ||
      r.fixedWorkingDaysPerMonth > 31
    ) {
      errors.push('fixedWorkingDaysPerMonth must be between 1 and 31 when prorationBasis is FIXED_WORKING_DAYS_PER_MONTH.');
    }
  }
  if (
    !['PRORATE_BY_SCHEDULED_DAYS', 'HALF_FOR_SEMI_MONTHLY', 'FULL_PER_PERIOD'].includes(
      String(r.allowanceProrationMode)
    )
  ) {
    errors.push('allowanceProrationMode must be PRORATE_BY_SCHEDULED_DAYS, HALF_FOR_SEMI_MONTHLY, or FULL_PER_PERIOD.');
  }

  if (!r.employeeTypes || typeof r.employeeTypes !== 'object' || Object.keys(r.employeeTypes).length === 0) {
    errors.push('employeeTypes must define at least one employee classification (e.g., Regular).');
  } else {
    for (const [k, cfg] of Object.entries(r.employeeTypes)) {
      if (!cfg || !['MONTHLY', 'DAILY', 'HOURLY'].includes(String(cfg.payBasis))) {
        errors.push(`employeeTypes.${k}.payBasis must be MONTHLY, DAILY, or HOURLY.`);
      }
    }
  }

  if (!r.tardiness || typeof r.tardiness.rateMultiplier !== 'number' || r.tardiness.rateMultiplier < 0) {
    errors.push('tardiness.rateMultiplier must be a non-negative number.');
  }
  if (!r.undertime || typeof r.undertime.rateMultiplier !== 'number' || r.undertime.rateMultiplier < 0) {
    errors.push('undertime.rateMultiplier must be a non-negative number.');
  }
  if (!r.absences || typeof r.absences.deductPerDayMultiplier !== 'number' || r.absences.deductPerDayMultiplier < 0) {
    errors.push('absences.deductPerDayMultiplier must be a non-negative number.');
  }
  if (!r.leaves || typeof r.leaves.paidLeaveRateMultiplier !== 'number' || typeof r.leaves.unpaidLeaveDeductionMultiplier !== 'number') {
    errors.push('leaves multipliers must be valid numbers.');
  }
  if (
    !r.overtime ||
    typeof r.overtime.ordinaryDayMultiplier !== 'number' ||
    typeof r.overtime.restDayMultiplier !== 'number' ||
    typeof r.overtime.specialHolidayMultiplier !== 'number' ||
    typeof r.overtime.regularHolidayMultiplier !== 'number'
  ) {
    errors.push('overtime multipliers must be valid numbers.');
  }
  if (
    !r.holidaysAndRestDays ||
    typeof r.holidaysAndRestDays.regularHolidayWorkedPremiumMultiplier !== 'number' ||
    typeof r.holidaysAndRestDays.specialHolidayWorkedPremiumMultiplier !== 'number' ||
    typeof r.holidaysAndRestDays.restDayWorkedMultiplier !== 'number'
  ) {
    errors.push('holidaysAndRestDays multipliers must be valid numbers.');
  }

  if (!Array.isArray(r.statutoryContributions)) {
    errors.push('statutoryContributions must be an array.');
  } else {
    for (const c of r.statutoryContributions) {
      if (!c.code?.trim() || !c.name?.trim()) {
        errors.push('Each statutory contribution requires a code and name.');
      }
      if (!['MONTHLY_SALARY', 'PRORATED_BASIC', 'GROSS_PAY'].includes(String(c.basis))) {
        errors.push(`Statutory contribution ${c.code || '?'} has invalid basis.`);
      }
      if (!['PERCENTAGE', 'FIXED_PER_PERIOD', 'BRACKET_TABLE'].includes(String(c.mode))) {
        errors.push(`Statutory contribution ${c.code || '?'} has invalid mode.`);
      }
      if (c.mode === 'PERCENTAGE' && (typeof c.ratePercent !== 'number' || c.ratePercent < 0 || c.ratePercent > 100)) {
        errors.push(`Statutory contribution ${c.code || '?'} ratePercent must be between 0 and 100.`);
      }
      if (c.mode === 'FIXED_PER_PERIOD' && (typeof c.fixedAmount !== 'number' || c.fixedAmount < 0)) {
        errors.push(`Statutory contribution ${c.code || '?'} fixedAmount must be >= 0.`);
      }
      if (c.mode === 'BRACKET_TABLE' && (!Array.isArray(c.brackets) || c.brackets.length === 0)) {
        errors.push(`Statutory contribution ${c.code || '?'} BRACKET_TABLE requires at least one bracket.`);
      }
    }
  }

  if (!r.withholdingTax || typeof r.withholdingTax.enabled !== 'boolean' || !Array.isArray(r.withholdingTax.brackets)) {
    errors.push('withholdingTax must include enabled (boolean) and brackets (array).');
  } else {
    for (const b of r.withholdingTax.brackets) {
      if (typeof b.min !== 'number' || b.min < 0 || typeof b.baseTax !== 'number' || b.baseTax < 0 || typeof b.excessRatePercent !== 'number' || b.excessRatePercent < 0 || b.excessRatePercent > 100) {
        errors.push('Each withholdingTax bracket requires valid non-negative min, baseTax, and excessRatePercent (0-100).');
      }
    }
  }

  if (
    !r.rounding ||
    !['HALF_UP', 'HALF_EVEN'].includes(String(r.rounding.mode)) ||
    !Number.isInteger(r.rounding.currencyDecimals) ||
    r.rounding.currencyDecimals < 0 ||
    r.rounding.currencyDecimals > 4
  ) {
    errors.push('rounding must specify mode (HALF_UP or HALF_EVEN) and integer currencyDecimals (0-4).');
  }

  if (!Array.isArray(r.specialExceptions)) {
    errors.push('specialExceptions must be an array.');
  } else {
    for (const ex of r.specialExceptions) {
      if (!ex.employeeCode?.trim() || !ex.label?.trim() || typeof ex.amount !== 'number' || ex.amount < 0) {
        errors.push('Each specialException requires employeeCode, label, and non-negative amount.');
      }
      if (!['EARNING', 'DEDUCTION'].includes(String(ex.adjustmentType))) {
        errors.push(`specialException for ${ex.employeeCode || '?'} adjustmentType must be EARNING or DEDUCTION.`);
      }
    }
  }

  if (errors.length > 0) {
    return { valid: false, errors };
  }
  return { valid: true, errors: [], rules: r as PayrollPolicyRules };
}

function getManilaWeekendSet(db: Database.Database): Set<string> {
  try {
    const row = db.prepare("SELECT value FROM settings WHERE key = 'leave_weekend_days'").get() as
      | { value: string }
      | undefined;
    const raw = row?.value || 'Sat,Sun';
    return new Set(
      raw
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
    );
  } catch {
    return new Set(['Sat', 'Sun']);
  }
}

function parseShiftRestDays(restDaysRaw: string | null | undefined, defaultWeekends: Set<string>): Set<string> {
  if (!restDaysRaw || !restDaysRaw.trim()) {
    return new Set(defaultWeekends);
  }
  const parsed = restDaysRaw
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  return parsed.length > 0 ? new Set(parsed) : new Set(defaultWeekends);
}

function getDaysInMonth(year: number, month1Based: number): number {
  return new Date(Date.UTC(year, month1Based, 0)).getUTCDate();
}

function countScheduledWorkingDaysInMonth(year: number, month1Based: number, restDays: Set<string>): number {
  const totalDays = getDaysInMonth(year, month1Based);
  const mm = String(month1Based).padStart(2, '0');
  let scheduled = 0;
  for (let d = 1; d <= totalDays; d++) {
    const iso = `${year}-${mm}-${String(d).padStart(2, '0')}`;
    const dayCode = getManilaDayCodeForIsoDate(iso);
    if (!restDays.has(dayCode)) {
      scheduled++;
    }
  }
  return scheduled;
}

function applyMinuteRounding(minutes: number, increment: number): number {
  if (minutes <= 0) return 0;
  if (!increment || increment <= 1) return minutes;
  return Math.ceil(minutes / increment) * increment;
}

function appendPayrollAudit(
  db: Database.Database,
  params: {
    payrollRunId: number | null;
    policyId: number | null;
    action: string;
    previousStatus?: string;
    newStatus?: string;
    calculationVersion?: number;
    snapshotSha256?: string;
    referenceCode?: string;
    details?: Record<string, unknown>;
    actor: PayrollActor;
    nowMs: number;
  }
): void {
  const utcIso = new Date(params.nowMs).toISOString();
  const manila = toManilaParts(params.nowMs);
  db.prepare(
    `INSERT INTO payroll_audit_log
      (payroll_run_id, policy_id, action, previous_status, new_status, calculation_version, snapshot_sha256,
       reference_code, details_json, actor_user_id, actor_username, actor_role, acted_at_utc, acted_at_manila, ip_address)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    params.payrollRunId,
    params.policyId,
    params.action,
    params.previousStatus || '',
    params.newStatus || '',
    params.calculationVersion ?? 0,
    params.snapshotSha256 || '',
    params.referenceCode || '',
    JSON.stringify(params.details || {}),
    params.actor.userId,
    params.actor.username,
    params.actor.role,
    utcIso,
    manila.isoTimestamp,
    params.actor.ipAddress || '127.0.0.1'
  );
}

export function listPayrollPolicies(db: Database.Database): Array<StoredPayrollPolicy & { rules: PayrollPolicyRules }> {
  const rows = db
    .prepare('SELECT * FROM payroll_policies ORDER BY effective_from DESC, id DESC')
    .all() as StoredPayrollPolicy[];
  return rows.map((row) => ({
    ...row,
    rules: JSON.parse(row.rules_json) as PayrollPolicyRules,
  }));
}

export function createPayrollPolicy(
  db: Database.Database,
  input: {
    policy_code: string;
    policy_name: string;
    effective_from: string;
    effective_to?: string | null;
    notes?: string;
    rules: unknown;
  },
  actor: PayrollActor,
  nowMs: number
): StoredPayrollPolicy & { rules: PayrollPolicyRules } {
  if (!input.policy_code?.trim() || !input.policy_name?.trim()) {
    throw new PayrollDomainError(400, 'INVALID_POLICY_METADATA', 'Policy code and policy name are required.');
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.effective_from || '')) {
    throw new PayrollDomainError(400, 'INVALID_POLICY_DATES', 'effective_from must be YYYY-MM-DD.');
  }
  if (input.effective_to && (!/^\d{4}-\d{2}-\d{2}$/.test(input.effective_to) || input.effective_to < input.effective_from)) {
    throw new PayrollDomainError(400, 'INVALID_POLICY_DATES', 'effective_to must be empty or >= effective_from.');
  }

  const validation = validatePayrollPolicyRules(input.rules);
  if (!validation.valid || !validation.rules) {
    throw new PayrollDomainError(422, 'INVALID_PAYROLL_POLICY', validation.errors.join(' '), {
      validationErrors: validation.errors,
    });
  }

  const rulesJson = JSON.stringify(validation.rules);
  try {
    const info = db
      .prepare(
        `INSERT INTO payroll_policies
          (policy_code, policy_name, effective_from, effective_to, approval_status, approval_reference,
           rules_json, notes, created_by_user_id, created_by, updated_by, updated_at)
         VALUES (?, ?, ?, ?, 'DRAFT_NOT_APPROVED', '', ?, ?, ?, ?, ?, datetime('now', 'localtime'))`
      )
      .run(
        input.policy_code.trim(),
        input.policy_name.trim(),
        input.effective_from,
        input.effective_to || null,
        rulesJson,
        (input.notes || '').trim(),
        actor.userId,
        actor.username,
        actor.username
      );
    const id = Number(info.lastInsertRowid);
    appendPayrollAudit(db, {
      payrollRunId: null,
      policyId: id,
      action: 'POLICY_CREATED',
      newStatus: 'DRAFT_NOT_APPROVED',
      referenceCode: input.policy_code.trim(),
      details: { effective_from: input.effective_from, effective_to: input.effective_to || null },
      actor,
      nowMs,
    });
    const created = db.prepare('SELECT * FROM payroll_policies WHERE id = ?').get(id) as StoredPayrollPolicy;
    return { ...created, rules: validation.rules };
  } catch (err) {
    if (err instanceof Error && err.message.includes('UNIQUE')) {
      throw new PayrollDomainError(409, 'DUPLICATE_POLICY_CODE', 'A payroll policy with this code already exists.');
    }
    throw err;
  }
}

export function updateDraftPayrollPolicy(
  db: Database.Database,
  policyId: number,
  input: {
    policy_name?: string;
    effective_from?: string;
    effective_to?: string | null;
    notes?: string;
    rules?: unknown;
  },
  actor: PayrollActor,
  nowMs: number
): StoredPayrollPolicy & { rules: PayrollPolicyRules } {
  const existing = db.prepare('SELECT * FROM payroll_policies WHERE id = ?').get(policyId) as
    | StoredPayrollPolicy
    | undefined;
  if (!existing) {
    throw new PayrollDomainError(404, 'POLICY_NOT_FOUND', 'Payroll policy not found.');
  }
  if (existing.approval_status !== 'DRAFT_NOT_APPROVED') {
    throw new PayrollDomainError(
      409,
      'POLICY_LOCKED',
      'Approved or superseded payroll policies are immutable. Create a new effective-dated policy version instead.'
    );
  }

  const nextFrom = input.effective_from || existing.effective_from;
  const nextTo = input.effective_to === undefined ? existing.effective_to : input.effective_to || null;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(nextFrom) || (nextTo && (!/^\d{4}-\d{2}-\d{2}$/.test(nextTo) || nextTo < nextFrom))) {
    throw new PayrollDomainError(400, 'INVALID_POLICY_DATES', 'Invalid effective_from / effective_to range.');
  }

  const rulesToValidate = input.rules !== undefined ? input.rules : JSON.parse(existing.rules_json);
  const validation = validatePayrollPolicyRules(rulesToValidate);
  if (!validation.valid || !validation.rules) {
    throw new PayrollDomainError(422, 'INVALID_PAYROLL_POLICY', validation.errors.join(' '), {
      validationErrors: validation.errors,
    });
  }

  db.prepare(
    `UPDATE payroll_policies
     SET policy_name = ?, effective_from = ?, effective_to = ?, notes = ?, rules_json = ?,
         updated_by = ?, updated_at = datetime('now', 'localtime')
     WHERE id = ?`
  ).run(
    (input.policy_name ?? existing.policy_name).trim(),
    nextFrom,
    nextTo,
    (input.notes ?? existing.notes).trim(),
    JSON.stringify(validation.rules),
    actor.username,
    policyId
  );

  appendPayrollAudit(db, {
    payrollRunId: null,
    policyId,
    action: 'POLICY_UPDATED',
    previousStatus: existing.approval_status,
    newStatus: 'DRAFT_NOT_APPROVED',
    referenceCode: existing.policy_code,
    actor,
    nowMs,
  });

  const updated = db.prepare('SELECT * FROM payroll_policies WHERE id = ?').get(policyId) as StoredPayrollPolicy;
  return { ...updated, rules: validation.rules };
}

export function approvePayrollPolicyByFinance(
  db: Database.Database,
  policyId: number,
  input: { approval_reference: string; notes?: string },
  actor: PayrollActor,
  nowMs: number
): StoredPayrollPolicy & { rules: PayrollPolicyRules } {
  const existing = db.prepare('SELECT * FROM payroll_policies WHERE id = ?').get(policyId) as
    | StoredPayrollPolicy
    | undefined;
  if (!existing) {
    throw new PayrollDomainError(404, 'POLICY_NOT_FOUND', 'Payroll policy not found.');
  }
  if (existing.approval_status === 'APPROVED_BY_FINANCE') {
    throw new PayrollDomainError(409, 'POLICY_ALREADY_APPROVED', 'This payroll policy is already Finance-approved.');
  }
  if (existing.approval_status === 'SUPERSEDED') {
    throw new PayrollDomainError(409, 'POLICY_SUPERSEDED', 'Superseded payroll policies cannot be re-approved.');
  }
  const ref = (input.approval_reference || '').trim();
  if (ref.length < 4) {
    throw new PayrollDomainError(
      400,
      'APPROVAL_REFERENCE_REQUIRED',
      'A written Finance approval reference (e.g., Board Resolution / Finance Memo number) is required.'
    );
  }

  const parsedRules = JSON.parse(existing.rules_json) as PayrollPolicyRules;
  const validation = validatePayrollPolicyRules(parsedRules);
  if (!validation.valid) {
    throw new PayrollDomainError(422, 'INVALID_PAYROLL_POLICY', validation.errors.join(' '));
  }

  const utcIso = new Date(nowMs).toISOString();
  const nextNotes = input.notes?.trim()
    ? `${existing.notes ? existing.notes + '\n' : ''}[Finance Approval ${ref}]: ${input.notes.trim()}`
    : existing.notes;

  db.prepare(
    `UPDATE payroll_policies
     SET approval_status = 'APPROVED_BY_FINANCE',
         approval_reference = ?,
         finance_approved_by = ?,
         finance_approved_by_user_id = ?,
         finance_approved_at_utc = ?,
         notes = ?,
         updated_by = ?,
         updated_at = datetime('now', 'localtime')
     WHERE id = ?`
  ).run(ref, actor.username, actor.userId, utcIso, nextNotes, actor.username, policyId);

  appendPayrollAudit(db, {
    payrollRunId: null,
    policyId,
    action: 'POLICY_FINANCE_APPROVED',
    previousStatus: existing.approval_status,
    newStatus: 'APPROVED_BY_FINANCE',
    referenceCode: ref,
    details: { policy_code: existing.policy_code },
    actor,
    nowMs,
  });

  const updated = db.prepare('SELECT * FROM payroll_policies WHERE id = ?').get(policyId) as StoredPayrollPolicy;
  return { ...updated, rules: parsedRules };
}

export function resolvePolicyForPeriod(
  db: Database.Database,
  startDate: string,
  endDate: string,
  explicitPolicyId?: number | null
): (StoredPayrollPolicy & { rules: PayrollPolicyRules }) | null {
  let row: StoredPayrollPolicy | undefined;
  if (explicitPolicyId) {
    row = db.prepare('SELECT * FROM payroll_policies WHERE id = ?').get(explicitPolicyId) as
      | StoredPayrollPolicy
      | undefined;
    if (!row) {
      throw new PayrollDomainError(404, 'POLICY_NOT_FOUND', `Payroll policy #${explicitPolicyId} not found.`);
    }
    if (row.effective_from > endDate || (row.effective_to && row.effective_to < startDate)) {
      throw new PayrollDomainError(
        422,
        'POLICY_NOT_EFFECTIVE_FOR_PERIOD',
        `Policy "${row.policy_code}" (${row.effective_from} to ${row.effective_to || 'open'}) does not cover period ${startDate} to ${endDate}.`
      );
    }
  } else {
    // Prefer Finance-approved effective policy; otherwise fall back to latest effective draft policy
    row = db
      .prepare(
        `SELECT * FROM payroll_policies
         WHERE effective_from <= ? AND (effective_to IS NULL OR effective_to >= ?)
           AND approval_status != 'SUPERSEDED'
         ORDER BY CASE approval_status WHEN 'APPROVED_BY_FINANCE' THEN 0 ELSE 1 END ASC,
                  effective_from DESC, id DESC
         LIMIT 1`
      )
      .get(endDate, startDate) as StoredPayrollPolicy | undefined;
  }

  if (!row) return null;
  return {
    ...row,
    rules: JSON.parse(row.rules_json) as PayrollPolicyRules,
  };
}

export interface PrecheckResult {
  start_date: string;
  end_date: string;
  canCompute: boolean;
  canFinalizeAndRelease: boolean;
  isProductionApprovedPolicy: boolean;
  policy: (StoredPayrollPolicy & { rules: PayrollPolicyRules }) | null;
  activeEmployeeCount: number;
  splitMonthSegments: Array<{ month: string; startDate: string; endDate: string; calendarDays: number }>;
  existingRunForPeriod: {
    id: number;
    period_label: string;
    status: string;
    calculation_version: number;
    snapshot_sha256: string;
  } | null;
  overlappingRuns: Array<{ id: number; period_label: string; start_date: string; end_date: string; status: string }>;
  pendingCorrections: Array<{
    id: number;
    employee_id: number;
    employee_code: string;
    employee_name: string;
    attendance_date: string;
    request_type: string;
  }>;
  pendingLeaves: Array<{
    id: number;
    employee_id: number;
    employee_code: string;
    employee_name: string;
    leave_type: string;
    start_date: string;
    end_date: string;
  }>;
  unresolvedMissingPunches: Array<{
    id: number;
    employee_id: number;
    employee_code: string;
    employee_name: string;
    date: string;
    status: string;
    time_in: string | null;
    time_out: string | null;
  }>;
  blockers: Array<{ code: string; message: string; count?: number }>;
  warnings: Array<{ code: string; message: string }>;
}

function buildSplitMonthSegments(startDate: string, endDate: string) {
  const segments: Array<{ month: string; startDate: string; endDate: string; calendarDays: number }> = [];
  let cursor = startDate;
  let guard = 0;
  while (cursor <= endDate && guard < 400) {
    const ym = cursor.slice(0, 7);
    const last = segments[segments.length - 1];
    if (!last || last.month !== ym) {
      segments.push({ month: ym, startDate: cursor, endDate: cursor, calendarDays: 1 });
    } else {
      last.endDate = cursor;
      last.calendarDays++;
    }
    cursor = addDaysIso(cursor, 1);
    guard++;
  }
  return segments;
}

export function reconcilePayrollPeriodPrecheck(
  db: Database.Database,
  startDate: string,
  endDate: string,
  explicitPolicyId?: number | null
): PrecheckResult {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(endDate) || endDate < startDate) {
    throw new PayrollDomainError(400, 'INVALID_PAYROLL_PERIOD', 'Valid start_date and end_date (end_date >= start_date) are required.');
  }

  const policy = resolvePolicyForPeriod(db, startDate, endDate, explicitPolicyId);
  const activeEmployeeCount = (
    db.prepare("SELECT COUNT(*) as c FROM employees WHERE status = 'Active'").get() as { c: number }
  ).c;

  const existingRunForPeriod =
    (db
      .prepare(
        `SELECT id, period_label, status, calculation_version, snapshot_sha256
         FROM payroll_runs WHERE start_date = ? AND end_date = ?`
      )
      .get(startDate, endDate) as PrecheckResult['existingRunForPeriod']) || null;

  const overlappingRuns = db
    .prepare(
      `SELECT id, period_label, start_date, end_date, status
       FROM payroll_runs
       WHERE start_date <= ? AND end_date >= ? AND NOT (start_date = ? AND end_date = ?)
       ORDER BY start_date ASC`
    )
    .all(endDate, startDate, startDate, endDate) as PrecheckResult['overlappingRuns'];

  const pendingCorrections = db
    .prepare(
      `SELECT c.id, c.employee_id, e.employee_code, e.full_name as employee_name, c.attendance_date, c.request_type
       FROM corrections c
       JOIN employees e ON e.id = c.employee_id
       WHERE c.status = 'Pending' AND c.attendance_date >= ? AND c.attendance_date <= ?
         AND e.status = 'Active'
       ORDER BY c.attendance_date ASC, e.employee_code ASC`
    )
    .all(startDate, endDate) as PrecheckResult['pendingCorrections'];

  const pendingLeaves = db
    .prepare(
      `SELECT l.id, l.employee_id, e.employee_code, e.full_name as employee_name, l.leave_type, l.start_date, l.end_date
       FROM leaves l
       JOIN employees e ON e.id = l.employee_id
       WHERE l.status = 'Pending' AND l.end_date >= ? AND l.start_date <= ?
         AND e.status = 'Active'
       ORDER BY l.start_date ASC, e.employee_code ASC`
    )
    .all(startDate, endDate) as PrecheckResult['pendingLeaves'];

  const unresolvedMissingPunches = db
    .prepare(
      `SELECT a.id, a.employee_id, e.employee_code, e.full_name as employee_name, a.date, a.status, a.time_in, a.time_out
       FROM attendance_records a
       JOIN employees e ON e.id = a.employee_id
       WHERE a.date >= ? AND a.date <= ?
         AND e.status = 'Active'
         AND (
           a.status IN ('Missing Time In', 'Missing Time Out')
           OR (a.status NOT IN ('On Leave', 'OB', 'Holiday', 'Rest Day', 'Absent', 'No Schedule')
               AND ((a.time_in IS NOT NULL AND a.time_out IS NULL) OR (a.time_in IS NULL AND a.time_out IS NOT NULL)))
         )
       ORDER BY a.date ASC, e.employee_code ASC`
    )
    .all(startDate, endDate) as PrecheckResult['unresolvedMissingPunches'];

  const blockers: PrecheckResult['blockers'] = [];
  const warnings: PrecheckResult['warnings'] = [];

  if (!policy) {
    blockers.push({
      code: 'PAYROLL_POLICY_REQUIRED',
      message:
        'No effective payroll policy is configured for this period. Create a policy from the institutional Policy Input Template first.',
    });
  }
  if (activeEmployeeCount === 0) {
    blockers.push({
      code: 'NO_ACTIVE_EMPLOYEES',
      message: 'No active employees found for payroll computation.',
    });
  }
  if (overlappingRuns.length > 0) {
    blockers.push({
      code: 'OVERLAPPING_PAYROLL_PERIOD',
      message: `Period overlaps existing payroll run "${overlappingRuns[0].period_label}" (${overlappingRuns[0].start_date} to ${overlappingRuns[0].end_date}).`,
      count: overlappingRuns.length,
    });
  }
  if (existingRunForPeriod && existingRunForPeriod.status !== 'Computed') {
    blockers.push({
      code: 'PAYROLL_RUN_LOCKED',
      message: `Payroll run "${existingRunForPeriod.period_label}" is already ${existingRunForPeriod.status} and locked from recomputation.`,
    });
  }
  if (pendingCorrections.length > 0) {
    blockers.push({
      code: 'PENDING_CORRECTIONS_EXIST',
      message: `${pendingCorrections.length} pending attendance correction(s) in this period must be approved or rejected before computing payroll.`,
      count: pendingCorrections.length,
    });
  }
  if (pendingLeaves.length > 0) {
    blockers.push({
      code: 'PENDING_LEAVES_EXIST',
      message: `${pendingLeaves.length} pending leave application(s) overlap this period and must be resolved before computing payroll.`,
      count: pendingLeaves.length,
    });
  }
  if (unresolvedMissingPunches.length > 0) {
    blockers.push({
      code: 'UNRESOLVED_MISSING_PUNCHES',
      message: `${unresolvedMissingPunches.length} unresolved Missing Time In / Missing Time Out record(s) must be corrected before computing payroll.`,
      count: unresolvedMissingPunches.length,
    });
  }

  const isProductionApprovedPolicy = Boolean(policy && policy.approval_status === 'APPROVED_BY_FINANCE');
  if (policy && !isProductionApprovedPolicy) {
    warnings.push({
      code: 'NOT_APPROVED_FOR_PRODUCTION',
      message: `Policy "${policy.policy_code}" is DRAFT_NOT_APPROVED. Computation will be stamped NOT APPROVED FOR PRODUCTION and Finalize/Release will remain blocked until Finance approves the policy.`,
    });
  }

  const splitMonthSegments = buildSplitMonthSegments(startDate, endDate);
  if (splitMonthSegments.length > 1) {
    warnings.push({
      code: 'SPLIT_MONTH_PERIOD',
      message: `Period spans ${splitMonthSegments.length} calendar months (${splitMonthSegments.map((s) => s.month).join(', ')}); daily rates are prorated per month's scheduled working days.`,
    });
  }

  return {
    start_date: startDate,
    end_date: endDate,
    canCompute: blockers.length === 0,
    canFinalizeAndRelease: blockers.length === 0 && isProductionApprovedPolicy,
    isProductionApprovedPolicy,
    policy,
    activeEmployeeCount,
    splitMonthSegments,
    existingRunForPeriod,
    overlappingRuns,
    pendingCorrections,
    pendingLeaves,
    unresolvedMissingPunches,
    blockers,
    warnings,
  };
}

interface ActiveEmployeeCalcRow {
  id: number;
  employee_code: string;
  full_name: string;
  department_id: number;
  position_id: number;
  position_type: string;
  shift_id: number;
  shift_rest_days: string | null;
  hired_date: string;
  monthly_salary: number;
  monthly_allowance: number;
}

interface AttendanceDayRow {
  date: string;
  time_in: string | null;
  time_out: string | null;
  status: string;
  late_minutes: number;
  undertime_minutes: number;
  overtime_minutes: number;
  work_hours: string;
}

interface ApprovedLeaveAllocRow {
  leave_date: string;
  day_fraction: number;
  day_portion: string;
  leave_type: string;
  is_paid: number;
}

function computeStatutoryDeductions(
  rules: PayrollPolicyRules,
  monthlySalary: number,
  proratedBasic: number,
  grossPay: number,
  decimals: number,
  roundingMode: RoundingMode
): { total: number; items: Array<{ code: string; name: string; basisAmount: number; amount: number }> } {
  const items: Array<{ code: string; name: string; basisAmount: number; amount: number }> = [];
  let total = 0;

  for (const rule of rules.statutoryContributions) {
    const rawBasis =
      rule.basis === 'MONTHLY_SALARY'
        ? monthlySalary
        : rule.basis === 'PRORATED_BASIC'
          ? proratedBasic
          : grossPay;

    let cappedBasis = rawBasis;
    if (typeof rule.minSalaryCap === 'number' && cappedBasis < rule.minSalaryCap) {
      cappedBasis = rule.minSalaryCap;
    }
    if (typeof rule.maxSalaryCap === 'number' && cappedBasis > rule.maxSalaryCap) {
      cappedBasis = rule.maxSalaryCap;
    }

    const divisor =
      rule.basis === 'MONTHLY_SALARY'
        ? typeof rule.periodDivisor === 'number' && rule.periodDivisor > 0
          ? rule.periodDivisor
          : rules.payFrequency === 'SEMI_MONTHLY'
            ? 2
            : 1
        : 1;

    let amount = 0;
    if (rule.mode === 'PERCENTAGE') {
      amount = (cappedBasis * ((rule.ratePercent || 0) / 100)) / divisor;
    } else if (rule.mode === 'FIXED_PER_PERIOD') {
      amount = rule.fixedAmount || 0;
    } else if (rule.mode === 'BRACKET_TABLE' && Array.isArray(rule.brackets)) {
      const matched = rule.brackets.find(
        (b) => cappedBasis >= b.min && (b.max === null || b.max === undefined || cappedBasis <= b.max)
      );
      amount = matched ? matched.employeeShare / divisor : 0;
    }

    const rounded = roundAmount(Math.max(0, amount), decimals, roundingMode);
    items.push({ code: rule.code, name: rule.name, basisAmount: roundAmount(cappedBasis, decimals, roundingMode), amount: rounded });
    total = roundAmount(total + rounded, decimals, roundingMode);
  }

  return { total, items };
}

function computeWithholdingTax(
  rules: PayrollPolicyRules,
  taxableIncome: number,
  decimals: number,
  roundingMode: RoundingMode
): number {
  if (!rules.withholdingTax.enabled || taxableIncome <= 0 || rules.withholdingTax.brackets.length === 0) {
    return 0;
  }
  const sorted = [...rules.withholdingTax.brackets].sort((a, b) => a.min - b.min);
  const bracket = sorted.find(
    (b) => taxableIncome >= b.min && (b.max === null || b.max === undefined || taxableIncome <= b.max)
  );
  if (!bracket) return 0;
  const excess = Math.max(0, taxableIncome - bracket.min);
  const rawTax = bracket.baseTax + excess * (bracket.excessRatePercent / 100);
  return roundAmount(Math.max(0, rawTax), decimals, roundingMode);
}

export interface ComputePayrollInput {
  period_label: string;
  start_date: string;
  end_date: string;
  policy_id?: number | null;
  recompute?: boolean;
  /** Internal test-only hook to simulate a mid-transaction write failure and verify atomic rollback. */
  _simulateWriteFailureAfterItemIndex?: number;
}

export interface ComputePayrollResult {
  id: number;
  period_label: string;
  start_date: string;
  end_date: string;
  status: string;
  policy_id: number;
  policy_code: string;
  policy_approval_status: PolicyApprovalStatus;
  is_production_approved: boolean;
  calculation_engine_version: string;
  calculation_version: number;
  snapshot_sha256: string;
  idempotentNoOp: boolean;
  employee_count: number;
  totals: {
    total_basic_pay: number;
    total_allowances: number;
    total_overtime_pay: number;
    total_holiday_rest_pay: number;
    total_gross_pay: number;
    total_deductions: number;
    total_net_pay: number;
  };
}

export function computeOrRecomputePayrollRun(
  db: Database.Database,
  input: ComputePayrollInput,
  actor: PayrollActor,
  nowMs: number
): ComputePayrollResult {
  const periodLabel = (input.period_label || '').trim();
  if (!periodLabel) {
    throw new PayrollDomainError(400, 'INVALID_PERIOD_LABEL', 'Payroll period label is required.');
  }

  const precheck = reconcilePayrollPeriodPrecheck(db, input.start_date, input.end_date, input.policy_id);
  if (!precheck.policy) {
    throw new PayrollDomainError(
      422,
      'PAYROLL_POLICY_REQUIRED',
      'No effective payroll policy exists for this period. Create an institutional payroll policy from the Policy Input Template first.'
    );
  }
  if (precheck.overlappingRuns.length > 0) {
    throw new PayrollDomainError(
      409,
      'OVERLAPPING_PAYROLL_PERIOD',
      `Payroll period ${input.start_date} to ${input.end_date} overlaps existing run "${precheck.overlappingRuns[0].period_label}".`,
      { overlappingRuns: precheck.overlappingRuns }
    );
  }
  if (precheck.existingRunForPeriod) {
    if (precheck.existingRunForPeriod.status !== 'Computed') {
      throw new PayrollDomainError(
        409,
        'PAYROLL_RUN_LOCKED',
        `Payroll run "${precheck.existingRunForPeriod.period_label}" is ${precheck.existingRunForPeriod.status} and cannot be recomputed.`
      );
    }
    if (!input.recompute) {
      throw new PayrollDomainError(
        409,
        'DUPLICATE_PAYROLL_PERIOD',
        `A payroll run already exists for ${input.start_date} to ${input.end_date} ("${precheck.existingRunForPeriod.period_label}"). Pass recompute=true to recalculate a Computed run.`,
        { existingRunId: precheck.existingRunForPeriod.id }
      );
    }
  }
  if (precheck.pendingCorrections.length > 0) {
    throw new PayrollDomainError(
      409,
      'PENDING_CORRECTIONS_EXIST',
      `Cannot compute payroll while ${precheck.pendingCorrections.length} pending attendance correction(s) exist in ${input.start_date} to ${input.end_date}.`,
      { pendingCorrections: precheck.pendingCorrections }
    );
  }
  if (precheck.pendingLeaves.length > 0) {
    throw new PayrollDomainError(
      409,
      'PENDING_LEAVES_EXIST',
      `Cannot compute payroll while ${precheck.pendingLeaves.length} pending leave application(s) overlap ${input.start_date} to ${input.end_date}.`,
      { pendingLeaves: precheck.pendingLeaves }
    );
  }
  if (precheck.unresolvedMissingPunches.length > 0) {
    throw new PayrollDomainError(
      409,
      'UNRESOLVED_MISSING_PUNCHES',
      `Cannot compute payroll while ${precheck.unresolvedMissingPunches.length} unresolved Missing Time In / Missing Time Out record(s) exist in ${input.start_date} to ${input.end_date}.`,
      { unresolvedMissingPunches: precheck.unresolvedMissingPunches }
    );
  }

  const policy = precheck.policy;
  const rules = policy.rules;
  const decimals = rules.rounding.currencyDecimals;
  const rMode = rules.rounding.mode;
  const round = (v: number) => roundAmount(v, decimals, rMode);

  const activeEmps = db
    .prepare(
      `SELECT e.id, e.employee_code, e.full_name, e.department_id, e.position_id,
              p.type as position_type, e.shift_id, s.rest_days as shift_rest_days,
              e.hired_date, e.monthly_salary, e.monthly_allowance
       FROM employees e
       JOIN positions p ON p.id = e.position_id
       JOIN shifts s ON s.id = e.shift_id
       WHERE e.status = 'Active'
       ORDER BY e.employee_code ASC`
    )
    .all() as ActiveEmployeeCalcRow[];

  if (activeEmps.length === 0) {
    throw new PayrollDomainError(400, 'NO_ACTIVE_EMPLOYEES', 'No active employees found for payroll computation.');
  }

  const defaultWeekends = getManilaWeekendSet(db);
  const holidayRows = db
    .prepare('SELECT date, name, type FROM holidays WHERE date >= ? AND date <= ?')
    .all(input.start_date, input.end_date) as Array<{ date: string; name: string; type: string }>;
  const holidayMap = new Map<string, { name: string; type: string }>();
  for (const h of holidayRows) {
    holidayMap.set(h.date, { name: h.name, type: h.type });
  }

  const attStmt = db.prepare(
    `SELECT date, time_in, time_out, status,
            COALESCE(late_minutes, 0) as late_minutes,
            COALESCE(undertime_minutes, 0) as undertime_minutes,
            COALESCE(overtime_minutes, 0) as overtime_minutes,
            work_hours
     FROM attendance_records
     WHERE employee_id = ? AND date >= ? AND date <= ?`
  );

  const leaveAllocStmt = db.prepare(
    `SELECT a.leave_date, a.day_fraction, a.day_portion, l.leave_type,
            COALESCE(lp.is_paid, 1) as is_paid
     FROM leave_day_allocations a
     JOIN leaves l ON l.id = a.leave_id
     LEFT JOIN leave_policies lp ON lp.leave_type = l.leave_type
     WHERE a.employee_id = ? AND l.status = 'Approved'
       AND a.leave_date >= ? AND a.leave_date <= ?`
  );

  const computedItems: Array<{
    employee_id: number;
    employee_code: string;
    employee_type: string;
    scheduled_working_days: number;
    days_present: number;
    days_late: number;
    days_absent: number;
    days_paid_leave: number;
    days_unpaid_leave: number;
    days_holiday: number;
    days_rest_worked: number;
    late_minutes: number;
    undertime_minutes: number;
    overtime_minutes: number;
    basic_pay: number;
    prorated_basic_pay: number;
    allowances: number;
    overtime_pay: number;
    holiday_rest_pay: number;
    other_earnings: number;
    late_deduction: number;
    undertime_deduction: number;
    absence_deduction: number;
    unpaid_leave_deduction: number;
    statutory_deductions: number;
    tax_deduction: number;
    other_deductions: number;
    gross_pay: number;
    deductions: number;
    net_pay: number;
    breakdown: Record<string, unknown>;
  }> = [];

  for (const emp of activeEmps) {
    const empTypeRule: EmployeeTypePayrollRule =
      rules.employeeTypes[emp.position_type] ||
      rules.employeeTypes['Regular'] ||
      Object.values(rules.employeeTypes)[0];

    const restDays = parseShiftRestDays(emp.shift_rest_days, defaultWeekends);
    const attRows = attStmt.all(emp.id, input.start_date, input.end_date) as AttendanceDayRow[];
    const attMap = new Map<string, AttendanceDayRow>();
    for (const a of attRows) attMap.set(a.date, a);

    const leaveRows = leaveAllocStmt.all(emp.id, input.start_date, input.end_date) as ApprovedLeaveAllocRow[];
    const leaveMap = new Map<string, ApprovedLeaveAllocRow>();
    for (const lv of leaveRows) leaveMap.set(lv.leave_date, lv);

    const monthScheduledDaysCache = new Map<string, number>();
    const getDailyRateForDate = (isoDate: string): number => {
      if (empTypeRule.payBasis === 'DAILY') {
        return emp.monthly_salary;
      }
      if (empTypeRule.payBasis === 'HOURLY') {
        return emp.monthly_salary * rules.standardWorkHoursPerDay;
      }
      const ym = isoDate.slice(0, 7);
      const yr = Number(ym.slice(0, 4));
      const mo = Number(ym.slice(5, 7));
      if (rules.prorationBasis === 'FIXED_WORKING_DAYS_PER_MONTH' && rules.fixedWorkingDaysPerMonth) {
        return emp.monthly_salary / rules.fixedWorkingDaysPerMonth;
      }
      if (rules.prorationBasis === 'CALENDAR_DAYS_IN_MONTH') {
        return emp.monthly_salary / getDaysInMonth(yr, mo);
      }
      if (!monthScheduledDaysCache.has(ym)) {
        monthScheduledDaysCache.set(ym, Math.max(1, countScheduledWorkingDaysInMonth(yr, mo, restDays)));
      }
      return emp.monthly_salary / monthScheduledDaysCache.get(ym)!;
    };

    const getAllowancePerDayForDate = (isoDate: string): number => {
      const ym = isoDate.slice(0, 7);
      const yr = Number(ym.slice(0, 4));
      const mo = Number(ym.slice(5, 7));
      if (rules.prorationBasis === 'FIXED_WORKING_DAYS_PER_MONTH' && rules.fixedWorkingDaysPerMonth) {
        return emp.monthly_allowance / rules.fixedWorkingDaysPerMonth;
      }
      if (rules.prorationBasis === 'CALENDAR_DAYS_IN_MONTH') {
        return emp.monthly_allowance / getDaysInMonth(yr, mo);
      }
      if (!monthScheduledDaysCache.has(ym)) {
        monthScheduledDaysCache.set(ym, Math.max(1, countScheduledWorkingDaysInMonth(yr, mo, restDays)));
      }
      return emp.monthly_allowance / monthScheduledDaysCache.get(ym)!;
    };

    let scheduledWorkingDays = 0;
    let daysPresent = 0;
    let daysLate = 0;
    let daysAbsent = 0;
    let daysPaidLeave = 0;
    let daysUnpaidLeave = 0;
    let daysHoliday = 0;
    let daysRestWorked = 0;
    let totalLateMinutes = 0;
    let totalUndertimeMinutes = 0;
    let totalOvertimeMinutes = 0;

    let rawProratedBasic = 0;
    let rawProratedAllowance = 0;
    let rawOvertimePay = 0;
    let rawHolidayRestPay = 0;
    let rawLateDeduction = 0;
    let rawUndertimeDeduction = 0;
    let rawAbsenceDeduction = 0;
    let rawUnpaidLeaveDeduction = 0;

    const monthProrationBreakdown: Record<string, { scheduledDays: number; dailyRate: number; accruedBasic: number }> = {};

    let cursor = input.start_date;
    let guard = 0;
    while (cursor <= input.end_date && guard < 400) {
      guard++;
      // Proration for mid-period hires: skip days strictly before employee's hired_date
      if (emp.hired_date && cursor < emp.hired_date) {
        cursor = addDaysIso(cursor, 1);
        continue;
      }

      const dayCode = getManilaDayCodeForIsoDate(cursor);
      const isRestDay = restDays.has(dayCode);
      const holiday = holidayMap.get(cursor) || null;
      const att = attMap.get(cursor) || null;
      const leaveAlloc = leaveMap.get(cursor) || null;
      const dailyRate = getDailyRateForDate(cursor);
      const hourlyRate = dailyRate / rules.standardWorkHoursPerDay;
      const workedDay = Boolean(
        att &&
          ((att.time_in && att.time_out) ||
            att.status === 'Present' ||
            att.status === 'Late' ||
            att.status === 'Undertime' ||
            att.status === 'OB')
      );
      const ym = cursor.slice(0, 7);

      if (isRestDay) {
        // Rest day is not counted in scheduled working days; if worked, pay rest day multiplier
        if (workedDay && att && att.time_in && att.time_out) {
          daysRestWorked += 1;
          rawHolidayRestPay += dailyRate * rules.holidaysAndRestDays.restDayWorkedMultiplier;
          if (
            rules.overtime.enabled &&
            empTypeRule.overtimeEligible &&
            att.overtime_minutes >= rules.overtime.minimumOvertimeMinutes
          ) {
            totalOvertimeMinutes += att.overtime_minutes;
            rawOvertimePay += (att.overtime_minutes / 60) * hourlyRate * rules.overtime.restDayMultiplier;
          }
        }
        cursor = addDaysIso(cursor, 1);
        continue;
      }

      // Scheduled working day
      scheduledWorkingDays += 1;
      if (empTypeRule.allowanceEligible && rules.allowanceProrationMode === 'PRORATE_BY_SCHEDULED_DAYS') {
        rawProratedAllowance += getAllowancePerDayForDate(cursor);
      }

      if (empTypeRule.payBasis === 'MONTHLY') {
        rawProratedBasic += dailyRate;
        if (!monthProrationBreakdown[ym]) {
          monthProrationBreakdown[ym] = { scheduledDays: 0, dailyRate: round(dailyRate), accruedBasic: 0 };
        }
        monthProrationBreakdown[ym].scheduledDays += 1;
        monthProrationBreakdown[ym].accruedBasic = round(monthProrationBreakdown[ym].accruedBasic + dailyRate);
      }

      if (holiday) {
        daysHoliday += 1;
        const isRegularHoliday = holiday.type === 'Regular';
        if (workedDay && att && att.time_in && att.time_out) {
          daysPresent += 1;
          if (empTypeRule.payBasis !== 'MONTHLY') {
            rawProratedBasic += dailyRate;
          }
          if (empTypeRule.holidayPayEligible) {
            const prem = isRegularHoliday
              ? rules.holidaysAndRestDays.regularHolidayWorkedPremiumMultiplier
              : rules.holidaysAndRestDays.specialHolidayWorkedPremiumMultiplier;
            rawHolidayRestPay += dailyRate * prem;
          }
          if (
            rules.overtime.enabled &&
            empTypeRule.overtimeEligible &&
            att.overtime_minutes >= rules.overtime.minimumOvertimeMinutes
          ) {
            totalOvertimeMinutes += att.overtime_minutes;
            const otMult = isRegularHoliday
              ? rules.overtime.regularHolidayMultiplier
              : rules.overtime.specialHolidayMultiplier;
            rawOvertimePay += (att.overtime_minutes / 60) * hourlyRate * otMult;
          }
        } else {
          // Unworked holiday
          if (isRegularHoliday) {
            if (empTypeRule.payBasis !== 'MONTHLY' && empTypeRule.holidayPayEligible) {
              rawProratedBasic += dailyRate;
            }
          } else {
            // Special Non-Working unworked
            if (!rules.holidaysAndRestDays.specialHolidayUnworkedPaid && empTypeRule.payBasis === 'MONTHLY') {
              rawAbsenceDeduction += dailyRate;
            }
          }
        }
        cursor = addDaysIso(cursor, 1);
        continue;
      }

      // Approved Leave day (full or half-day)
      if (leaveAlloc) {
        const frac = Math.min(1, Math.max(0, Number(leaveAlloc.day_fraction) || 1));
        const isPaidLeave = leaveAlloc.is_paid === 1 && empTypeRule.paidLeaveEligible;
        if (isPaidLeave) {
          daysPaidLeave += frac;
          if (empTypeRule.payBasis !== 'MONTHLY') {
            rawProratedBasic += frac * dailyRate * rules.leaves.paidLeaveRateMultiplier;
          } else if (rules.leaves.paidLeaveRateMultiplier < 1) {
            rawUnpaidLeaveDeduction += frac * dailyRate * (1 - rules.leaves.paidLeaveRateMultiplier);
          }
        } else {
          daysUnpaidLeave += frac;
          if (empTypeRule.payBasis === 'MONTHLY') {
            rawUnpaidLeaveDeduction += frac * dailyRate * rules.leaves.unpaidLeaveDeductionMultiplier;
          }
        }

        // Half-day leave: evaluate the other 0.5 day against attendance
        if (frac < 1) {
          const remainingFrac = 1 - frac;
          if (workedDay && att) {
            daysPresent += remainingFrac;
            if (empTypeRule.payBasis !== 'MONTHLY') {
              rawProratedBasic += remainingFrac * dailyRate;
            }
            if (rules.tardiness.enabled && att.late_minutes > 0) {
              const billedLate = applyMinuteRounding(att.late_minutes, rules.tardiness.roundingIncrementMinutes);
              totalLateMinutes += billedLate;
              daysLate += 1;
              rawLateDeduction += (billedLate / 60) * hourlyRate * rules.tardiness.rateMultiplier;
            }
            if (rules.undertime.enabled && att.undertime_minutes > 0) {
              const billedUt = applyMinuteRounding(att.undertime_minutes, rules.undertime.roundingIncrementMinutes);
              totalUndertimeMinutes += billedUt;
              rawUndertimeDeduction += (billedUt / 60) * hourlyRate * rules.undertime.rateMultiplier;
            }
          } else if (empTypeRule.payBasis === 'MONTHLY' && rules.absences.deductMissingRecordAsAbsent) {
            daysAbsent += remainingFrac;
            rawAbsenceDeduction += remainingFrac * dailyRate * rules.absences.deductPerDayMultiplier;
          }
        }

        cursor = addDaysIso(cursor, 1);
        continue;
      }

      // Ordinary scheduled working day without holiday or leave
      if (workedDay && att) {
        daysPresent += 1;
        if (empTypeRule.payBasis !== 'MONTHLY') {
          rawProratedBasic += dailyRate;
        }
        if (rules.tardiness.enabled && att.late_minutes > 0) {
          const billedLate = applyMinuteRounding(att.late_minutes, rules.tardiness.roundingIncrementMinutes);
          totalLateMinutes += billedLate;
          daysLate += 1;
          rawLateDeduction += (billedLate / 60) * hourlyRate * rules.tardiness.rateMultiplier;
        }
        if (rules.undertime.enabled && att.undertime_minutes > 0) {
          const billedUt = applyMinuteRounding(att.undertime_minutes, rules.undertime.roundingIncrementMinutes);
          totalUndertimeMinutes += billedUt;
          rawUndertimeDeduction += (billedUt / 60) * hourlyRate * rules.undertime.rateMultiplier;
        }
        if (
          rules.overtime.enabled &&
          empTypeRule.overtimeEligible &&
          att.overtime_minutes >= rules.overtime.minimumOvertimeMinutes
        ) {
          totalOvertimeMinutes += att.overtime_minutes;
          rawOvertimePay += (att.overtime_minutes / 60) * hourlyRate * rules.overtime.ordinaryDayMultiplier;
        }
      } else if (att && att.status === 'Absent') {
        daysAbsent += 1;
        if (empTypeRule.payBasis === 'MONTHLY') {
          rawAbsenceDeduction += dailyRate * rules.absences.deductPerDayMultiplier;
        }
      } else if (att && att.status === 'On Leave') {
        // Legacy attendance-only On Leave without allocation defaults to paid leave
        daysPaidLeave += 1;
        if (empTypeRule.payBasis !== 'MONTHLY' && empTypeRule.paidLeaveEligible) {
          rawProratedBasic += dailyRate * rules.leaves.paidLeaveRateMultiplier;
        }
      } else if (!att && rules.absences.deductMissingRecordAsAbsent) {
        daysAbsent += 1;
        if (empTypeRule.payBasis === 'MONTHLY') {
          rawAbsenceDeduction += dailyRate * rules.absences.deductPerDayMultiplier;
        }
      }

      cursor = addDaysIso(cursor, 1);
    }

    // Allowances
    let allowances = 0;
    if (empTypeRule.allowanceEligible && scheduledWorkingDays > 0) {
      if (rules.allowanceProrationMode === 'PRORATE_BY_SCHEDULED_DAYS') {
        allowances = round(rawProratedAllowance);
      } else if (rules.allowanceProrationMode === 'HALF_FOR_SEMI_MONTHLY') {
        allowances = round(rules.payFrequency === 'SEMI_MONTHLY' ? emp.monthly_allowance / 2 : emp.monthly_allowance);
      } else {
        allowances = round(emp.monthly_allowance);
      }
    }

    // Special exceptions scoped to this employee & effective date
    let otherEarnings = 0;
    let taxableOtherEarnings = 0;
    let otherDeductions = 0;
    const appliedExceptions: Array<{ label: string; adjustmentType: string; amount: number; taxable: boolean }> = [];
    for (const ex of rules.specialExceptions) {
      if (ex.employeeCode !== emp.employee_code) continue;
      if (ex.effectiveFrom && ex.effectiveFrom > input.end_date) continue;
      if (ex.effectiveTo && ex.effectiveTo < input.start_date) continue;
      const amt = round(ex.amount);
      appliedExceptions.push({
        label: ex.label,
        adjustmentType: ex.adjustmentType,
        amount: amt,
        taxable: ex.taxable,
      });
      if (ex.adjustmentType === 'EARNING') {
        otherEarnings = round(otherEarnings + amt);
        if (ex.taxable) taxableOtherEarnings = round(taxableOtherEarnings + amt);
      } else {
        otherDeductions = round(otherDeductions + amt);
      }
    }

    const proratedBasicPay = round(rawProratedBasic);
    const overtimePay = round(rawOvertimePay);
    const holidayRestPay = round(rawHolidayRestPay);
    const lateDeduction = round(rawLateDeduction);
    const undertimeDeduction = round(rawUndertimeDeduction);
    const absenceDeduction = round(rawAbsenceDeduction);
    const unpaidLeaveDeduction = round(rawUnpaidLeaveDeduction);

    const grossPay = round(proratedBasicPay + allowances + overtimePay + holidayRestPay + otherEarnings);

    // Statutory contributions
    const statutory = empTypeRule.statutoryEligible
      ? computeStatutoryDeductions(rules, emp.monthly_salary, proratedBasicPay, grossPay, decimals, rMode)
      : { total: 0, items: [] };

    // Withholding tax (attendance & unpaid-leave deductions and statutory contributions reduce taxable pay)
    const taxableIncome = Math.max(
      0,
      round(
        proratedBasicPay +
          overtimePay +
          holidayRestPay +
          taxableOtherEarnings +
          (rules.withholdingTax.taxExemptAllowances ? 0 : allowances) -
          (lateDeduction + undertimeDeduction + absenceDeduction + unpaidLeaveDeduction + statutory.total)
      )
    );
    const taxDeduction = empTypeRule.taxEligible
      ? computeWithholdingTax(rules, taxableIncome, decimals, rMode)
      : 0;

    const totalDeductions = round(
      lateDeduction +
        undertimeDeduction +
        absenceDeduction +
        unpaidLeaveDeduction +
        statutory.total +
        taxDeduction +
        otherDeductions
    );
    const netPay = Math.max(0, round(grossPay - totalDeductions));

    computedItems.push({
      employee_id: emp.id,
      employee_code: emp.employee_code,
      employee_type: emp.position_type,
      scheduled_working_days: scheduledWorkingDays,
      days_present: roundAmount(daysPresent, 2, rMode),
      days_late: daysLate,
      days_absent: roundAmount(daysAbsent, 2, rMode),
      days_paid_leave: roundAmount(daysPaidLeave, 2, rMode),
      days_unpaid_leave: roundAmount(daysUnpaidLeave, 2, rMode),
      days_holiday: daysHoliday,
      days_rest_worked: daysRestWorked,
      late_minutes: totalLateMinutes,
      undertime_minutes: totalUndertimeMinutes,
      overtime_minutes: totalOvertimeMinutes,
      basic_pay: proratedBasicPay,
      prorated_basic_pay: proratedBasicPay,
      allowances,
      overtime_pay: overtimePay,
      holiday_rest_pay: holidayRestPay,
      other_earnings: otherEarnings,
      late_deduction: lateDeduction,
      undertime_deduction: undertimeDeduction,
      absence_deduction: absenceDeduction,
      unpaid_leave_deduction: unpaidLeaveDeduction,
      statutory_deductions: statutory.total,
      tax_deduction: taxDeduction,
      other_deductions: otherDeductions,
      gross_pay: grossPay,
      deductions: totalDeductions,
      net_pay: netPay,
      breakdown: {
        monthly_salary: emp.monthly_salary,
        monthly_allowance: emp.monthly_allowance,
        pay_basis: empTypeRule.payBasis,
        proration_basis: rules.prorationBasis,
        month_proration: monthProrationBreakdown,
        statutory_items: statutory.items,
        taxable_income: taxableIncome,
        applied_exceptions: appliedExceptions,
      },
    });
  }

  const totals = {
    total_basic_pay: round(computedItems.reduce((s, i) => s + i.basic_pay, 0)),
    total_allowances: round(computedItems.reduce((s, i) => s + i.allowances, 0)),
    total_overtime_pay: round(computedItems.reduce((s, i) => s + i.overtime_pay, 0)),
    total_holiday_rest_pay: round(computedItems.reduce((s, i) => s + i.holiday_rest_pay, 0)),
    total_gross_pay: round(computedItems.reduce((s, i) => s + i.gross_pay, 0)),
    total_deductions: round(computedItems.reduce((s, i) => s + i.deductions, 0)),
    total_net_pay: round(computedItems.reduce((s, i) => s + i.net_pay, 0)),
  };

  const canonicalSnapshotPayload = JSON.stringify({
    engineVersion: PAYROLL_ENGINE_VERSION,
    start_date: input.start_date,
    end_date: input.end_date,
    policy_id: policy.id,
    policy_code: policy.policy_code,
    policy_approval_status: policy.approval_status,
    rules,
    totals,
    items: computedItems.map((i) => ({
      employee_id: i.employee_id,
      scheduled_working_days: i.scheduled_working_days,
      days_present: i.days_present,
      days_late: i.days_late,
      days_absent: i.days_absent,
      days_paid_leave: i.days_paid_leave,
      days_unpaid_leave: i.days_unpaid_leave,
      days_holiday: i.days_holiday,
      days_rest_worked: i.days_rest_worked,
      late_minutes: i.late_minutes,
      undertime_minutes: i.undertime_minutes,
      overtime_minutes: i.overtime_minutes,
      basic_pay: i.basic_pay,
      allowances: i.allowances,
      overtime_pay: i.overtime_pay,
      holiday_rest_pay: i.holiday_rest_pay,
      other_earnings: i.other_earnings,
      late_deduction: i.late_deduction,
      undertime_deduction: i.undertime_deduction,
      absence_deduction: i.absence_deduction,
      unpaid_leave_deduction: i.unpaid_leave_deduction,
      statutory_deductions: i.statutory_deductions,
      tax_deduction: i.tax_deduction,
      other_deductions: i.other_deductions,
      gross_pay: i.gross_pay,
      deductions: i.deductions,
      net_pay: i.net_pay,
    })),
  });
  const snapshotSha256 = crypto.createHash('sha256').update(canonicalSnapshotPayload).digest('hex');

  const isProdApproved = policy.approval_status === 'APPROVED_BY_FINANCE' ? 1 : 0;
  const policySnapshotJson = JSON.stringify({
    id: policy.id,
    policy_code: policy.policy_code,
    policy_name: policy.policy_name,
    effective_from: policy.effective_from,
    effective_to: policy.effective_to,
    approval_status: policy.approval_status,
    approval_reference: policy.approval_reference,
    finance_approved_by: policy.finance_approved_by,
    finance_approved_at_utc: policy.finance_approved_at_utc,
    rules,
  });
  const reconciliationSummaryJson = JSON.stringify({
    checkedAtUtc: new Date(nowMs).toISOString(),
    pendingCorrections: 0,
    pendingLeaves: 0,
    unresolvedMissingPunches: 0,
    splitMonthSegments: precheck.splitMonthSegments,
    isProductionApprovedPolicy: Boolean(isProdApproved),
  });

  // Idempotent recompute check: if Computed run already has the exact same SHA-256 snapshot and policy, no-op cleanly!
  if (
    precheck.existingRunForPeriod &&
    input.recompute &&
    precheck.existingRunForPeriod.snapshot_sha256 === snapshotSha256
  ) {
    return {
      id: precheck.existingRunForPeriod.id,
      period_label: precheck.existingRunForPeriod.period_label,
      start_date: input.start_date,
      end_date: input.end_date,
      status: precheck.existingRunForPeriod.status,
      policy_id: policy.id,
      policy_code: policy.policy_code,
      policy_approval_status: policy.approval_status,
      is_production_approved: Boolean(isProdApproved),
      calculation_engine_version: PAYROLL_ENGINE_VERSION,
      calculation_version: precheck.existingRunForPeriod.calculation_version,
      snapshot_sha256: snapshotSha256,
      idempotentNoOp: true,
      employee_count: computedItems.length,
      totals,
    };
  }

  // Atomic BEGIN IMMEDIATE transaction with automatic ROLLBACK on any error (zero partial writes)
  let runId = precheck.existingRunForPeriod?.id || 0;
  let calcVersion = 1;

  const atomicWrite = db.transaction(() => {
    if (precheck.existingRunForPeriod) {
      runId = precheck.existingRunForPeriod.id;
      calcVersion = (precheck.existingRunForPeriod.calculation_version || 1) + 1;
      db.prepare(
        `UPDATE payroll_runs
         SET period_label = ?,
             policy_id = ?,
             policy_code = ?,
             policy_approval_status = ?,
             is_production_approved = ?,
             calculation_engine_version = ?,
             calculation_version = ?,
             snapshot_sha256 = ?,
             policy_snapshot_json = ?,
             reconciliation_summary_json = ?,
             computed_by_user_id = ?,
             created_by = ?,
             employee_count = ?,
             total_basic_pay = ?,
             total_allowances = ?,
             total_overtime_pay = ?,
             total_holiday_rest_pay = ?,
             total_gross_pay = ?,
             total_deductions = ?,
             total_net_pay = ?,
             updated_at = datetime('now', 'localtime')
         WHERE id = ? AND status = 'Computed'`
      ).run(
        periodLabel,
        policy.id,
        policy.policy_code,
        policy.approval_status,
        isProdApproved,
        PAYROLL_ENGINE_VERSION,
        calcVersion,
        snapshotSha256,
        policySnapshotJson,
        reconciliationSummaryJson,
        actor.userId,
        actor.username,
        computedItems.length,
        totals.total_basic_pay,
        totals.total_allowances,
        totals.total_overtime_pay,
        totals.total_holiday_rest_pay,
        totals.total_gross_pay,
        totals.total_deductions,
        totals.total_net_pay,
        runId
      );

      db.prepare('DELETE FROM payroll_items WHERE payroll_run_id = ?').run(runId);
    } else {
      const info = db
        .prepare(
          `INSERT INTO payroll_runs (
             period_label, start_date, end_date, status,
             policy_id, policy_code, policy_approval_status, is_production_approved,
             calculation_engine_version, calculation_version, snapshot_sha256,
             policy_snapshot_json, reconciliation_summary_json,
             computed_by_user_id, created_by, employee_count,
             total_basic_pay, total_allowances, total_overtime_pay, total_holiday_rest_pay,
             total_gross_pay, total_deductions, total_net_pay, updated_at
           )
           VALUES (?, ?, ?, 'Computed', ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', 'localtime'))`
        )
        .run(
          periodLabel,
          input.start_date,
          input.end_date,
          policy.id,
          policy.policy_code,
          policy.approval_status,
          isProdApproved,
          PAYROLL_ENGINE_VERSION,
          snapshotSha256,
          policySnapshotJson,
          reconciliationSummaryJson,
          actor.userId,
          actor.username,
          computedItems.length,
          totals.total_basic_pay,
          totals.total_allowances,
          totals.total_overtime_pay,
          totals.total_holiday_rest_pay,
          totals.total_gross_pay,
          totals.total_deductions,
          totals.total_net_pay
        );
      runId = Number(info.lastInsertRowid);
      calcVersion = 1;
    }

    const insertItem = db.prepare(`
      INSERT INTO payroll_items (
        payroll_run_id, employee_id, employee_type, scheduled_working_days,
        days_present, days_late, days_absent, days_paid_leave, days_unpaid_leave,
        days_holiday, days_rest_worked, late_minutes, undertime_minutes, overtime_minutes,
        basic_pay, prorated_basic_pay, allowances, overtime_pay, holiday_rest_pay,
        other_earnings, late_deduction, undertime_deduction, absence_deduction,
        unpaid_leave_deduction, statutory_deductions, tax_deduction, other_deductions,
        gross_pay, deductions, net_pay, breakdown_json
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (let idx = 0; idx < computedItems.length; idx++) {
      if (
        typeof input._simulateWriteFailureAfterItemIndex === 'number' &&
        idx === input._simulateWriteFailureAfterItemIndex
      ) {
        throw new Error('SIMULATED_PARTIAL_WRITE_FAILURE');
      }
      const item = computedItems[idx];
      insertItem.run(
        runId,
        item.employee_id,
        item.employee_type,
        item.scheduled_working_days,
        item.days_present,
        item.days_late,
        item.days_absent,
        item.days_paid_leave,
        item.days_unpaid_leave,
        item.days_holiday,
        item.days_rest_worked,
        item.late_minutes,
        item.undertime_minutes,
        item.overtime_minutes,
        item.basic_pay,
        item.prorated_basic_pay,
        item.allowances,
        item.overtime_pay,
        item.holiday_rest_pay,
        item.other_earnings,
        item.late_deduction,
        item.undertime_deduction,
        item.absence_deduction,
        item.unpaid_leave_deduction,
        item.statutory_deductions,
        item.tax_deduction,
        item.other_deductions,
        item.gross_pay,
        item.deductions,
        item.net_pay,
        JSON.stringify(item.breakdown)
      );
    }

    appendPayrollAudit(db, {
      payrollRunId: runId,
      policyId: policy.id,
      action: precheck.existingRunForPeriod ? 'RECOMPUTED' : 'COMPUTED',
      previousStatus: precheck.existingRunForPeriod ? 'Computed' : '',
      newStatus: 'Computed',
      calculationVersion: calcVersion,
      snapshotSha256,
      referenceCode: policy.policy_code,
      details: {
        period_label: periodLabel,
        start_date: input.start_date,
        end_date: input.end_date,
        policy_approval_status: policy.approval_status,
        employee_count: computedItems.length,
        totals,
      },
      actor,
      nowMs,
    });
  });

  atomicWrite.immediate();

  return {
    id: runId,
    period_label: periodLabel,
    start_date: input.start_date,
    end_date: input.end_date,
    status: 'Computed',
    policy_id: policy.id,
    policy_code: policy.policy_code,
    policy_approval_status: policy.approval_status,
    is_production_approved: Boolean(isProdApproved),
    calculation_engine_version: PAYROLL_ENGINE_VERSION,
    calculation_version: calcVersion,
    snapshot_sha256: snapshotSha256,
    idempotentNoOp: false,
    employee_count: computedItems.length,
    totals,
  };
}

interface StoredPayrollRunRow {
  id: number;
  period_label: string;
  start_date: string;
  end_date: string;
  status: 'Computed' | 'Finalized' | 'Released';
  policy_id: number | null;
  policy_code: string;
  policy_approval_status: string;
  is_production_approved: number;
  calculation_version: number;
  snapshot_sha256: string;
  computed_by_user_id: number | null;
  created_by: string;
  finalized_by_user_id: number | null;
  finalized_by: string | null;
  finance_signoff_by_user_id: number | null;
  finance_signoff_by: string | null;
  finance_signoff_ref: string;
  finance_signoff_at_utc: string | null;
  released_by_user_id: number | null;
  released_by: string | null;
}

export function finalizePayrollRun(
  db: Database.Database,
  runId: number,
  actor: PayrollActor,
  nowMs: number
): StoredPayrollRunRow {
  const run = db.prepare('SELECT * FROM payroll_runs WHERE id = ?').get(runId) as StoredPayrollRunRow | undefined;
  if (!run) {
    throw new PayrollDomainError(404, 'PAYROLL_RUN_NOT_FOUND', 'Payroll run not found.');
  }
  if (run.status === 'Finalized' || run.status === 'Released') {
    throw new PayrollDomainError(409, 'PAYROLL_RUN_LOCKED', `Payroll run is already ${run.status} and locked.`);
  }
  if (run.policy_approval_status !== 'APPROVED_BY_FINANCE' || run.is_production_approved !== 1) {
    throw new PayrollDomainError(
      409,
      'PAYROLL_POLICY_NOT_APPROVED',
      'Cannot finalize payroll run computed under a draft/unapproved policy (NOT APPROVED FOR PRODUCTION). Approve the institutional policy via Finance first and recompute.'
    );
  }
  if (run.computed_by_user_id && actor.userId === run.computed_by_user_id) {
    throw new PayrollDomainError(
      403,
      'MAKER_CHECKER_VIOLATION',
      'Maker-checker policy prohibits the user who computed a payroll run from finalizing it. A second authorized reviewer must finalize.'
    );
  }

  const utcIso = new Date(nowMs).toISOString();
  const tx = db.transaction(() => {
    db.prepare(
      `UPDATE payroll_runs
       SET status = 'Finalized',
           finalized_by_user_id = ?,
           finalized_by = ?,
           finalized_at = datetime('now', 'localtime'),
           finalized_at_utc = ?,
           updated_at = datetime('now', 'localtime')
       WHERE id = ?`
    ).run(actor.userId, actor.username, utcIso, runId);

    appendPayrollAudit(db, {
      payrollRunId: runId,
      policyId: run.policy_id,
      action: 'FINALIZED',
      previousStatus: 'Computed',
      newStatus: 'Finalized',
      calculationVersion: run.calculation_version,
      snapshotSha256: run.snapshot_sha256,
      referenceCode: run.policy_code,
      actor,
      nowMs,
    });
  });
  tx.immediate();

  return db.prepare('SELECT * FROM payroll_runs WHERE id = ?').get(runId) as StoredPayrollRunRow;
}

export function recordFinanceSignoff(
  db: Database.Database,
  runId: number,
  input: { finance_signoff_ref: string; notes?: string },
  actor: PayrollActor,
  nowMs: number
): StoredPayrollRunRow {
  const run = db.prepare('SELECT * FROM payroll_runs WHERE id = ?').get(runId) as StoredPayrollRunRow | undefined;
  if (!run) {
    throw new PayrollDomainError(404, 'PAYROLL_RUN_NOT_FOUND', 'Payroll run not found.');
  }
  if (run.status === 'Released') {
    throw new PayrollDomainError(409, 'PAYROLL_RUN_LOCKED', 'Payroll run is already Released and immutable.');
  }
  if (run.status !== 'Finalized') {
    throw new PayrollDomainError(
      409,
      'PAYROLL_NOT_FINALIZED',
      'Payroll run must be Finalized before recording Finance sign-off.'
    );
  }
  if (run.policy_approval_status !== 'APPROVED_BY_FINANCE' || run.is_production_approved !== 1) {
    throw new PayrollDomainError(
      409,
      'PAYROLL_POLICY_NOT_APPROVED',
      'Payroll policy must be Finance-approved before run sign-off.'
    );
  }
  if (run.computed_by_user_id && actor.userId === run.computed_by_user_id) {
    throw new PayrollDomainError(
      403,
      'MAKER_CHECKER_VIOLATION',
      'Maker-checker policy prohibits the payroll maker from recording Finance sign-off on their own computed run.'
    );
  }
  const ref = (input.finance_signoff_ref || '').trim();
  if (ref.length < 4) {
    throw new PayrollDomainError(
      400,
      'FINANCE_SIGNOFF_REF_REQUIRED',
      'A written Finance sign-off reference (e.g., Disbursement Voucher / Finance Clearance number) is required.'
    );
  }

  const utcIso = new Date(nowMs).toISOString();
  const tx = db.transaction(() => {
    db.prepare(
      `UPDATE payroll_runs
       SET finance_signoff_by_user_id = ?,
           finance_signoff_by = ?,
           finance_signoff_ref = ?,
           finance_signoff_at_utc = ?,
           updated_at = datetime('now', 'localtime')
       WHERE id = ?`
    ).run(actor.userId, actor.username, ref, utcIso, runId);

    appendPayrollAudit(db, {
      payrollRunId: runId,
      policyId: run.policy_id,
      action: 'FINANCE_SIGNED_OFF',
      previousStatus: 'Finalized',
      newStatus: 'Finalized',
      calculationVersion: run.calculation_version,
      snapshotSha256: run.snapshot_sha256,
      referenceCode: ref,
      details: { notes: (input.notes || '').trim() },
      actor,
      nowMs,
    });
  });
  tx.immediate();

  return db.prepare('SELECT * FROM payroll_runs WHERE id = ?').get(runId) as StoredPayrollRunRow;
}

export function releasePayrollRun(
  db: Database.Database,
  runId: number,
  actor: PayrollActor,
  nowMs: number
): StoredPayrollRunRow {
  const run = db.prepare('SELECT * FROM payroll_runs WHERE id = ?').get(runId) as StoredPayrollRunRow | undefined;
  if (!run) {
    throw new PayrollDomainError(404, 'PAYROLL_RUN_NOT_FOUND', 'Payroll run not found.');
  }
  if (run.status === 'Released') {
    throw new PayrollDomainError(409, 'PAYROLL_RUN_LOCKED', 'Payroll run is already Released and immutable.');
  }
  if (run.status !== 'Finalized') {
    throw new PayrollDomainError(
      409,
      'PAYROLL_NOT_FINALIZED',
      'Payroll run must be Finalized before release.'
    );
  }
  if (run.policy_approval_status !== 'APPROVED_BY_FINANCE' || run.is_production_approved !== 1) {
    throw new PayrollDomainError(
      409,
      'PAYROLL_POLICY_NOT_APPROVED',
      'Cannot release payroll run without an institution-approved written payroll policy.'
    );
  }
  if (!run.finance_signoff_ref || !run.finance_signoff_at_utc) {
    throw new PayrollDomainError(
      409,
      'FINANCE_SIGNOFF_REQUIRED',
      'Finance sign-off must be recorded on the Finalized payroll run prior to release.'
    );
  }
  if (run.computed_by_user_id && actor.userId === run.computed_by_user_id) {
    throw new PayrollDomainError(
      403,
      'MAKER_CHECKER_VIOLATION',
      'Maker-checker policy prohibits the payroll maker from releasing their own computed run.'
    );
  }

  const utcIso = new Date(nowMs).toISOString();
  const tx = db.transaction(() => {
    db.prepare(
      `UPDATE payroll_runs
       SET status = 'Released',
           released_by_user_id = ?,
           released_by = ?,
           released_at = datetime('now', 'localtime'),
           released_at_utc = ?,
           updated_at = datetime('now', 'localtime')
       WHERE id = ?`
    ).run(actor.userId, actor.username, utcIso, runId);

    appendPayrollAudit(db, {
      payrollRunId: runId,
      policyId: run.policy_id,
      action: 'RELEASED',
      previousStatus: 'Finalized',
      newStatus: 'Released',
      calculationVersion: run.calculation_version,
      snapshotSha256: run.snapshot_sha256,
      referenceCode: run.finance_signoff_ref,
      actor,
      nowMs,
    });
  });
  tx.immediate();

  return db.prepare('SELECT * FROM payroll_runs WHERE id = ?').get(runId) as StoredPayrollRunRow;
}

/**
 * Neutralizes spreadsheet formula injection (=, +, -, @, TAB, CR) and safely RFC-4180 quotes CSV fields.
 */
export function sanitizeCsvCell(value: unknown): string {
  const raw = value === null || value === undefined ? '' : String(value);
  const trimmedLeading = raw.replace(/^[ ]+/, '');
  const neutralized =
    trimmedLeading.length > 0 && /^[=+\-@\t\r]/.test(trimmedLeading) ? `'${raw}` : raw;
  if (/[",\r\n]/.test(neutralized)) {
    return `"${neutralized.replace(/"/g, '""')}"`;
  }
  return neutralized;
}

export function generateSafePayrollCsv(
  run: {
    period_label: string;
    start_date: string;
    end_date: string;
    status: string;
    policy_code: string;
    policy_approval_status: string;
    calculation_version: number;
    snapshot_sha256: string;
  },
  items: Array<Record<string, unknown>>
): string {
  const headers = [
    'period_label',
    'start_date',
    'end_date',
    'run_status',
    'policy_code',
    'policy_approval_status',
    'calculation_version',
    'employee_code',
    'employee_name',
    'department_code',
    'position_name',
    'employee_type',
    'scheduled_working_days',
    'days_present',
    'days_late',
    'days_absent',
    'days_paid_leave',
    'days_unpaid_leave',
    'days_holiday',
    'days_rest_worked',
    'late_minutes',
    'undertime_minutes',
    'overtime_minutes',
    'basic_pay',
    'allowances',
    'overtime_pay',
    'holiday_rest_pay',
    'other_earnings',
    'gross_pay',
    'late_deduction',
    'undertime_deduction',
    'absence_deduction',
    'unpaid_leave_deduction',
    'statutory_deductions',
    'tax_deduction',
    'other_deductions',
    'deductions',
    'net_pay',
  ];

  const lines: string[] = [headers.join(',')];
  for (const item of items) {
    const row = [
      run.period_label,
      run.start_date,
      run.end_date,
      run.status,
      run.policy_code || '',
      run.policy_approval_status || '',
      run.calculation_version || 1,
      item.employee_code,
      item.employee_name,
      item.department_code,
      item.position_name,
      item.employee_type || 'Regular',
      item.scheduled_working_days ?? 0,
      item.days_present ?? 0,
      item.days_late ?? 0,
      item.days_absent ?? 0,
      item.days_paid_leave ?? 0,
      item.days_unpaid_leave ?? 0,
      item.days_holiday ?? 0,
      item.days_rest_worked ?? 0,
      item.late_minutes ?? 0,
      item.undertime_minutes ?? 0,
      item.overtime_minutes ?? 0,
      item.basic_pay ?? 0,
      item.allowances ?? 0,
      item.overtime_pay ?? 0,
      item.holiday_rest_pay ?? 0,
      item.other_earnings ?? 0,
      item.gross_pay ?? 0,
      item.late_deduction ?? 0,
      item.undertime_deduction ?? 0,
      item.absence_deduction ?? 0,
      item.unpaid_leave_deduction ?? 0,
      item.statutory_deductions ?? 0,
      item.tax_deduction ?? 0,
      item.other_deductions ?? 0,
      item.deductions ?? 0,
      item.net_pay ?? 0,
    ];
    lines.push(row.map(sanitizeCsvCell).join(','));
  }

  return lines.join('\r\n') + '\r\n';
}
