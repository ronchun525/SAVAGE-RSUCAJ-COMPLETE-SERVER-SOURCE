import Database from 'better-sqlite3';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  checkpointWal,
  collectTableRowCounts,
  CURRENT_SCHEMA_VERSION,
  runMigrations,
} from './db.ts';

const ENCRYPTION_MAGIC = Buffer.from('SVB1', 'ascii');
const SALT_LENGTH = 16;
const IV_LENGTH = 12;
const AUTH_TAG_LENGTH = 16;

export interface BackupManifest {
  backupId: string;
  system: string;
  build: string;
  schemaVersion: string;
  createdAt: string;
  createdBy: string;
  sqliteFile: string;
  sqliteSha256: string;
  sqliteSizeBytes: number;
  encrypted: boolean;
  encryptedFile: string | null;
  encryptedSha256: string | null;
  encryptedSizeBytes: number | null;
  encryptionAlgorithm: string | null;
  integrityCheck: string;
  foreignKeyViolations: number;
  tableCounts: Record<string, number>;
}

export interface CreateBackupOptions {
  backupDir: string;
  createdBy?: string;
  encryptionKey?: string;
  retentionCount?: number;
  recordInHistory?: boolean;
}

export interface CreateBackupResult {
  manifest: BackupManifest;
  sqlitePath: string;
  manifestPath: string;
  encryptedPath: string | null;
  prunedFiles: string[];
}

export interface VerifyBackupOptions {
  encryptionKey?: string;
  manifestPath?: string;
}

export interface VerifyBackupResult {
  valid: boolean;
  errors: string[];
  sqliteSha256: string | null;
  encrypted: boolean;
  integrityCheck: string | null;
  foreignKeyViolations: number;
  schemaVersion: string | null;
  tableCounts: Record<string, number>;
  manifestMatched: boolean | null;
}

export interface RestoreBackupOptions {
  encryptionKey?: string;
  manifestPath?: string;
  dryRun?: boolean;
  /** Internal test hook ONLY to verify automatic rollback when post-restore verification fails. */
  _simulatePostRestoreFailure?: boolean;
}

export interface RestoreBackupResult {
  ok: boolean;
  dryRun: boolean;
  rolledBack: boolean;
  targetDbPath: string;
  preRestoreBackupPath: string | null;
  verification: VerifyBackupResult;
  errors: string[];
}

export interface MigrationRollbackDryRunResult {
  ok: boolean;
  sourceSchemaVersion: string;
  migratedSchemaVersion: string;
  restoredSchemaVersion: string;
  snapshotSha256: string;
  preMigrationCounts: Record<string, number>;
  postRestoreCounts: Record<string, number>;
  rowCountsMatchExact: boolean;
  integrityCheck: string;
  foreignKeyViolations: number;
}

export function sha256File(filePath: string): string {
  const hash = crypto.createHash('sha256');
  const buf = fs.readFileSync(filePath);
  hash.update(buf);
  return hash.digest('hex');
}

export function encryptBackupFile(sourcePath: string, destinationPath: string, passphrase: string): void {
  if (!passphrase || passphrase.length < 32) {
    throw new Error('BACKUP_ENCRYPTION_KEY must be at least 32 characters long for AES-256-GCM archival.');
  }
  const plaintext = fs.readFileSync(sourcePath);
  const salt = crypto.randomBytes(SALT_LENGTH);
  const iv = crypto.randomBytes(IV_LENGTH);
  const key = crypto.scryptSync(passphrase, salt, 32, { N: 16384, r: 8, p: 1 });
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const authTag = cipher.getAuthTag();

  const envelope = Buffer.concat([ENCRYPTION_MAGIC, salt, iv, authTag, ciphertext]);
  fs.writeFileSync(destinationPath, envelope, { mode: 0o600 });
}

export function decryptBackupFile(encryptedPath: string, destinationPath: string, passphrase: string): void {
  if (!passphrase) {
    throw new Error('Decryption passphrase (BACKUP_ENCRYPTION_KEY) is required to restore an encrypted archive.');
  }
  const envelope = fs.readFileSync(encryptedPath);
  const headerLen = ENCRYPTION_MAGIC.length + SALT_LENGTH + IV_LENGTH + AUTH_TAG_LENGTH;
  if (envelope.length <= headerLen) {
    throw new Error('Encrypted backup archive is truncated or corrupt.');
  }
  const magic = envelope.subarray(0, ENCRYPTION_MAGIC.length);
  if (!magic.equals(ENCRYPTION_MAGIC)) {
    throw new Error('Invalid encrypted backup header magic.');
  }

  let offset = ENCRYPTION_MAGIC.length;
  const salt = envelope.subarray(offset, offset + SALT_LENGTH);
  offset += SALT_LENGTH;
  const iv = envelope.subarray(offset, offset + IV_LENGTH);
  offset += IV_LENGTH;
  const authTag = envelope.subarray(offset, offset + AUTH_TAG_LENGTH);
  offset += AUTH_TAG_LENGTH;
  const ciphertext = envelope.subarray(offset);

  const key = crypto.scryptSync(passphrase, salt, 32, { N: 16384, r: 8, p: 1 });
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);

  const plaintext = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
  fs.writeFileSync(destinationPath, plaintext, { mode: 0o600 });
}

function inspectSqliteSnapshotFile(sqlitePath: string): {
  integrityCheck: string;
  foreignKeyViolations: number;
  schemaVersion: string;
  tableCounts: Record<string, number>;
} {
  const snapDb = new Database(sqlitePath, { readonly: true, fileMustExist: true });
  try {
    snapDb.pragma('foreign_keys = ON');
    const integrityCheck = String(snapDb.pragma('integrity_check', { simple: true }));
    const fkViolations = snapDb.pragma('foreign_key_check', { simple: false }) as unknown[];
    let schemaVersion = '000';
    try {
      const latest = snapDb
        .prepare('SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1')
        .get() as { version: string } | undefined;
      if (latest?.version) schemaVersion = latest.version;
    } catch {
      schemaVersion = '000';
    }
    const tableCounts = collectTableRowCounts(snapDb);
    return {
      integrityCheck,
      foreignKeyViolations: fkViolations.length,
      schemaVersion,
      tableCounts,
    };
  } finally {
    snapDb.close();
  }
}

function pruneOldBackups(backupDir: string, retentionCount: number): string[] {
  if (retentionCount < 1 || !fs.existsSync(backupDir)) return [];
  const manifests = fs
    .readdirSync(backupDir)
    .filter((f) => f.endsWith('.manifest.json') && f.startsWith('savage-rsucaj-'))
    .sort()
    .reverse();

  const pruned: string[] = [];
  if (manifests.length <= retentionCount) return pruned;

  const toDelete = manifests.slice(retentionCount);
  for (const manifestFile of toDelete) {
    const manifestFull = path.join(backupDir, manifestFile);
    try {
      const parsed = JSON.parse(fs.readFileSync(manifestFull, 'utf8')) as Partial<BackupManifest>;
      const related = [parsed.sqliteFile, parsed.encryptedFile, manifestFile].filter(
        (v): v is string => typeof v === 'string' && v.length > 0
      );
      for (const rel of related) {
        const candidate = path.join(backupDir, path.basename(rel));
        if (fs.existsSync(candidate)) {
          fs.unlinkSync(candidate);
          pruned.push(path.basename(candidate));
        }
      }
    } catch {
      // ignore malformed manifest during retention pruning
    }
  }
  return pruned;
}

/**
 * Creates a consistent online SQLite snapshot using `VACUUM INTO`, verifies integrity & FKs,
 * writes a SHA-256 checksum manifest, and optionally produces an AES-256-GCM encrypted offsite archive.
 */
export function createOnlineSqliteBackup(
  db: Database.Database,
  options: CreateBackupOptions
): CreateBackupResult {
  const backupDir = path.resolve(options.backupDir);
  fs.mkdirSync(backupDir, { recursive: true, mode: 0o750 });

  const now = new Date();
  const stamp = now.toISOString().replace(/[:.]/g, '-');
  const shortRand = crypto.randomBytes(3).toString('hex');
  const backupId = `bkp-${stamp}-${shortRand}`;
  const sqliteFile = `savage-rsucaj-${backupId}.sqlite`;
  const sqlitePath = path.join(backupDir, sqliteFile);
  const manifestFile = `savage-rsucaj-${backupId}.manifest.json`;
  const manifestPath = path.join(backupDir, manifestFile);

  // Best-effort WAL passive checkpoint before online snapshot
  if (!db.memory) {
    try {
      checkpointWal(db, 'PASSIVE');
    } catch {
      // VACUUM INTO still produces a transactionally consistent snapshot even if WAL is busy
    }
  }

  // VACUUM INTO creates a self-contained, defragmented, transactionally consistent single-file SQLite DB
  db.prepare('VACUUM INTO ?').run(sqlitePath);

  const inspection = inspectSqliteSnapshotFile(sqlitePath);
  if (inspection.integrityCheck !== 'ok' || inspection.foreignKeyViolations > 0) {
    fs.unlinkSync(sqlitePath);
    throw new Error(
      `Online backup integrity check failed (integrity=${inspection.integrityCheck}, fkViolations=${inspection.foreignKeyViolations}).`
    );
  }

  const sqliteSha256 = sha256File(sqlitePath);
  const sqliteSizeBytes = fs.statSync(sqlitePath).size;

  const encryptionKey = options.encryptionKey?.trim() || '';
  let encryptedFile: string | null = null;
  let encryptedPath: string | null = null;
  let encryptedSha256: string | null = null;
  let encryptedSizeBytes: number | null = null;

  if (encryptionKey) {
    encryptedFile = `${sqliteFile}.enc`;
    encryptedPath = path.join(backupDir, encryptedFile);
    encryptBackupFile(sqlitePath, encryptedPath, encryptionKey);
    encryptedSha256 = sha256File(encryptedPath);
    encryptedSizeBytes = fs.statSync(encryptedPath).size;
  }

  const manifest: BackupManifest = {
    backupId,
    system: 'SAVAGE-RSUCAJ Smart Attendance System',
    build: 'BUILD 17',
    schemaVersion: inspection.schemaVersion || CURRENT_SCHEMA_VERSION,
    createdAt: now.toISOString(),
    createdBy: options.createdBy || 'system',
    sqliteFile,
    sqliteSha256,
    sqliteSizeBytes,
    encrypted: Boolean(encryptedPath),
    encryptedFile,
    encryptedSha256,
    encryptedSizeBytes,
    encryptionAlgorithm: encryptedPath ? 'AES-256-GCM (scrypt N=16384,r=8,p=1)' : null,
    integrityCheck: inspection.integrityCheck,
    foreignKeyViolations: inspection.foreignKeyViolations,
    tableCounts: inspection.tableCounts,
  };

  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2), { mode: 0o600 });

  if (options.recordInHistory !== false) {
    try {
      db.prepare(
        `INSERT INTO backup_history
          (backup_id, file_name, manifest_file, encrypted_file, sha256, size_bytes, encrypted, integrity_status, foreign_key_violations, schema_version, table_counts_json, operation_type, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'backup', ?)`
      ).run(
        manifest.backupId,
        manifest.sqliteFile,
        manifestFile,
        manifest.encryptedFile || '',
        manifest.sqliteSha256,
        manifest.sqliteSizeBytes,
        manifest.encrypted ? 1 : 0,
        manifest.integrityCheck,
        manifest.foreignKeyViolations,
        manifest.schemaVersion,
        JSON.stringify(manifest.tableCounts),
        manifest.createdBy
      );
    } catch {
      // Backup file & manifest are already safely persisted even if read-only source DB skips history insert
    }
  }

  const prunedFiles =
    typeof options.retentionCount === 'number' && options.retentionCount > 0
      ? pruneOldBackups(backupDir, options.retentionCount)
      : [];

  return {
    manifest,
    sqlitePath,
    manifestPath,
    encryptedPath,
    prunedFiles,
  };
}

function resolveManifestForArchive(archivePath: string, explicitManifestPath?: string): BackupManifest | null {
  if (explicitManifestPath && fs.existsSync(explicitManifestPath)) {
    return JSON.parse(fs.readFileSync(explicitManifestPath, 'utf8')) as BackupManifest;
  }
  const baseName = path.basename(archivePath);
  const stripped = baseName.replace(/\.sqlite\.enc$/i, '').replace(/\.sqlite$/i, '');
  const guessed = path.join(path.dirname(archivePath), `${stripped}.manifest.json`);
  if (fs.existsSync(guessed)) {
    return JSON.parse(fs.readFileSync(guessed, 'utf8')) as BackupManifest;
  }
  return null;
}

export function verifyBackupArchive(
  archivePath: string,
  options: VerifyBackupOptions = {}
): VerifyBackupResult {
  const errors: string[] = [];
  const resolvedArchive = path.resolve(archivePath);

  if (!fs.existsSync(resolvedArchive)) {
    return {
      valid: false,
      errors: [`Backup archive not found: ${resolvedArchive}`],
      sqliteSha256: null,
      encrypted: resolvedArchive.endsWith('.enc'),
      integrityCheck: null,
      foreignKeyViolations: -1,
      schemaVersion: null,
      tableCounts: {},
      manifestMatched: null,
    };
  }

  let manifest: BackupManifest | null = null;
  try {
    manifest = resolveManifestForArchive(resolvedArchive, options.manifestPath);
  } catch (err) {
    errors.push(`Failed to parse backup manifest JSON: ${err instanceof Error ? err.message : String(err)}`);
  }

  const isEncrypted = resolvedArchive.endsWith('.enc');
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-rsucaj-verify-'));
  let workingSqlitePath = resolvedArchive;

  try {
    if (isEncrypted) {
      if (manifest?.encryptedSha256) {
        const actualEncSha = sha256File(resolvedArchive);
        if (actualEncSha !== manifest.encryptedSha256) {
          errors.push(
            `Encrypted archive SHA-256 mismatch (expected ${manifest.encryptedSha256}, got ${actualEncSha}).`
          );
        }
      }
      workingSqlitePath = path.join(tmpDir, 'decrypted.sqlite');
      try {
        decryptBackupFile(resolvedArchive, workingSqlitePath, options.encryptionKey || '');
      } catch (err) {
        errors.push(`AES-256-GCM decryption failed: ${err instanceof Error ? err.message : String(err)}`);
        return {
          valid: false,
          errors,
          sqliteSha256: null,
          encrypted: true,
          integrityCheck: null,
          foreignKeyViolations: -1,
          schemaVersion: null,
          tableCounts: {},
          manifestMatched: false,
        };
      }
    }

    const actualSqliteSha = sha256File(workingSqlitePath);
    let manifestMatched: boolean | null = null;
    if (manifest) {
      manifestMatched = true;
      if (manifest.sqliteSha256 !== actualSqliteSha) {
        manifestMatched = false;
        errors.push(
          `SQLite SHA-256 checksum mismatch (expected ${manifest.sqliteSha256}, got ${actualSqliteSha}).`
        );
      }
    }

    let inspection: ReturnType<typeof inspectSqliteSnapshotFile>;
    try {
      inspection = inspectSqliteSnapshotFile(workingSqlitePath);
    } catch (err) {
      errors.push(`Backup file is not a valid readable SQLite database: ${err instanceof Error ? err.message : String(err)}`);
      return {
        valid: false,
        errors,
        sqliteSha256: actualSqliteSha,
        encrypted: isEncrypted,
        integrityCheck: 'corrupt',
        foreignKeyViolations: -1,
        schemaVersion: null,
        tableCounts: {},
        manifestMatched: manifest ? false : null,
      };
    }

    if (inspection.integrityCheck !== 'ok') {
      errors.push(`PRAGMA integrity_check failed: ${inspection.integrityCheck}`);
    }
    if (inspection.foreignKeyViolations > 0) {
      errors.push(`PRAGMA foreign_key_check found ${inspection.foreignKeyViolations} violation(s).`);
    }

    if (manifest?.tableCounts) {
      for (const [table, expectedCount] of Object.entries(manifest.tableCounts)) {
        const actualCount = inspection.tableCounts[table] ?? 0;
        if (actualCount !== expectedCount) {
          manifestMatched = false;
          errors.push(`Row count mismatch for table "${table}" (expected ${expectedCount}, got ${actualCount}).`);
        }
      }
    }

    return {
      valid: errors.length === 0,
      errors,
      sqliteSha256: actualSqliteSha,
      encrypted: isEncrypted,
      integrityCheck: inspection.integrityCheck,
      foreignKeyViolations: inspection.foreignKeyViolations,
      schemaVersion: inspection.schemaVersion,
      tableCounts: inspection.tableCounts,
      manifestMatched,
    };
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}

/**
 * Safely restores a verified SQLite backup (plain or AES-256-GCM encrypted) to `targetDbPath`.
 * - Validates archive checksum, integrity, FKs, and row counts BEFORE touching `targetDbPath`.
 * - When `dryRun: true`, performs full validation in isolation without modifying `targetDbPath`.
 * - When `dryRun: false`, creates a consistent `.pre-restore-*.bak` snapshot first and
 *   automatically rolls back if post-restore verification fails.
 */
export function restoreSqliteBackup(
  archivePath: string,
  targetDbPath: string,
  options: RestoreBackupOptions = {}
): RestoreBackupResult {
  const dryRun = options.dryRun === true;
  const resolvedArchive = path.resolve(archivePath);
  const resolvedTarget = path.resolve(targetDbPath);

  const verification = verifyBackupArchive(resolvedArchive, {
    encryptionKey: options.encryptionKey,
    manifestPath: options.manifestPath,
  });

  if (!verification.valid) {
    return {
      ok: false,
      dryRun,
      rolledBack: false,
      targetDbPath: resolvedTarget,
      preRestoreBackupPath: null,
      verification,
      errors: [...verification.errors, 'Restore aborted prior to touching target database.'],
    };
  }

  if (dryRun) {
    return {
      ok: true,
      dryRun: true,
      rolledBack: false,
      targetDbPath: resolvedTarget,
      preRestoreBackupPath: null,
      verification,
      errors: [],
    };
  }

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-rsucaj-restore-'));
  let preRestoreBackupPath: string | null = null;

  try {
    const stagedPath = path.join(tmpDir, 'staged.sqlite');
    if (resolvedArchive.endsWith('.enc')) {
      decryptBackupFile(resolvedArchive, stagedPath, options.encryptionKey || '');
    } else {
      fs.copyFileSync(resolvedArchive, stagedPath);
    }

    fs.mkdirSync(path.dirname(resolvedTarget), { recursive: true, mode: 0o750 });

    // Preserve existing target DB atomically using VACUUM INTO (captures uncheckpointed WAL frames safely)
    if (fs.existsSync(resolvedTarget)) {
      const stamp = new Date().toISOString().replace(/[:.]/g, '-');
      preRestoreBackupPath = `${resolvedTarget}.pre-restore-${stamp}.bak`;
      try {
        const existingDb = new Database(resolvedTarget, { readonly: false });
        try {
          existingDb.prepare('VACUUM INTO ?').run(preRestoreBackupPath);
        } finally {
          existingDb.close();
        }
      } catch {
        fs.copyFileSync(resolvedTarget, preRestoreBackupPath);
      }
    }

    // Remove stale WAL/SHM sidecars before swapping target file
    for (const suffix of ['-wal', '-shm']) {
      const sidecar = `${resolvedTarget}${suffix}`;
      if (fs.existsSync(sidecar)) {
        fs.unlinkSync(sidecar);
      }
    }

    const tempTargetSwap = `${resolvedTarget}.restoring-${process.pid}`;
    fs.copyFileSync(stagedPath, tempTargetSwap);
    fs.renameSync(tempTargetSwap, resolvedTarget);

    // Post-restore verification
    const postCheck = verifyBackupArchive(resolvedTarget, {
      manifestPath: options.manifestPath,
    });
    const postValid = postCheck.valid && !options._simulatePostRestoreFailure;

    if (!postValid) {
      const failureReasons = options._simulatePostRestoreFailure
        ? ['Simulated post-restore verification failure triggered automatic rollback.']
        : postCheck.errors;

      let rolledBack = false;
      if (preRestoreBackupPath && fs.existsSync(preRestoreBackupPath)) {
        for (const suffix of ['-wal', '-shm']) {
          const sidecar = `${resolvedTarget}${suffix}`;
          if (fs.existsSync(sidecar)) fs.unlinkSync(sidecar);
        }
        fs.copyFileSync(preRestoreBackupPath, resolvedTarget);
        rolledBack = true;
      }

      return {
        ok: false,
        dryRun: false,
        rolledBack,
        targetDbPath: resolvedTarget,
        preRestoreBackupPath,
        verification: postCheck,
        errors: failureReasons,
      };
    }

    return {
      ok: true,
      dryRun: false,
      rolledBack: false,
      targetDbPath: resolvedTarget,
      preRestoreBackupPath,
      verification: {
        ...postCheck,
        encrypted: verification.encrypted,
      },
      errors: [],
    };
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}

/**
 * Non-destructive migration & rollback dry run executed entirely inside an isolated temp directory:
 * 1. Creates an online snapshot of `sourceDbPath` (pre-migration backup A).
 * 2. Copies snapshot to working copy B and executes `runMigrations(copyB)`.
 * 3. Restores snapshot A over copy B using `restoreSqliteBackup` and verifies exact pre-migration
 *    schema version, zero FK violations, integrity_check=ok, and exact row counts.
 */
export function runMigrationRollbackDryRun(sourceDbPath: string): MigrationRollbackDryRunResult {
  const resolvedSource = path.resolve(sourceDbPath);
  if (!fs.existsSync(resolvedSource)) {
    throw new Error(`Source SQLite database not found: ${resolvedSource}`);
  }

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-rsucaj-mig-dryrun-'));
  try {
    const backupDir = path.join(tmpDir, 'snapshots');
    const sourceDb = new Database(resolvedSource, { readonly: false });
    let snapshotResult: CreateBackupResult;
    try {
      snapshotResult = createOnlineSqliteBackup(sourceDb, {
        backupDir,
        createdBy: 'migration-dry-run',
        recordInHistory: false,
      });
    } finally {
      sourceDb.close();
    }

    const workDbPath = path.join(tmpDir, 'work-migrated.sqlite');
    fs.copyFileSync(snapshotResult.sqlitePath, workDbPath);

    // Apply all versioned migrations to isolated working copy
    let migratedSchemaVersion = snapshotResult.manifest.schemaVersion;
    const workDb = new Database(workDbPath);
    try {
      workDb.pragma('foreign_keys = ON');
      runMigrations(workDb);
      const latest = workDb
        .prepare('SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1')
        .get() as { version: string } | undefined;
      if (latest?.version) migratedSchemaVersion = latest.version;
    } finally {
      workDb.close();
    }

    // Roll back working copy using pre-migration snapshot A
    const rollbackRes = restoreSqliteBackup(snapshotResult.sqlitePath, workDbPath, {
      manifestPath: snapshotResult.manifestPath,
      dryRun: false,
    });

    if (!rollbackRes.ok) {
      throw new Error(`Migration rollback dry run failed: ${rollbackRes.errors.join('; ')}`);
    }

    const postInspection = inspectSqliteSnapshotFile(workDbPath);
    const preCounts = snapshotResult.manifest.tableCounts;
    const postCounts = postInspection.tableCounts;

    const allTables = new Set([...Object.keys(preCounts), ...Object.keys(postCounts)]);
    let rowCountsMatchExact = true;
    for (const t of allTables) {
      if ((preCounts[t] ?? 0) !== (postCounts[t] ?? 0)) {
        rowCountsMatchExact = false;
      }
    }

    return {
      ok:
        rollbackRes.ok &&
        rowCountsMatchExact &&
        postInspection.integrityCheck === 'ok' &&
        postInspection.foreignKeyViolations === 0,
      sourceSchemaVersion: snapshotResult.manifest.schemaVersion,
      migratedSchemaVersion,
      restoredSchemaVersion: postInspection.schemaVersion,
      snapshotSha256: snapshotResult.manifest.sqliteSha256,
      preMigrationCounts: preCounts,
      postRestoreCounts: postCounts,
      rowCountsMatchExact,
      integrityCheck: postInspection.integrityCheck,
      foreignKeyViolations: postInspection.foreignKeyViolations,
    };
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}
