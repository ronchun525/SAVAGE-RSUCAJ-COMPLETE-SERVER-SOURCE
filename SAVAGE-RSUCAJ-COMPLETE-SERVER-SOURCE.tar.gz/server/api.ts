import express from 'express';
import crypto from 'node:crypto';
import PDFDocument from 'pdfkit';
import type Database from 'better-sqlite3';
import {
  AuthenticatedRequest,
  clearAuthCookies,
  constantTimeEqualString,
  createRequireAuth,
  createUserSession,
  hashPassword,
  loadActiveSessionFromRequest,
  parseCookies,
  requireCsrf,
  requirePasswordChanged,
  requirePermission,
  revokeAllUserSessions,
  revokeSessionById,
  SESSION_COOKIE_NAME,
  setAuthCookies,
  verifyPassword,
  verifySignedSessionCookie,
} from './auth.ts';
import path from 'node:path';
import fs from 'node:fs';
import {
  checkpointWal,
  closeDatabaseSafely,
  getDatabaseStatus,
  getTodayDateString,
  initDatabase,
  isDatabaseUnavailableError,
  logAudit,
  verifyAuditLogChain,
} from './db.ts';
import { createOnlineSqliteBackup, restoreSqliteBackup, verifyBackupArchive } from './backup.ts';
import {
  AdminOpsError,
  clearNotificationsForRole,
  createTargetedNotification,
  deleteNotificationForRole,
  deleteNotificationsForRole,
  evaluateDeviceConnectivityAlerts,
  executeDataRetention,
  formatMaskedKioskToken,
  getUnreadNotificationCountForRole,
  hashKioskToken,
  listRetentionJobs,
  listSecurityChangeHistory,
  markNotificationReadForRole,
  markNotificationsReadForRole,
  previewDataRetention,
  queryNotificationsForRole,
  rotateDeviceToken,
  validateAndApplySettingsUpdates,
} from './adminOpsEngine.ts';
import { formatManilaDateTime } from './auditHelpers.ts';
import { validatePasswordStrength } from './env.ts';
import { isValidRole, type PermissionCode, type RoleName } from './rbac.ts';
import { resolveEmployeeAccountLink } from './employeeAccounts.ts';
import { resolveEmployeeTodayShiftDate } from './employeeToday.ts';
import {
  apiNoStoreMiddleware,
  getClientIp,
  isIsoDateString,
  isRequestOriginAllowed,
  parsePositiveIntId,
  SlidingWindowRateLimiter,
} from './security.ts';

import {
  addDaysIso,
  APPROVED_ATTENDANCE_STATUSES,
  computeWorkHoursFromStrings,
  DEFAULT_MAX_CLOCK_DRIFT_SECONDS,
  DEFAULT_MAX_OFFLINE_REPLAY_HOURS,
  getManilaDayCodeForIsoDate,
  isApprovedAttendanceStatus,
  normalizeAttendanceAction,
  parseExplicitIsoTimestampToUtcMs,
  processKioskPunch,
  reconcileAttendanceForDate,
  toManilaParts,
} from './attendanceEngine.ts';
import { verifyBiometricEvidenceEnvelope } from './kioskOfflineQueue.ts';
import { registerAndroidBridgeRoutes } from './androidBridge.ts';
import { registerWebKioskAdminRoutes, registerWebKioskPublicRoutes } from './webKioskRoutes.ts';
import { RealtimeHub } from './realtimeHub.ts';
import {
  cancelLeaveRequest,
  computeEmployeeLeaveBalances,
  createCorrectionRequest,
  createLeaveRequest,
  evaluateLeaveRequestDates,
  getLeavePolicies,
  reverseCorrectionRequest,
  reviewCorrectionRequest,
  reviewLeaveRequest,
  type LeaveDayPortion,
} from './correctionsLeavesEngine.ts';
import {
  approvePayrollPolicyByFinance,
  computeOrRecomputePayrollRun,
  createPayrollPolicy,
  finalizePayrollRun,
  generateSafePayrollCsv,
  getPayrollPolicyTemplate,
  listPayrollPolicies,
  PAYROLL_ENGINE_VERSION,
  PayrollDomainError,
  reconcilePayrollPeriodPrecheck,
  recordFinanceSignoff,
  releasePayrollRun,
  updateDraftPayrollPolicy,
} from './payrollEngine.ts';
import {
  buildMonthlyDtrReports,
  generateReportPdfBuffer,
  getMonthCalendarMeta,
  isValidIsoDate,
  isValidIsoMonth,
  isValidReportType,
  queryReport,
  ReportEngineError,
  type ReportFilters,
  type ReportType,
  revokeMonthlyDtrSignoff,
  signMonthlyDtr,
  streamCsvReportResponse,
} from './reportsEngine.ts';
import type { AppMode } from './env.ts';
import {
  createStructuredLoggerMiddleware,
  StagingImpairmentController,
  StructuredLogStore,
} from './stagingRuntime.ts';

export const DEFAULT_HEARTBEAT_TIMEOUT_SECONDS = 90;
export const DEFAULT_STALE_WARNING_SECONDS = 60;
export const DEFAULT_SYNC_MAX_BATCH_SIZE = 100;

export interface ApiRouterOptions {
  maxFailedLoginAttempts?: number;
  lockoutDurationMinutes?: number;
  loginRateLimitMax?: number;
  dbPath?: string;
  backupDir?: string;
  backupRetentionCount?: number;
  appMode?: string;
  /** Optional deterministic server clock provider (epoch ms), defaults to Date.now() */
  nowProvider?: () => number;
  maxClockDriftSeconds?: number;
  maxOfflineReplayHours?: number;
  heartbeatTimeoutSeconds?: number;
  staleWarningSeconds?: number;
  realtimeHub?: RealtimeHub;
  onDatabaseReplaced?: (nextDb: Database.Database) => void;
  stagingImpairmentEnabled?: boolean;
  structuredLogStore?: StructuredLogStore;
  impairmentController?: StagingImpairmentController;
}

export interface StoredDeviceRow {
  id: number;
  name: string;
  device_type: 'Raspberry Pi' | 'Android';
  model_info: string;
  ip_address: string;
  location: string;
  api_token: string;
  token_hash?: string;
  token_masked?: string;
  token_rotated_at?: string | null;
  offline_alert_state?: string;
  last_alerted_at_utc?: string | null;
  status: string;
  last_heartbeat: string;
  last_heartbeat_utc: string | null;
  last_sync_utc: string | null;
  pending_queue_count: number;
  last_clock_drift_seconds: number | null;
  last_monotonic_seq: number;
  last_sync_status: string;
  last_sync_error: string;
  is_revoked: number;
  revoked_at: string | null;
  device_boot_id: string;
  created_at: string;
}

export interface ComputedDeviceTelemetry {
  id: number;
  name: string;
  device_type: 'Raspberry Pi' | 'Android';
  model_info: string;
  ip_address: string;
  location: string;
  status: 'Online' | 'Offline';
  connectivity: 'Online' | 'Stale' | 'Offline' | 'Revoked';
  last_heartbeat: string;
  last_heartbeat_utc: string | null;
  last_sync_utc: string | null;
  seconds_since_heartbeat: number | null;
  pending_queue_count: number;
  stale_warning: boolean;
  last_clock_drift_seconds: number | null;
  last_monotonic_seq: number;
  last_sync_status: string;
  last_sync_error: string;
  is_revoked: number;
  revoked_at: string | null;
  device_boot_id: string;
  token_masked: string;
  token_fingerprint: string;
  token_rotated_at: string | null;
  offline_alert_state: string;
  created_at: string;
}

/**
 * Strictly computes real kiosk Online / Stale / Offline / Revoked connectivity from
 * verified `last_heartbeat_utc` vs authoritative server clock. Never trusts a manual
 * fake status toggle or seeded Online value.
 */
export function computeDeviceTelemetry(
  row: StoredDeviceRow,
  nowMs: number,
  thresholds: { heartbeatTimeoutSec: number; staleWarningSec: number }
): ComputedDeviceTelemetry {
  const tokenMasked =
    row.token_masked && row.token_masked.length > 0
      ? row.token_masked
      : formatMaskedKioskToken(row.api_token || '');
  const tokenHash =
    row.token_hash && row.token_hash.length >= 12
      ? row.token_hash
      : row.api_token
        ? hashKioskToken(row.api_token)
        : '';

  const base = {
    id: row.id,
    name: row.name,
    device_type: row.device_type,
    model_info: row.model_info,
    ip_address: row.ip_address,
    location: row.location,
    last_heartbeat: row.last_heartbeat || 'Never',
    last_heartbeat_utc: row.last_heartbeat_utc ?? null,
    last_sync_utc: row.last_sync_utc ?? null,
    pending_queue_count: Number(row.pending_queue_count) || 0,
    last_clock_drift_seconds:
      row.last_clock_drift_seconds === null || row.last_clock_drift_seconds === undefined
        ? null
        : Number(row.last_clock_drift_seconds),
    last_monotonic_seq: Number(row.last_monotonic_seq) || 0,
    last_sync_status: row.is_revoked ? 'Revoked' : row.last_sync_status || 'Idle',
    last_sync_error: row.last_sync_error || '',
    is_revoked: Number(row.is_revoked) ? 1 : 0,
    revoked_at: row.revoked_at ?? null,
    device_boot_id: row.device_boot_id || '',
    token_masked: tokenMasked,
    token_fingerprint: tokenHash ? tokenHash.slice(0, 12) : '',
    token_rotated_at: row.token_rotated_at ?? null,
    offline_alert_state: row.offline_alert_state || 'NONE',
    created_at: row.created_at,
  };

  if (base.is_revoked === 1) {
    return {
      ...base,
      status: 'Offline',
      connectivity: 'Revoked',
      seconds_since_heartbeat: null,
      stale_warning: false,
    };
  }

  if (!row.last_heartbeat_utc) {
    return {
      ...base,
      status: 'Offline',
      connectivity: 'Offline',
      seconds_since_heartbeat: null,
      stale_warning: true,
    };
  }

  const parsedMs = Date.parse(row.last_heartbeat_utc);
  if (Number.isNaN(parsedMs)) {
    return {
      ...base,
      status: 'Offline',
      connectivity: 'Offline',
      seconds_since_heartbeat: null,
      stale_warning: true,
    };
  }

  const ageSec = Math.max(0, Math.floor((nowMs - parsedMs) / 1000));
  if (ageSec <= thresholds.staleWarningSec) {
    return {
      ...base,
      status: 'Online',
      connectivity: 'Online',
      seconds_since_heartbeat: ageSec,
      stale_warning: false,
    };
  }
  if (ageSec <= thresholds.heartbeatTimeoutSec) {
    return {
      ...base,
      status: 'Online',
      connectivity: 'Stale',
      seconds_since_heartbeat: ageSec,
      stale_warning: true,
    };
  }
  return {
    ...base,
    status: 'Offline',
    connectivity: 'Offline',
    seconds_since_heartbeat: ageSec,
    stale_warning: true,
  };
}

function findDeviceByToken(db: Database.Database, token: string): StoredDeviceRow | null {
  if (!token || token.length < 10) return null;
  const presentedHash = hashKioskToken(token);
  const devices = db.prepare('SELECT * FROM devices').all() as StoredDeviceRow[];
  for (const dev of devices) {
    if (dev.token_hash && dev.token_hash.length === 64 && constantTimeEqualString(presentedHash, dev.token_hash)) {
      return dev;
    }
    if (dev.api_token && constantTimeEqualString(token, dev.api_token)) {
      return dev;
    }
  }
  return null;
}

function checkEmployeeScope(
  db: Database.Database,
  user: AuthenticatedRequest['user'],
  targetEmployeeId: number
): boolean {
  if (!user) return false;
  if (user.role === 'Employee') {
    return user.employee_id !== null && user.employee_id === targetEmployeeId;
  }
  if (user.role === 'Department Head') {
    if (user.department_id === null) return false;
    const emp = db.prepare('SELECT department_id FROM employees WHERE id = ?').get(targetEmployeeId) as
      | { department_id: number }
      | undefined;
    return Boolean(emp && emp.department_id === user.department_id);
  }
  return true;
}

const ACTION_SORT_RANK: Record<string, number> = {
  TIME_IN: 1,
  BREAK_OUT: 2,
  BREAK_IN: 3,
  TIME_OUT: 4,
  OVERTIME_OUT: 5,
};

export function createApiRouter(initialDb: Database.Database, options: ApiRouterOptions = {}): express.Router {
  let db = initialDb;
  const router = express.Router();
  router.use(apiNoStoreMiddleware);
  router.use(express.json({ limit: '2mb' }));

  const maxFailedAttempts = options.maxFailedLoginAttempts ?? (Number(process.env.MAX_FAILED_LOGIN_ATTEMPTS) || 5);
  const lockoutMinutes = options.lockoutDurationMinutes ?? (Number(process.env.LOCKOUT_DURATION_MINUTES) || 15);
  const loginRateLimitMax = options.loginRateLimitMax ?? (Number(process.env.LOGIN_RATE_LIMIT_MAX) || 20);

  const loginRateLimiter = new SlidingWindowRateLimiter({
    windowMs: 15 * 60 * 1000,
    maxRequests: loginRateLimitMax,
    message: 'Too many login attempts from this network address. Please try again later.',
  });

  const kioskRateLimiter = new SlidingWindowRateLimiter({
    windowMs: 60 * 1000,
    maxRequests: 120,
    message: 'Kiosk rate limit exceeded. Slow down terminal polling.',
  });

  const requireAuth = createRequireAuth(() => db);

  const resolvedDbPath = options.dbPath ?? (db.memory ? ':memory:' : db.name || './data/savage_rsucaj.db');
  const resolvedBackupDir =
    options.backupDir ??
    process.env.BACKUP_DIR?.trim() ??
    (resolvedDbPath === ':memory:'
      ? path.resolve(process.cwd(), 'data', 'backups')
      : path.resolve(path.dirname(resolvedDbPath), 'backups'));
  const backupRetentionCount = options.backupRetentionCount ?? (Number(process.env.BACKUP_RETENTION_COUNT) || 14);
  const appMode = (options.appMode ?? (process.env.APP_MODE?.trim() || 'production')) as AppMode;
  const getNowMs = options.nowProvider ?? (() => Date.now());
  const realtimeHub = options.realtimeHub ?? new RealtimeHub({ nowProvider: getNowMs });

  const structuredLogStore =
    options.structuredLogStore ??
    new StructuredLogStore({
      logFilePath: process.env.STAGING_LOG_FILE,
      emitStdout:
        (process.env.LOG_FORMAT || '').trim().toLowerCase() === 'json' &&
        appMode !== 'test',
    });

  const allowImpairment =
    appMode !== 'production' &&
    (options.stagingImpairmentEnabled ??
      (process.env.STAGING_IMPAIRMENT_ENABLED || '').trim().toLowerCase() === 'true');
  const impairmentController =
    options.impairmentController ?? new StagingImpairmentController(appMode, allowImpairment, getNowMs);

  router.use(createStructuredLoggerMiddleware({ appMode, store: structuredLogStore }));
  router.use(impairmentController.middleware());

  const resolveKioskVoiceCue = (
    statusCode: number,
    body: Record<string, unknown>
  ): string => {
    const code = typeof body.code === 'string' ? body.code : '';
    const action = typeof body.action === 'string' ? body.action.toLowerCase() : '';
    if (action === 'duplicate_ignored' || code === 'DUPLICATE_ACTION' || code === 'DUPLICATE_IGNORED') {
      return 'DUPLICATE_ALREADY_RECORDED';
    }
    if (statusCode === 200 || statusCode === 201) {
      if (action === 'time_in') return 'TIME_IN_RECORDED';
      if (action === 'break_out') return 'BREAK_OUT_RECORDED';
      if (action === 'break_in') return 'BREAK_IN_RECORDED';
      if (action === 'time_out') return 'TIME_OUT_RECORDED';
      if (action === 'overtime_out') return 'OVERTIME_OUT_RECORDED';
      return 'PUNCH_RECORDED';
    }
    if (body.escalated === true) return 'ESCALATED_TO_HR';
    return 'PUNCH_REJECTED';
  };

  const readNumericSetting = (key: string, fallback: number): number => {
    try {
      const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as { value: string } | undefined;
      const n = row ? Number(row.value) : NaN;
      return Number.isFinite(n) && n > 0 ? n : fallback;
    } catch {
      return fallback;
    }
  };

  const getHeartbeatThresholds = () => {
    const heartbeatTimeoutSec =
      options.heartbeatTimeoutSeconds ??
      readNumericSetting('device_heartbeat_timeout_sec', DEFAULT_HEARTBEAT_TIMEOUT_SECONDS);
    const staleWarningSec = Math.min(
      heartbeatTimeoutSec,
      options.staleWarningSeconds ??
        readNumericSetting('device_stale_warning_sec', DEFAULT_STALE_WARNING_SECONDS)
    );
    return { heartbeatTimeoutSec, staleWarningSec };
  };

  const broadcastDeviceTelemetryById = (deviceId: number) => {
    const row = db.prepare('SELECT * FROM devices WHERE id = ?').get(deviceId) as StoredDeviceRow | undefined;
    if (!row) return;
    const telemetry = computeDeviceTelemetry(row, getNowMs(), getHeartbeatThresholds());
    realtimeHub.emitDeviceTelemetry({
      device_id: telemetry.id,
      name: telemetry.name,
      status: telemetry.status,
      connectivity: telemetry.connectivity,
      last_heartbeat: telemetry.last_heartbeat,
      last_heartbeat_utc: telemetry.last_heartbeat_utc,
      last_sync_utc: telemetry.last_sync_utc,
      pending_queue_count: telemetry.pending_queue_count,
      stale_warning: telemetry.stale_warning,
      last_clock_drift_seconds: telemetry.last_clock_drift_seconds,
      last_sync_status: telemetry.last_sync_status,
      last_sync_error: telemetry.last_sync_error,
      is_revoked: telemetry.is_revoked,
    });
  };

  // =========================================================================
  // HEALTH & PUBLIC AUTH CONFIGURATION
  // =========================================================================
  router.get('/health', (_req, res) => {
    try {
      const dbCheck = db.prepare('SELECT 1 as ok').get() as { ok: number };
      const connected = dbCheck.ok === 1;
      if (!connected) {
        res.status(503).json({
          status: 'error',
          database: 'unavailable',
          code: 'DATABASE_UNAVAILABLE',
          version: '1.13.0',
          build: 'BUILD 17',
          timestamp: new Date(getNowMs()).toISOString(),
        });
        return;
      }
      const journalMode = String(db.pragma('journal_mode', { simple: true }));
      const foreignKeys = Number(db.pragma('foreign_keys', { simple: true })) === 1;
      const latestMig = db
        .prepare('SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1')
        .get() as { version: string } | undefined;
      const safeSize = (p: string): number => {
        if (db.memory || resolvedDbPath === ':memory:') return 0;
        try {
          return fs.existsSync(p) ? fs.statSync(p).size : 0;
        } catch {
          return 0;
        }
      };

      res.status(200).json({
        status: 'ok',
        database: 'connected',
        version: '1.13.0',
        build: 'BUILD 17',
        mode: appMode,
        timezone: 'Asia/Manila',
        journalMode,
        foreignKeys,
        schemaVersion: latestMig?.version ?? '000',
        dbFileBytes: safeSize(resolvedDbPath),
        walFileBytes: safeSize(`${resolvedDbPath}-wal`),
        realtimeClients: realtimeHub.clientCount(),
        uptimeSeconds: Math.floor(process.uptime()),
        requestId: res.locals.requestId ?? null,
        stagingImpairmentActive: impairmentController.getState(getNowMs()).enabled,
        timestamp: new Date(getNowMs()).toISOString(),
      });
    } catch (err) {
      res.status(503).json({
        status: 'error',
        database: 'unavailable',
        code: 'DATABASE_UNAVAILABLE',
        error: isDatabaseUnavailableError(err) ? 'Database connection unavailable.' : 'Health check failed.',
        version: '1.13.0',
        build: 'BUILD 17',
        timestamp: new Date(getNowMs()).toISOString(),
      });
    }
  });

  router.get('/auth/config', (_req, res) => {
    res.json({
      googleSsoConfigured: Boolean(process.env.GOOGLE_OAUTH_CLIENT_ID?.trim()),
      smtpConfigured: Boolean(process.env.SMTP_HOST?.trim()),
      passwordPolicy: {
        minLength: 10,
        requireUppercase: true,
        requireLowercase: true,
        requireDigit: true,
        requireSymbol: true,
      },
    });
  });

  router.post('/auth/login', loginRateLimiter.middleware((req) => getClientIp(req)), (req, res) => {
    if (!isRequestOriginAllowed(req)) {
      res.status(403).json({ error: 'Cross-origin login request rejected.', code: 'ORIGIN_DENIED' });
      return;
    }

    const { identifier, password, rememberMe } = (req.body || {}) as {
      identifier?: string;
      password?: string;
      rememberMe?: boolean;
    };

    if (typeof identifier !== 'string' || typeof password !== 'string' || !identifier.trim() || !password) {
      res.status(400).json({ error: 'Username/email and password are required.' });
      return;
    }

    const cleanIdentifier = identifier.trim();
    const clientIp = getClientIp(req);

    // Session fixation defense: immediately revoke any pre-existing session cookie sent with login
    const existingCookies = parseCookies(req.headers.cookie);
    const priorCookie = verifySignedSessionCookie(existingCookies[SESSION_COOKIE_NAME]);
    if (priorCookie) {
      revokeSessionById(db, priorCookie.sid, 'rotated_on_login');
    }

    const user = db
      .prepare(
        `SELECT u.*
         FROM users u
         LEFT JOIN employees e ON e.id = u.employee_id
         WHERE lower(u.username) = lower(?)
            OR lower(u.email) = lower(?)
            OR lower(e.employee_code) = lower(?)`
      )
      .get(cleanIdentifier, cleanIdentifier, cleanIdentifier) as
      | {
          id: number;
          username: string;
          email: string;
          full_name: string;
          role: RoleName;
          department_id: number | null;
          employee_id: number | null;
          password_hash: string;
          salt: string;
          must_change_password: number;
          is_active: number;
          failed_login_attempts: number;
          locked_until: string | null;
        }
      | undefined;

    if (!user) {
      logAudit(db, cleanIdentifier, 'Failed login attempt (unknown account)', 'Authentication', 'Warning', clientIp);
      res.status(401).json({ error: 'Invalid username/email or password.' });
      return;
    }

    if (user.is_active !== 1) {
      logAudit(db, user.username, 'Blocked login attempt for deactivated account', 'Authentication', 'Warning', clientIp);
      res.status(403).json({ error: 'This user account has been deactivated. Contact RSU Cajidiocan MIS.' });
      return;
    }

    // Check active account brute-force lockout
    if (user.locked_until) {
      const lockedUntilMs = Date.parse(user.locked_until);
      if (!Number.isNaN(lockedUntilMs) && lockedUntilMs > Date.now()) {
        const retryAfterSec = Math.max(1, Math.ceil((lockedUntilMs - Date.now()) / 1000));
        res.setHeader('Retry-After', String(retryAfterSec));
        logAudit(db, user.username, 'Blocked login attempt while account locked out', 'Authentication', 'Warning', clientIp);
        res.status(429).json({
          error: `Account temporarily locked due to repeated failed sign-in attempts. Try again in ${Math.ceil(retryAfterSec / 60)} minute(s).`,
          code: 'ACCOUNT_LOCKED',
          retryAfterSeconds: retryAfterSec,
        });
        return;
      }
      // Lockout expired — reset counters before verifying
      db.prepare('UPDATE users SET failed_login_attempts = 0, locked_until = NULL WHERE id = ?').run(user.id);
      user.failed_login_attempts = 0;
    }

    if (!verifyPassword(password, user.password_hash, user.salt)) {
      const nextAttempts = (user.failed_login_attempts || 0) + 1;
      if (nextAttempts >= maxFailedAttempts) {
        const lockUntilIso = new Date(Date.now() + lockoutMinutes * 60 * 1000).toISOString();
        db.prepare('UPDATE users SET failed_login_attempts = ?, locked_until = ? WHERE id = ?').run(
          nextAttempts,
          lockUntilIso,
          user.id
        );
        logAudit(
          db,
          user.username,
          `Account locked for ${lockoutMinutes}m after ${nextAttempts} failed login attempts`,
          'Authentication',
          'Error',
          clientIp
        );
        res.setHeader('Retry-After', String(lockoutMinutes * 60));
        res.status(429).json({
          error: `Too many failed sign-in attempts. Account locked for ${lockoutMinutes} minutes.`,
          code: 'ACCOUNT_LOCKED',
          retryAfterSeconds: lockoutMinutes * 60,
        });
        return;
      }

      db.prepare('UPDATE users SET failed_login_attempts = ? WHERE id = ?').run(nextAttempts, user.id);
      logAudit(
        db,
        user.username,
        `Failed login attempt (${nextAttempts}/${maxFailedAttempts})`,
        'Authentication',
        'Warning',
        clientIp
      );
      res.status(401).json({ error: 'Invalid username/email or password.' });
      return;
    }

    // Valid credentials: reset lockout counters & mint fresh server-backed session
    db.prepare('UPDATE users SET failed_login_attempts = 0, locked_until = NULL WHERE id = ?').run(user.id);

    const createdSession = createUserSession(db, user.id, {
      rememberMe: Boolean(rememberMe),
      ipAddress: clientIp,
      userAgent: typeof req.headers['user-agent'] === 'string' ? req.headers['user-agent'] : '',
    });

    setAuthCookies(res, createdSession.signedCookieValue, createdSession.csrfToken, createdSession.expiresAt, req);
    logAudit(
      db,
      user.username,
      `Signed in to SAVAGE-RSUCAJ Portal (role: ${user.role})`,
      'Authentication',
      'Success',
      clientIp
    );

    const perms = (
      db
        .prepare('SELECT permission_code FROM role_permissions WHERE role_name = ? ORDER BY permission_code ASC')
        .all(user.role) as Array<{ permission_code: PermissionCode }>
    ).map((r) => r.permission_code);

    // Note: Raw session token is intentionally NOT returned in JSON (HttpOnly cookie only)
    res.json({
      csrfToken: createdSession.csrfToken,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        full_name: user.full_name,
        role: user.role,
        department_id: user.department_id ?? null,
        employee_id: user.employee_id ?? null,
        must_change_password: Boolean(user.must_change_password),
        permissions: perms,
      },
    });
  });

  router.post('/auth/forgot-password', (req, res) => {
    const smtpConfigured = Boolean(process.env.SMTP_HOST?.trim());
    if (!smtpConfigured) {
      logAudit(
        db,
        typeof req.body?.email === 'string' && req.body.email.trim() ? req.body.email.trim() : 'anonymous',
        'Attempted password reset while outbound SMTP is not configured',
        'Authentication',
        'Warning',
        getClientIp(req)
      );
      res.status(503).json({
        smtpConfigured: false,
        error:
          'Self-service password reset via email is disabled because outbound SMTP is not configured. Contact RSU Cajidiocan MIS to run local account recovery (`npm run admin:recover`).',
      });
      return;
    }

    res.status(501).json({
      smtpConfigured: false,
      error: 'SMTP mail transport integration is not yet installed in BUILD 05.',
    });
  });

  // BUILD 18: Android contract adapter using the SAME canonical attendance engine.
  registerAndroidBridgeRoutes(router, {
    db: () => db,
    findDevice: (token) => findDeviceByToken(db, token),
    nowMs: getNowMs,
    realtimeHub,
    rateLimit: kioskRateLimiter.middleware((req) => getClientIp(req)),
  });

  // BUILD 36: Web Face Recognition Kiosk endpoints (HttpOnly device session + single-use challenges)
  registerWebKioskPublicRoutes(router, {
    db: () => db,
    appMode,
    nowMs: getNowMs,
    realtimeHub,
    broadcastDeviceTelemetryById,
    rateLimit: kioskRateLimiter.middleware((req) => getClientIp(req)),
  });

  // =========================================================================
  // PUBLIC KIOSK DEVICE ENDPOINTS (Token-Authenticated ONLY; Kiosk Device role)
  // =========================================================================
  router.post('/kiosk/heartbeat', kioskRateLimiter.middleware((req) => getClientIp(req)), (req, res) => {
    const token = typeof req.headers['x-kiosk-token'] === 'string' ? req.headers['x-kiosk-token'].trim() : '';
    if (!token) {
      res.status(401).json({ error: 'Missing kiosk API token header (x-kiosk-token).', code: 'MISSING_TOKEN' });
      return;
    }
    const device = findDeviceByToken(db, token);
    if (!device) {
      logAudit(db, 'kiosk-unknown', 'Rejected kiosk heartbeat with invalid token', 'Devices', 'Warning', getClientIp(req));
      res.status(403).json({ error: 'Invalid kiosk API token.', code: 'INVALID_TOKEN' });
      return;
    }
    if (device.is_revoked === 1) {
      logAudit(db, device.name, 'Rejected heartbeat from revoked kiosk device', 'Devices', 'Warning', getClientIp(req));
      res.status(403).json({ error: 'Kiosk device credentials have been revoked.', code: 'DEVICE_REVOKED' });
      return;
    }

    const {
      device_timestamp,
      device_boot_id,
      pending_queue_count,
      last_monotonic_seq,
      last_sync_error,
    } = (req.body || {}) as {
      device_timestamp?: string;
      device_boot_id?: string;
      pending_queue_count?: number;
      last_monotonic_seq?: number;
      last_sync_error?: string;
    };

    const nowMs = getNowMs();
    const serverIso = new Date(nowMs).toISOString();
    const manila = toManilaParts(nowMs);
    const displayHeartbeat = `${manila.isoDate} ${manila.time24}`;

    let clockDriftSeconds: number | null = device.last_clock_drift_seconds;
    if (typeof device_timestamp === 'string' && device_timestamp.trim()) {
      const parsed = parseExplicitIsoTimestampToUtcMs(device_timestamp);
      if (parsed !== null) {
        clockDriftSeconds = Math.round((parsed - nowMs) / 1000);
      }
    }

    const safeQueueCount =
      typeof pending_queue_count === 'number' && Number.isFinite(pending_queue_count)
        ? Math.max(0, Math.floor(pending_queue_count))
        : device.pending_queue_count;
    const safeSeq =
      typeof last_monotonic_seq === 'number' && Number.isFinite(last_monotonic_seq) && last_monotonic_seq >= 0
        ? Math.max(device.last_monotonic_seq, Math.floor(last_monotonic_seq))
        : device.last_monotonic_seq;
    const safeBootId =
      typeof device_boot_id === 'string' && device_boot_id.trim()
        ? device_boot_id.trim().slice(0, 80)
        : device.device_boot_id;
    const safeError =
      typeof last_sync_error === 'string' ? last_sync_error.trim().slice(0, 240) : device.last_sync_error;

    db.prepare(
      `UPDATE devices
       SET status = 'Online',
           last_heartbeat = ?,
           last_heartbeat_utc = ?,
           pending_queue_count = ?,
           last_clock_drift_seconds = ?,
           last_monotonic_seq = ?,
           device_boot_id = ?,
           last_sync_error = ?,
           offline_alert_state = 'NONE',
           last_alerted_at_utc = NULL
       WHERE id = ?`
    ).run(
      displayHeartbeat,
      serverIso,
      safeQueueCount,
      clockDriftSeconds,
      safeSeq,
      safeBootId,
      safeError,
      device.id
    );

    broadcastDeviceTelemetryById(device.id);
    const thresholds = getHeartbeatThresholds();
    res.json({
      ok: true,
      device: device.name,
      timestamp: serverIso,
      clock_drift_seconds: clockDriftSeconds,
      heartbeat_timeout_seconds: thresholds.heartbeatTimeoutSec,
      stale_warning_seconds: thresholds.staleWarningSec,
      pending_queue_count: safeQueueCount,
    });
  });

  router.post('/kiosk/punch', kioskRateLimiter.middleware((req) => getClientIp(req)), (req, res) => {
    const token = typeof req.headers['x-kiosk-token'] === 'string' ? req.headers['x-kiosk-token'].trim() : '';
    const {
      employee_code,
      punch_type,
      action,
      punch_time,
      event_uid,
      idempotency_key,
      device_timestamp,
      offline_replay,
      monotonic_seq,
      device_boot_id,
      biometric_evidence,
    } = (req.body || {}) as {
      employee_code?: string;
      punch_type?: string;
      action?: string;
      punch_time?: string;
      event_uid?: string;
      idempotency_key?: string;
      device_timestamp?: string;
      offline_replay?: boolean;
      monotonic_seq?: number;
      device_boot_id?: string;
      biometric_evidence?: unknown;
    };

    if (!token) {
      res.status(401).json({ error: 'Missing kiosk API token header (x-kiosk-token).', code: 'MISSING_TOKEN' });
      return;
    }
    const device = findDeviceByToken(db, token);
    if (!device) {
      logAudit(db, 'kiosk-unknown', 'Rejected kiosk punch with invalid token', 'Devices', 'Warning', getClientIp(req));
      res.status(403).json({ error: 'Invalid kiosk API token.', code: 'INVALID_TOKEN' });
      return;
    }
    if (device.is_revoked === 1) {
      logAudit(db, device.name, 'Rejected punch from revoked kiosk device', 'Devices', 'Warning', getClientIp(req));
      res.status(403).json({ error: 'Kiosk device credentials have been revoked.', code: 'DEVICE_REVOKED' });
      return;
    }
    if (!employee_code || typeof employee_code !== 'string' || !employee_code.trim()) {
      res.status(400).json({ error: 'employee_code is required.', code: 'EMPLOYEE_CODE_REQUIRED' });
      return;
    }

    const headerIdempotency =
      typeof req.headers['x-idempotency-key'] === 'string' ? req.headers['x-idempotency-key'].trim() : undefined;
    const resolvedEventUid = event_uid || idempotency_key || headerIdempotency;
    const normalizedAction = normalizeAttendanceAction(punch_type ?? action);

    let biometricEvidenceHash: string | null = null;
    let biometricBound = false;
    let captureMetadataJson: string | null = null;

    if (biometric_evidence !== undefined && biometric_evidence !== null) {
      if (!resolvedEventUid || !normalizedAction || typeof device_timestamp !== 'string' || !device_timestamp.trim()) {
        res.status(422).json({
          error: 'biometric_evidence requires explicit event_uid, punch_type, and device_timestamp.',
          code: 'BIOMETRIC_EVIDENCE_INVALID',
        });
        return;
      }
      const verification = verifyBiometricEvidenceEnvelope(
        device.api_token,
        {
          deviceId: device.id,
          eventUid: resolvedEventUid,
          employeeCode: employee_code.trim(),
          punchType: normalizedAction,
          capturedAtUtc: device_timestamp,
          monotonicSeq: typeof monotonic_seq === 'number' ? monotonic_seq : undefined,
          deviceBootId: typeof device_boot_id === 'string' ? device_boot_id : undefined,
        },
        biometric_evidence
      );
      if (!verification.valid) {
        logAudit(
          db,
          device.name,
          `Rejected kiosk punch with invalid biometric evidence binding: ${verification.reason}`,
          'Attendance',
          'Warning',
          getClientIp(req)
        );
        res.status(422).json({
          error: verification.reason || 'Biometric evidence cryptographic binding verification failed.',
          code: 'BIOMETRIC_EVIDENCE_INVALID',
          event_uid: resolvedEventUid,
        });
        return;
      }
      biometricEvidenceHash = verification.evidenceHash ?? null;
      biometricBound = true;
      captureMetadataJson = JSON.stringify({
        device_id: device.id,
        device_boot_id: device_boot_id ?? null,
        monotonic_seq: monotonic_seq ?? null,
        captured_at_utc: device_timestamp,
      });
    }

    const maxClockDriftSeconds =
      options.maxClockDriftSeconds ?? readNumericSetting('kiosk_max_clock_drift_sec', DEFAULT_MAX_CLOCK_DRIFT_SECONDS);
    const maxOfflineReplayHours =
      options.maxOfflineReplayHours ??
      readNumericSetting('kiosk_offline_replay_max_hours', DEFAULT_MAX_OFFLINE_REPLAY_HOURS);

    const nowMs = getNowMs();
    const outcome = processKioskPunch(db, {
      device,
      employeeCode: employee_code.trim(),
      actionRaw: punch_type ?? action,
      eventUid: resolvedEventUid,
      deviceTimestamp: typeof device_timestamp === 'string' ? device_timestamp : undefined,
      offlineReplay: offline_replay === true,
      untrustedClientPunchTime: typeof punch_time === 'string' ? punch_time : undefined,
      clientIp: getClientIp(req),
      serverNowUtc: nowMs,
      maxClockDriftSeconds,
      maxOfflineReplayHours,
      monotonicSeq: typeof monotonic_seq === 'number' ? monotonic_seq : undefined,
      deviceBootId: typeof device_boot_id === 'string' ? device_boot_id : undefined,
      biometricEvidenceHash,
      biometricBound,
      captureMetadataJson,
    });

    if (outcome.statusCode === 200 || outcome.statusCode === 201) {
      db.prepare(`UPDATE devices SET last_sync_utc = ?, last_sync_status = 'Synced', last_sync_error = '' WHERE id = ?`).run(
        new Date(nowMs).toISOString(),
        device.id
      );
      if (outcome.body.action !== 'duplicate_ignored' && typeof outcome.body.employee_id === 'number') {
        realtimeHub.emitAttendanceUpdated({
          event_uid: String(outcome.body.event_uid || ''),
          employee_id: outcome.body.employee_id,
          employee_code: employee_code.trim(),
          department_id:
            typeof outcome.body.department_id === 'number' ? outcome.body.department_id : null,
          shift_date: String(outcome.body.shift_date || ''),
          action: String(outcome.body.action || ''),
          status: typeof outcome.body.status === 'string' ? outcome.body.status : undefined,
          time: typeof outcome.body.time === 'string' ? outcome.body.time : null,
          source: offline_replay ? 'kiosk_offline' : 'kiosk',
          offline_replay: offline_replay === true,
        });
      }
      broadcastDeviceTelemetryById(device.id);
    }

    const voiceCue = resolveKioskVoiceCue(outcome.statusCode, outcome.body as Record<string, unknown>);
    res.status(outcome.statusCode).json({
      ...outcome.body,
      backend_confirmed: true,
      voice_cue: voiceCue,
      request_id: res.locals.requestId ?? null,
    });
  });

  // BUILD 10: Idempotent Encrypted Offline Batch Sync Endpoint with Cryptographic Biometric Binding
  router.post('/kiosk/sync', kioskRateLimiter.middleware((req) => getClientIp(req)), (req, res) => {
    const token = typeof req.headers['x-kiosk-token'] === 'string' ? req.headers['x-kiosk-token'].trim() : '';
    if (!token) {
      res.status(401).json({ error: 'Missing kiosk API token header (x-kiosk-token).', code: 'MISSING_TOKEN' });
      return;
    }
    const device = findDeviceByToken(db, token);
    if (!device) {
      logAudit(db, 'kiosk-unknown', 'Rejected kiosk sync batch with invalid token', 'Devices', 'Warning', getClientIp(req));
      res.status(403).json({ error: 'Invalid kiosk API token.', code: 'INVALID_TOKEN' });
      return;
    }
    if (device.is_revoked === 1) {
      logAudit(db, device.name, 'Rejected sync batch from revoked kiosk device', 'Devices', 'Warning', getClientIp(req));
      res.status(403).json({ error: 'Kiosk device credentials have been revoked.', code: 'DEVICE_REVOKED' });
      return;
    }

    interface IncomingSyncEvent {
      event_uid?: string;
      monotonic_seq?: number;
      device_boot_id?: string;
      employee_code?: string;
      punch_type?: string;
      action?: string;
      device_timestamp?: string;
      offline_replay?: boolean;
      biometric_evidence?: unknown;
    }

    const {
      batch_uid,
      device_boot_id,
      device_timestamp,
      pending_queue_count,
      events,
    } = (req.body || {}) as {
      batch_uid?: string;
      device_boot_id?: string;
      device_timestamp?: string;
      pending_queue_count?: number;
      events?: IncomingSyncEvent[];
    };

    if (!Array.isArray(events) || events.length === 0) {
      res.status(400).json({ error: 'events array with at least one event is required.', code: 'EMPTY_SYNC_BATCH' });
      return;
    }

    const maxBatchSize = readNumericSetting('kiosk_sync_max_batch_size', DEFAULT_SYNC_MAX_BATCH_SIZE);
    if (events.length > maxBatchSize) {
      res.status(400).json({
        error: `Batch exceeds maximum allowed size (${maxBatchSize} events).`,
        code: 'BATCH_TOO_LARGE',
        max_batch_size: maxBatchSize,
      });
      return;
    }

    const nowMs = getNowMs();
    const receivedAtUtc = new Date(nowMs).toISOString();
    const manilaNow = toManilaParts(nowMs);
    const resolvedBatchUid =
      typeof batch_uid === 'string' && batch_uid.trim()
        ? batch_uid.trim().slice(0, 128)
        : `batch-${device.id}-${nowMs}-${crypto.randomBytes(4).toString('hex')}`;
    const batchBootId =
      typeof device_boot_id === 'string' && device_boot_id.trim()
        ? device_boot_id.trim().slice(0, 80)
        : device.device_boot_id;

    let batchClockDrift: number | null = device.last_clock_drift_seconds;
    if (typeof device_timestamp === 'string' && device_timestamp.trim()) {
      const parsed = parseExplicitIsoTimestampToUtcMs(device_timestamp);
      if (parsed !== null) {
        batchClockDrift = Math.round((parsed - nowMs) / 1000);
      }
    }

    const maxClockDriftSeconds =
      options.maxClockDriftSeconds ?? readNumericSetting('kiosk_max_clock_drift_sec', DEFAULT_MAX_CLOCK_DRIFT_SECONDS);
    const maxOfflineReplayHours =
      options.maxOfflineReplayHours ??
      readNumericSetting('kiosk_offline_replay_max_hours', DEFAULT_MAX_OFFLINE_REPLAY_HOURS);

    // Prepare indexed items and sort valid chronologically-ordered items so out-of-order
    // punches within the same outage batch reconcile cleanly without corrupting shifts.
    const indexed = events.map((ev, idx) => {
      const parsedTs = parseExplicitIsoTimestampToUtcMs(ev.device_timestamp);
      const normAct = normalizeAttendanceAction(ev.punch_type ?? ev.action);
      return {
        originalIndex: idx,
        ev,
        parsedTs: parsedTs ?? Number.MAX_SAFE_INTEGER,
        seq: typeof ev.monotonic_seq === 'number' && Number.isInteger(ev.monotonic_seq) ? ev.monotonic_seq : Number.MAX_SAFE_INTEGER,
        actionRank: normAct ? ACTION_SORT_RANK[normAct] ?? 99 : 99,
      };
    });

    const ordered = [...indexed].sort((a, b) => {
      if (a.parsedTs !== b.parsedTs) return a.parsedTs - b.parsedTs;
      if (a.seq !== b.seq) return a.seq - b.seq;
      if (a.actionRank !== b.actionRank) return a.actionRank - b.actionRank;
      return a.originalIndex - b.originalIndex;
    });

    interface BatchAckItem {
      event_uid: string;
      monotonic_seq: number | null;
      outcome: 'ACCEPTED' | 'DUPLICATE_IGNORED' | 'CONFLICT_PRESERVED' | 'ESCALATED' | 'REJECTED';
      code: string;
      status_code: number;
      shift_date?: string;
      attendance_status?: string;
      message?: string;
    }

    const resultsByIndex = new Map<number, BatchAckItem>();
    const acceptedForRealtime: Array<{
      event_uid: string;
      employee_id: number;
      employee_code: string;
      department_id: number | null;
      shift_date: string;
      action: string;
      status?: string;
      time: string | null;
      offline_replay: boolean;
    }> = [];

    let acceptedCount = 0;
    let duplicateCount = 0;
    let conflictCount = 0;
    let rejectedCount = 0;
    let escalatedCount = 0;
    let highestSeq = device.last_monotonic_seq;
    let firstError = '';
    const clientIp = getClientIp(req);

    for (const item of ordered) {
      const ev = item.ev;
      const evUid = typeof ev.event_uid === 'string' ? ev.event_uid.trim().slice(0, 128) : '';
      const evSeq =
        typeof ev.monotonic_seq === 'number' && Number.isInteger(ev.monotonic_seq) && ev.monotonic_seq > 0
          ? ev.monotonic_seq
          : null;
      const evBootId =
        typeof ev.device_boot_id === 'string' && ev.device_boot_id.trim()
          ? ev.device_boot_id.trim().slice(0, 80)
          : batchBootId;
      const evEmployeeCode = typeof ev.employee_code === 'string' ? ev.employee_code.trim() : '';
      const evAction = normalizeAttendanceAction(ev.punch_type ?? ev.action);
      const isOfflineReplay = ev.offline_replay !== false;

      if (!evUid) {
        rejectedCount += 1;
        firstError = firstError || 'EVENT_UID_REQUIRED';
        resultsByIndex.set(item.originalIndex, {
          event_uid: '',
          monotonic_seq: evSeq,
          outcome: 'REJECTED',
          code: 'EVENT_UID_REQUIRED',
          status_code: 400,
          message: 'Every synced kiosk event requires a unique event_uid.',
        });
        continue;
      }

      if (!evEmployeeCode || !evAction) {
        rejectedCount += 1;
        firstError = firstError || (!evEmployeeCode ? 'EMPLOYEE_CODE_REQUIRED' : 'INVALID_ACTION');
        resultsByIndex.set(item.originalIndex, {
          event_uid: evUid,
          monotonic_seq: evSeq,
          outcome: 'REJECTED',
          code: !evEmployeeCode ? 'EMPLOYEE_CODE_REQUIRED' : 'INVALID_ACTION',
          status_code: 400,
          message: !evEmployeeCode ? 'employee_code is required.' : 'Explicit valid punch_type is required.',
        });
        continue;
      }

      // Check idempotency BEFORE biometric check so re-sent already-acknowledged events stay cleanly idempotent
      const alreadyRecorded = db
        .prepare('SELECT event_uid, attendance_date, decision, decision_code, punch_time FROM attendance_events WHERE event_uid = ?')
        .get(evUid) as
        | { event_uid: string; attendance_date: string; decision: string; decision_code: string; punch_time: string }
        | undefined;
      if (alreadyRecorded) {
        duplicateCount += 1;
        resultsByIndex.set(item.originalIndex, {
          event_uid: evUid,
          monotonic_seq: evSeq,
          outcome: 'DUPLICATE_IGNORED',
          code: 'DUPLICATE_IGNORED',
          status_code: 200,
          shift_date: alreadyRecorded.attendance_date,
          message: `Duplicate event_uid ignored (original decision: ${alreadyRecorded.decision}/${alreadyRecorded.decision_code}).`,
        });
        continue;
      }

      // STRICT BUILD 10 POLICY: Offline-queued batch sync events MUST carry cryptographically bound biometric_evidence
      if (isOfflineReplay) {
        if (!ev.biometric_evidence || typeof ev.biometric_evidence !== 'object') {
          rejectedCount += 1;
          firstError = firstError || 'BIOMETRIC_EVIDENCE_REQUIRED';
          logAudit(
            db,
            device.name,
            `Rejected offline sync event ${evUid} (${evEmployeeCode}): missing cryptographic biometric_evidence binding`,
            'Attendance',
            'Warning',
            clientIp
          );
          resultsByIndex.set(item.originalIndex, {
            event_uid: evUid,
            monotonic_seq: evSeq,
            outcome: 'REJECTED',
            code: 'BIOMETRIC_EVIDENCE_REQUIRED',
            status_code: 422,
            message: 'Offline replay events in /api/kiosk/sync require cryptographically bound biometric_evidence.',
          });
          continue;
        }
        if (typeof ev.device_timestamp !== 'string' || !ev.device_timestamp.trim()) {
          rejectedCount += 1;
          firstError = firstError || 'INVALID_OFFLINE_TIMESTAMP';
          resultsByIndex.set(item.originalIndex, {
            event_uid: evUid,
            monotonic_seq: evSeq,
            outcome: 'REJECTED',
            code: 'INVALID_OFFLINE_TIMESTAMP',
            status_code: 400,
            message: 'Offline replay events require an explicit ISO-8601 device_timestamp.',
          });
          continue;
        }
      }

      let evidenceHash: string | null = null;
      let biometricBound = false;
      if (ev.biometric_evidence !== undefined && ev.biometric_evidence !== null) {
        const verification = verifyBiometricEvidenceEnvelope(
          device.api_token,
          {
            deviceId: device.id,
            eventUid: evUid,
            employeeCode: evEmployeeCode,
            punchType: evAction,
            capturedAtUtc: String(ev.device_timestamp || ''),
            monotonicSeq: evSeq ?? undefined,
            deviceBootId: evBootId || undefined,
          },
          ev.biometric_evidence
        );
        if (!verification.valid) {
          rejectedCount += 1;
          firstError = firstError || 'BIOMETRIC_EVIDENCE_INVALID';
          logAudit(
            db,
            device.name,
            `Rejected tampered/unbound sync event ${evUid} (${evEmployeeCode}): ${verification.reason}`,
            'Attendance',
            'Warning',
            clientIp
          );
          resultsByIndex.set(item.originalIndex, {
            event_uid: evUid,
            monotonic_seq: evSeq,
            outcome: 'REJECTED',
            code: 'BIOMETRIC_EVIDENCE_INVALID',
            status_code: 422,
            message: verification.reason || 'Biometric evidence cryptographic binding failed.',
          });
          continue;
        }
        evidenceHash = verification.evidenceHash ?? null;
        biometricBound = true;
      }

      // Log monotonic sequence regression anomaly on same boot session (never drops audit trail)
      if (evSeq !== null && evBootId && evBootId === device.device_boot_id && evSeq <= device.last_monotonic_seq) {
        logAudit(
          db,
          device.name,
          `Monotonic sequence regression observed on boot ${evBootId}: seq ${evSeq} <= last ${device.last_monotonic_seq} (event ${evUid})`,
          'Devices',
          'Warning',
          clientIp
        );
      }
      if (evSeq !== null && evSeq > highestSeq) {
        highestSeq = evSeq;
      }

      const outcome = processKioskPunch(db, {
        device,
        employeeCode: evEmployeeCode,
        actionRaw: evAction,
        eventUid: evUid,
        deviceTimestamp: typeof ev.device_timestamp === 'string' ? ev.device_timestamp : undefined,
        offlineReplay: isOfflineReplay,
        clientIp,
        serverNowUtc: nowMs,
        maxClockDriftSeconds,
        maxOfflineReplayHours,
        monotonicSeq: evSeq ?? undefined,
        deviceBootId: evBootId || undefined,
        biometricEvidenceHash: evidenceHash,
        biometricBound,
        captureMetadataJson: JSON.stringify({
          batch_uid: resolvedBatchUid,
          device_id: device.id,
          device_boot_id: evBootId || null,
          monotonic_seq: evSeq,
          captured_at_utc: ev.device_timestamp ?? null,
        }),
      });

      if ((outcome.statusCode === 200 || outcome.statusCode === 201) && outcome.body.action === 'duplicate_ignored') {
        duplicateCount += 1;
        resultsByIndex.set(item.originalIndex, {
          event_uid: evUid,
          monotonic_seq: evSeq,
          outcome: 'DUPLICATE_IGNORED',
          code: 'DUPLICATE_IGNORED',
          status_code: 200,
          shift_date: typeof outcome.body.shift_date === 'string' ? outcome.body.shift_date : undefined,
          message: 'Duplicate event_uid ignored.',
        });
      } else if (outcome.statusCode === 200 || outcome.statusCode === 201) {
        acceptedCount += 1;
        resultsByIndex.set(item.originalIndex, {
          event_uid: evUid,
          monotonic_seq: evSeq,
          outcome: 'ACCEPTED',
          code: 'OK',
          status_code: outcome.statusCode,
          shift_date: typeof outcome.body.shift_date === 'string' ? outcome.body.shift_date : undefined,
          attendance_status: typeof outcome.body.status === 'string' ? outcome.body.status : undefined,
          message: `${String(outcome.body.action)} accepted at ${String(outcome.body.time || '')}`,
        });
        if (typeof outcome.body.employee_id === 'number') {
          acceptedForRealtime.push({
            event_uid: evUid,
            employee_id: outcome.body.employee_id,
            employee_code: evEmployeeCode,
            department_id: typeof outcome.body.department_id === 'number' ? outcome.body.department_id : null,
            shift_date: String(outcome.body.shift_date || ''),
            action: String(outcome.body.action || evAction),
            status: typeof outcome.body.status === 'string' ? outcome.body.status : undefined,
            time: typeof outcome.body.time === 'string' ? outcome.body.time : null,
            offline_replay: isOfflineReplay,
          });
        }
      } else if (outcome.body.conflict_preserved === true) {
        conflictCount += 1;
        resultsByIndex.set(item.originalIndex, {
          event_uid: evUid,
          monotonic_seq: evSeq,
          outcome: 'CONFLICT_PRESERVED',
          code: String(outcome.body.code || 'CONFLICT_PRESERVED'),
          status_code: outcome.statusCode,
          shift_date: typeof outcome.body.shift_date === 'string' ? outcome.body.shift_date : undefined,
          message: String(outcome.body.error || 'Verified original punch preserved.'),
        });
      } else if (outcome.body.escalated === true) {
        escalatedCount += 1;
        resultsByIndex.set(item.originalIndex, {
          event_uid: evUid,
          monotonic_seq: evSeq,
          outcome: 'ESCALATED',
          code: String(outcome.body.code || 'ESCALATED'),
          status_code: outcome.statusCode,
          shift_date: typeof outcome.body.shift_date === 'string' ? outcome.body.shift_date : undefined,
          message: String(outcome.body.error || 'Escalated to HR for review.'),
        });
      } else {
        rejectedCount += 1;
        const code = String(outcome.body.code || 'REJECTED');
        firstError = firstError || code;
        resultsByIndex.set(item.originalIndex, {
          event_uid: evUid,
          monotonic_seq: evSeq,
          outcome: 'REJECTED',
          code,
          status_code: outcome.statusCode,
          shift_date: typeof outcome.body.shift_date === 'string' ? outcome.body.shift_date : undefined,
          message: String(outcome.body.error || 'Event rejected.'),
        });
      }
    }

    const orderedResults: BatchAckItem[] = events.map((_, idx) => resultsByIndex.get(idx)!);
    const syncStatus =
      rejectedCount === 0 && escalatedCount === 0 && conflictCount === 0
        ? 'Synced'
        : acceptedCount > 0 || duplicateCount > 0
          ? 'Partial'
          : 'Error';
    const syncErrorSummary =
      rejectedCount > 0 || conflictCount > 0 || escalatedCount > 0
        ? `rejected=${rejectedCount}, conflicts=${conflictCount}, escalated=${escalatedCount}${firstError ? ` (${firstError})` : ''}`
        : '';

    const safeRemainingQueue =
      typeof pending_queue_count === 'number' && Number.isFinite(pending_queue_count)
        ? Math.max(0, Math.floor(pending_queue_count))
        : 0;
    const displayHeartbeat = `${manilaNow.isoDate} ${manilaNow.time24}`;

    db.prepare(
      `UPDATE devices
       SET status = 'Online',
           last_heartbeat = ?,
           last_heartbeat_utc = ?,
           last_sync_utc = ?,
           pending_queue_count = ?,
           last_clock_drift_seconds = COALESCE(?, last_clock_drift_seconds),
           last_monotonic_seq = CASE WHEN ? > last_monotonic_seq THEN ? ELSE last_monotonic_seq END,
           device_boot_id = CASE WHEN ? != '' THEN ? ELSE device_boot_id END,
           last_sync_status = ?,
           last_sync_error = ?,
           offline_alert_state = 'NONE',
           last_alerted_at_utc = NULL
       WHERE id = ?`
    ).run(
      displayHeartbeat,
      receivedAtUtc,
      receivedAtUtc,
      safeRemainingQueue,
      batchClockDrift,
      highestSeq,
      highestSeq,
      batchBootId,
      batchBootId,
      syncStatus,
      syncErrorSummary,
      device.id
    );

    db.prepare(
      `INSERT OR IGNORE INTO kiosk_sync_batches
        (batch_uid, device_id, device_name, device_boot_id, received_at_utc, total_events,
         accepted_count, duplicate_count, conflict_count, rejected_count, escalated_count, error_summary)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      resolvedBatchUid,
      device.id,
      device.name,
      batchBootId,
      receivedAtUtc,
      events.length,
      acceptedCount,
      duplicateCount,
      conflictCount,
      rejectedCount,
      escalatedCount,
      syncErrorSummary
    );

    logAudit(
      db,
      device.name,
      `Synced kiosk batch ${resolvedBatchUid}: total=${events.length}, accepted=${acceptedCount}, duplicate=${duplicateCount}, conflict_preserved=${conflictCount}, escalated=${escalatedCount}, rejected=${rejectedCount}`,
      'Devices',
      rejectedCount > 0 || conflictCount > 0 ? 'Warning' : 'Success',
      clientIp,
      {
        actionType: 'KIOSK_SYNC_BATCH',
        targetType: 'device',
        targetId: device.id,
        after: {
          batch_uid: resolvedBatchUid,
          sync_status: syncStatus,
          acceptedCount,
          rejectedCount,
          conflictCount,
          escalatedCount,
        },
        isSecurityEvent: rejectedCount > 0 || conflictCount > 0,
      }
    );

    // Explicitly alert on sync errors/rejections/conflicts; NEVER emit a false 'successful sync' message
    if (rejectedCount > 0 || conflictCount > 0 || syncStatus !== 'Synced') {
      createTargetedNotification(db, realtimeHub, {
        title: `${device.name} sync batch reported ${syncStatus} status`,
        message: `Batch ${resolvedBatchUid} completed with ${rejectedCount} rejected, ${conflictCount} conflicts, ${escalatedCount} escalated (${acceptedCount} accepted). ${syncErrorSummary}`,
        category: 'Device Alerts',
        priority: rejectedCount > 0 ? 'High' : 'Medium',
        actionModule: 'devices',
        actionEntityId: device.id,
        targetRoles: ['Administrator', 'HR Officer'],
        eventType: 'kiosk_sync_failure',
        metadata: { batch_uid: resolvedBatchUid, syncStatus, rejectedCount, conflictCount, escalatedCount },
        createdAt: formatManilaDateTime(nowMs),
      });
    }

    // Emit authorized real-time deltas
    for (const ev of acceptedForRealtime) {
      realtimeHub.emitAttendanceUpdated({
        event_uid: ev.event_uid,
        employee_id: ev.employee_id,
        employee_code: ev.employee_code,
        department_id: ev.department_id,
        shift_date: ev.shift_date,
        action: ev.action,
        status: ev.status,
        time: ev.time,
        source: ev.offline_replay ? 'kiosk_offline' : 'kiosk',
        offline_replay: ev.offline_replay,
      });
    }
    broadcastDeviceTelemetryById(device.id);

    res.status(200).json({
      ok: true,
      batch_uid: resolvedBatchUid,
      device: device.name,
      received_at_utc: receivedAtUtc,
      sync_status: syncStatus,
      summary: {
        total: events.length,
        accepted: acceptedCount,
        duplicate: duplicateCount,
        conflict_preserved: conflictCount,
        escalated: escalatedCount,
        rejected: rejectedCount,
      },
      results: orderedResults,
    });
  });

  // =========================================================================
  // AUTHENTICATED SESSION ROUTES (HttpOnly Cookie + CSRF + Forced Rotation Gate)
  // =========================================================================
  router.use(requireAuth);
  router.use(requireCsrf);
  router.use(requirePasswordChanged);

  router.get('/auth/me', (req: AuthenticatedRequest, res) => {
    res.json({
      user: req.user,
      csrfToken: req.session!.csrfToken,
    });
  });

  router.get('/auth/csrf', (req: AuthenticatedRequest, res) => {
    res.json({ csrfToken: req.session!.csrfToken });
  });

  router.post('/auth/logout', (req: AuthenticatedRequest, res) => {
    const active = loadActiveSessionFromRequest(db, req);
    if (active) {
      revokeSessionById(db, active.session.sid, 'logout');
      logAudit(db, active.user.username, 'Signed out and revoked server session', 'Authentication', 'Success', getClientIp(req));
    }
    clearAuthCookies(res, req);
    res.json({ success: true });
  });

  router.post('/auth/change-password', (req: AuthenticatedRequest, res) => {
    const { currentPassword, newPassword } = (req.body || {}) as {
      currentPassword?: string;
      newPassword?: string;
    };

    if (typeof currentPassword !== 'string' || typeof newPassword !== 'string' || !currentPassword || !newPassword) {
      res.status(400).json({ error: 'Current password and new password are required.' });
      return;
    }
    if (currentPassword === newPassword) {
      res.status(400).json({ error: 'New password must be different from your current password.' });
      return;
    }

    const strengthErr = validatePasswordStrength(newPassword);
    if (strengthErr) {
      res.status(400).json({ error: strengthErr });
      return;
    }

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user!.id) as
      | { id: number; username: string; password_hash: string; salt: string }
      | undefined;

    if (!user || !verifyPassword(currentPassword, user.password_hash, user.salt)) {
      logAudit(db, req.user!.username, 'Failed password change (incorrect current password)', 'Security', 'Warning', getClientIp(req));
      res.status(400).json({ error: 'Current password is incorrect.' });
      return;
    }

    const { hash, salt } = hashPassword(newPassword);
    const clientIp = getClientIp(req);

    // Atomic password update + revoke ALL prior sessions for this user + issue rotated session
    let rotatedSession!: ReturnType<typeof createUserSession>;
    const tx = db.transaction(() => {
      db.prepare(
        `UPDATE users
         SET password_hash = ?, salt = ?, must_change_password = 0,
             failed_login_attempts = 0, locked_until = NULL,
             password_changed_at = datetime('now', 'localtime')
         WHERE id = ?`
      ).run(hash, salt, user.id);

      revokeAllUserSessions(db, user.id, 'password_changed');
      rotatedSession = createUserSession(db, user.id, {
        rememberMe: false,
        ipAddress: clientIp,
        userAgent: typeof req.headers['user-agent'] === 'string' ? req.headers['user-agent'] : '',
      });

      logAudit(
        db,
        req.user!.username,
        'Updated account password and invalidated all prior active sessions',
        'Security',
        'Success',
        clientIp
      );
    });
    tx();

    setAuthCookies(res, rotatedSession.signedCookieValue, rotatedSession.csrfToken, rotatedSession.expiresAt, req);
    res.json({
      success: true,
      csrfToken: rotatedSession.csrfToken,
      user: { ...req.user!, must_change_password: false },
    });
  });

  // =========================================================================
  // USER & ROLE MANAGEMENT (Administrator Only)
  // =========================================================================
  router.get('/users', requirePermission('users:manage'), (_req, res) => {
    const rows = db
      .prepare(
        `SELECT u.id, u.username, u.email, u.full_name, u.role, u.department_id, u.employee_id,
                u.must_change_password, u.is_active, u.failed_login_attempts, u.locked_until,
                u.password_changed_at, u.created_at,
                d.code as department_code, d.name as department_name
         FROM users u
         LEFT JOIN departments d ON u.department_id = d.id
         ORDER BY u.id ASC`
      )
      .all();
    const roles = db.prepare('SELECT name, description FROM roles ORDER BY name ASC').all();
    res.json({ data: rows, roles });
  });

  // Narrow, non-financial employee options for secure account provisioning.
  // Includes ALL employees rather than the paginated employee-management view.
  router.get('/users/employee-options', requirePermission('users:manage'), (_req, res) => {
    const employees = db.prepare(`
      SELECT e.id, e.employee_code, e.full_name, e.email, e.department_id, e.status,
             u.id AS linked_user_id, u.username AS linked_username
      FROM employees e
      LEFT JOIN users u ON u.employee_id = e.id AND u.role = 'Employee'
      ORDER BY e.employee_code ASC
    `).all();
    res.json({ data: employees });
  });

  router.post('/users', requirePermission('users:manage'), (req: AuthenticatedRequest, res) => {
    const { username, email, full_name, role, password, department_id, employee_id, must_change_password } =
      (req.body || {}) as {
        username?: string;
        email?: string;
        full_name?: string;
        role?: string;
        password?: string;
        department_id?: number | null;
        employee_id?: number | null;
        must_change_password?: boolean;
      };

    if (!username?.trim() || !email?.trim() || !full_name?.trim() || !role || !password) {
      res.status(400).json({ error: 'Username, email, full name, role, and initial password are required.' });
      return;
    }
    if (!isValidRole(role) || role === 'Kiosk Device') {
      res.status(400).json({ error: 'Invalid human portal role specified.' });
      return;
    }
    if (!/^[a-zA-Z0-9._-]{3,64}$/.test(username.trim()) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      res.status(400).json({ error: 'Use a 3–64 character username (letters, numbers, dot, hyphen, underscore) and a valid email address.' });
      return;
    }
    const existingLogin = db.prepare('SELECT id FROM users WHERE lower(username) = lower(?) OR lower(email) = lower(?) LIMIT 1')
      .get(username.trim(), email.trim());
    if (existingLogin) {
      res.status(409).json({ error: 'Username or email already exists.', code: 'ACCOUNT_CONFLICT' });
      return;
    }
    const pwErr = validatePasswordStrength(password);
    if (pwErr) {
      res.status(400).json({ error: pwErr });
      return;
    }

    // Employee accounts are always bound to ONE existing active personnel record.
    // This is enforced server-side; the browser's selected employee ID is untrusted.
    const link = role === 'Employee' ? resolveEmployeeAccountLink(db, employee_id) : null;
    if (link && !link.ok) {
      res.status(link.status).json({ error: link.error, code: link.code });
      return;
    }
    const { hash, salt } = hashPassword(password);
    try {
      const info = db
        .prepare(
          `INSERT INTO users (username, email, full_name, role, department_id, employee_id, password_hash, salt, must_change_password, is_active)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`
        )
        .run(
          username.trim(),
          email.trim(),
          link?.ok ? link.employee.full_name : full_name.trim(),
          role,
          link?.ok ? link.employee.department_id : department_id ? Number(department_id) : null,
          link?.ok ? link.employee.id : employee_id ? Number(employee_id) : null,
          hash,
          salt,
          role === 'Employee' ? 1 : must_change_password === false ? 0 : 1
        );
      logAudit(
        db,
        req.user!.username,
        `Created user account "${username.trim()}" (role: ${role})`,
        'Security',
        'Success',
        getClientIp(req),
        {
          actionType: 'USER_CREATED',
          targetType: 'user',
          targetId: Number(info.lastInsertRowid),
          after: { username: username.trim(), role, is_active: true },
          isSecurityEvent: true,
        }
      );
      res.status(201).json({ id: Number(info.lastInsertRowid) });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to create user';
      res.status(400).json({ error: msg.includes('UNIQUE') ? 'Username or email already exists.' : msg });
    }
  });

  router.patch('/users/:id', requirePermission('users:manage'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid user ID.' });
      return;
    }
    const existing = db.prepare('SELECT id, username, role, is_active, employee_id FROM users WHERE id = ?').get(id) as
      | { id: number; username: string; role: string; is_active: number; employee_id: number | null }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    const { role, is_active, department_id, employee_id, must_change_password } = (req.body || {}) as {
      role?: string;
      is_active?: boolean;
      department_id?: number | null;
      employee_id?: number | null;
      must_change_password?: boolean;
    };

    if (role !== undefined && (!isValidRole(role) || role === 'Kiosk Device')) {
      res.status(400).json({ error: 'Invalid portal role.' });
      return;
    }
    if (id === req.user!.id && is_active === false) {
      res.status(400).json({ error: 'You cannot deactivate your own active Administrator account.' });
      return;
    }

    const nextRole = role ?? existing.role;
    const nextActive = is_active === undefined ? existing.is_active : is_active ? 1 : 0;
    const changingEmployeeLink = employee_id !== undefined;
    const targetEmployeeId = changingEmployeeLink ? employee_id : existing.employee_id;
    const link = nextRole === 'Employee' ? resolveEmployeeAccountLink(db, targetEmployeeId, id) : null;
    if (link && !link.ok) {
      res.status(link.status).json({ error: link.error, code: link.code });
      return;
    }

    db.prepare(
      `UPDATE users
       SET role = ?,
           is_active = ?,
           department_id = COALESCE(?, department_id),
           employee_id = COALESCE(?, employee_id),
           must_change_password = COALESCE(?, must_change_password)
       WHERE id = ?`
    ).run(
      nextRole,
      nextActive,
      link?.ok ? link.employee.department_id : department_id === undefined ? null : department_id,
      link?.ok ? link.employee.id : employee_id === undefined ? null : employee_id,
      must_change_password === undefined ? null : must_change_password ? 1 : 0,
      id
    );

    if (link?.ok) {
      db.prepare('UPDATE users SET full_name = ? WHERE id = ?').run(link.employee.full_name, id);
    }
    if (nextActive === 0 || nextRole !== existing.role || (link?.ok && existing.employee_id !== link.employee.id)) {
      revokeAllUserSessions(db, id, 'account_updated_by_admin');
    }

    logAudit(
      db,
      req.user!.username,
      `Updated user "${existing.username}" (role: ${nextRole}, active: ${Boolean(nextActive)})`,
      'Security',
      'Warning',
      getClientIp(req),
      {
        actionType: 'USER_UPDATED',
        targetType: 'user',
        targetId: id,
        before: { role: existing.role, is_active: Boolean(existing.is_active) },
        after: { role: nextRole, is_active: Boolean(nextActive) },
        isSecurityEvent: true,
      }
    );
    res.json({ success: true });
  });

  // -------------------------------------------------------------------------
  // REAL-TIME AUTHENTICATED & RBAC-SCOPED SSE STREAM (BUILD 10)
  // -------------------------------------------------------------------------
  router.get('/events/stream', (req: AuthenticatedRequest, res) => {
    const rawChannels = typeof req.query.channels === 'string' ? req.query.channels : '';
    const requestedChannels = rawChannels
      ? rawChannels
          .split(',')
          .map((c) => c.trim())
          .filter(Boolean)
      : undefined;

    const attachment = realtimeHub.attachClient(
      req,
      res,
      {
        userId: req.user!.id,
        username: req.user!.username,
        role: req.user!.role as RoleName,
        departmentId: req.user!.department_id,
        employeeId: req.user!.employee_id,
        permissions: new Set<PermissionCode>(req.user!.permissions as PermissionCode[]),
      },
      requestedChannels,
      () => {
        // Long-running SSE must not retain permissions after logout, expiry,
        // account deactivation, role or employee-link updates.
        const current = loadActiveSessionFromRequest(db, req);
        if (!current || current.session.sid !== req.session?.sid) return false;
        const original = req.user!;
        const latest = current.user;
        return latest.id === original.id && latest.role === original.role &&
          latest.department_id === original.department_id &&
          latest.employee_id === original.employee_id &&
          !latest.must_change_password &&
          latest.permissions.length === original.permissions.length &&
          original.permissions.every((permission) => latest.permissions.includes(permission));
      }
    );

    if (!attachment.accepted) {
      res.status(503).json({
        error: 'Real-time event stream capacity reached. Falling back to polling.',
        code: 'REALTIME_CAPACITY_EXCEEDED',
      });
    }
  });

  // -------------------------------------------------------------------------
  // EMPLOYEE READ-ONLY TODAY ATTENDANCE (Web & Android Read-Only Portal; NO punch buttons)
  // -------------------------------------------------------------------------
  router.get('/employee/today-attendance', requirePermission('attendance:read_self'), (req: AuthenticatedRequest, res) => {
    if (req.user!.employee_id === null) {
      res.status(403).json({
        error: 'Account is not linked to an employee profile.',
        code: 'EMPLOYEE_LINK_REQUIRED',
      });
      return;
    }

    const nowMs = getNowMs();
    const today = getTodayDateString(nowMs);
    const emp = db
      .prepare(
        `SELECT e.id, e.employee_code, e.full_name, d.code as department_code, d.name as department_name,
                s.name as shift_name, s.time_in as shift_time_in, s.time_out as shift_time_out, s.grace_minutes
         FROM employees e
         JOIN departments d ON e.department_id = d.id
         JOIN shifts s ON e.shift_id = s.id
         WHERE e.id = ?`
      )
      .get(req.user!.employee_id) as Record<string, unknown> | undefined;

    if (!emp) {
      res.status(404).json({ error: 'Linked employee profile not found.' });
      return;
    }

    // An open shift from yesterday remains the active work period after midnight
    // until its real cutoff, unless an attendance record already exists today.
    const hasToday = db.prepare('SELECT 1 FROM attendance_records WHERE employee_id = ? AND date = ?')
      .get(req.user!.employee_id, today) !== undefined;
    const previousDate = addDaysIso(today, -1);
    const previous = db.prepare('SELECT date, time_in, time_out FROM attendance_records WHERE employee_id = ? AND date = ?')
      .get(req.user!.employee_id, previousDate) as
      | { date: string; time_in: string | null; time_out: string | null } | undefined;
    const displayDate = resolveEmployeeTodayShiftDate(nowMs, today, {
      time_in: String(emp.shift_time_in), time_out: String(emp.shift_time_out),
    }, previous ?? null, hasToday);
    const record = db
      .prepare(
        `SELECT a.*, e.employee_code, e.full_name as employee_name, d.code as department_code, d.name as department_name
         FROM attendance_records a
         JOIN employees e ON a.employee_id = e.id
         JOIN departments d ON e.department_id = d.id
         WHERE a.employee_id = ? AND a.date = ?`
      )
      .get(req.user!.employee_id, displayDate);

    const events = db
      .prepare(
        `SELECT id, event_uid, employee_id, device_id, device_name, attendance_date, punch_type, punch_time,
                server_timestamp_utc, manila_timestamp, device_timestamp_utc, clock_drift_seconds,
                offline_replay, decision, decision_code, decision_reason, source, recorded_at as created_at
         FROM attendance_events
         WHERE employee_id = ? AND attendance_date = ?
         ORDER BY id ASC`
      )
      .all(req.user!.employee_id, displayDate);

    res.json({
      date: displayDate,
      calendar_date: today,
      active_prior_shift: displayDate !== today,
      timezone: 'Asia/Manila',
      read_only: true,
      allow_manual_punch: false,
      server_timestamp_utc: new Date(nowMs).toISOString(),
      employee: emp,
      attendance: record ?? null,
      events,
    });
  });

  // -------------------------------------------------------------------------
  // EMPLOYEE SELF-SERVICE: read-only personal profile and monthly DTR summary.
  // No employee ID parameter accepted; identity comes only from the session.
  // -------------------------------------------------------------------------
  router.get('/employee/profile', requirePermission('attendance:read_self'), (req: AuthenticatedRequest, res) => {
    const empId = req.user!.employee_id;
    if (!empId) {
      res.status(403).json({ error: 'Account is not linked to an employee profile.', code: 'EMPLOYEE_LINK_REQUIRED' });
      return;
    }
    const employee = db.prepare(`
      SELECT e.id, e.employee_code, e.full_name, e.email, e.status, e.hired_date,
             d.code AS department_code, d.name AS department_name,
             p.name AS position_name, s.name AS shift_name,
             s.time_in AS shift_time_in, s.time_out AS shift_time_out
      FROM employees e
      JOIN departments d ON d.id = e.department_id
      JOIN positions p ON p.id = e.position_id
      JOIN shifts s ON s.id = e.shift_id
      WHERE e.id = ?
    `).get(empId);
    if (!employee) {
      res.status(404).json({ error: 'Linked employee profile not found.' });
      return;
    }
    res.json({ employee, read_only: true });
  });

  router.get('/employee/attendance-month', requirePermission('attendance:read_self'), (req: AuthenticatedRequest, res) => {
    const empId = req.user!.employee_id;
    if (!empId) {
      res.status(403).json({ error: 'Account is not linked to an employee profile.', code: 'EMPLOYEE_LINK_REQUIRED' });
      return;
    }
    const month = typeof req.query.month === 'string'
      ? req.query.month.trim()
      : getTodayDateString(getNowMs()).slice(0, 7);
    if (!/^(?:19|20|21)\d{2}-(?:0[1-9]|1[0-2])$/.test(month)) {
      res.status(400).json({ error: 'Invalid month; use YYYY-MM.', code: 'INVALID_MONTH' });
      return;
    }
    const [y, m] = month.split('-').map(Number);
    const nextMonth = m === 12 ? `${y + 1}-01-01` : `${y}-${String(m + 1).padStart(2, '0')}-01`;
    const rows = db.prepare(`
      SELECT date, time_in, time_out, break_out, break_in, overtime_out,
             work_hours, status, late_minutes, undertime_minutes, overtime_minutes
      FROM attendance_records
      WHERE employee_id = ? AND date >= ? AND date < ?
      ORDER BY date DESC
    `).all(empId, `${month}-01`, nextMonth);
    res.json({ employee_id: empId, month, timezone: 'Asia/Manila', read_only: true, data: rows });
  });

  // -------------------------------------------------------------------------
  // EMPLOYEE SELF-SERVICE NOTIFICATIONS (strictly scoped to authenticated employee)
  // -------------------------------------------------------------------------
  router.get('/employee/notifications', requirePermission('attendance:read_self'), (req: AuthenticatedRequest, res) => {
    const userId = req.user!.id;
    const empId = req.user!.employee_id;
    if (!empId) {
      res.status(403).json({ error: 'Account is not linked to an employee profile.', code: 'EMPLOYEE_LINK_REQUIRED' });
      return;
    }

    const readRows = db
      .prepare('SELECT notification_key FROM employee_notification_reads WHERE user_id = ?')
      .all(userId) as Array<{ notification_key: string }>;
    const readSet = new Set(readRows.map((r) => r.notification_key));

    interface EmployeeNotifItem {
      key: string;
      category: 'System Announcement' | 'Leave Update' | 'Attendance Correction' | 'Payroll' | 'Attendance';
      title: string;
      message: string;
      timestamp: string;
      is_read: boolean;
      target_tab: 'today' | 'attendance' | 'requests' | 'payslips';
      entity_id: number | null;
    }

    const items: EmployeeNotifItem[] = [];

    // 1. Campus holidays / announcements (public campus calendar)
    const holidays = db
      .prepare(
        `SELECT id, date, name, type, created_at
         FROM holidays
         ORDER BY date DESC
         LIMIT 8`
      )
      .all() as Array<{ id: number; date: string; name: string; type: string; created_at: string }>;
    for (const h of holidays) {
      const key = `holiday:${h.id}`;
      items.push({
        key,
        category: 'System Announcement',
        title: 'System Announcement',
        message: `${h.name} (${h.type} Holiday) on ${h.date}.`,
        timestamp: h.created_at || `${h.date} 08:00:00`,
        is_read: readSet.has(key),
        target_tab: 'attendance',
        entity_id: h.id,
      });
    }

    // 2. Employee's own leave requests & status updates
    const myLeaves = db
      .prepare(
        `SELECT id, leave_type, start_date, end_date, status, reviewed_at, created_at
         FROM leaves
         WHERE employee_id = ?
         ORDER BY COALESCE(reviewed_at, created_at) DESC
         LIMIT 15`
      )
      .all(empId) as Array<{
        id: number;
        leave_type: string;
        start_date: string;
        end_date: string;
        status: string;
        reviewed_at: string | null;
        created_at: string;
      }>;
    for (const l of myLeaves) {
      const year = (l.start_date || '').slice(0, 4) || new Date(getNowMs()).getUTCFullYear().toString();
      const refNo = `LV-${year}-${String(l.id).padStart(5, '0')}`;
      const statusText = l.status === 'Pending' ? 'Pending Approval' : l.status;
      const key = `leave:${l.id}:${l.status}`;
      items.push({
        key,
        category: 'Leave Update',
        title: 'Leave Update',
        message: `Your leave request ${refNo} (${l.leave_type}) is ${statusText}.`,
        timestamp: l.reviewed_at || l.created_at,
        is_read: readSet.has(key),
        target_tab: 'requests',
        entity_id: l.id,
      });
    }

    // 3. Employee's own attendance correction requests & status updates
    const myCorrections = db
      .prepare(
        `SELECT id, attendance_date, request_type, status, reviewed_at, created_at
         FROM corrections
         WHERE employee_id = ?
         ORDER BY COALESCE(reviewed_at, created_at) DESC
         LIMIT 15`
      )
      .all(empId) as Array<{
        id: number;
        attendance_date: string;
        request_type: string;
        status: string;
        reviewed_at: string | null;
        created_at: string;
      }>;
    for (const c of myCorrections) {
      const year = (c.attendance_date || '').slice(0, 4) || new Date(getNowMs()).getUTCFullYear().toString();
      const refNo = `AC-${year}-${String(c.id).padStart(5, '0')}`;
      const statusText = c.status === 'Pending' ? 'Pending Approval' : c.status;
      const key = `correction:${c.id}:${c.status}`;
      items.push({
        key,
        category: 'Attendance Correction',
        title: 'Attendance Correction',
        message: `Correction request ${refNo} (${c.request_type}) for ${c.attendance_date} is ${statusText}.`,
        timestamp: c.reviewed_at || c.created_at,
        is_read: readSet.has(key),
        target_tab: 'requests',
        entity_id: c.id,
      });
    }

    // 4. Employee's own released payslips ONLY
    const myPayslips = db
      .prepare(
        `SELECT pi.payroll_run_id, r.period_label, r.released_at, r.created_at
         FROM payroll_items pi
         JOIN payroll_runs r ON r.id = pi.payroll_run_id
         WHERE pi.employee_id = ? AND r.status = 'Released'
         ORDER BY COALESCE(r.released_at, r.created_at) DESC
         LIMIT 10`
      )
      .all(empId) as Array<{ payroll_run_id: number; period_label: string; released_at: string | null; created_at: string }>;
    for (const p of myPayslips) {
      const key = `payslip:${p.payroll_run_id}`;
      items.push({
        key,
        category: 'Payroll',
        title: 'Payroll',
        message: `Your payslip for ${p.period_label} is now available.`,
        timestamp: p.released_at || p.created_at,
        is_read: readSet.has(key),
        target_tab: 'payslips',
        entity_id: p.payroll_run_id,
      });
    }

    // 5. Employee's own recent recorded attendance
    const myAttendance = db
      .prepare(
        `SELECT id, date, time_in, time_out, status
         FROM attendance_records
         WHERE employee_id = ? AND (time_in IS NOT NULL OR time_out IS NOT NULL)
         ORDER BY date DESC
         LIMIT 8`
      )
      .all(empId) as Array<{ id: number; date: string; time_in: string | null; time_out: string | null; status: string }>;
    for (const a of myAttendance) {
      const key = `attendance:${a.id}:${a.time_out ? 'out' : 'in'}`;
      items.push({
        key,
        category: 'Attendance',
        title: 'Attendance',
        message: `Your attendance for ${a.date} has been recorded (${a.status}).`,
        timestamp: `${a.date} ${a.time_out || a.time_in || '08:00:00'}`,
        is_read: readSet.has(key),
        target_tab: 'attendance',
        entity_id: a.id,
      });
    }

    items.sort((a, b) => String(b.timestamp).localeCompare(String(a.timestamp)));
    const sliced = items.slice(0, 40);
    const unread = sliced.filter((item) => !item.is_read).length;

    res.json({
      data: sliced,
      notifications: sliced,
      unreadCount: unread,
      counts: { total: sliced.length, unread },
    });
  });

  router.patch('/employee/notifications/:key/read', requirePermission('attendance:read_self'), (req: AuthenticatedRequest, res) => {
    const rawKey = typeof req.params.key === 'string' ? req.params.key.trim() : '';
    if (!rawKey || rawKey.length > 120 || !/^[a-z0-9:_-]+$/i.test(rawKey)) {
      res.status(400).json({ error: 'Invalid notification key.' });
      return;
    }
    db.prepare(
      `INSERT OR IGNORE INTO employee_notification_reads (user_id, notification_key)
       VALUES (?, ?)`
    ).run(req.user!.id, rawKey);
    res.json({ success: true });
  });

  router.post('/employee/notifications/mark-all-read', requirePermission('attendance:read_self'), (req: AuthenticatedRequest, res) => {
    const { keys } = (req.body || {}) as { keys?: unknown[] };
    const cleanKeys = Array.isArray(keys)
      ? keys
          .map((k) => (typeof k === 'string' ? k.trim() : ''))
          .filter((k) => k.length > 0 && k.length <= 120 && /^[a-z0-9:_-]+$/i.test(k))
      : [];
    const insert = db.prepare(
      `INSERT OR IGNORE INTO employee_notification_reads (user_id, notification_key)
       VALUES (?, ?)`
    );
    const tx = db.transaction((list: string[]) => {
      for (const k of list) {
        insert.run(req.user!.id, k);
      }
    });
    tx(cleanKeys);
    res.json({ success: true, marked: cleanKeys.length });
  });

  // -------------------------------------------------------------------------
  // EMPLOYEE SELF-SERVICE ACCOUNT SECURITY & ACTIVE SESSIONS
  // -------------------------------------------------------------------------
  router.get('/employee/security/sessions', (req: AuthenticatedRequest, res) => {
    const userId = req.user!.id;
    const currentSid = req.session!.sid;
    const nowMs = getNowMs();

    const rows = db
      .prepare(
        `SELECT sid, created_at, expires_at, revoked_at, revoked_reason, ip_address, user_agent
         FROM user_sessions
         WHERE user_id = ?
         ORDER BY created_at DESC
         LIMIT 25`
      )
      .all(userId) as Array<{
        sid: string;
        created_at: string;
        expires_at: number;
        revoked_at: string | null;
        revoked_reason: string | null;
        ip_address: string;
        user_agent: string;
      }>;

    const timeoutSetting = db
      .prepare("SELECT value FROM settings WHERE key = 'session_timeout_hours'")
      .get() as { value?: string } | undefined;
    const sessionTimeoutHours = Math.max(1, Number(timeoutSetting?.value || 12) || 12);

    const sessions = rows.map((row) => {
      const isCurrent = row.sid === currentSid;
      const isActive = !row.revoked_at && row.expires_at > nowMs;
      return {
        session_id: row.sid.slice(0, 12),
        is_current: isCurrent,
        is_active: isActive,
        status: isActive ? 'Active' : row.revoked_at ? 'Revoked' : 'Expired',
        revoked_reason: row.revoked_reason || null,
        ip_address: row.ip_address || 'Unknown',
        user_agent: row.user_agent || 'Web Browser',
        created_at: row.created_at,
        expires_at_utc: new Date(row.expires_at).toISOString(),
      };
    });

    res.json({
      twoFactorSupported: false,
      twoFactorNotice: 'Two-factor authenticator enrollment is not yet enabled on the campus server. Account protection uses scrypt password hashing, brute-force lockout, and signed HttpOnly server sessions.',
      sessionTimeoutHours,
      currentSessionExpiresAtUtc: new Date(req.session!.expiresAt).toISOString(),
      activeCount: sessions.filter((s) => s.is_active).length,
      sessions,
    });
  });

  router.delete('/employee/security/sessions/:sessionPrefix', (req: AuthenticatedRequest, res) => {
    const prefix = typeof req.params.sessionPrefix === 'string' ? req.params.sessionPrefix.trim() : '';
    if (!/^[a-f0-9]{12}$/i.test(prefix)) {
      res.status(400).json({ error: 'Invalid session identifier.' });
      return;
    }
    const target = db
      .prepare(
        `SELECT sid FROM user_sessions
         WHERE user_id = ? AND substr(sid, 1, 12) = ? AND revoked_at IS NULL`
      )
      .get(req.user!.id, prefix) as { sid: string } | undefined;

    if (!target) {
      res.status(404).json({ error: 'Active session not found for your account.' });
      return;
    }
    if (target.sid === req.session!.sid) {
      res.status(400).json({ error: 'Use Sign Out to end your current session.' });
      return;
    }

    revokeSessionById(db, target.sid, 'user_revoked_device');
    logAudit(
      db,
      req.user!.username,
      `Revoked another active session (${prefix}...) from Account Security`,
      'Security',
      'Success',
      getClientIp(req)
    );
    res.json({ success: true });
  });

  router.post('/employee/security/sessions/revoke-others', (req: AuthenticatedRequest, res) => {
    const result = db
      .prepare(
        `UPDATE user_sessions
         SET revoked_at = datetime('now', 'localtime'), revoked_reason = 'user_revoked_other_devices'
         WHERE user_id = ? AND sid != ? AND revoked_at IS NULL`
      )
      .run(req.user!.id, req.session!.sid);
    logAudit(
      db,
      req.user!.username,
      `Revoked ${result.changes} other active session(s) from Account Security`,
      'Security',
      'Success',
      getClientIp(req)
    );
    res.json({ success: true, revoked: result.changes });
  });

  // -------------------------------------------------------------------------
  // DASHBOARD SUMMARY
  // -------------------------------------------------------------------------
  router.get('/dashboard', requirePermission('dashboard:read'), (req: AuthenticatedRequest, res) => {
    const range = (req.query.range as string) || 'week';
    const nowMs = getNowMs();
    const today = getTodayDateString(nowMs);
    const scopedDeptId = req.user!.role === 'Department Head' ? req.user!.department_id : null;

    const totalEmployees = (
      scopedDeptId
        ? db.prepare("SELECT COUNT(*) as c FROM employees WHERE status = 'Active' AND department_id = ?").get(scopedDeptId)
        : db.prepare("SELECT COUNT(*) as c FROM employees WHERE status = 'Active'").get()
    ) as { c: number };

    const todayCounts = (
      scopedDeptId
        ? db
            .prepare(
              `SELECT a.status, COUNT(*) as c
               FROM attendance_records a
               JOIN employees e ON a.employee_id = e.id
               WHERE a.date = ? AND e.department_id = ?
               GROUP BY a.status`
            )
            .all(today, scopedDeptId)
        : db
            .prepare(
              `SELECT status, COUNT(*) as c
               FROM attendance_records
               WHERE date = ?
               GROUP BY status`
            )
            .all(today)
    ) as Array<{ status: string; c: number }>;

    const statusMap: Record<string, number> = {
      Present: 0,
      Late: 0,
      Undertime: 0,
      Absent: 0,
      'On Leave': 0,
      OB: 0,
      'Rest Day': 0,
      Holiday: 0,
      'Missing Time Out': 0,
      'No Schedule': 0,
    };
    for (const row of todayCounts) {
      statusMap[row.status] = (statusMap[row.status] || 0) + row.c;
    }

    const attended = statusMap.Present + statusMap.Late + statusMap.Undertime + statusMap.OB + statusMap['Missing Time Out'];
    const accounted =
      statusMap.Present + statusMap.Late + statusMap.Undertime + statusMap.Absent + statusMap['On Leave'];
    const others = Math.max(0, totalEmployees.c - accounted);
    const attendanceRate = totalEmployees.c > 0 ? Math.round((attended / totalEmployees.c) * 1000) / 10 : 0;

    // Never leak kiosk api_token on dashboard summary; derive Online/Stale/Offline strictly from verified heartbeat
    const thresholds = getHeartbeatThresholds();
    evaluateDeviceConnectivityAlerts(db, realtimeHub, nowMs, thresholds);
    const rawDevices = db.prepare('SELECT * FROM devices ORDER BY id ASC').all() as StoredDeviceRow[];
    const devices = rawDevices.map((row) => computeDeviceTelemetry(row, nowMs, thresholds));
    const onlineDevices = devices.filter((d) => d.status === 'Online').length;

    const offsetStart = range === 'lastWeek' ? 13 : 6;
    const weeklyTrend = [];
    for (let i = offsetStart; i >= offsetStart - 6; i--) {
      const iso = addDaysIso(today, -i);
      const rows = (
        scopedDeptId
          ? db
              .prepare(
                `SELECT a.status, COUNT(*) as c
                 FROM attendance_records a JOIN employees e ON a.employee_id = e.id
                 WHERE a.date = ? AND e.department_id = ?
                 GROUP BY a.status`
              )
              .all(iso, scopedDeptId)
          : db.prepare('SELECT status, COUNT(*) as c FROM attendance_records WHERE date = ? GROUP BY status').all(iso)
      ) as Array<{ status: string; c: number }>;

      let present = 0;
      let late = 0;
      let absent = 0;
      for (const r of rows) {
        if (r.status === 'Present' || r.status === 'OB' || r.status === 'Undertime') present += r.c;
        if (r.status === 'Late') late += r.c;
        if (r.status === 'Absent') absent += r.c;
      }
      weeklyTrend.push({
        day: getManilaDayCodeForIsoDate(iso),
        date: iso,
        present,
        late,
        absent,
        total: present + late,
        isToday: iso === today,
      });
    }

    const recentAttendance = scopedDeptId
      ? db
          .prepare(
            `SELECT a.*, e.employee_code, e.full_name as employee_name, d.code as department_code, d.name as department_name
             FROM attendance_records a
             JOIN employees e ON a.employee_id = e.id
             JOIN departments d ON e.department_id = d.id
             WHERE a.date = ? AND a.time_in IS NOT NULL AND e.department_id = ?
             ORDER BY a.id ASC
             LIMIT 6`
          )
          .all(today, scopedDeptId)
      : db
          .prepare(
            `SELECT a.*, e.employee_code, e.full_name as employee_name, d.code as department_code, d.name as department_name
             FROM attendance_records a
             JOIN employees e ON a.employee_id = e.id
             JOIN departments d ON e.department_id = d.id
             WHERE a.date = ? AND a.time_in IS NOT NULL
             ORDER BY a.id ASC
             LIMIT 6`
          )
          .all(today);

    evaluateDeviceConnectivityAlerts(db, realtimeHub, getNowMs(), getHeartbeatThresholds());
    const unreadNotifications = getUnreadNotificationCountForRole(db, req.user!.role);
    const pendingCorrections = (
      db.prepare("SELECT COUNT(*) as c FROM corrections WHERE status = 'Pending'").get() as { c: number }
    ).c;
    const pendingLeaves = (
      db.prepare("SELECT COUNT(*) as c FROM leaves WHERE status = 'Pending'").get() as { c: number }
    ).c;

    res.json({
      date: today,
      kpis: {
        totalEmployees: totalEmployees.c,
        present: statusMap.Present,
        late: statusMap.Late,
        absent: statusMap.Absent,
        onLeave: statusMap['On Leave'],
        others,
        attendanceRate,
        onlineDevices,
        totalDevices: devices.length,
      },
      weeklyTrend,
      devices,
      recentAttendance,
      unreadNotifications,
      pendingCorrections,
      pendingLeaves,
    });
  });

  // -------------------------------------------------------------------------
  // EMPLOYEES CRUD + CSV IMPORT
  // -------------------------------------------------------------------------
  router.get('/employees', requirePermission('employees:read'), (req: AuthenticatedRequest, res) => {
    const search = ((req.query.search as string) || '').trim();
    let deptId = req.query.department_id ? Number(req.query.department_id) : null;
    if (req.user!.role === 'Department Head') {
      if (req.user!.department_id === null) {
        res.status(403).json({ error: 'Department Head account is not assigned to a department.' });
        return;
      }
      deptId = req.user!.department_id;
    }

    const status = ((req.query.status as string) || '').trim();
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const where: string[] = [];
    const params: unknown[] = [];

    if (search) {
      where.push('(e.employee_code LIKE ? OR e.full_name LIKE ? OR d.code LIKE ? OR d.name LIKE ? OR p.name LIKE ?)');
      const like = `%${search}%`;
      params.push(like, like, like, like, like);
    }
    if (deptId) {
      where.push('e.department_id = ?');
      params.push(deptId);
    }
    if (status) {
      where.push('e.status = ?');
      params.push(status);
    }

    const whereSql = where.length > 0 ? `WHERE ${where.join(' AND ')}` : '';
    const total = (
      db
        .prepare(
          `SELECT COUNT(*) as c FROM employees e
           JOIN departments d ON e.department_id = d.id
           JOIN positions p ON e.position_id = p.id
           ${whereSql}`
        )
        .get(...params) as { c: number }
    ).c;

    const rows = db
      .prepare(
        `SELECT e.*, d.code as department_code, d.name as department_name,
                p.code as position_code, p.name as position_name,
                s.name as shift_name
         FROM employees e
         JOIN departments d ON e.department_id = d.id
         JOIN positions p ON e.position_id = p.id
         JOIN shifts s ON e.shift_id = s.id
         ${whereSql}
         ORDER BY e.employee_code ASC
         LIMIT ? OFFSET ?`
      )
      .all(...params, limit, offset);

    res.json({ data: rows, total, page, limit });
  });

  router.post('/employees', requirePermission('employees:write'), (req: AuthenticatedRequest, res) => {
    const {
      employee_code,
      full_name,
      email,
      department_id,
      position_id,
      shift_id,
      status,
      hired_date,
      monthly_salary,
      monthly_allowance,
      portal_account,
    } = req.body || {};

    if (!employee_code?.trim() || !full_name?.trim() || !department_id || !position_id || !shift_id) {
      res.status(400).json({ error: 'Employee ID, full name, department, position, and shift are required.' });
      return;
    }

    // Optional employee portal account is created in the SAME transaction as
    // its personnel record. No incomplete employee is left if credentials fail.
    let newAccount: { username: string; password: string } | null = null;
    if (portal_account !== undefined && portal_account !== null) {
      if (!req.user!.permissions.includes('users:manage')) {
        res.status(403).json({ error: 'User account provisioning requires users:manage permission.' });
        return;
      }
      const username = typeof portal_account?.username === 'string' ? portal_account.username.trim() : '';
      const password = typeof portal_account?.password === 'string' ? portal_account.password : '';
      if (!/^[a-zA-Z0-9._-]{3,64}$/.test(username) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || '').trim())) {
        res.status(400).json({ error: 'Employee account requires a valid username (3–64 characters) and institutional email.' });
        return;
      }
      if (status === 'Inactive') {
        res.status(400).json({ error: 'Cannot provision an account for an inactive employee.' });
        return;
      }
      const strengthErr = validatePasswordStrength(password);
      if (strengthErr) { res.status(400).json({ error: strengthErr }); return; }
      const duplicate = db.prepare('SELECT id FROM users WHERE lower(username) = lower(?) OR lower(email) = lower(?) LIMIT 1')
        .get(username, String(email).trim());
      if (duplicate) { res.status(409).json({ error: 'Portal username or email is already in use.' }); return; }
      newAccount = { username, password };
    }
    try {
      const created = db.transaction(() => {
        const info = db.prepare(
          `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id,
            status, hired_date, monthly_salary, monthly_allowance)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).run(employee_code.trim(), full_name.trim(), String(email || '').trim(), Number(department_id),
          Number(position_id), Number(shift_id), status === 'Inactive' ? 'Inactive' : 'Active',
          hired_date || getTodayDateString(), Number(monthly_salary) || 25000,
          Number(monthly_allowance) || 2000);
        const employeeId = Number(info.lastInsertRowid);
        if (newAccount) {
          const { hash, salt } = hashPassword(newAccount.password);
          db.prepare(`INSERT INTO users
            (username, email, full_name, role, department_id, employee_id,
             password_hash, salt, must_change_password, is_active)
             VALUES (?, ?, ?, 'Employee', ?, ?, ?, ?, 1, 1)`)
            .run(newAccount.username, String(email).trim(), full_name.trim(), Number(department_id),
              employeeId, hash, salt);
        }
        logAudit(db, req.user!.username, `Added employee ${full_name.trim()} (${employee_code.trim()})`,
          'Employees', 'Success', getClientIp(req));
        if (newAccount) {
          logAudit(db, req.user!.username, `Created employee portal login "${newAccount.username}"`,
            'Security', 'Success', getClientIp(req),
            { actionType: 'USER_CREATED', targetType: 'employee', targetId: employeeId,
              isSecurityEvent: true, after: { role: 'Employee', must_change_password: true } });
        }
        return employeeId;
      })();
      res.status(201).json({ id: created, account_created: Boolean(newAccount) });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to create employee';
      res.status(msg.includes('UNIQUE') ? 409 : 400).json({
        error: msg.includes('UNIQUE')
          ? 'Employee ID, portal username, or email already exists.'
          : 'Unable to create the employee record. Verify the selected department, position, and shift.',
      });
    }
  });

  router.put('/employees/:id', requirePermission('employees:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid employee ID.' });
      return;
    }
    const {
      employee_code,
      full_name,
      email,
      department_id,
      position_id,
      shift_id,
      status,
      hired_date,
      monthly_salary,
      monthly_allowance,
    } = req.body || {};

    if (!employee_code?.trim() || !full_name?.trim() || !department_id || !position_id || !shift_id) {
      res.status(400).json({ error: 'Employee ID, full name, department, position, and shift are required.' });
      return;
    }

    try {
      const result = db
        .prepare(
          `UPDATE employees
           SET employee_code = ?, full_name = ?, email = ?, department_id = ?, position_id = ?,
               shift_id = ?, status = ?, hired_date = ?, monthly_salary = ?, monthly_allowance = ?
           WHERE id = ?`
        )
        .run(
          employee_code.trim(),
          full_name.trim(),
          (email || '').trim(),
          Number(department_id),
          Number(position_id),
          Number(shift_id),
          status === 'Inactive' ? 'Inactive' : 'Active',
          hired_date || getTodayDateString(),
          Number(monthly_salary) || 25000,
          Number(monthly_allowance) || 2000,
          id
        );
      if (result.changes === 0) {
        res.status(404).json({ error: 'Employee not found.' });
        return;
      }
      logAudit(db, req.user!.username, `Updated employee ${full_name.trim()} (${employee_code.trim()})`, 'Employees', 'Success', getClientIp(req));
      res.json({ success: true });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Update failed';
      res.status(400).json({ error: msg.includes('UNIQUE') ? 'Employee ID already exists.' : msg });
    }
  });

  router.delete('/employees/:id', requirePermission('employees:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid employee ID.' });
      return;
    }
    const emp = db.prepare('SELECT employee_code, full_name FROM employees WHERE id = ?').get(id) as
      | { employee_code: string; full_name: string }
      | undefined;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }
    db.prepare('DELETE FROM employees WHERE id = ?').run(id);
    logAudit(db, req.user!.username, `Deleted employee ${emp.full_name} (${emp.employee_code})`, 'Employees', 'Warning', getClientIp(req));
    res.json({ success: true });
  });

  router.post('/employees/import', requirePermission('employees:write'), (req: AuthenticatedRequest, res) => {
    const { rows } = (req.body || {}) as {
      rows?: Array<{
        employee_code: string;
        full_name: string;
        email?: string;
        department_code?: string;
        position_code?: string;
        status?: string;
      }>;
    };
    if (!Array.isArray(rows) || rows.length === 0 || rows.length > 2000) {
      res.status(400).json({ error: 'Supply between 1 and 2000 valid rows for CSV import.' });
      return;
    }

    const defaultDept = db.prepare('SELECT id FROM departments ORDER BY id ASC LIMIT 1').get() as
      | { id: number }
      | undefined;
    const defaultPos = db.prepare('SELECT id, base_salary, allowance FROM positions ORDER BY id ASC LIMIT 1').get() as
      | { id: number; base_salary: number; allowance: number }
      | undefined;
    const defaultShift = db.prepare('SELECT id FROM shifts ORDER BY id ASC LIMIT 1').get() as
      | { id: number }
      | undefined;

    if (!defaultDept || !defaultPos || !defaultShift) {
      res.status(400).json({ error: 'Configure at least one department, position, and shift before importing employees.' });
      return;
    }

    let inserted = 0;
    let skipped = 0;

    const tx = db.transaction(() => {
      const stmt = db.prepare(`
        INSERT OR IGNORE INTO employees
          (employee_code, full_name, email, department_id, position_id, shift_id, status, hired_date, monthly_salary, monthly_allowance)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      for (const row of rows) {
        if (!row.employee_code?.trim() || !row.full_name?.trim()) {
          skipped++;
          continue;
        }
        const dept = row.department_code
          ? (db.prepare('SELECT id FROM departments WHERE upper(code) = upper(?)').get(row.department_code.trim()) as
              | { id: number }
              | undefined)
          : undefined;
        const pos = row.position_code
          ? (db
              .prepare('SELECT id, base_salary, allowance FROM positions WHERE upper(code) = upper(?)')
              .get(row.position_code.trim()) as { id: number; base_salary: number; allowance: number } | undefined)
          : undefined;

        const r = stmt.run(
          row.employee_code.trim(),
          row.full_name.trim(),
          (row.email || '').trim(),
          dept ? dept.id : defaultDept.id,
          pos ? pos.id : defaultPos.id,
          defaultShift.id,
          row.status === 'Inactive' ? 'Inactive' : 'Active',
          getTodayDateString(),
          pos ? pos.base_salary : defaultPos.base_salary,
          pos ? pos.allowance : defaultPos.allowance
        );
        if (r.changes > 0) inserted++;
        else skipped++;
      }
    });

    tx();
    logAudit(db, req.user!.username, `Imported ${inserted} employee(s) via CSV (${skipped} skipped)`, 'Employees', 'Success', getClientIp(req));
    res.json({ inserted, skipped });
  });

  // -------------------------------------------------------------------------
  // DEPARTMENTS
  // -------------------------------------------------------------------------
  router.get('/departments', requirePermission('org:read'), (_req, res) => {
    const rows = db
      .prepare(
        `SELECT d.*, COUNT(e.id) as employee_count
         FROM departments d
         LEFT JOIN employees e ON e.department_id = d.id
         GROUP BY d.id
         ORDER BY d.code ASC`
      )
      .all();
    res.json({ data: rows });
  });

  router.post('/departments', requirePermission('org:write'), (req: AuthenticatedRequest, res) => {
    const { code, name, head_name } = req.body || {};
    if (!code?.trim() || !name?.trim()) {
      res.status(400).json({ error: 'Department code and name are required.' });
      return;
    }
    try {
      const info = db
        .prepare('INSERT INTO departments (code, name, head_name) VALUES (?, ?, ?)')
        .run(code.trim().toUpperCase(), name.trim(), (head_name || '').trim());
      logAudit(db, req.user!.username, `Added department ${code.trim().toUpperCase()} — ${name.trim()}`, 'Departments', 'Success', getClientIp(req));
      res.status(201).json({ id: Number(info.lastInsertRowid) });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to add department';
      res.status(400).json({ error: msg.includes('UNIQUE') ? 'Department code already exists.' : msg });
    }
  });

  router.put('/departments/:id', requirePermission('org:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid department ID.' });
      return;
    }
    const { code, name, head_name } = req.body || {};
    if (!code?.trim() || !name?.trim()) {
      res.status(400).json({ error: 'Department code and name are required.' });
      return;
    }
    try {
      const r = db
        .prepare('UPDATE departments SET code = ?, name = ?, head_name = ? WHERE id = ?')
        .run(code.trim().toUpperCase(), name.trim(), (head_name || '').trim(), id);
      if (r.changes === 0) {
        res.status(404).json({ error: 'Department not found.' });
        return;
      }
      logAudit(db, req.user!.username, `Updated department ${code.trim().toUpperCase()}`, 'Departments', 'Success', getClientIp(req));
      res.json({ success: true });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to update department';
      res.status(400).json({ error: msg.includes('UNIQUE') ? 'Department code already exists.' : msg });
    }
  });

  router.delete('/departments/:id', requirePermission('org:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid department ID.' });
      return;
    }
    const count = (db.prepare('SELECT COUNT(*) as c FROM employees WHERE department_id = ?').get(id) as { c: number }).c;
    if (count > 0) {
      res.status(400).json({ error: `Cannot delete department with ${count} assigned employee(s). Reassign them first.` });
      return;
    }
    db.prepare('DELETE FROM departments WHERE id = ?').run(id);
    logAudit(db, req.user!.username, `Deleted department #${id}`, 'Departments', 'Warning', getClientIp(req));
    res.json({ success: true });
  });

  // -------------------------------------------------------------------------
  // POSITIONS
  // -------------------------------------------------------------------------
  router.get('/positions', requirePermission('org:read'), (_req, res) => {
    const rows = db
      .prepare(
        `SELECT p.*, COUNT(e.id) as employee_count
         FROM positions p
         LEFT JOIN employees e ON e.position_id = p.id
         GROUP BY p.id
         ORDER BY p.code ASC`
      )
      .all();
    res.json({ data: rows });
  });

  router.post('/positions', requirePermission('org:write'), (req: AuthenticatedRequest, res) => {
    const { code, name, type, base_salary, allowance } = req.body || {};
    if (!code?.trim() || !name?.trim()) {
      res.status(400).json({ error: 'Position code and name are required.' });
      return;
    }
    try {
      const info = db
        .prepare('INSERT INTO positions (code, name, type, base_salary, allowance) VALUES (?, ?, ?, ?, ?)')
        .run(code.trim().toUpperCase(), name.trim(), type || 'Regular', Number(base_salary) || 25000, Number(allowance) || 2000);
      logAudit(db, req.user!.username, `Added position ${code.trim().toUpperCase()} — ${name.trim()}`, 'Positions', 'Success', getClientIp(req));
      res.status(201).json({ id: Number(info.lastInsertRowid) });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to create position';
      res.status(400).json({ error: msg.includes('UNIQUE') ? 'Position code already exists.' : msg });
    }
  });

  router.put('/positions/:id', requirePermission('org:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid position ID.' });
      return;
    }
    const { code, name, type, base_salary, allowance } = req.body || {};
    if (!code?.trim() || !name?.trim()) {
      res.status(400).json({ error: 'Position code and name are required.' });
      return;
    }
    try {
      const r = db
        .prepare('UPDATE positions SET code = ?, name = ?, type = ?, base_salary = ?, allowance = ? WHERE id = ?')
        .run(code.trim().toUpperCase(), name.trim(), type || 'Regular', Number(base_salary) || 25000, Number(allowance) || 2000, id);
      if (r.changes === 0) {
        res.status(404).json({ error: 'Position not found.' });
        return;
      }
      logAudit(db, req.user!.username, `Updated position ${code.trim().toUpperCase()}`, 'Positions', 'Success', getClientIp(req));
      res.json({ success: true });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Update failed';
      res.status(400).json({ error: msg.includes('UNIQUE') ? 'Position code already exists.' : msg });
    }
  });

  router.delete('/positions/:id', requirePermission('org:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid position ID.' });
      return;
    }
    const count = (db.prepare('SELECT COUNT(*) as c FROM employees WHERE position_id = ?').get(id) as { c: number }).c;
    if (count > 0) {
      res.status(400).json({ error: `Cannot delete position with ${count} assigned employee(s).` });
      return;
    }
    db.prepare('DELETE FROM positions WHERE id = ?').run(id);
    logAudit(db, req.user!.username, `Deleted position #${id}`, 'Positions', 'Warning', getClientIp(req));
    res.json({ success: true });
  });

  // -------------------------------------------------------------------------
  // SHIFTS & SCHEDULES
  // -------------------------------------------------------------------------
  router.get('/shifts', requirePermission('org:read'), (_req, res) => {
    const rows = db.prepare('SELECT * FROM shifts ORDER BY id ASC').all();
    res.json({ data: rows });
  });

  router.post('/shifts', requirePermission('org:write'), (req: AuthenticatedRequest, res) => {
    const { name, time_in, time_out, grace_minutes, status, rest_days } = req.body || {};
    if (!name?.trim() || !time_in?.trim() || !time_out?.trim()) {
      res.status(400).json({ error: 'Shift name, time in, and time out are required.' });
      return;
    }
    try {
      const info = db
        .prepare('INSERT INTO shifts (name, time_in, time_out, grace_minutes, status, rest_days) VALUES (?, ?, ?, ?, ?, ?)')
        .run(
          name.trim(),
          time_in.trim(),
          time_out.trim(),
          Number(grace_minutes) || 15,
          status || 'Active',
          typeof rest_days === 'string' ? rest_days.trim() : ''
        );
      logAudit(db, req.user!.username, `Created work shift "${name.trim()}"`, 'Shifts', 'Success', getClientIp(req));
      res.status(201).json({ id: Number(info.lastInsertRowid) });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to create shift';
      res.status(400).json({ error: msg.includes('UNIQUE') ? 'Shift name already exists.' : msg });
    }
  });

  router.put('/shifts/:id', requirePermission('org:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid shift ID.' });
      return;
    }
    const { name, time_in, time_out, grace_minutes, status, rest_days } = req.body || {};
    if (!name?.trim() || !time_in?.trim() || !time_out?.trim()) {
      res.status(400).json({ error: 'Shift name, time in, and time out are required.' });
      return;
    }
    try {
      const r = db
        .prepare('UPDATE shifts SET name = ?, time_in = ?, time_out = ?, grace_minutes = ?, status = ?, rest_days = COALESCE(?, rest_days) WHERE id = ?')
        .run(
          name.trim(),
          time_in.trim(),
          time_out.trim(),
          Number(grace_minutes) || 15,
          status || 'Active',
          typeof rest_days === 'string' ? rest_days.trim() : null,
          id
        );
      if (r.changes === 0) {
        res.status(404).json({ error: 'Shift not found.' });
        return;
      }
      logAudit(db, req.user!.username, `Updated work shift "${name.trim()}"`, 'Shifts', 'Success', getClientIp(req));
      res.json({ success: true });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Update failed';
      res.status(400).json({ error: msg });
    }
  });

  router.delete('/shifts/:id', requirePermission('org:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid shift ID.' });
      return;
    }
    const count = (db.prepare('SELECT COUNT(*) as c FROM employees WHERE shift_id = ?').get(id) as { c: number }).c;
    if (count > 0) {
      res.status(400).json({ error: `Cannot delete shift assigned to ${count} employee(s).` });
      return;
    }
    db.prepare('DELETE FROM shifts WHERE id = ?').run(id);
    logAudit(db, req.user!.username, `Deleted shift #${id}`, 'Shifts', 'Warning', getClientIp(req));
    res.json({ success: true });
  });

  // -------------------------------------------------------------------------
  // HOLIDAYS
  // -------------------------------------------------------------------------
  router.get('/holidays', requirePermission('org:read'), (_req, res) => {
    const rows = db.prepare('SELECT * FROM holidays ORDER BY date ASC').all();
    res.json({ data: rows });
  });

  router.post('/holidays', requirePermission('org:write'), (req: AuthenticatedRequest, res) => {
    const { date, name, type } = req.body || {};
    if (!isIsoDateString(date) || !name?.trim()) {
      res.status(400).json({ error: 'Valid holiday date (YYYY-MM-DD) and name are required.' });
      return;
    }
    const info = db
      .prepare('INSERT INTO holidays (date, name, type) VALUES (?, ?, ?)')
      .run(date.trim(), name.trim(), type || 'Regular');
    logAudit(db, req.user!.username, `Added holiday "${name.trim()}" (${date.trim()})`, 'Holidays', 'Success', getClientIp(req));
    res.status(201).json({ id: Number(info.lastInsertRowid) });
  });

  router.put('/holidays/:id', requirePermission('org:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid holiday ID.' });
      return;
    }
    const { date, name, type } = req.body || {};
    if (!isIsoDateString(date) || !name?.trim()) {
      res.status(400).json({ error: 'Valid holiday date (YYYY-MM-DD) and name are required.' });
      return;
    }
    const r = db
      .prepare('UPDATE holidays SET date = ?, name = ?, type = ? WHERE id = ?')
      .run(date.trim(), name.trim(), type || 'Regular', id);
    if (r.changes === 0) {
      res.status(404).json({ error: 'Holiday not found.' });
      return;
    }
    logAudit(db, req.user!.username, `Updated holiday "${name.trim()}"`, 'Holidays', 'Success', getClientIp(req));
    res.json({ success: true });
  });

  router.delete('/holidays/:id', requirePermission('org:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid holiday ID.' });
      return;
    }
    db.prepare('DELETE FROM holidays WHERE id = ?').run(id);
    logAudit(db, req.user!.username, `Deleted holiday #${id}`, 'Holidays', 'Warning', getClientIp(req));
    res.json({ success: true });
  });

  // -------------------------------------------------------------------------
  // ATTENDANCE RECORDS, IMMUTABLE PUNCH HISTORY & RECONCILIATION
  // -------------------------------------------------------------------------
  router.get('/attendance', requirePermission('attendance:read', 'attendance:read_self'), (req: AuthenticatedRequest, res) => {
    const date = ((req.query.date as string) || getTodayDateString(getNowMs())).trim();
    let deptId = req.query.department_id ? Number(req.query.department_id) : null;
    const status = ((req.query.status as string) || '').trim();
    const search = ((req.query.search as string) || '').trim();

    const where: string[] = ['a.date = ?'];
    const params: unknown[] = [date];

    if (req.user!.role === 'Employee') {
      if (req.user!.employee_id === null) {
        res.status(403).json({ error: 'Employee account is not linked to an employee record.' });
        return;
      }
      where.push('a.employee_id = ?');
      params.push(req.user!.employee_id);
      deptId = null;
    } else if (req.user!.role === 'Department Head') {
      if (req.user!.department_id === null) {
        res.status(403).json({ error: 'Department Head account is not assigned to a department.' });
        return;
      }
      deptId = req.user!.department_id;
    }

    if (deptId) {
      where.push('e.department_id = ?');
      params.push(deptId);
    }
    if (status) {
      where.push('a.status = ?');
      params.push(status);
    }
    if (search) {
      where.push('(e.employee_code LIKE ? OR e.full_name LIKE ?)');
      params.push(`%${search}%`, `%${search}%`);
    }

    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(200, Math.max(1, Number(req.query.limit) || 50));
    const offset = (page - 1) * limit;

    const total = (
      db
        .prepare(
          `SELECT COUNT(*) as c
           FROM attendance_records a
           JOIN employees e ON a.employee_id = e.id
           JOIN departments d ON e.department_id = d.id
           WHERE ${where.join(' AND ')}`
        )
        .get(...params) as { c: number }
    ).c;

    const rows = db
      .prepare(
        `SELECT a.*, e.employee_code, e.full_name as employee_name, d.code as department_code, d.name as department_name
         FROM attendance_records a
         JOIN employees e ON a.employee_id = e.id
         JOIN departments d ON e.department_id = d.id
         WHERE ${where.join(' AND ')}
         ORDER BY e.employee_code ASC
         LIMIT ? OFFSET ?`
      )
      .all(...params, limit, offset);

    res.json({ data: rows, date, total, page, limit });
  });

  router.get('/attendance/:id/events', requirePermission('attendance:read', 'attendance:read_self'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid attendance record ID.' });
      return;
    }
    const rec = db
      .prepare('SELECT id, employee_id, date FROM attendance_records WHERE id = ?')
      .get(id) as { id: number; employee_id: number; date: string } | undefined;
    if (!rec) {
      res.status(404).json({ error: 'Attendance record not found.' });
      return;
    }
    if (!checkEmployeeScope(db, req.user, rec.employee_id)) {
      res.status(403).json({ error: 'Access denied for this employee attendance history.', code: 'FORBIDDEN' });
      return;
    }
    const events = db
      .prepare(
        `SELECT id, event_uid, employee_id, device_id, device_name, attendance_date, punch_type, punch_time,
                server_timestamp_utc, manila_timestamp, device_timestamp_utc, clock_drift_seconds,
                offline_replay, decision, decision_code, decision_reason, source, recorded_at
         FROM attendance_events
         WHERE employee_id = ? AND attendance_date = ?
         ORDER BY id ASC`
      )
      .all(rec.employee_id, rec.date);
    res.json({ record_id: rec.id, shift_date: rec.date, data: events });
  });

  router.post('/attendance/reconcile', requirePermission('attendance:write'), (req: AuthenticatedRequest, res) => {
    const { date, force_past_shift_end } = (req.body || {}) as {
      date?: string;
      force_past_shift_end?: boolean;
    };
    const targetDate = typeof date === 'string' && date.trim() ? date.trim() : addDaysIso(getTodayDateString(getNowMs()), -1);
    if (!isIsoDateString(targetDate)) {
      res.status(400).json({ error: 'Valid reconciliation shift date (YYYY-MM-DD) is required.' });
      return;
    }
    const summary = reconcileAttendanceForDate(db, targetDate, {
      serverNowUtc: getNowMs(),
      actorUsername: req.user!.username,
      clientIp: getClientIp(req),
      forcePastShiftEnd: force_past_shift_end === true,
    });
    res.json({ success: true, summary });
  });

  router.post('/attendance', requirePermission('attendance:write'), (req: AuthenticatedRequest, res) => {
    const { employee_id, date, time_in, time_out, break_out, break_in, overtime_out, status, device_name, remarks } =
      req.body || {};
    if (!employee_id || !isIsoDateString(date)) {
      res.status(400).json({ error: 'Employee and valid date (YYYY-MM-DD) are required.' });
      return;
    }
    const cleanIn = time_in ? String(time_in).trim() : null;
    const cleanOut = time_out ? String(time_out).trim() : null;
    const cleanBreakOut = break_out ? String(break_out).trim() : null;
    const cleanBreakIn = break_in ? String(break_in).trim() : null;
    const cleanOtOut = overtime_out ? String(overtime_out).trim() : null;
    const finalStatus = status ? String(status).trim() : cleanIn ? 'Present' : 'Absent';
    if (!isApprovedAttendanceStatus(finalStatus)) {
      res.status(400).json({
        error: `Invalid attendance status. Approved statuses: ${APPROVED_ATTENDANCE_STATUSES.join(', ')}.`,
      });
      return;
    }

    const noTimeStatuses = new Set(['Absent', 'On Leave', 'No Schedule']);
    const effectiveIn = noTimeStatuses.has(finalStatus) ? null : cleanIn;
    const effectiveOut = noTimeStatuses.has(finalStatus) || finalStatus === 'Missing Time Out' ? null : cleanOut;
    const workHours =
      noTimeStatuses.has(finalStatus)
        ? '-'
        : finalStatus === 'Missing Time Out'
          ? 'Incomplete'
          : computeWorkHoursFromStrings(effectiveIn, effectiveOut);

    const nowMs = getNowMs();
    const manilaNow = toManilaParts(nowMs);
    const serverIso = new Date(nowMs).toISOString();

    const tx = db.transaction(() => {
      db.prepare(
        `INSERT INTO attendance_records
          (employee_id, date, time_in, time_out, break_out, break_in, overtime_out, work_hours, status, device_name, remarks)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(employee_id, date) DO UPDATE SET
           time_in = excluded.time_in,
           time_out = excluded.time_out,
           break_out = COALESCE(excluded.break_out, attendance_records.break_out),
           break_in = COALESCE(excluded.break_in, attendance_records.break_in),
           overtime_out = COALESCE(excluded.overtime_out, attendance_records.overtime_out),
           work_hours = excluded.work_hours,
           status = excluded.status,
           device_name = excluded.device_name,
           remarks = excluded.remarks`
      ).run(
        Number(employee_id),
        date,
        effectiveIn,
        effectiveOut,
        noTimeStatuses.has(finalStatus) ? null : cleanBreakOut,
        noTimeStatuses.has(finalStatus) ? null : cleanBreakIn,
        noTimeStatuses.has(finalStatus) ? null : cleanOtOut,
        workHours,
        finalStatus,
        device_name || 'Admin Manual Entry',
        remarks || ''
      );

      db.prepare(
        `INSERT INTO attendance_events
          (event_uid, employee_id, device_id, device_name, attendance_date, punch_type, punch_time,
           server_timestamp_utc, manila_timestamp, decision, decision_code, decision_reason, source)
         VALUES (?, ?, NULL, ?, ?, 'manual', ?, ?, ?, 'ACCEPTED', 'MANUAL_ADMIN_ENTRY', ?, 'admin_portal')`
      ).run(
        `man-${employee_id}-${date}-${crypto.randomBytes(6).toString('hex')}`,
        Number(employee_id),
        `Portal (${req.user!.username})`,
        date,
        effectiveIn || manilaNow.time12,
        serverIso,
        manilaNow.isoTimestamp,
        `Manual attendance record saved (${finalStatus})`
      );
    });
    tx();

    const empRow = db.prepare('SELECT employee_code, full_name, department_id FROM employees WHERE id = ?').get(Number(employee_id)) as
      | { employee_code: string; full_name: string; department_id: number }
      | undefined;

    logAudit(db, req.user!.username, `Recorded attendance for employee #${employee_id} on ${date} (${finalStatus})`, 'Attendance', 'Success', getClientIp(req));
    if (empRow && (finalStatus === 'Absent' || finalStatus === 'Missing Time In' || finalStatus === 'Missing Time Out')) {
      createTargetedNotification(db, realtimeHub, {
        title: `Attendance exception (${finalStatus}) — ${empRow.full_name}`,
        message: `Employee ${empRow.employee_code} recorded status "${finalStatus}" for shift date ${date}.`,
        category: 'Attendance Alerts',
        priority: finalStatus === 'Absent' ? 'Medium' : 'High',
        actionModule: 'attendance',
        targetRoles: ['Administrator', 'HR Officer', 'Department Head'],
        eventType: 'attendance_exception',
        dedupeKey: `att_exc_${employee_id}_${date}_${finalStatus}`,
      });
    }
    realtimeHub.emitAttendanceUpdated({
      employee_id: Number(employee_id),
      employee_code: empRow?.employee_code,
      department_id: empRow?.department_id ?? null,
      shift_date: date,
      action: 'MANUAL_ENTRY',
      status: finalStatus,
      time: effectiveIn,
      source: 'admin_portal',
    });
    res.status(201).json({ success: true });
  });

  router.delete('/attendance/:id', requirePermission('attendance:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid attendance record ID.' });
      return;
    }
    const existing = db
      .prepare(
        `SELECT a.employee_id, a.date, e.employee_code, e.department_id
         FROM attendance_records a JOIN employees e ON a.employee_id = e.id WHERE a.id = ?`
      )
      .get(id) as { employee_id: number; date: string; employee_code: string; department_id: number } | undefined;
    db.prepare('DELETE FROM attendance_records WHERE id = ?').run(id);
    logAudit(db, req.user!.username, `Deleted attendance record #${id}`, 'Attendance', 'Warning', getClientIp(req));
    if (existing) {
      realtimeHub.emitAttendanceUpdated({
        employee_id: existing.employee_id,
        employee_code: existing.employee_code,
        department_id: existing.department_id,
        shift_date: existing.date,
        action: 'DELETED',
        source: 'admin_portal',
      });
    }
    res.json({ success: true });
  });

  // -------------------------------------------------------------------------
  // CORRECTIONS (BUILD 11 — Zero Fabricated Punches, Immutable Audit, Reversible)
  // -------------------------------------------------------------------------
  router.get('/corrections', requirePermission('corrections:read', 'corrections:read_self'), (req: AuthenticatedRequest, res) => {
    const status = ((req.query.status as string) || '').trim();
    const where: string[] = [];
    const params: unknown[] = [];

    if (status && status !== 'All') {
      where.push('c.status = ?');
      params.push(status);
    }
    if (req.user!.role === 'Employee') {
      if (req.user!.employee_id === null) {
        res.status(403).json({ error: 'Employee account is not linked to an employee record.' });
        return;
      }
      where.push('c.employee_id = ?');
      params.push(req.user!.employee_id);
    } else if (req.user!.role === 'Department Head') {
      if (req.user!.department_id === null) {
        res.status(403).json({ error: 'Department Head account is not assigned to a department.' });
        return;
      }
      where.push('e.department_id = ?');
      params.push(req.user!.department_id);
    }

    const whereSql = where.length > 0 ? `WHERE ${where.join(' AND ')}` : '';
    const rows = db
      .prepare(
        `SELECT c.id, c.employee_id, c.attendance_date, c.request_type, c.requested_time, c.requested_time_out,
                c.reason, c.status, c.reviewed_by, c.reviewed_by_user_id, c.reviewed_at, c.reviewed_at_utc,
                c.reviewer_notes, c.original_time_in, c.original_time_out, c.original_status,
                c.original_work_hours, c.approved_time, c.approved_time_out,
                c.attachment_name, c.attachment_mime,
                CASE WHEN c.attachment_data != '' THEN 1 ELSE 0 END as has_attachment,
                c.document_reference, c.reversed_by, c.reversed_at_utc, c.reversal_reason,
                c.created_by_username, c.created_at,
                e.employee_code, e.full_name as employee_name, d.code as department_code,
                a.time_in as current_time_in, a.time_out as current_time_out, a.status as current_attendance_status
         FROM corrections c
         JOIN employees e ON c.employee_id = e.id
         JOIN departments d ON e.department_id = d.id
         LEFT JOIN attendance_records a ON a.employee_id = c.employee_id AND a.date = c.attendance_date
         ${whereSql}
         ORDER BY CASE c.status WHEN 'Pending' THEN 0 ELSE 1 END, c.id DESC`
      )
      .all(...params);

    const scopeWhere: string[] = [];
    const scopeParams: unknown[] = [];
    if (req.user!.role === 'Employee') {
      scopeWhere.push('c.employee_id = ?');
      scopeParams.push(req.user!.employee_id);
    } else if (req.user!.role === 'Department Head') {
      scopeWhere.push('e.department_id = ?');
      scopeParams.push(req.user!.department_id);
    }
    const scopeSql = scopeWhere.length ? `WHERE ${scopeWhere.join(' AND ')}` : '';
    const counts = db
      .prepare(`SELECT c.status, COUNT(*) as c FROM corrections c JOIN employees e ON c.employee_id = e.id ${scopeSql} GROUP BY c.status`)
      .all(...scopeParams) as Array<{ status: string; c: number }>;

    res.json({ data: rows, counts });
  });

  router.get('/corrections/:id/audit', requirePermission('corrections:read', 'corrections:read_self'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid correction ID.' });
      return;
    }
    const corr = db
      .prepare(
        `SELECT c.*, e.employee_code, e.full_name as employee_name, e.department_id, d.code as department_code
         FROM corrections c
         JOIN employees e ON c.employee_id = e.id
         JOIN departments d ON e.department_id = d.id
         WHERE c.id = ?`
      )
      .get(id) as
      | { id: number; employee_id: number; department_id: number; attachment_data?: string }
      | undefined;
    if (!corr) {
      res.status(404).json({ error: 'Correction request not found.' });
      return;
    }
    if (req.user!.role === 'Employee' && req.user!.employee_id !== corr.employee_id) {
      res.status(403).json({ error: 'Access denied.', code: 'FORBIDDEN' });
      return;
    }
    if (req.user!.role === 'Department Head' && req.user!.department_id !== corr.department_id) {
      res.status(403).json({ error: 'Access denied.', code: 'FORBIDDEN' });
      return;
    }
    const audit = db
      .prepare('SELECT * FROM correction_audit_log WHERE correction_id = ? ORDER BY id ASC')
      .all(id);
    res.json({ correction: corr, audit });
  });

  router.post('/corrections', requirePermission('corrections:create'), (req: AuthenticatedRequest, res) => {
    const {
      employee_id,
      attendance_date,
      request_type,
      requested_time,
      requested_time_out,
      reason,
      attachment_name,
      attachment_mime,
      attachment_data,
      document_reference,
    } = req.body || {};
    const targetEmpId = req.user!.role === 'Employee' && !employee_id ? req.user!.employee_id : Number(employee_id);

    if (!targetEmpId || !isIsoDateString(attendance_date) || !requested_time?.trim()) {
      res.status(400).json({ error: 'Employee, valid attendance date (YYYY-MM-DD), and requested time are required.' });
      return;
    }

    if (!checkEmployeeScope(db, req.user, targetEmpId)) {
      res.status(403).json({ error: 'Access denied: you may only file corrections within your authorized scope.', code: 'FORBIDDEN' });
      return;
    }

    const outcome = createCorrectionRequest(db, {
      employee_id: targetEmpId,
      attendance_date,
      request_type: request_type || 'Time In',
      requested_time,
      requested_time_out,
      reason: reason || '',
      attachment_name,
      attachment_mime,
      attachment_data,
      document_reference,
      actor: {
        userId: req.user!.id,
        username: req.user!.username,
        role: req.user!.role,
        ipAddress: getClientIp(req),
      },
      nowMs: getNowMs(),
    });

    if (outcome.statusCode === 201) {
      realtimeHub.emitNotificationCreated({
        title: 'Attendance correction pending approval',
        category: 'Attendance Alerts',
        priority: 'Medium',
        action_module: 'corrections',
      });
    }
    res.status(outcome.statusCode).json(outcome.body);
  });

  router.patch('/corrections/:id/status', requirePermission('corrections:approve'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid correction ID.' });
      return;
    }
    const { status, approved_time, approved_time_out, reviewer_notes } = (req.body || {}) as {
      status?: 'Approved' | 'Rejected';
      approved_time?: string;
      approved_time_out?: string;
      reviewer_notes?: string;
    };
    if (status !== 'Approved' && status !== 'Rejected') {
      res.status(400).json({ error: 'Status must be Approved or Rejected.' });
      return;
    }

    const outcome = reviewCorrectionRequest(db, {
      correctionId: id,
      status,
      approved_time,
      approved_time_out,
      reviewer_notes,
      actor: {
        userId: req.user!.id,
        username: req.user!.username,
        role: req.user!.role,
        ipAddress: getClientIp(req),
      },
      departmentScopeId: req.user!.role === 'Department Head' ? req.user!.department_id : null,
      nowMs: getNowMs(),
    });

    if (outcome.realtimeAttendanceEvents) {
      for (const ev of outcome.realtimeAttendanceEvents) {
        realtimeHub.emitAttendanceUpdated(ev);
      }
    }
    if (outcome.statusCode === 200) {
      const corrRow = db
        .prepare('SELECT employee_id, attendance_date FROM corrections WHERE id = ?')
        .get(id) as { employee_id: number; attendance_date: string } | undefined;
      if (corrRow) {
        realtimeHub.emitEmployeeNotification(corrRow.employee_id, {
          type: 'Attendance Correction',
          title: `Correction request ${status}`,
          ref: `AC-${(corrRow.attendance_date || '').slice(0, 4)}-${String(id).padStart(5, '0')}`,
        });
      }
    }
    res.status(outcome.statusCode).json(outcome.body);
  });

  router.post('/corrections/:id/reverse', requirePermission('corrections:approve'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid correction ID.' });
      return;
    }
    const { reversal_reason } = (req.body || {}) as { reversal_reason?: string };
    const outcome = reverseCorrectionRequest(db, {
      correctionId: id,
      reversal_reason: reversal_reason || '',
      actor: {
        userId: req.user!.id,
        username: req.user!.username,
        role: req.user!.role,
        ipAddress: getClientIp(req),
      },
      departmentScopeId: req.user!.role === 'Department Head' ? req.user!.department_id : null,
      nowMs: getNowMs(),
    });

    if (outcome.realtimeAttendanceEvents) {
      for (const ev of outcome.realtimeAttendanceEvents) {
        realtimeHub.emitAttendanceUpdated(ev);
      }
    }
    res.status(outcome.statusCode).json(outcome.body);
  });

  // -------------------------------------------------------------------------
  // LEAVES MANAGEMENT (BUILD 11 — Configurable Policies, Per-Day Propagation, Cancellation)
  // -------------------------------------------------------------------------
  router.get('/leaves/policies', requirePermission('leaves:read', 'leaves:read_self'), (_req, res) => {
    res.json({ data: getLeavePolicies(db) });
  });

  router.put('/leaves/policies/:id', requirePermission('leaves:approve'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid leave policy ID.' });
      return;
    }
    const existing = db.prepare('SELECT * FROM leave_policies WHERE id = ?').get(id) as
      | { id: number; leave_type: string }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Leave policy not found.' });
      return;
    }
    const {
      annual_entitlement,
      track_balance,
      allow_half_day,
      exclude_weekends_rest_days,
      exclude_holidays,
      allow_negative_balance,
      requires_document_after_days,
    } = (req.body || {}) as Record<string, unknown>;

    const entitlement = Number(annual_entitlement);
    const docThreshold = Number(requires_document_after_days ?? 0);
    if (!Number.isFinite(entitlement) || entitlement < 0 || entitlement > 365) {
      res.status(400).json({ error: 'annual_entitlement must be a number between 0 and 365.' });
      return;
    }
    if (!Number.isFinite(docThreshold) || docThreshold < 0 || docThreshold > 365) {
      res.status(400).json({ error: 'requires_document_after_days must be a number between 0 and 365.' });
      return;
    }

    db.prepare(
      `UPDATE leave_policies
       SET annual_entitlement = ?,
           track_balance = ?,
           allow_half_day = ?,
           exclude_weekends_rest_days = ?,
           exclude_holidays = ?,
           allow_negative_balance = ?,
           requires_document_after_days = ?,
           updated_by = ?,
           updated_at = datetime('now', 'localtime')
       WHERE id = ?`
    ).run(
      entitlement,
      track_balance ? 1 : 0,
      allow_half_day ? 1 : 0,
      exclude_weekends_rest_days ? 1 : 0,
      exclude_holidays ? 1 : 0,
      allow_negative_balance ? 1 : 0,
      docThreshold,
      req.user!.username,
      id
    );

    logAudit(
      db,
      req.user!.username,
      `Updated leave policy "${existing.leave_type}" (entitlement=${entitlement}d, docAfter=${docThreshold}d)`,
      'Leaves',
      'Success',
      getClientIp(req)
    );
    const updated = db.prepare('SELECT * FROM leave_policies WHERE id = ?').get(id);
    res.json({ success: true, policy: updated });
  });

  router.get('/leaves/preview', requirePermission('leaves:create', 'leaves:read', 'leaves:read_self'), (req: AuthenticatedRequest, res) => {
    const rawEmpId = req.query.employee_id ? Number(req.query.employee_id) : null;
    const targetEmpId = req.user!.role === 'Employee' ? req.user!.employee_id : rawEmpId;
    const leaveType = String(req.query.leave_type || '').trim();
    const startDate = String(req.query.start_date || '').trim();
    const endDate = String(req.query.end_date || '').trim();
    const dayPortion = (String(req.query.day_portion || 'FULL').trim() as LeaveDayPortion) || 'FULL';

    if (!targetEmpId || !leaveType || !startDate || !endDate) {
      res.status(400).json({ error: 'employee_id, leave_type, start_date, and end_date are required.' });
      return;
    }
    if (!checkEmployeeScope(db, req.user, targetEmpId)) {
      res.status(403).json({ error: 'Access denied for preview outside authorized scope.', code: 'FORBIDDEN' });
      return;
    }

    const evalRes = evaluateLeaveRequestDates(db, {
      employeeId: targetEmpId,
      leaveType,
      startDate,
      endDate,
      dayPortion,
    });
    if (!evalRes.ok) {
      res.status(evalRes.statusCode).json({ error: evalRes.error, code: evalRes.code });
      return;
    }
    res.json(evalRes.evaluation);
  });

  router.get('/leaves', requirePermission('leaves:read', 'leaves:read_self'), (req: AuthenticatedRequest, res) => {
    const status = ((req.query.status as string) || '').trim();
    const requestedYear = req.query.year ? Number(req.query.year) : toManilaParts(getNowMs()).year;
    const balanceYear = Number.isInteger(requestedYear) && requestedYear >= 2000 && requestedYear <= 2100
      ? requestedYear
      : toManilaParts(getNowMs()).year;

    const where: string[] = [];
    const params: unknown[] = [];

    if (status && status !== 'All') {
      where.push('l.status = ?');
      params.push(status);
    }

    let scopedEmpId: number | null = null;
    let scopedDeptId: number | null = null;

    if (req.user!.role === 'Employee') {
      if (req.user!.employee_id === null) {
        res.status(403).json({ error: 'Employee account is not linked to an employee record.' });
        return;
      }
      where.push('l.employee_id = ?');
      params.push(req.user!.employee_id);
      scopedEmpId = req.user!.employee_id;
    } else if (req.user!.role === 'Department Head') {
      if (req.user!.department_id === null) {
        res.status(403).json({ error: 'Department Head account is not assigned to a department.' });
        return;
      }
      where.push('e.department_id = ?');
      params.push(req.user!.department_id);
      scopedDeptId = req.user!.department_id;
    }

    const whereSql = where.length > 0 ? `WHERE ${where.join(' AND ')}` : '';
    const rows = db
      .prepare(
        `SELECT l.id, l.employee_id, l.leave_type, l.start_date, l.end_date, l.days_count,
                l.day_portion, l.calendar_days, l.excluded_days_json, l.eligible_dates_json,
                l.reason, l.status, l.reviewed_by, l.reviewed_at, l.reviewed_at_utc, l.reviewer_notes,
                l.cancelled_by, l.cancelled_at_utc, l.cancel_reason,
                l.attachment_name, l.attachment_mime,
                CASE WHEN l.attachment_data != '' THEN 1 ELSE 0 END as has_attachment,
                l.document_reference, l.created_by_username, l.created_at,
                e.employee_code, e.full_name as employee_name, d.code as department_code
         FROM leaves l
         JOIN employees e ON l.employee_id = e.id
         JOIN departments d ON e.department_id = d.id
         ${whereSql}
         ORDER BY CASE l.status WHEN 'Pending' THEN 0 ELSE 1 END, l.start_date DESC, l.id DESC`
      )
      .all(...params);

    const balances = computeEmployeeLeaveBalances(db, {
      year: balanceYear,
      departmentId: scopedDeptId,
      employeeId: scopedEmpId,
    });
    const policies = getLeavePolicies(db);

    res.json({ data: rows, balances, policies, year: balanceYear });
  });

  router.get('/leaves/:id/details', requirePermission('leaves:read', 'leaves:read_self'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid leave ID.' });
      return;
    }
    const leave = db
      .prepare(
        `SELECT l.*, e.employee_code, e.full_name as employee_name, e.department_id, d.code as department_code
         FROM leaves l
         JOIN employees e ON l.employee_id = e.id
         JOIN departments d ON e.department_id = d.id
         WHERE l.id = ?`
      )
      .get(id) as { id: number; employee_id: number; department_id: number } | undefined;
    if (!leave) {
      res.status(404).json({ error: 'Leave request not found.' });
      return;
    }
    if (req.user!.role === 'Employee' && req.user!.employee_id !== leave.employee_id) {
      res.status(403).json({ error: 'Access denied.', code: 'FORBIDDEN' });
      return;
    }
    if (req.user!.role === 'Department Head' && req.user!.department_id !== leave.department_id) {
      res.status(403).json({ error: 'Access denied.', code: 'FORBIDDEN' });
      return;
    }

    const allocations = db
      .prepare('SELECT * FROM leave_day_allocations WHERE leave_id = ? ORDER BY leave_date ASC')
      .all(id);
    const audit = db
      .prepare('SELECT * FROM leave_audit_log WHERE leave_id = ? ORDER BY id ASC')
      .all(id);

    res.json({ leave, allocations, audit });
  });

  router.post('/leaves', requirePermission('leaves:create'), (req: AuthenticatedRequest, res) => {
    const {
      employee_id,
      leave_type,
      start_date,
      end_date,
      day_portion,
      reason,
      attachment_name,
      attachment_mime,
      attachment_data,
      document_reference,
    } = req.body || {};
    const targetEmpId = req.user!.role === 'Employee' && !employee_id ? req.user!.employee_id : Number(employee_id);

    if (!targetEmpId || !leave_type?.trim() || !isIsoDateString(start_date) || !isIsoDateString(end_date)) {
      res.status(400).json({ error: 'Employee, leave type, and valid start/end dates (YYYY-MM-DD) are required.' });
      return;
    }

    if (!checkEmployeeScope(db, req.user, targetEmpId)) {
      res.status(403).json({ error: 'Access denied: you may only file leave within your authorized scope.', code: 'FORBIDDEN' });
      return;
    }

    const outcome = createLeaveRequest(db, {
      employee_id: targetEmpId,
      leave_type: leave_type.trim(),
      start_date,
      end_date,
      day_portion: (day_portion || 'FULL') as LeaveDayPortion,
      reason: reason || '',
      attachment_name,
      attachment_mime,
      attachment_data,
      document_reference,
      actor: {
        userId: req.user!.id,
        username: req.user!.username,
        role: req.user!.role,
        ipAddress: getClientIp(req),
      },
      nowMs: getNowMs(),
    });

    if (outcome.statusCode === 201) {
      realtimeHub.emitNotificationCreated({
        title: 'New leave request submitted',
        category: 'Attendance Alerts',
        priority: 'Medium',
        action_module: 'leaves',
      });
    }
    res.status(outcome.statusCode).json(outcome.body);
  });

  router.patch('/leaves/:id/status', requirePermission('leaves:approve'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid leave ID.' });
      return;
    }
    const { status, reviewer_notes, conflict_resolution } = (req.body || {}) as {
      status?: 'Approved' | 'Rejected';
      reviewer_notes?: string;
      conflict_resolution?: 'BLOCK' | 'PRESERVE_PUNCHES';
    };
    if (status !== 'Approved' && status !== 'Rejected') {
      res.status(400).json({ error: 'Status must be Approved or Rejected.' });
      return;
    }

    const outcome = reviewLeaveRequest(db, {
      leaveId: id,
      status,
      reviewer_notes,
      conflict_resolution,
      actor: {
        userId: req.user!.id,
        username: req.user!.username,
        role: req.user!.role,
        ipAddress: getClientIp(req),
      },
      departmentScopeId: req.user!.role === 'Department Head' ? req.user!.department_id : null,
      nowMs: getNowMs(),
    });

    if (outcome.realtimeAttendanceEvents) {
      for (const ev of outcome.realtimeAttendanceEvents) {
        realtimeHub.emitAttendanceUpdated(ev);
      }
    }
    if (outcome.statusCode === 200) {
      const leaveRow = db
        .prepare('SELECT employee_id, start_date FROM leaves WHERE id = ?')
        .get(id) as { employee_id: number; start_date: string } | undefined;
      if (leaveRow) {
        realtimeHub.emitEmployeeNotification(leaveRow.employee_id, {
          type: 'Leave Update',
          title: `Leave request ${status}`,
          ref: `LV-${(leaveRow.start_date || '').slice(0, 4)}-${String(id).padStart(5, '0')}`,
        });
      }
    }
    res.status(outcome.statusCode).json(outcome.body);
  });

  router.post('/leaves/:id/cancel', requirePermission('leaves:read', 'leaves:read_self'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid leave ID.' });
      return;
    }
    const { cancel_reason } = (req.body || {}) as { cancel_reason?: string };
    const perms = new Set(req.user!.permissions);
    const canCancelApproved = perms.has('leaves:approve');

    const outcome = cancelLeaveRequest(db, {
      leaveId: id,
      cancel_reason: cancel_reason || '',
      canCancelApproved,
      employeeSelfId: req.user!.role === 'Employee' ? req.user!.employee_id : null,
      departmentScopeId: req.user!.role === 'Department Head' ? req.user!.department_id : null,
      actor: {
        userId: req.user!.id,
        username: req.user!.username,
        role: req.user!.role,
        ipAddress: getClientIp(req),
      },
      nowMs: getNowMs(),
    });

    if (outcome.realtimeAttendanceEvents) {
      for (const ev of outcome.realtimeAttendanceEvents) {
        realtimeHub.emitAttendanceUpdated(ev);
      }
    }
    res.status(outcome.statusCode).json(outcome.body);
  });

  router.delete('/leaves/:id', requirePermission('leaves:delete'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid leave ID.' });
      return;
    }
    const existing = db.prepare('SELECT id, status FROM leaves WHERE id = ?').get(id) as
      | { id: number; status: string }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Leave record not found.' });
      return;
    }
    // If deleting an Approved leave, atomically reverse its attendance propagation first so zero orphaned 'On Leave' rows remain
    if (existing.status === 'Approved') {
      cancelLeaveRequest(db, {
        leaveId: id,
        cancel_reason: 'Deleted by authorized administrator',
        canCancelApproved: true,
        employeeSelfId: null,
        departmentScopeId: null,
        actor: {
          userId: req.user!.id,
          username: req.user!.username,
          role: req.user!.role,
          ipAddress: getClientIp(req),
        },
        nowMs: getNowMs(),
      });
    }
    db.prepare('DELETE FROM leaves WHERE id = ?').run(id);
    logAudit(db, req.user!.username, `Deleted leave record #${id}`, 'Leaves', 'Warning', getClientIp(req));
    res.json({ success: true });
  });

  // -------------------------------------------------------------------------
  // PAYROLL PROCESSING & GOVERNANCE (BUILD 12: Effective-Dated Policies,
  // Pre-Compute Reconciliation, Maker-Checker Separation, Finance Sign-Off,
  // Immutability, Secure Released Payslips & Formula-Safe CSV Export)
  // -------------------------------------------------------------------------
  const handlePayrollError = (res: express.Response, err: unknown) => {
    if (err instanceof PayrollDomainError) {
      res.status(err.status).json({
        error: err.message,
        code: err.code,
        ...(err.details ? { details: err.details } : {}),
      });
      return;
    }
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('PAYROLL_LOCKED_VIOLATION')) {
      res.status(409).json({ error: msg, code: 'PAYROLL_RUN_LOCKED' });
      return;
    }
    res.status(500).json({ error: msg || 'Payroll operation failed.' });
  };

  router.get('/payroll/policy-template', requirePermission('payroll:read'), (_req, res) => {
    res.json(getPayrollPolicyTemplate());
  });

  router.get('/payroll/policies', requirePermission('payroll:read'), (_req, res) => {
    const policies = listPayrollPolicies(db);
    const activeApprovedPolicy = policies.find((p) => p.approval_status === 'APPROVED_BY_FINANCE') || null;
    res.json({
      engineVersion: PAYROLL_ENGINE_VERSION,
      policies,
      activeApprovedPolicy,
    });
  });

  router.post('/payroll/policies', requirePermission('payroll:policy_manage'), (req: AuthenticatedRequest, res) => {
    try {
      const created = createPayrollPolicy(
        db,
        req.body || {},
        {
          userId: req.user!.id,
          username: req.user!.username,
          role: req.user!.role,
          ipAddress: getClientIp(req),
        },
        getNowMs()
      );
      logAudit(
        db,
        req.user!.username,
        `Created draft payroll policy "${created.policy_code}" (${created.effective_from} to ${created.effective_to || 'open'})`,
        'Payroll',
        'Success',
        getClientIp(req)
      );
      res.status(201).json({ policy: created });
    } catch (err) {
      handlePayrollError(res, err);
    }
  });

  router.put('/payroll/policies/:id', requirePermission('payroll:policy_manage'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid payroll policy ID.' });
      return;
    }
    try {
      const updated = updateDraftPayrollPolicy(
        db,
        id,
        req.body || {},
        {
          userId: req.user!.id,
          username: req.user!.username,
          role: req.user!.role,
          ipAddress: getClientIp(req),
        },
        getNowMs()
      );
      logAudit(
        db,
        req.user!.username,
        `Updated draft payroll policy "${updated.policy_code}"`,
        'Payroll',
        'Success',
        getClientIp(req)
      );
      res.json({ policy: updated });
    } catch (err) {
      handlePayrollError(res, err);
    }
  });

  router.post(
    '/payroll/policies/:id/finance-approve',
    requirePermission('payroll:finance_signoff'),
    (req: AuthenticatedRequest, res) => {
      const id = parsePositiveIntId(req.params.id);
      if (!id) {
        res.status(400).json({ error: 'Invalid payroll policy ID.' });
        return;
      }
      try {
        const approved = approvePayrollPolicyByFinance(
          db,
          id,
          req.body || {},
          {
            userId: req.user!.id,
            username: req.user!.username,
            role: req.user!.role,
            ipAddress: getClientIp(req),
          },
          getNowMs()
        );
        logAudit(
          db,
          req.user!.username,
          `Finance-approved payroll policy "${approved.policy_code}" (Ref: ${approved.approval_reference})`,
          'Payroll',
          'Success',
          getClientIp(req)
        );
        res.json({ policy: approved });
      } catch (err) {
        handlePayrollError(res, err);
      }
    }
  );

  router.get('/payroll/precheck', requirePermission('payroll:compute'), (req, res) => {
    const startDate = String(req.query.start_date || '');
    const endDate = String(req.query.end_date || '');
    const policyId = req.query.policy_id ? parsePositiveIntId(String(req.query.policy_id)) : null;
    try {
      const precheck = reconcilePayrollPeriodPrecheck(db, startDate, endDate, policyId);
      res.json(precheck);
    } catch (err) {
      handlePayrollError(res, err);
    }
  });

  // Self-service endpoint: Employee can ONLY read their own RELEASED payslips (never draft/computed/other employees)
  router.get('/payroll/my-payslips', requirePermission('payroll:read_self'), (req: AuthenticatedRequest, res) => {
    const empId = req.user!.employee_id;
    if (!empId) {
      res.json({ employee_id: null, payslips: [] });
      return;
    }
    const payslips = db
      .prepare(
        `SELECT pi.*, r.period_label, r.start_date, r.end_date, r.status as run_status,
                r.policy_code, r.policy_approval_status, r.calculation_version, r.snapshot_sha256,
                r.released_at, r.released_at_utc, r.finance_signoff_ref,
                e.employee_code, e.full_name as employee_name, d.code as department_code, d.name as department_name,
                p.name as position_name
         FROM payroll_items pi
         JOIN payroll_runs r ON r.id = pi.payroll_run_id
         JOIN employees e ON e.id = pi.employee_id
         JOIN departments d ON d.id = e.department_id
         JOIN positions p ON p.id = e.position_id
         WHERE pi.employee_id = ? AND r.status = 'Released'
         ORDER BY r.start_date DESC, r.id DESC`
      )
      .all(empId);
    res.json({ employee_id: empId, payslips });
  });

  router.get('/payroll', requirePermission('payroll:read'), (req, res) => {
    const runs = db.prepare('SELECT * FROM payroll_runs ORDER BY start_date DESC, id DESC').all() as Array<{
      id: number;
    }>;
    const activeRunId = req.query.run_id ? parsePositiveIntId(String(req.query.run_id)) : runs[0]?.id;

    let items: unknown[] = [];
    let audit: unknown[] = [];
    if (activeRunId) {
      items = db
        .prepare(
          `SELECT pi.*, e.employee_code, e.full_name as employee_name, d.code as department_code,
                  d.name as department_name, p.name as position_name
           FROM payroll_items pi
           JOIN employees e ON pi.employee_id = e.id
           JOIN departments d ON e.department_id = d.id
           JOIN positions p ON e.position_id = p.id
           WHERE pi.payroll_run_id = ?
           ORDER BY e.employee_code ASC`
        )
        .all(activeRunId);

      audit = db
        .prepare('SELECT * FROM payroll_audit_log WHERE payroll_run_id = ? ORDER BY id DESC LIMIT 100')
        .all(activeRunId);
    }

    const policies = listPayrollPolicies(db);
    const activeApprovedPolicy = policies.find((p) => p.approval_status === 'APPROVED_BY_FINANCE') || null;

    res.json({
      engineVersion: PAYROLL_ENGINE_VERSION,
      runs,
      activeRunId: activeRunId || null,
      items,
      policies,
      activeApprovedPolicy,
      audit,
    });
  });

  router.get('/payroll/:id/audit', requirePermission('payroll:read'), (req, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid payroll run ID.' });
      return;
    }
    const entries = db
      .prepare('SELECT * FROM payroll_audit_log WHERE payroll_run_id = ? ORDER BY id ASC')
      .all(id);
    res.json({ payroll_run_id: id, entries });
  });

  router.get('/payroll/:runId/payslip/:employeeId', (req: AuthenticatedRequest, res) => {
    const runId = parsePositiveIntId(req.params.runId);
    const employeeId = parsePositiveIntId(req.params.employeeId);
    if (!runId || !employeeId) {
      res.status(400).json({ error: 'Invalid payroll run ID or employee ID.' });
      return;
    }

    const perms = new Set(req.user!.permissions);
    const canReadAll = perms.has('payroll:read');
    const canReadSelf = perms.has('payroll:read_self');

    if (!canReadAll && !canReadSelf) {
      res.status(403).json({ error: 'Access denied for payslip retrieval.', code: 'FORBIDDEN' });
      return;
    }

    const run = db.prepare('SELECT * FROM payroll_runs WHERE id = ?').get(runId) as
      | {
          id: number;
          period_label: string;
          start_date: string;
          end_date: string;
          status: string;
          policy_code: string;
          policy_approval_status: string;
          is_production_approved: number;
          calculation_version: number;
          snapshot_sha256: string;
          finance_signoff_ref: string;
          released_at: string | null;
          released_at_utc: string | null;
        }
      | undefined;
    if (!run) {
      res.status(404).json({ error: 'Payroll run not found.' });
      return;
    }

    if (!canReadAll) {
      if (req.user!.employee_id !== employeeId) {
        res.status(403).json({ error: 'You may only view your own released payslip.', code: 'FORBIDDEN' });
        return;
      }
      if (run.status !== 'Released') {
        res.status(403).json({
          error: 'Payslips are only accessible to employees after the payroll run has been Released.',
          code: 'PAYSLIP_NOT_RELEASED',
        });
        return;
      }
    }

    const item = db
      .prepare(
        `SELECT pi.*, e.employee_code, e.full_name as employee_name, d.code as department_code,
                d.name as department_name, p.name as position_name
         FROM payroll_items pi
         JOIN employees e ON e.id = pi.employee_id
         JOIN departments d ON d.id = e.department_id
         JOIN positions p ON p.id = e.position_id
         WHERE pi.payroll_run_id = ? AND pi.employee_id = ?`
      )
      .get(runId, employeeId);

    if (!item) {
      res.status(404).json({ error: 'Payslip not found for this employee and payroll run.' });
      return;
    }

    res.setHeader('Cache-Control', 'no-store');
    res.json({ run, payslip: item });
  });

  // Official Payslip PDF export (strictly scoped with identical RBAC & Released enforcement)
  router.get('/payroll/:runId/payslip/:employeeId/pdf', async (req: AuthenticatedRequest, res) => {
    const runId = parsePositiveIntId(req.params.runId);
    const employeeId = parsePositiveIntId(req.params.employeeId);
    if (!runId || !employeeId) {
      res.status(400).json({ error: 'Invalid payroll run ID or employee ID.' });
      return;
    }

    const perms = new Set(req.user!.permissions);
    const canReadAll = perms.has('payroll:read');
    const canReadSelf = perms.has('payroll:read_self');

    if (!canReadAll && !canReadSelf) {
      res.status(403).json({ error: 'Access denied for payslip PDF download.', code: 'FORBIDDEN' });
      return;
    }

    const run = db.prepare('SELECT * FROM payroll_runs WHERE id = ?').get(runId) as
      | {
          id: number;
          period_label: string;
          start_date: string;
          end_date: string;
          status: string;
          policy_code: string;
          finance_signoff_ref: string;
          released_at: string | null;
        }
      | undefined;
    if (!run) {
      res.status(404).json({ error: 'Payroll run not found.' });
      return;
    }

    if (!canReadAll) {
      if (req.user!.employee_id !== employeeId) {
        res.status(403).json({ error: 'You may only download your own released payslip.', code: 'FORBIDDEN' });
        return;
      }
      if (run.status !== 'Released') {
        res.status(403).json({
          error: 'Payslips are only downloadable after the payroll run has been Released.',
          code: 'PAYSLIP_NOT_RELEASED',
        });
        return;
      }
    }

    const item = db
      .prepare(
        `SELECT pi.*, e.employee_code, e.full_name as employee_name, d.code as department_code,
                d.name as department_name, p.name as position_name
         FROM payroll_items pi
         JOIN employees e ON e.id = pi.employee_id
         JOIN departments d ON d.id = e.department_id
         JOIN positions p ON p.id = e.position_id
         WHERE pi.payroll_run_id = ? AND pi.employee_id = ?`
      )
      .get(runId, employeeId) as Record<string, unknown> | undefined;

    if (!item) {
      res.status(404).json({ error: 'Payslip not found for this employee and payroll run.' });
      return;
    }

    const fmtPhp = (v: unknown) =>
      `PHP ${Number(v || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

    const pdfBuffer = await new Promise<Buffer>((resolve, reject) => {
      const doc = new PDFDocument({ size: 'A4', margin: 48 });
      const chunks: Buffer[] = [];
      doc.on('data', (c: Buffer) => chunks.push(c));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);

      // Header Banner
      doc.rect(0, 0, doc.page.width, 92).fill('#064E2C');
      doc.rect(0, 92, doc.page.width, 6).fill('#F4B400');

      const shieldPath = path.resolve(process.cwd(), 'public', 'assets', 'aistudio', 'Savage-Rsucaj_Attendance_Shield_bca5b40c.png');
      if (fs.existsSync(shieldPath)) {
        try {
          doc.image(shieldPath, 48, 16, { width: 58, height: 58, fit: [58, 58] });
        } catch {
          // ignore logo embed errors
        }
      }

      doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(18).text('SAVAGE-RSUCAJ', 120, 24);
      doc.font('Helvetica').fontSize(10).fillColor('#D1FAE5').text('Romblon State University - Cajidiocan Campus', 120, 46);
      doc.font('Helvetica-Bold').fontSize(11).fillColor('#FEF08A').text('OFFICIAL EMPLOYEE PAYSLIP', 120, 62);

      doc.moveDown(3.2);
      doc.fillColor('#0F172A').font('Helvetica-Bold').fontSize(13).text(`Payroll Period: ${run.period_label}`, 48, 118);
      doc.font('Helvetica').fontSize(9.5).fillColor('#475569').text(`Coverage: ${run.start_date} to ${run.end_date}   |   Status: ${run.status}${run.released_at ? `   |   Released: ${run.released_at}` : ''}`, 48, 136);

      // Employee Info Box
      doc.roundedRect(48, 158, 499, 84, 8).strokeColor('#CBD5E1').lineWidth(1).stroke();
      const empRows: Array<[string, string]> = [
        ['Employee Name:', String(item.employee_name || '-')],
        ['Employee ID:', String(item.employee_code || '-')],
        ['Department:', String(item.department_name || item.department_code || '-')],
        ['Position:', String(item.position_name || '-')],
      ];
      let y = 170;
      for (const [label, val] of empRows) {
        doc.font('Helvetica').fontSize(10).fillColor('#64748B').text(label, 64, y);
        doc.font('Helvetica-Bold').fontSize(10).fillColor('#0F172A').text(val, 220, y, { width: 310, align: 'right' });
        y += 17;
      }

      // Earnings section
      y = 264;
      doc.rect(48, y, 499, 24).fill('#EEF5F2');
      doc.font('Helvetica-Bold').fontSize(10.5).fillColor('#064E2C').text('EARNINGS', 60, y + 6);
      y += 32;

      const basicAmount = Number(item.prorated_basic_pay ?? item.basic_pay ?? 0);
      const allowancesAmount = Number(item.allowances ?? 0);
      const overtimeAmount = Number(item.overtime_pay ?? 0);
      const holidayAmount = Number(item.holiday_rest_pay ?? 0);
      const otherEarnAmount = Number(item.other_earnings ?? 0);
      const grossAmount = Number(item.gross_pay ?? basicAmount + allowancesAmount + overtimeAmount + holidayAmount + otherEarnAmount);

      const earningRows: Array<[string, number]> = [
        ['Basic Salary', basicAmount],
        ['Allowance', allowancesAmount],
      ];
      if (overtimeAmount > 0) earningRows.push(['Overtime Pay', overtimeAmount]);
      if (holidayAmount > 0) earningRows.push(['Holiday / Rest Day Pay', holidayAmount]);
      if (otherEarnAmount > 0) earningRows.push(['Other Earnings', otherEarnAmount]);

      for (const [label, amt] of earningRows) {
        doc.font('Helvetica').fontSize(10).fillColor('#334155').text(label, 60, y);
        doc.font('Helvetica').fontSize(10).fillColor('#0F172A').text(fmtPhp(amt), 320, y, { width: 215, align: 'right' });
        y += 20;
      }
      doc.moveTo(60, y).lineTo(535, y).strokeColor('#CBD5E1').stroke();
      y += 8;
      doc.font('Helvetica-Bold').fontSize(10.5).fillColor('#0F172A').text('Total Earnings', 60, y);
      doc.font('Helvetica-Bold').fontSize(10.5).fillColor('#064E2C').text(fmtPhp(grossAmount), 320, y, { width: 215, align: 'right' });

      // Deductions section
      y += 32;
      doc.rect(48, y, 499, 24).fill('#EEF5F2');
      doc.font('Helvetica-Bold').fontSize(10.5).fillColor('#064E2C').text('DEDUCTIONS', 60, y + 6);
      y += 32;

      const taxAmount = Number(item.tax_deduction ?? 0);
      const statutoryAmount = Number(item.statutory_deductions ?? 0);
      const attendanceDed = Number(item.late_deduction ?? 0) + Number(item.undertime_deduction ?? 0) + Number(item.absence_deduction ?? 0) + Number(item.unpaid_leave_deduction ?? 0);
      const totalDed = Number(item.deductions ?? 0);
      const otherDed = Math.max(0, Number(item.other_deductions ?? (totalDed - taxAmount - statutoryAmount - attendanceDed)));

      const dedRows: Array<[string, number]> = [
        ['Withholding Tax', taxAmount],
      ];
      if (statutoryAmount > 0) dedRows.push(['Statutory Deductions', statutoryAmount]);
      if (attendanceDed > 0) dedRows.push(['Late / Undertime / Absence Deductions', attendanceDed]);
      dedRows.push(['Other Deductions', otherDed]);

      for (const [label, amt] of dedRows) {
        doc.font('Helvetica').fontSize(10).fillColor('#334155').text(label, 60, y);
        doc.font('Helvetica').fontSize(10).fillColor('#0F172A').text(fmtPhp(amt), 320, y, { width: 215, align: 'right' });
        y += 20;
      }
      doc.moveTo(60, y).lineTo(535, y).strokeColor('#CBD5E1').stroke();
      y += 8;
      doc.font('Helvetica-Bold').fontSize(10.5).fillColor('#0F172A').text('Total Deductions', 60, y);
      doc.font('Helvetica-Bold').fontSize(10.5).fillColor('#B91C1C').text(fmtPhp(totalDed), 320, y, { width: 215, align: 'right' });

      // Net Pay Highlight Banner
      y += 34;
      doc.roundedRect(48, y, 499, 44, 8).fill('#FEF08A');
      doc.font('Helvetica-Bold').fontSize(13).fillColor('#0F172A').text('Net Pay', 64, y + 14);
      doc.font('Helvetica-Bold').fontSize(15).fillColor('#064E2C').text(fmtPhp(item.net_pay), 280, y + 13, { width: 250, align: 'right' });

      // Footer Metadata
      y += 68;
      doc.font('Helvetica').fontSize(8.5).fillColor('#64748B').text(
        `Attendance Summary: Present ${Number(item.days_present || 0)} day(s) | Late ${Number(item.days_late || 0)} day(s) | Absent ${Number(item.days_absent || 0)} day(s)`,
        48,
        y
      );
      doc.text(
        `Policy: ${run.policy_code || 'RSU-STD'}  |  Finance Ref: ${run.finance_signoff_ref || 'Verified'}  |  Generated: ${new Date(getNowMs()).toISOString()}`,
        48,
        y + 14
      );
      doc.text('This is an official computer-generated payslip from SAVAGE-RSUCAJ Smart Attendance System.', 48, y + 32);

      doc.end();
    });

    const safeCode = String(item.employee_code || employeeId).replace(/[^A-Za-z0-9_-]/g, '_');
    const safePeriod = String(run.start_date || run.id).replace(/[^A-Za-z0-9_-]/g, '_');
    const filename = `SAVAGE-RSUCAJ_Payslip_${safeCode}_${safePeriod}.pdf`;

    logAudit(db, req.user!.username, `Downloaded official payslip PDF (${filename})`, 'Payroll', 'Success', getClientIp(req));
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.send(pdfBuffer);
  });

  router.get('/payroll/:id/export.csv', requirePermission('payroll:read'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid payroll run ID.' });
      return;
    }
    const run = db.prepare('SELECT * FROM payroll_runs WHERE id = ?').get(id) as
      | {
          id: number;
          period_label: string;
          start_date: string;
          end_date: string;
          status: string;
          policy_code: string;
          policy_approval_status: string;
          calculation_version: number;
          snapshot_sha256: string;
        }
      | undefined;
    if (!run) {
      res.status(404).json({ error: 'Payroll run not found.' });
      return;
    }

    const items = db
      .prepare(
        `SELECT pi.*, e.employee_code, e.full_name as employee_name, d.code as department_code, p.name as position_name
         FROM payroll_items pi
         JOIN employees e ON pi.employee_id = e.id
         JOIN departments d ON e.department_id = d.id
         JOIN positions p ON e.position_id = p.id
         WHERE pi.payroll_run_id = ?
         ORDER BY e.employee_code ASC`
      )
      .all(id) as Array<Record<string, unknown>>;

    const csv = generateSafePayrollCsv(run, items);
    const safeFilename = `SAVAGE-RSUCAJ-Payroll-${run.start_date}_to_${run.end_date}-v${run.calculation_version || 1}.csv`;
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${safeFilename}"`);
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    logAudit(
      db,
      req.user!.username,
      `Exported payroll CSV for "${run.period_label}" (${items.length} employee rows)`,
      'Payroll',
      'Success',
      getClientIp(req)
    );
    res.send(csv);
  });

  router.post('/payroll/compute', requirePermission('payroll:compute'), (req: AuthenticatedRequest, res) => {
    const { period_label, start_date, end_date, policy_id, recompute } = (req.body || {}) as {
      period_label?: string;
      start_date?: string;
      end_date?: string;
      policy_id?: number | null;
      recompute?: boolean;
    };
    if (!period_label?.trim() || !isIsoDateString(start_date) || !isIsoDateString(end_date)) {
      res.status(400).json({ error: 'Period label and valid start/end dates (YYYY-MM-DD) are required.' });
      return;
    }
    try {
      const result = computeOrRecomputePayrollRun(
        db,
        {
          period_label: period_label.trim(),
          start_date,
          end_date,
          policy_id: policy_id ? Number(policy_id) : null,
          recompute: Boolean(recompute),
        },
        {
          userId: req.user!.id,
          username: req.user!.username,
          role: req.user!.role,
          ipAddress: getClientIp(req),
        },
        getNowMs()
      );

      if (!result.idempotentNoOp) {
        const prodNote = result.is_production_approved
          ? 'Finance-approved policy applied.'
          : 'STAMPED NOT APPROVED FOR PRODUCTION (draft policy — Finalize/Release blocked).';
        createTargetedNotification(db, realtimeHub, {
          title: `Payroll for ${result.period_label} ${result.calculation_version > 1 ? `recomputed (v${result.calculation_version})` : 'computed'}`,
          message: `Computed payroll for ${result.employee_count} active employees. ${prodNote}`,
          category: 'System Notices',
          priority: 'Medium',
          actionModule: 'payroll',
          actionEntityId: result.id,
          targetRoles: ['Administrator', 'Payroll Officer'],
          eventType: 'payroll_computed',
        });
        logAudit(
          db,
          req.user!.username,
          `${result.calculation_version > 1 ? 'Recomputed' : 'Computed'} payroll run "${result.period_label}" v${result.calculation_version} (policy=${result.policy_code}, status=${result.policy_approval_status}, sha256=${result.snapshot_sha256.slice(0, 12)})`,
          'Payroll',
          'Success',
          getClientIp(req)
        );
      }

      res.status(result.idempotentNoOp ? 200 : 201).json(result);
    } catch (err) {
      handlePayrollError(res, err);
    }
  });

  router.patch('/payroll/:id/finalize', requirePermission('payroll:finalize'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid payroll run ID.' });
      return;
    }
    try {
      const updated = finalizePayrollRun(
        db,
        id,
        {
          userId: req.user!.id,
          username: req.user!.username,
          role: req.user!.role,
          ipAddress: getClientIp(req),
        },
        getNowMs()
      );
      logAudit(
        db,
        req.user!.username,
        `Finalized payroll run "${updated.period_label}" (v${updated.calculation_version}, locked)`,
        'Payroll',
        'Success',
        getClientIp(req)
      );
      res.json({ success: true, run: updated });
    } catch (err) {
      handlePayrollError(res, err);
    }
  });

  router.post(
    '/payroll/:id/finance-signoff',
    requirePermission('payroll:finance_signoff'),
    (req: AuthenticatedRequest, res) => {
      const id = parsePositiveIntId(req.params.id);
      if (!id) {
        res.status(400).json({ error: 'Invalid payroll run ID.' });
        return;
      }
      try {
        const updated = recordFinanceSignoff(
          db,
          id,
          req.body || {},
          {
            userId: req.user!.id,
            username: req.user!.username,
            role: req.user!.role,
            ipAddress: getClientIp(req),
          },
          getNowMs()
        );
        logAudit(
          db,
          req.user!.username,
          `Recorded Finance sign-off for payroll run "${updated.period_label}" (Ref: ${updated.finance_signoff_ref})`,
          'Payroll',
          'Success',
          getClientIp(req)
        );
        res.json({ success: true, run: updated });
      } catch (err) {
        handlePayrollError(res, err);
      }
    }
  );

  router.patch('/payroll/:id/release', requirePermission('payroll:release'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid payroll run ID.' });
      return;
    }
    try {
      const updated = releasePayrollRun(
        db,
        id,
        {
          userId: req.user!.id,
          username: req.user!.username,
          role: req.user!.role,
          ipAddress: getClientIp(req),
        },
        getNowMs()
      );
      createTargetedNotification(db, realtimeHub, {
        title: `Payroll released — ${updated.period_label}`,
        message: `Finance-signed payslips and summary ledger for ${updated.period_label} (Ref: ${updated.finance_signoff_ref}) have been released.`,
        category: 'System Notices',
        priority: 'Low',
        actionModule: 'payroll',
        actionEntityId: id,
        targetRoles: ['Administrator', 'Payroll Officer'],
        eventType: 'payroll_released',
      });
      const releasedItems = db
        .prepare('SELECT employee_id FROM payroll_items WHERE payroll_run_id = ?')
        .all(id) as Array<{ employee_id: number }>;
      for (const row of releasedItems) {
        realtimeHub.emitEmployeeNotification(row.employee_id, {
          type: 'Payroll',
          title: `Payslip released for ${updated.period_label}`,
          ref: `PAY-${id}`,
        });
      }
      logAudit(
        db,
        req.user!.username,
        `Released payroll run "${updated.period_label}" (Ref: ${updated.finance_signoff_ref})`,
        'Payroll',
        'Success',
        getClientIp(req)
      );
      res.json({ success: true, run: updated });
    } catch (err) {
      handlePayrollError(res, err);
    }
  });

  // -------------------------------------------------------------------------
  // REPORTS & MONTHLY DTR ENGINE (BUILD 13 — DB-backed, Streaming CSV, A4 PDF)
  // -------------------------------------------------------------------------
  const handleReportError = (res: express.Response, err: unknown) => {
    if (err instanceof ReportEngineError) {
      res.status(err.statusCode).json({
        error: err.message,
        code: err.code,
        ...(err.details ? { details: err.details } : {}),
      });
      return;
    }
    throw err;
  };

  const parseReportFiltersFromQuery = (req: AuthenticatedRequest): ReportFilters => {
    const monthRaw = ((req.query.month as string) || '').trim();
    if (monthRaw && !isValidIsoMonth(monthRaw)) {
      throw new ReportEngineError(400, 'INVALID_MONTH', 'Month must be in YYYY-MM format (e.g. 2026-03).');
    }

    const startDate = ((req.query.start_date as string) || (req.query.startDate as string) || '').trim();
    if (startDate && !isValidIsoDate(startDate)) {
      throw new ReportEngineError(400, 'INVALID_DATE', 'start_date must be a valid YYYY-MM-DD calendar date.');
    }

    const endDate = ((req.query.end_date as string) || (req.query.endDate as string) || '').trim();
    if (endDate && !isValidIsoDate(endDate)) {
      throw new ReportEngineError(400, 'INVALID_DATE', 'end_date must be a valid YYYY-MM-DD calendar date.');
    }

    const empRaw = (req.query.employee_id as string) || (req.query.empId as string) || '';
    let empId: number | null = null;
    if (empRaw.trim() !== '') {
      empId = parsePositiveIntId(empRaw);
      if (!empId) {
        throw new ReportEngineError(400, 'INVALID_EMPLOYEE_ID', 'employee_id must be a positive integer.');
      }
    }

    const deptRaw = (req.query.department_id as string) || (req.query.deptId as string) || '';
    let deptId: number | null = null;
    if (deptRaw.trim() !== '') {
      deptId = parsePositiveIntId(deptRaw);
      if (!deptId) {
        throw new ReportEngineError(400, 'INVALID_DEPARTMENT_ID', 'department_id must be a positive integer.');
      }
    }

    const runRaw = (req.query.run_id as string) || (req.query.runId as string) || '';
    let runId: number | null = null;
    if (runRaw.trim() !== '') {
      runId = parsePositiveIntId(runRaw);
      if (!runId) {
        throw new ReportEngineError(400, 'INVALID_RUN_ID', 'run_id must be a positive integer.');
      }
    }

    return {
      month: monthRaw || undefined,
      startDate: startDate || undefined,
      endDate: endDate || undefined,
      empId,
      deptId,
      runId,
      status: ((req.query.status as string) || '').trim() || undefined,
      module: ((req.query.module as string) || '').trim() || undefined,
      search: ((req.query.search as string) || '').trim() || undefined,
    };
  };

  const resolveAuthorizedReportScope = (
    req: AuthenticatedRequest,
    type: ReportType,
    filters: ReportFilters
  ): ReportFilters => {
    const perms = new Set(req.user!.permissions);
    if (type === 'payroll') {
      if (!perms.has('reports:payroll')) {
        throw new ReportEngineError(403, 'FORBIDDEN', 'Access denied for Payroll reports.');
      }
    } else if (type === 'audit-logs') {
      if (!perms.has('reports:audit')) {
        throw new ReportEngineError(403, 'FORBIDDEN', 'Access denied for Audit Logs reports.');
      }
    } else if (!perms.has('reports:read')) {
      throw new ReportEngineError(403, 'FORBIDDEN', 'Access denied for system reports.');
    }

    if (req.user!.role === 'Department Head') {
      if (req.user!.department_id === null) {
        throw new ReportEngineError(403, 'FORBIDDEN', 'Department Head account is not assigned to a department.');
      }
      if (filters.deptId && filters.deptId !== req.user!.department_id) {
        throw new ReportEngineError(
          403,
          'FORBIDDEN',
          'Department Heads cannot access reports for other departments.'
        );
      }
      if (filters.empId) {
        const empRow = db
          .prepare('SELECT department_id FROM employees WHERE id = ?')
          .get(filters.empId) as { department_id: number } | undefined;
        if (empRow && empRow.department_id !== req.user!.department_id) {
          throw new ReportEngineError(
            403,
            'FORBIDDEN',
            'Department Heads cannot access reports for employees outside their assigned department.'
          );
        }
      }
      return { ...filters, deptId: req.user!.department_id };
    }

    return filters;
  };

  const parseBooleanFlag = (raw: unknown): boolean => {
    const s = String(raw || '').trim().toLowerCase();
    return s === 'true' || s === '1' || s === 'yes';
  };

  // Self-service Monthly DTR (Employee own DTR view + A4 PDF download)
  router.get('/reports/my-dtr', (req: AuthenticatedRequest, res) => {
    try {
      const perms = new Set(req.user!.permissions);
      if (!perms.has('attendance:read_self') && !perms.has('reports:read')) {
        res.status(403).json({ error: 'Access denied for personal DTR.', code: 'FORBIDDEN' });
        return;
      }
      if (!req.user!.employee_id) {
        res.status(403).json({ error: 'Account is not linked to an employee profile.', code: 'FORBIDDEN' });
        return;
      }
      const parsed = parseReportFiltersFromQuery(req);
      if (parsed.empId && parsed.empId !== req.user!.employee_id) {
        res.status(403).json({ error: 'You can only view your own Monthly DTR.', code: 'FORBIDDEN' });
        return;
      }
      const effectiveMonth =
        parsed.month ||
        (parsed.startDate ? parsed.startDate.slice(0, 7) : toManilaParts(getNowMs()).isoDate.slice(0, 7));

      const built = buildMonthlyDtrReports(db, {
        month: effectiveMonth,
        empId: req.user!.employee_id,
        serverNowUtc: getNowMs(),
      });
      res.json(built);
    } catch (err) {
      handleReportError(res, err);
    }
  });

  router.get('/reports/my-dtr/export.pdf', async (req: AuthenticatedRequest, res) => {
    try {
      const perms = new Set(req.user!.permissions);
      if (!perms.has('attendance:read_self') && !perms.has('reports:read')) {
        res.status(403).json({ error: 'Access denied for personal DTR PDF.', code: 'FORBIDDEN' });
        return;
      }
      if (!req.user!.employee_id) {
        res.status(403).json({ error: 'Account is not linked to an employee profile.', code: 'FORBIDDEN' });
        return;
      }
      const parsed = parseReportFiltersFromQuery(req);
      if (parsed.empId && parsed.empId !== req.user!.employee_id) {
        res.status(403).json({ error: 'You can only export your own Monthly DTR.', code: 'FORBIDDEN' });
        return;
      }
      const pdf = await generateReportPdfBuffer(
        db,
        'dtr',
        { ...parsed, empId: req.user!.employee_id, deptId: null },
        {
          strict: parseBooleanFlag(req.query.strict),
          requireSigned: parseBooleanFlag(req.query.require_signed),
          generatedBy: req.user!.username,
          serverNowUtc: getNowMs(),
        }
      );
      logAudit(db, req.user!.username, `Downloaded personal Monthly DTR PDF (${pdf.filename})`, 'Reports', 'Success', getClientIp(req));
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${pdf.filename}"`);
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('X-Report-Page-Count', String(pdf.pageCount));
      res.setHeader('X-Report-Row-Count', String(pdf.rowCount));
      res.send(pdf.buffer);
    } catch (err) {
      handleReportError(res, err);
    }
  });

  // Monthly DTR structured JSON endpoint
  router.get('/reports/dtr/monthly', (req: AuthenticatedRequest, res) => {
    try {
      const parsed = parseReportFiltersFromQuery(req);
      const scoped = resolveAuthorizedReportScope(req, 'dtr', parsed);
      const effectiveMonth =
        scoped.month ||
        (scoped.startDate ? scoped.startDate.slice(0, 7) : toManilaParts(getNowMs()).isoDate.slice(0, 7));

      const built = buildMonthlyDtrReports(db, {
        month: effectiveMonth,
        empId: scoped.empId ?? null,
        deptId: scoped.deptId ?? null,
        serverNowUtc: getNowMs(),
      });
      logAudit(
        db,
        req.user!.username,
        `Viewed Monthly DTR bundle (${effectiveMonth}, employees=${built.reports.length})`,
        'Reports',
        'Success',
        getClientIp(req)
      );
      res.json(built);
    } catch (err) {
      handleReportError(res, err);
    }
  });

  // Sign / verify Monthly DTR (captures employee + supervisor signoff + SHA-256 snapshot binding)
  router.post('/reports/dtr/sign', (req: AuthenticatedRequest, res) => {
    try {
      const empId = parsePositiveIntId(String(req.body?.employee_id ?? ''));
      const month = String(req.body?.month || '').trim();
      const requestedAction = String(req.body?.role_action || '').trim();
      const campusDirectorName =
        req.body?.campus_director_name !== undefined ? String(req.body.campus_director_name) : undefined;
      const notes = req.body?.notes !== undefined ? String(req.body.notes) : '';

      if (!empId) {
        throw new ReportEngineError(400, 'INVALID_EMPLOYEE_ID', 'employee_id must be a positive integer.');
      }
      if (!isValidIsoMonth(month)) {
        throw new ReportEngineError(400, 'INVALID_MONTH', 'month must be in YYYY-MM format.');
      }

      const perms = new Set(req.user!.permissions);
      let roleAction: 'EMPLOYEE_SIGN' | 'SUPERVISOR_VERIFY' | 'BOTH' = 'SUPERVISOR_VERIFY';

      if (req.user!.role === 'Employee') {
        if (req.user!.employee_id !== empId) {
          throw new ReportEngineError(403, 'FORBIDDEN', 'Employees can only sign their own Monthly DTR.');
        }
        if (requestedAction && requestedAction !== 'EMPLOYEE_SIGN') {
          throw new ReportEngineError(403, 'FORBIDDEN', 'Employees cannot perform supervisor verification.');
        }
        roleAction = 'EMPLOYEE_SIGN';
      } else {
        if (!perms.has('reports:read')) {
          throw new ReportEngineError(403, 'FORBIDDEN', 'Access denied for DTR sign-off verification.');
        }
        if (req.user!.role === 'Department Head') {
          const empRow = db
            .prepare('SELECT department_id FROM employees WHERE id = ?')
            .get(empId) as { department_id: number } | undefined;
          if (!empRow || empRow.department_id !== req.user!.department_id) {
            throw new ReportEngineError(
              403,
              'FORBIDDEN',
              'Department Heads can only verify DTRs within their assigned department.'
            );
          }
        }
        if (
          requestedAction === 'EMPLOYEE_SIGN' ||
          requestedAction === 'SUPERVISOR_VERIFY' ||
          requestedAction === 'BOTH'
        ) {
          roleAction = requestedAction;
        }
      }

      const report = signMonthlyDtr(db, {
        employeeId: empId,
        month: getMonthCalendarMeta(month).month,
        roleAction,
        campusDirectorName,
        notes,
        actor: {
          userId: req.user!.id,
          username: req.user!.username,
          role: req.user!.role,
          ipAddress: getClientIp(req),
        },
      });
      res.json({ report });
    } catch (err) {
      handleReportError(res, err);
    }
  });

  // Revoke Monthly DTR sign-off
  router.post('/reports/dtr/revoke', (req: AuthenticatedRequest, res) => {
    try {
      const perms = new Set(req.user!.permissions);
      if (!perms.has('reports:read')) {
        throw new ReportEngineError(403, 'FORBIDDEN', 'Access denied for revoking DTR sign-off.');
      }
      const empId = parsePositiveIntId(String(req.body?.employee_id ?? ''));
      const month = String(req.body?.month || '').trim();
      const reason = String(req.body?.reason || '').trim();
      if (!empId) {
        throw new ReportEngineError(400, 'INVALID_EMPLOYEE_ID', 'employee_id must be a positive integer.');
      }
      if (!isValidIsoMonth(month)) {
        throw new ReportEngineError(400, 'INVALID_MONTH', 'month must be in YYYY-MM format.');
      }
      if (req.user!.role === 'Department Head') {
        const empRow = db
          .prepare('SELECT department_id FROM employees WHERE id = ?')
          .get(empId) as { department_id: number } | undefined;
        if (!empRow || empRow.department_id !== req.user!.department_id) {
          throw new ReportEngineError(
            403,
            'FORBIDDEN',
            'Department Heads can only revoke DTR sign-offs within their assigned department.'
          );
        }
      }
      const report = revokeMonthlyDtrSignoff(db, {
        employeeId: empId,
        month,
        reason,
        actor: { username: req.user!.username, ipAddress: getClientIp(req) },
      });
      res.json({ report });
    } catch (err) {
      handleReportError(res, err);
    }
  });

  // Convenience alias: GET /api/reports/dtr/pdf
  router.get('/reports/dtr/pdf', async (req: AuthenticatedRequest, res) => {
    try {
      const parsed = parseReportFiltersFromQuery(req);
      const scoped = resolveAuthorizedReportScope(req, 'dtr', parsed);
      const pdf = await generateReportPdfBuffer(db, 'dtr', scoped, {
        strict: parseBooleanFlag(req.query.strict),
        requireSigned: parseBooleanFlag(req.query.require_signed),
        generatedBy: req.user!.username,
        serverNowUtc: getNowMs(),
      });
      logAudit(
        db,
        req.user!.username,
        `Exported Monthly DTR PDF (${pdf.filename}, ${pdf.pageCount} page(s))`,
        'Reports',
        'Success',
        getClientIp(req)
      );
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${pdf.filename}"`);
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('X-Report-Page-Count', String(pdf.pageCount));
      res.setHeader('X-Report-Row-Count', String(pdf.rowCount));
      res.send(pdf.buffer);
    } catch (err) {
      handleReportError(res, err);
    }
  });

  // Unclipped, formula-safe streaming CSV export for all 6 report types
  router.get('/reports/:type/export.csv', (req: AuthenticatedRequest, res) => {
    try {
      const type = String(req.params.type || '').trim();
      if (!isValidReportType(type)) {
        throw new ReportEngineError(400, 'UNKNOWN_REPORT_TYPE', 'Unknown report type.');
      }
      const parsed = parseReportFiltersFromQuery(req);
      const scoped = resolveAuthorizedReportScope(req, type, parsed);

      const exported = streamCsvReportResponse(db, res, type, scoped, {
        strict: parseBooleanFlag(req.query.strict),
        requireSigned: parseBooleanFlag(req.query.require_signed),
        serverNowUtc: getNowMs(),
      });
      logAudit(
        db,
        req.user!.username,
        `Exported ${type} CSV (${exported.filename}, ${exported.rowCount} row(s))`,
        'Reports',
        'Success',
        getClientIp(req)
      );
    } catch (err) {
      handleReportError(res, err);
    }
  });

  // Server-side A4 Portrait PDF export for all 6 report types
  router.get('/reports/:type/export.pdf', async (req: AuthenticatedRequest, res) => {
    try {
      const type = String(req.params.type || '').trim();
      if (!isValidReportType(type)) {
        throw new ReportEngineError(400, 'UNKNOWN_REPORT_TYPE', 'Unknown report type.');
      }
      const parsed = parseReportFiltersFromQuery(req);
      const scoped = resolveAuthorizedReportScope(req, type, parsed);

      const pdf = await generateReportPdfBuffer(db, type, scoped, {
        strict: parseBooleanFlag(req.query.strict),
        requireSigned: parseBooleanFlag(req.query.require_signed),
        generatedBy: req.user!.username,
        serverNowUtc: getNowMs(),
      });
      logAudit(
        db,
        req.user!.username,
        `Exported ${type} PDF (${pdf.filename}, ${pdf.pageCount} page(s), ${pdf.rowCount} row(s))`,
        'Reports',
        'Success',
        getClientIp(req)
      );
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${pdf.filename}"`);
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('X-Report-Page-Count', String(pdf.pageCount));
      res.setHeader('X-Report-Row-Count', String(pdf.rowCount));
      res.send(pdf.buffer);
    } catch (err) {
      handleReportError(res, err);
    }
  });

  // Full-range paginated report query for all 6 report types
  router.get('/reports/:type', (req: AuthenticatedRequest, res) => {
    try {
      const type = String(req.params.type || '').trim();
      if (!isValidReportType(type)) {
        throw new ReportEngineError(400, 'UNKNOWN_REPORT_TYPE', 'Unknown report type.');
      }
      const parsed = parseReportFiltersFromQuery(req);
      const scoped = resolveAuthorizedReportScope(req, type, parsed);

      const page = Math.max(1, Number(req.query.page) || 1);
      const limit = Math.min(1000, Math.max(1, Number(req.query.limit) || 100));

      const result = queryReport(db, type, scoped, {
        page,
        limit,
        serverNowUtc: getNowMs(),
      });

      logAudit(db, req.user!.username, `Generated ${result.title}`, 'Reports', 'Success', getClientIp(req));
      res.json(result);
    } catch (err) {
      handleReportError(res, err);
    }
  });

  // -------------------------------------------------------------------------
  // DEVICES (KIOSK) — Administrator Only (Heartbeat-Derived, Secret Masked)
  // -------------------------------------------------------------------------
  router.get('/devices', requirePermission('devices:read'), (_req, res) => {
    const nowMs = getNowMs();
    const thresholds = getHeartbeatThresholds();
    evaluateDeviceConnectivityAlerts(db, realtimeHub, nowMs, thresholds);
    const rows = db.prepare('SELECT * FROM devices ORDER BY id ASC').all() as StoredDeviceRow[];
    // SECURITY: Never return raw api_token on list/read queries — only masked token & SHA-256 fingerprint
    const enriched = rows.map((row) => computeDeviceTelemetry(row, nowMs, thresholds));
    res.json({
      data: enriched,
      thresholds: {
        heartbeat_timeout_seconds: thresholds.heartbeatTimeoutSec,
        stale_warning_seconds: thresholds.staleWarningSec,
      },
    });
  });

  router.get('/devices/:id/sync-batches', requirePermission('devices:read'), (req, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid device ID.' });
      return;
    }
    const batches = db
      .prepare('SELECT * FROM kiosk_sync_batches WHERE device_id = ? ORDER BY id DESC LIMIT 20')
      .all(id);
    res.json({ data: batches });
  });

  router.post('/devices', requirePermission('devices:write'), (req: AuthenticatedRequest, res) => {
    const { name, device_type, model_info, ip_address, location } = req.body || {};
    if (!name?.trim() || !ip_address?.trim()) {
      res.status(400).json({ error: 'Device name and IP address are required.' });
      return;
    }
    const apiToken = 'ksk_' + crypto.randomBytes(16).toString('hex');
    const tokenHash = hashKioskToken(apiToken);
    const tokenMasked = formatMaskedKioskToken(apiToken);
    const nowIso = new Date(getNowMs()).toISOString();

    try {
      // Newly registered devices start Offline with NULL last_heartbeat_utc until real verified heartbeat
      const info = db
        .prepare(
          `INSERT INTO devices
            (name, device_type, model_info, ip_address, location, api_token, token_hash, token_masked, token_rotated_at, status, last_heartbeat, last_heartbeat_utc)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Offline', 'Never', NULL)`
        )
        .run(
          name.trim(),
          device_type || 'Raspberry Pi',
          (model_info || device_type || 'Raspberry Pi 3B').trim(),
          ip_address.trim(),
          (location || 'Campus Entrance').trim(),
          apiToken,
          tokenHash,
          tokenMasked,
          nowIso
        );
      const deviceId = Number(info.lastInsertRowid);
      logAudit(
        db,
        req.user!.username,
        `Registered kiosk device "${name.trim()}" (${ip_address.trim()}, token=${tokenMasked})`,
        'Devices',
        'Success',
        getClientIp(req),
        {
          actionType: 'DEVICE_REGISTERED',
          targetType: 'device',
          targetId: deviceId,
          after: { name: name.trim(), ip_address: ip_address.trim(), token_masked: tokenMasked },
          isSecurityEvent: true,
        }
      );
      broadcastDeviceTelemetryById(deviceId);
      // One-time plaintext token display on creation
      res.status(201).json({
        id: deviceId,
        api_token: apiToken,
        token_masked: tokenMasked,
        token_fingerprint: tokenHash.slice(0, 12),
        one_time_secret: true,
        status: 'Offline',
        connectivity: 'Offline',
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to register device';
      res.status(400).json({ error: msg.includes('UNIQUE') ? 'Device name already exists.' : msg });
    }
  });

  router.post('/devices/:id/rotate-token', requirePermission('devices:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid device ID.' });
      return;
    }
    try {
      const rotated = rotateDeviceToken(
        db,
        realtimeHub,
        id,
        { username: req.user!.username, ipAddress: getClientIp(req) },
        getNowMs()
      );
      broadcastDeviceTelemetryById(id);
      res.json(rotated);
    } catch (err) {
      if (err instanceof AdminOpsError) {
        res.status(err.statusCode).json({ error: err.message, code: err.code });
        return;
      }
      res.status(500).json({ error: 'Failed to rotate kiosk credentials.' });
    }
  });

  router.put('/devices/:id', requirePermission('devices:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid device ID.' });
      return;
    }
    const { name, device_type, model_info, ip_address, location } = req.body || {};
    if (!name?.trim() || !ip_address?.trim()) {
      res.status(400).json({ error: 'Device name and IP address are required.' });
      return;
    }
    const existing = db.prepare('SELECT id, name, device_type, model_info, ip_address, location FROM devices WHERE id = ?').get(id);
    if (!existing) {
      res.status(404).json({ error: 'Device not found.' });
      return;
    }
    try {
      db.prepare(
        `UPDATE devices
         SET name = ?, device_type = ?, model_info = ?, ip_address = ?, location = ?
         WHERE id = ?`
      ).run(
        name.trim(),
        device_type || 'Raspberry Pi',
        (model_info || '').trim(),
        ip_address.trim(),
        (location || '').trim(),
        id
      );
      logAudit(
        db,
        req.user!.username,
        `Updated kiosk device "${name.trim()}" configuration`,
        'Devices',
        'Success',
        getClientIp(req),
        {
          actionType: 'DEVICE_UPDATED',
          targetType: 'device',
          targetId: id,
          before: existing,
          after: { name: name.trim(), device_type: device_type || 'Raspberry Pi', ip_address: ip_address.trim(), location: (location || '').trim() },
          isSecurityEvent: true,
        }
      );
      broadcastDeviceTelemetryById(id);
      res.json({ success: true });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Update failed';
      res.status(400).json({ error: msg });
    }
  });

  router.post('/devices/:id/revoke', requirePermission('devices:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid device ID.' });
      return;
    }
    const dev = db.prepare('SELECT * FROM devices WHERE id = ?').get(id) as StoredDeviceRow | undefined;
    if (!dev) {
      res.status(404).json({ error: 'Device not found.' });
      return;
    }
    const nowIso = new Date(getNowMs()).toISOString();
    db.prepare(
      `UPDATE devices
       SET is_revoked = 1, revoked_at = ?, status = 'Offline', last_sync_status = 'Revoked',
           last_sync_error = 'Device credentials revoked by administrator',
           activation_code_hash = '', activation_code_expires_at = NULL
       WHERE id = ?`
    ).run(nowIso, id);
    db.prepare(
      `UPDATE web_kiosk_sessions
       SET revoked_at = ?, revoked_reason = 'device_revoked'
       WHERE device_id = ? AND revoked_at IS NULL`
    ).run(nowIso, id);

    createTargetedNotification(db, realtimeHub, {
      title: `${dev.name} credentials revoked`,
      message: `Kiosk terminal ${dev.name} was administratively revoked and blocked from syncing.`,
      category: 'Device Alerts',
      priority: 'High',
      actionModule: 'devices',
      actionEntityId: id,
      targetRoles: ['Administrator', 'HR Officer'],
      eventType: 'device_revoked',
    });

    logAudit(
      db,
      req.user!.username,
      `Revoked kiosk credentials for "${dev.name}"`,
      'Devices',
      'Warning',
      getClientIp(req),
      {
        actionType: 'DEVICE_REVOKED',
        targetType: 'device',
        targetId: id,
        before: { is_revoked: dev.is_revoked },
        after: { is_revoked: 1, revoked_at: nowIso },
        isSecurityEvent: true,
      }
    );
    broadcastDeviceTelemetryById(id);
    res.json({ success: true, is_revoked: 1, status: 'Offline', connectivity: 'Revoked' });
  });

  router.post('/devices/:id/restore-access', requirePermission('devices:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid device ID.' });
      return;
    }
    const dev = db.prepare('SELECT * FROM devices WHERE id = ?').get(id) as StoredDeviceRow | undefined;
    if (!dev) {
      res.status(404).json({ error: 'Device not found.' });
      return;
    }
    // Restoring access NEVER fakes Online — status remains strictly heartbeat-derived!
    db.prepare(
      `UPDATE devices
       SET is_revoked = 0, revoked_at = NULL, last_sync_status = 'Idle', last_sync_error = ''
       WHERE id = ?`
    ).run(id);
    logAudit(
      db,
      req.user!.username,
      `Restored kiosk credential access for "${dev.name}" (awaiting heartbeat)`,
      'Devices',
      'Success',
      getClientIp(req),
      {
        actionType: 'DEVICE_RESTORED',
        targetType: 'device',
        targetId: id,
        before: { is_revoked: dev.is_revoked },
        after: { is_revoked: 0 },
        isSecurityEvent: true,
      }
    );
    broadcastDeviceTelemetryById(id);
    const updated = db.prepare('SELECT * FROM devices WHERE id = ?').get(id) as StoredDeviceRow;
    const telemetry = computeDeviceTelemetry(updated, getNowMs(), getHeartbeatThresholds());
    res.json({ success: true, is_revoked: 0, status: telemetry.status, connectivity: telemetry.connectivity });
  });

  // BUILD 36: Admin-managed Web Kiosk device activation codes & Kiosk Administrator PIN
  registerWebKioskAdminRoutes(router, {
    db: () => db,
    appMode,
    nowMs: getNowMs,
    realtimeHub,
    broadcastDeviceTelemetryById,
    rateLimit: kioskRateLimiter.middleware((req) => getClientIp(req)),
  });

  // Legacy endpoint preserved as credential suspension toggle (NEVER fabricates Online status)
  router.post('/devices/:id/toggle-status', requirePermission('devices:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid device ID.' });
      return;
    }
    const dev = db.prepare('SELECT * FROM devices WHERE id = ?').get(id) as StoredDeviceRow | undefined;
    if (!dev) {
      res.status(404).json({ error: 'Device not found.' });
      return;
    }
    const nextRevoked = dev.is_revoked === 1 ? 0 : 1;
    const nowIso = new Date(getNowMs()).toISOString();
    if (nextRevoked === 1) {
      db.prepare(
        `UPDATE devices
         SET is_revoked = 1, revoked_at = ?, status = 'Offline', last_sync_status = 'Revoked',
             last_sync_error = 'Device credentials suspended by administrator'
         WHERE id = ?`
      ).run(nowIso, id);
      createTargetedNotification(db, realtimeHub, {
        title: `${dev.name} access suspended`,
        message: `Biometric terminal ${dev.name} credentials were suspended.`,
        category: 'Device Alerts',
        priority: 'High',
        actionModule: 'devices',
        actionEntityId: id,
        targetRoles: ['Administrator', 'HR Officer'],
        eventType: 'device_suspended',
      });
      logAudit(db, req.user!.username, `Suspended kiosk device "${dev.name}" credentials`, 'Devices', 'Warning', getClientIp(req), {
        actionType: 'DEVICE_SUSPENDED',
        targetType: 'device',
        targetId: id,
        isSecurityEvent: true,
      });
    } else {
      db.prepare(
        `UPDATE devices SET is_revoked = 0, revoked_at = NULL, last_sync_status = 'Idle', last_sync_error = '' WHERE id = ?`
      ).run(id);
      logAudit(db, req.user!.username, `Restored kiosk device "${dev.name}" credentials (awaiting heartbeat)`, 'Devices', 'Success', getClientIp(req), {
        actionType: 'DEVICE_RESTORED',
        targetType: 'device',
        targetId: id,
        isSecurityEvent: true,
      });
    }
    broadcastDeviceTelemetryById(id);
    const updated = db.prepare('SELECT * FROM devices WHERE id = ?').get(id) as StoredDeviceRow;
    const telemetry = computeDeviceTelemetry(updated, getNowMs(), getHeartbeatThresholds());
    res.json({ is_revoked: nextRevoked, status: telemetry.status, connectivity: telemetry.connectivity });
  });

  router.delete('/devices/:id', requirePermission('devices:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid device ID.' });
      return;
    }
    const existing = db.prepare('SELECT id, name, ip_address FROM devices WHERE id = ?').get(id) as
      | { id: number; name: string; ip_address: string }
      | undefined;
    db.prepare('DELETE FROM devices WHERE id = ?').run(id);
    logAudit(db, req.user!.username, `Revoked and removed kiosk device #${id}${existing ? ` (${existing.name})` : ''}`, 'Devices', 'Warning', getClientIp(req), {
      actionType: 'DEVICE_DELETED',
      targetType: 'device',
      targetId: id,
      before: existing,
      isSecurityEvent: true,
    });
    res.json({ success: true });
  });

  // -------------------------------------------------------------------------
  // AUDIT LOGS & TAMPER-EVIDENT CHAIN VERIFICATION — Administrator Only
  // -------------------------------------------------------------------------
  router.get('/audit-logs', requirePermission('audit:read'), (req, res) => {
    const search = ((req.query.search as string) || '').trim();
    const moduleFilter = ((req.query.module as string) || '').trim();
    const dateFilter = ((req.query.date as string) || '').trim();
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(200, Math.max(1, Number(req.query.limit) || 15));
    const offset = (page - 1) * limit;

    const where: string[] = [];
    const params: unknown[] = [];
    if (search) {
      where.push('(username LIKE ? OR activity LIKE ? OR module LIKE ?)');
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    if (moduleFilter && moduleFilter !== 'All') {
      where.push('module = ?');
      params.push(moduleFilter);
    }
    if (dateFilter) {
      where.push('date(timestamp) = ?');
      params.push(dateFilter);
    }
    const wSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const total = (db.prepare(`SELECT COUNT(*) as c FROM audit_logs ${wSql}`).get(...params) as { c: number }).c;
    const rows = db
      .prepare(`SELECT * FROM audit_logs ${wSql} ORDER BY id DESC LIMIT ? OFFSET ?`)
      .all(...params, limit, offset);
    res.json({ data: rows, total, page, limit });
  });

  router.get('/audit-logs/verify', requirePermission('audit:read'), (_req, res) => {
    const result = verifyAuditLogChain(db);
    res.status(result.valid ? 200 : 409).json(result);
  });

  router.get('/security/history', requirePermission('settings:read'), (req, res) => {
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 25));
    const events = listSecurityChangeHistory(db, limit);
    res.json({ data: events });
  });

  // -------------------------------------------------------------------------
  // NOTIFICATIONS — Role-Targeted & Server-Persisted
  // -------------------------------------------------------------------------
  router.get('/notifications', requirePermission('notifications:read'), (req: AuthenticatedRequest, res) => {
    evaluateDeviceConnectivityAlerts(db, realtimeHub, getNowMs(), getHeartbeatThresholds());
    const filter = ((req.query.filter as string) || 'All').trim();
    const result = queryNotificationsForRole(db, req.user!.role, filter);
    res.json(result);
  });

  router.patch('/notifications/:id/read', requirePermission('notifications:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid notification ID.' });
      return;
    }
    const updated = markNotificationReadForRole(db, req.user!.role, id);
    if (!updated) {
      res.status(404).json({ error: 'Notification not found in your authorized role scope.' });
      return;
    }
    res.json({ success: true });
  });

  router.post('/notifications/mark-all-read', requirePermission('notifications:write'), (req: AuthenticatedRequest, res) => {
    const { ids } = (req.body || {}) as { ids?: unknown[] };
    const cleanIds = Array.isArray(ids)
      ? ids.map((n) => Number(n)).filter((n) => Number.isInteger(n) && n > 0)
      : [];
    const changes = markNotificationsReadForRole(db, req.user!.role, cleanIds);
    logAudit(
      db,
      req.user!.username,
      cleanIds.length > 0
        ? `Marked ${cleanIds.length} notification(s) as read (${changes} updated)`
        : `Marked all scoped notifications as read (${changes} updated)`,
      'Notifications',
      'Success',
      getClientIp(req),
      { actionType: 'NOTIFICATIONS_MARK_READ', targetType: 'notifications', after: { updated: changes } }
    );
    res.json({ success: true, updated: changes });
  });

  router.delete('/notifications/:id', requirePermission('notifications:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid notification ID.' });
      return;
    }
    const deleted = deleteNotificationForRole(db, req.user!.role, id);
    if (!deleted) {
      res.status(404).json({ error: 'Notification not found in your authorized role scope.' });
      return;
    }
    res.json({ success: true });
  });

  router.delete('/notifications', requirePermission('notifications:write'), (req: AuthenticatedRequest, res) => {
    const { ids } = (req.body || {}) as { ids?: unknown[] };
    const cleanIds = Array.isArray(ids)
      ? ids.map((n) => Number(n)).filter((n) => Number.isInteger(n) && n > 0)
      : [];
    const deleted =
      cleanIds.length > 0
        ? deleteNotificationsForRole(db, req.user!.role, cleanIds)
        : clearNotificationsForRole(db, req.user!.role);
    logAudit(
      db,
      req.user!.username,
      cleanIds.length > 0
        ? `Dismissed ${deleted} selected scoped notification(s)`
        : `Cleared ${deleted} scoped system notification(s)`,
      'Notifications',
      'Warning',
      getClientIp(req),
      {
        actionType: cleanIds.length > 0 ? 'NOTIFICATIONS_BULK_DISMISSED' : 'NOTIFICATIONS_CLEARED',
        targetType: 'notifications',
        after: { deleted, selectiveCount: cleanIds.length },
      }
    );
    res.json({ success: true, deleted });
  });

  // -------------------------------------------------------------------------
  // SYSTEM SETTINGS, BACKUP, LIVE RESTORE & RETENTION — Administrator Only
  // -------------------------------------------------------------------------
  router.get('/settings', requirePermission('settings:read'), (_req, res) => {
    const rows = db.prepare('SELECT key, value, category, updated_at FROM settings').all() as Array<{
      key: string;
      value: string;
      category: string;
      updated_at: string;
    }>;
    const map: Record<string, string> = {};
    for (const r of rows) map[r.key] = r.value;
    res.json({
      settings: map,
      rows,
      secretStatus: {
        sessionSecretConfigured: Boolean(process.env.SESSION_SECRET?.trim()),
        sessionSecretMasked: process.env.SESSION_SECRET?.trim() ? '•••••••••••• (Configured in environment)' : 'Dev Ephemeral Key',
        backupEncryptionConfigured: Boolean(process.env.BACKUP_ENCRYPTION_KEY?.trim()),
        backupEncryptionMasked: process.env.BACKUP_ENCRYPTION_KEY?.trim() ? 'AES-256-GCM (Key Protected)' : 'Not Configured',
        smtpConfigured: Boolean(process.env.SMTP_HOST?.trim()),
        googleSsoConfigured: Boolean(process.env.GOOGLE_OAUTH_CLIENT_ID?.trim()),
      },
    });
  });

  router.put('/settings', requirePermission('settings:write'), (req: AuthenticatedRequest, res) => {
    const { updates } = (req.body || {}) as { updates?: Record<string, unknown> };
    if (!updates || typeof updates !== 'object' || Array.isArray(updates)) {
      res.status(400).json({ error: 'Settings updates object is required.' });
      return;
    }

    try {
      const result = validateAndApplySettingsUpdates(db, updates, {
        username: req.user!.username,
        ipAddress: getClientIp(req),
      });
      res.json({ success: true, updatedKeys: result.updatedKeys, settings: result.settings });
    } catch (err) {
      if (err instanceof AdminOpsError) {
        res.status(err.statusCode).json({
          error: err.message,
          code: err.code,
          fieldErrors: err.fieldErrors || [],
        });
        return;
      }
      res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to save settings.' });
    }
  });

  router.get('/backup/status', requirePermission('backup:export'), (_req, res) => {
    const dbStatus = getDatabaseStatus(db, resolvedDbPath);
    const history = db
      .prepare(
        `SELECT id, backup_id, file_name, manifest_file, encrypted_file, sha256, size_bytes, encrypted,
                integrity_status, foreign_key_violations, schema_version, operation_type, created_by, created_at
         FROM backup_history
         ORDER BY id DESC
         LIMIT 20`
      )
      .all();

    let availableArchives: Array<{ fileName: string; sizeBytes: number; modifiedAt: string; encrypted: boolean }> = [];
    if (fs.existsSync(resolvedBackupDir)) {
      availableArchives = fs
        .readdirSync(resolvedBackupDir)
        .filter((f) => f.startsWith('savage-rsucaj-') && (f.endsWith('.sqlite.enc') || f.endsWith('.sqlite')))
        .sort()
        .reverse()
        .map((fileName) => {
          const st = fs.statSync(path.join(resolvedBackupDir, fileName));
          return {
            fileName,
            sizeBytes: st.size,
            modifiedAt: st.mtime.toISOString(),
            encrypted: fileName.endsWith('.sqlite.enc'),
          };
        });
    }

    res.json({
      mode: appMode,
      database: dbStatus,
      backupDir: resolvedBackupDir,
      backupEncryptionConfigured: Boolean(process.env.BACKUP_ENCRYPTION_KEY?.trim()),
      backupRetentionCount,
      availableArchives,
      history,
    });
  });

  router.post('/backup/snapshot', requirePermission('backup:export'), (req: AuthenticatedRequest, res) => {
    try {
      const result = createOnlineSqliteBackup(db, {
        backupDir: resolvedBackupDir,
        createdBy: req.user!.username,
        encryptionKey: process.env.BACKUP_ENCRYPTION_KEY?.trim() || undefined,
        retentionCount: backupRetentionCount,
        recordInHistory: true,
      });
      logAudit(
        db,
        req.user!.username,
        `Created online SQLite snapshot ${result.manifest.sqliteFile} (encrypted=${result.manifest.encrypted}, sha256=${result.manifest.sqliteSha256.slice(0, 12)}…)`,
        'Settings',
        'Success',
        getClientIp(req),
        {
          actionType: 'BACKUP_SNAPSHOT',
          targetType: 'backup',
          targetId: result.manifest.backupId,
          after: { file: result.manifest.sqliteFile, encrypted: result.manifest.encrypted },
          isSecurityEvent: true,
        }
      );
      res.status(201).json({
        success: true,
        manifest: result.manifest,
        prunedCount: result.prunedFiles.length,
      });
    } catch (err) {
      logAudit(
        db,
        req.user!.username,
        `Online SQLite backup failed: ${err instanceof Error ? err.message : String(err)}`,
        'Settings',
        'Error',
        getClientIp(req),
        { actionType: 'BACKUP_SNAPSHOT_FAILED', targetType: 'backup', isSecurityEvent: true }
      );
      res.status(500).json({ error: err instanceof Error ? err.message : 'Online SQLite backup failed.' });
    }
  });

  router.post('/backup/checkpoint', requirePermission('backup:export'), (req: AuthenticatedRequest, res) => {
    const walResult = db.memory ? { mode: 'TRUNCATE' as const, busy: 0, log: 0, checkpointed: 0 } : checkpointWal(db, 'TRUNCATE');
    const dbStatus = getDatabaseStatus(db, resolvedDbPath);
    const cpId = `chk-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    db.prepare(
      `INSERT INTO backup_history
        (backup_id, file_name, sha256, size_bytes, encrypted, integrity_status, foreign_key_violations, schema_version, table_counts_json, operation_type, created_by)
       VALUES (?, ?, 'n/a', ?, 0, ?, ?, ?, ?, 'checkpoint', ?)`
    ).run(
      cpId,
      path.basename(resolvedDbPath),
      dbStatus.dbFileBytes,
      dbStatus.integrityCheck,
      dbStatus.foreignKeyViolations,
      dbStatus.schemaVersion,
      JSON.stringify(dbStatus.tableCounts),
      req.user!.username
    );
    logAudit(
      db,
      req.user!.username,
      `Executed SQLite WAL checkpoint (TRUNCATE: ${walResult.checkpointed}/${walResult.log} frames, wal=${dbStatus.walFileBytes}B)`,
      'Settings',
      'Success',
      getClientIp(req),
      { actionType: 'BACKUP_CHECKPOINT', targetType: 'database', isSecurityEvent: true }
    );
    res.json({ success: true, checkpoint: walResult, database: dbStatus });
  });

  router.post('/backup/verify-drill', requirePermission('backup:export'), (req: AuthenticatedRequest, res) => {
    const { fileName } = (req.body || {}) as { fileName?: string };
    let targetArchivePath: string | null = null;

    const baseBackupDir = path.resolve(resolvedBackupDir);
    if (typeof fileName === 'string' && fileName.trim()) {
      const trimmed = fileName.trim();
      const safeName = path.basename(trimmed);
      if (
        trimmed !== safeName ||
        !safeName.startsWith('savage-rsucaj-') ||
        (!safeName.endsWith('.sqlite') && !safeName.endsWith('.sqlite.enc'))
      ) {
        res.status(400).json({ error: 'Invalid backup archive filename.' });
        return;
      }
      const candidate = path.resolve(baseBackupDir, safeName);
      if (!candidate.startsWith(baseBackupDir + path.sep)) {
        res.status(400).json({ error: 'Backup archive path is outside BACKUP_DIR.' });
        return;
      }
      targetArchivePath = candidate;
    } else if (fs.existsSync(baseBackupDir)) {
      const candidates = fs
        .readdirSync(baseBackupDir)
        .filter((f) => f.startsWith('savage-rsucaj-') && (f.endsWith('.sqlite.enc') || f.endsWith('.sqlite')))
        .sort()
        .reverse();
      if (candidates.length > 0) {
        targetArchivePath = path.resolve(baseBackupDir, candidates[0]);
      }
    }

    if (!targetArchivePath || !fs.existsSync(targetArchivePath)) {
      res.status(404).json({
        error: 'No online SQLite backup archive found in BACKUP_DIR. Create a snapshot first before running a restore drill.',
      });
      return;
    }

    const drill = restoreSqliteBackup(targetArchivePath, resolvedDbPath, {
      encryptionKey: process.env.BACKUP_ENCRYPTION_KEY?.trim() || undefined,
      dryRun: true,
    });

    const drillId = `drl-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    db.prepare(
      `INSERT INTO backup_history
        (backup_id, file_name, sha256, size_bytes, encrypted, integrity_status, foreign_key_violations, schema_version, table_counts_json, operation_type, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'restore_drill', ?)`
    ).run(
      drillId,
      path.basename(targetArchivePath),
      drill.verification.sqliteSha256 || 'failed',
      fs.statSync(targetArchivePath).size,
      drill.verification.encrypted ? 1 : 0,
      drill.verification.integrityCheck || (drill.ok ? 'ok' : 'failed'),
      Math.max(0, drill.verification.foreignKeyViolations),
      drill.verification.schemaVersion || '000',
      JSON.stringify(drill.verification.tableCounts),
      req.user!.username
    );

    logAudit(
      db,
      req.user!.username,
      `Restore verification drill on ${path.basename(targetArchivePath)}: ${drill.ok ? 'PASS' : 'FAIL'}`,
      'Settings',
      drill.ok ? 'Success' : 'Error',
      getClientIp(req),
      {
        actionType: 'BACKUP_VERIFY_DRILL',
        targetType: 'backup',
        targetId: path.basename(targetArchivePath),
        after: { ok: drill.ok, integrity: drill.verification.integrityCheck },
        isSecurityEvent: true,
      }
    );

    res.status(drill.ok ? 200 : 422).json({
      success: drill.ok,
      archiveFile: path.basename(targetArchivePath),
      dryRun: true,
      verification: drill.verification,
      errors: drill.errors,
    });
  });

  // Guarded Live SQLite Restore (Administrator only, password + confirmation phrase + safety snapshot + auto-rollback)
  router.post('/backup/restore', requirePermission('backup:export'), (req: AuthenticatedRequest, res) => {
    if (req.user!.role !== 'Administrator') {
      res.status(403).json({ error: 'Only an Administrator may execute a live database restore.', code: 'FORBIDDEN' });
      return;
    }
    if (db.memory || resolvedDbPath === ':memory:') {
      res.status(400).json({
        error: 'Live SQLite file restore is not supported on in-memory databases.',
        code: 'LIVE_RESTORE_REQUIRES_FILE_DB',
      });
      return;
    }

    const { fileName, confirmText, currentPassword } = (req.body || {}) as {
      fileName?: string;
      confirmText?: string;
      currentPassword?: string;
    };

    if (confirmText !== 'RESTORE LIVE DATABASE') {
      res.status(400).json({
        error: 'Confirmation phrase mismatch. Type exactly "RESTORE LIVE DATABASE" to confirm.',
        code: 'CONFIRMATION_REQUIRED',
      });
      return;
    }
    if (!currentPassword || typeof currentPassword !== 'string') {
      res.status(400).json({ error: 'Your current Administrator password is required to authorize live database restore.' });
      return;
    }

    const userCreds = db
      .prepare('SELECT password_hash, salt FROM users WHERE id = ?')
      .get(req.user!.id) as { password_hash: string; salt: string } | undefined;
    if (!userCreds || !verifyPassword(currentPassword, userCreds.password_hash, userCreds.salt)) {
      logAudit(db, req.user!.username, 'Rejected live database restore due to invalid administrator password', 'Security', 'Error', getClientIp(req), {
        actionType: 'BACKUP_RESTORE_REJECTED',
        targetType: 'database',
        isSecurityEvent: true,
      });
      res.status(403).json({ error: 'Administrator password verification failed.' });
      return;
    }

    const trimmedName = typeof fileName === 'string' ? fileName.trim() : '';
    const safeName = trimmedName ? path.basename(trimmedName) : '';
    if (
      !safeName ||
      trimmedName !== safeName ||
      !safeName.startsWith('savage-rsucaj-') ||
      (!safeName.endsWith('.sqlite') && !safeName.endsWith('.sqlite.enc'))
    ) {
      res.status(400).json({ error: 'Select a valid SAVAGE-RSUCAJ backup archive (.sqlite or .sqlite.enc).' });
      return;
    }

    const baseBackupDir = path.resolve(resolvedBackupDir);
    const targetArchivePath = path.resolve(baseBackupDir, safeName);
    if (!targetArchivePath.startsWith(baseBackupDir + path.sep)) {
      res.status(400).json({ error: 'Backup archive path is outside BACKUP_DIR.' });
      return;
    }
    if (!fs.existsSync(targetArchivePath)) {
      res.status(404).json({ error: `Backup archive "${safeName}" was not found in BACKUP_DIR.` });
      return;
    }

    const encryptionKey = process.env.BACKUP_ENCRYPTION_KEY?.trim() || undefined;
    const preVerify = verifyBackupArchive(targetArchivePath, { encryptionKey });
    if (!preVerify.valid) {
      logAudit(db, req.user!.username, `Aborted live restore of ${safeName} due to pre-restore verification failure`, 'Settings', 'Error', getClientIp(req), {
        actionType: 'BACKUP_RESTORE_ABORTED',
        targetType: 'backup',
        targetId: safeName,
        after: { errors: preVerify.errors },
        isSecurityEvent: true,
      });
      res.status(422).json({
        success: false,
        rolledBack: false,
        error: `Backup archive failed pre-restore verification: ${preVerify.errors.join(' ')}`,
        errors: preVerify.errors,
        verification: preVerify,
      });
      return;
    }

    // Close active handle cleanly before atomic filesystem swap, then reopen & rebind router handle
    try {
      closeDatabaseSafely(db);
    } catch {
      // continue to restore + reopen recovery
    }

    const restoreRes = restoreSqliteBackup(targetArchivePath, resolvedDbPath, {
      encryptionKey,
      dryRun: false,
    });

    const reopenedDb = initDatabase(resolvedDbPath, {
      mode: appMode,
      seedDemoData: false,
      skipAdminBootstrap: true,
    });
    db = reopenedDb;
    options.onDatabaseReplaced?.(reopenedDb);

    if (!restoreRes.ok) {
      logAudit(
        db,
        req.user!.username,
        `Live restore failed on ${safeName} (rolledBack=${restoreRes.rolledBack})`,
        'Settings',
        'Error',
        getClientIp(req),
        {
          actionType: 'BACKUP_RESTORE_FAILED',
          targetType: 'database',
          targetId: safeName,
          after: { errors: restoreRes.errors, rolledBack: restoreRes.rolledBack },
          isSecurityEvent: true,
        }
      );
      res.status(422).json({
        success: false,
        rolledBack: restoreRes.rolledBack,
        preRestoreBackupFile: restoreRes.preRestoreBackupPath ? path.basename(restoreRes.preRestoreBackupPath) : null,
        error: restoreRes.errors.join(' '),
        errors: restoreRes.errors,
        verification: restoreRes.verification,
      });
      return;
    }

    const restoreId = `rst-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    db.prepare(
      `INSERT INTO backup_history
        (backup_id, file_name, sha256, size_bytes, encrypted, integrity_status, foreign_key_violations, schema_version, table_counts_json, operation_type, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'restore', ?)`
    ).run(
      restoreId,
      safeName,
      restoreRes.verification.sqliteSha256 || 'verified',
      fs.statSync(targetArchivePath).size,
      restoreRes.verification.encrypted ? 1 : 0,
      restoreRes.verification.integrityCheck || 'ok',
      Math.max(0, restoreRes.verification.foreignKeyViolations),
      restoreRes.verification.schemaVersion || '009',
      JSON.stringify(restoreRes.verification.tableCounts),
      req.user!.username
    );

    logAudit(
      db,
      req.user!.username,
      `Restored live SQLite database from archive ${safeName} (safety snapshot: ${restoreRes.preRestoreBackupPath ? path.basename(restoreRes.preRestoreBackupPath) : 'none'})`,
      'Settings',
      'Warning',
      getClientIp(req),
      {
        actionType: 'BACKUP_RESTORE_LIVE',
        targetType: 'database',
        targetId: safeName,
        after: {
          schemaVersion: restoreRes.verification.schemaVersion,
          sha256: restoreRes.verification.sqliteSha256?.slice(0, 12),
          preRestoreBackupFile: restoreRes.preRestoreBackupPath ? path.basename(restoreRes.preRestoreBackupPath) : null,
        },
        isSecurityEvent: true,
      }
    );

    createTargetedNotification(db, realtimeHub, {
      title: `Live database restored from ${safeName}`,
      message: `Administrator ${req.user!.username} restored the SQLite database (${restoreRes.verification.integrityCheck}, schema ${restoreRes.verification.schemaVersion}).`,
      category: 'System Notices',
      priority: 'High',
      actionModule: 'settings',
      targetRoles: ['Administrator'],
      eventType: 'database_restored',
      createdAt: formatManilaDateTime(getNowMs()),
    });

    res.json({
      success: true,
      restoredFrom: safeName,
      preRestoreBackupFile: restoreRes.preRestoreBackupPath ? path.basename(restoreRes.preRestoreBackupPath) : null,
      verification: restoreRes.verification,
    });
  });

  // Data Retention Preview (Dry-Run) & Policy-Compliant Execution
  router.get('/retention/preview', requirePermission('settings:read'), (req, res) => {
    try {
      const attDays = req.query.attendanceDays !== undefined ? Number(req.query.attendanceDays) : undefined;
      const audDays = req.query.auditDays !== undefined ? Number(req.query.auditDays) : undefined;
      const preview = previewDataRetention(db, getNowMs(), {
        attendanceRetentionDays: attDays,
        auditLogRetentionDays: audDays,
      });
      res.json(preview);
    } catch (err) {
      if (err instanceof AdminOpsError) {
        res.status(err.statusCode).json({ error: err.message, code: err.code });
        return;
      }
      res.status(400).json({ error: err instanceof Error ? err.message : 'Retention preview failed.' });
    }
  });

  router.post('/retention/execute', requirePermission('settings:write'), (req: AuthenticatedRequest, res) => {
    try {
      const { attendanceRetentionDays, auditLogRetentionDays, confirmExecute } = (req.body || {}) as {
        attendanceRetentionDays?: number;
        auditLogRetentionDays?: number;
        confirmExecute?: boolean;
      };
      if (confirmExecute !== true) {
        res.status(400).json({ error: 'Explicit confirmation flag confirmExecute=true is required to purge expired records.' });
        return;
      }
      const job = executeDataRetention(
        db,
        realtimeHub,
        { username: req.user!.username, ipAddress: getClientIp(req) },
        getNowMs(),
        {
          attendanceRetentionDays: attendanceRetentionDays !== undefined ? Number(attendanceRetentionDays) : undefined,
          auditLogRetentionDays: auditLogRetentionDays !== undefined ? Number(auditLogRetentionDays) : undefined,
        }
      );
      res.status(201).json({ success: true, job });
    } catch (err) {
      if (err instanceof AdminOpsError) {
        res.status(err.statusCode).json({ error: err.message, code: err.code });
        return;
      }
      res.status(500).json({ error: err instanceof Error ? err.message : 'Retention execution failed.' });
    }
  });

  router.get('/retention/jobs', requirePermission('settings:read'), (req, res) => {
    const limit = Math.min(50, Math.max(1, Number(req.query.limit) || 20));
    res.json({ data: listRetentionJobs(db, limit) });
  });

  router.get('/backup/export', requirePermission('backup:export'), (req: AuthenticatedRequest, res) => {
    const payload = {
      exportedAt: new Date(getNowMs()).toISOString(),
      system: 'SAVAGE-RSUCAJ Smart Attendance System',
      version: '1.13.0',
      build: 'BUILD 17',
      tables: {
        schema_migrations: db.prepare('SELECT * FROM schema_migrations').all(),
        departments: db.prepare('SELECT * FROM departments').all(),
        positions: db.prepare('SELECT * FROM positions').all(),
        shifts: db.prepare('SELECT * FROM shifts').all(),
        holidays: db.prepare('SELECT * FROM holidays').all(),
        employees: db.prepare('SELECT * FROM employees').all(),
        attendance_records: db.prepare('SELECT * FROM attendance_records').all(),
        attendance_events: db.prepare('SELECT * FROM attendance_events').all(),
        corrections: db.prepare('SELECT * FROM corrections').all(),
        correction_audit_log: db.prepare('SELECT * FROM correction_audit_log').all(),
        leaves: db.prepare('SELECT * FROM leaves').all(),
        leave_policies: db.prepare('SELECT * FROM leave_policies').all(),
        leave_day_allocations: db.prepare('SELECT * FROM leave_day_allocations').all(),
        leave_audit_log: db.prepare('SELECT * FROM leave_audit_log').all(),
        payroll_policies: db.prepare('SELECT * FROM payroll_policies').all(),
        payroll_runs: db.prepare('SELECT * FROM payroll_runs').all(),
        payroll_items: db.prepare('SELECT * FROM payroll_items').all(),
        payroll_audit_log: db.prepare('SELECT * FROM payroll_audit_log').all(),
        dtr_signoffs: db.prepare('SELECT * FROM dtr_signoffs').all(),
        devices: db
          .prepare(
            `SELECT id, name, device_type, model_info, ip_address, location, status, last_heartbeat,
                    last_heartbeat_utc, last_sync_utc, pending_queue_count, last_clock_drift_seconds,
                    last_monotonic_seq, last_sync_status, is_revoked, revoked_at, device_boot_id,
                    token_masked, token_rotated_at, created_at
             FROM devices`
          )
          .all(),
        kiosk_sync_batches: db.prepare('SELECT * FROM kiosk_sync_batches').all(),
        retention_jobs: db.prepare('SELECT * FROM retention_jobs').all(),
        settings: db.prepare('SELECT * FROM settings').all(),
      },
    };
    logAudit(db, req.user!.username, 'Exported full JSON database backup', 'Settings', 'Success', getClientIp(req), {
      actionType: 'BACKUP_JSON_EXPORT',
      targetType: 'backup',
      isSecurityEvent: true,
    });
    res.json(payload);
  });

  // =========================================================================
  // STAGING OPERATIONS (BUILD 16): Controllable Network Impairment & Structured Logs
  // Strictly disabled in APP_MODE=production (returns HTTP 403).
  // =========================================================================
  router.get('/staging/impairment', requirePermission('settings:write'), (_req, res) => {
    if (appMode === 'production' || !impairmentController.isAllowed()) {
      res.status(403).json({
        error: 'Staging network impairment endpoints are disabled in production mode.',
        code: 'STAGING_ONLY_ENDPOINT',
      });
      return;
    }
    res.json({
      mode: appMode,
      impairment: impairmentController.getState(getNowMs()),
      request_id: res.locals.requestId ?? null,
    });
  });

  router.put('/staging/impairment', requirePermission('settings:write'), (req: AuthenticatedRequest, res) => {
    if (appMode === 'production' || !impairmentController.isAllowed()) {
      res.status(403).json({
        error: 'Staging network impairment endpoints are disabled in production mode.',
        code: 'STAGING_ONLY_ENDPOINT',
      });
      return;
    }
    try {
      const before = impairmentController.getState(getNowMs());
      const nextState = impairmentController.update(req.body || {}, req.user!.username, getNowMs());
      logAudit(
        db,
        req.user!.username,
        `Updated staging network impairment (enabled=${nextState.enabled}, latency=${nextState.latencyMs}ms, drop=${nextState.dropRatePercent}%)`,
        'Settings',
        'Success',
        getClientIp(req),
        {
          actionType: 'STAGING_IMPAIRMENT_UPDATE',
          targetType: 'staging_impairment',
          before,
          after: nextState,
          isSecurityEvent: true,
        }
      );
      res.json({
        ok: true,
        mode: appMode,
        impairment: nextState,
        request_id: res.locals.requestId ?? null,
      });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Invalid staging impairment configuration.',
        code: 'INVALID_IMPAIRMENT_CONFIG',
      });
    }
  });

  router.get('/staging/logs', requirePermission('settings:write'), (req, res) => {
    if (appMode === 'production') {
      res.status(403).json({
        error: 'Staging structured log inspection endpoint is disabled in production mode.',
        code: 'STAGING_ONLY_ENDPOINT',
      });
      return;
    }
    const limit = Math.min(500, Math.max(1, Number(req.query.limit) || 100));
    res.json({
      mode: appMode,
      metrics: structuredLogStore.getMetrics(),
      entries: structuredLogStore.list(limit),
      request_id: res.locals.requestId ?? null,
    });
  });

  // Centralized SQLite / runtime error boundary (maps unavailable DB cleanly to HTTP 503)
  router.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    if (isDatabaseUnavailableError(err)) {
      res.status(503).json({
        error: 'Database is temporarily unavailable. Please retry or contact RSU Cajidiocan MIS.',
        code: 'DATABASE_UNAVAILABLE',
      });
      return;
    }
    console.error('Unhandled API error:', err instanceof Error ? err.message : err);
    res.status(500).json({ error: 'Internal server error.' });
  });

  return router;
}
