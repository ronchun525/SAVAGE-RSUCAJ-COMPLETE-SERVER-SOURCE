import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type Database from 'better-sqlite3';
import type { AppMode } from './env.ts';

/**
 * SAVAGE-RSUCAJ BUILD 36 — Verified Biometric Model Specifications (from BUILD 20)
 *
 * CRITICAL HONESTY & SECURITY INVARIANT:
 * - Never fabricate biometric inference or pretend missing .tflite models are loaded.
 * - All preprocessing, output decoding, normalization, and SHA-256 verification strictly
 *   follow the BUILD 20 model contracts.
 */
export type KioskModelKey = 'anti_spoofing_pad' | 'liveness_detection' | 'face_recognition';

export interface KioskModelSpec {
  key: KioskModelKey;
  filename: string;
  architecture: string;
  expectedSha256: string;
  inputShape: readonly [number, number, number, number];
  layout: 'NHWC' | 'NCHW';
  colorOrder: 'RGB' | 'BGR';
  normalization: 'MINUS_ONE_TO_ONE' | 'ZERO_TO_ONE';
  outputShape: readonly [number, number];
  liveClassIndex: number | null;
  embeddingDim: number | null;
  description: string;
}

export const KIOSK_MODEL_SPECS: Record<KioskModelKey, KioskModelSpec> = {
  anti_spoofing_pad: {
    key: 'anti_spoofing_pad',
    filename: 'anti_spoofing_pad.tflite',
    architecture: 'MiniFASNetV1',
    expectedSha256: '5d573d20b795a19d7b2a0f67cc4c1130ce8ec30d5f6aa06b2c788a344a49d4dd',
    inputShape: [1, 80, 80, 3],
    layout: 'NHWC',
    colorOrder: 'RGB',
    normalization: 'MINUS_ONE_TO_ONE',
    outputShape: [1, 3],
    liveClassIndex: 0,
    embeddingDim: null,
    description: 'Presentation Attack Detection (PAD) / Anti-Spoofing classifier (live_class=0)',
  },
  liveness_detection: {
    key: 'liveness_detection',
    filename: 'liveness_detection.tflite',
    architecture: 'MiniFASNetV2',
    expectedSha256: '4ff758f470b757d9005b418c9978693f09b8f2a5e7b7ee848c160db21208e1b2',
    inputShape: [1, 3, 80, 80],
    layout: 'NCHW',
    colorOrder: 'BGR',
    normalization: 'ZERO_TO_ONE',
    outputShape: [1, 3],
    liveClassIndex: 1,
    embeddingDim: null,
    description: 'Passive RGB Liveness Detection classifier (live_class=1; passive PAD, not blink)',
  },
  face_recognition: {
    key: 'face_recognition',
    filename: 'face_recognition.tflite',
    architecture: 'MobileFaceNet',
    expectedSha256: 'be4bc7cfc53f7bc336d0f28b1ab92535f618c913a422b683210750f6b5354854',
    inputShape: [1, 112, 112, 3],
    layout: 'NHWC',
    colorOrder: 'RGB',
    normalization: 'MINUS_ONE_TO_ONE',
    outputShape: [1, 192],
    liveClassIndex: null,
    embeddingDim: 192,
    description: '192-dimensional L2-normalized frontal face recognition embedding extractor',
  },
};

export const EMBEDDING_DIMENSION = 192;

// Uncalibrated staging thresholds — NOT certified production cutoffs (never silently lowered!)
export const BIOMETRIC_THRESHOLDS = {
  CALIBRATION_STATUS: 'UNCALIBRATED_STAGING_ONLY',
  FACE_DETECTION_MIN_CONFIDENCE: 0.80,
  FACE_QUALITY_MIN_SCORE: 0.72,
  LIVENESS_MIN_SCORE: 0.80,
  ANTI_SPOOF_MIN_SCORE: 0.80,
  RECOGNITION_MATCH_MIN_SIMILARITY: 0.62,
  DUPLICATE_IDENTITY_MIN_SIMILARITY: 0.68,
  MIN_ENROLLMENT_FRAMES: 3,
  MAX_ENROLLMENT_FRAMES: 7,
  L2_NORM_TOLERANCE: 0.05,
} as const;

export type ModelDiskStatus = 'VERIFIED_ON_DISK' | 'MISSING' | 'INVALID_HEADER' | 'HASH_MISMATCH';

export interface InspectedModelInfo {
  key: KioskModelKey;
  filename: string;
  architecture: string;
  status: ModelDiskStatus;
  size_bytes: number | null;
  expected_sha256: string;
  actual_sha256: string | null;
  input_shape: readonly number[];
  layout: 'NHWC' | 'NCHW';
  color_order: 'RGB' | 'BGR';
  output_shape: readonly number[];
  live_class_index: number | null;
  reason: string;
}

export interface KioskModelsInspectionResult {
  models_dir: string;
  all_models_verified_on_disk: boolean;
  server_inference_available: boolean;
  production_attendance_ready: boolean;
  blocking_reasons: string[];
  models: Record<KioskModelKey, InspectedModelInfo>;
}

// This state is set ONLY by a genuine YuNet + three-model subprocess probe.
// It expires automatically to prevent stale success after worker failure.
let trustedRuntimeLastVerifiedMs = 0;
export function markTrustedKioskRuntimeProbe(verified: boolean): void {
  trustedRuntimeLastVerifiedMs = verified ? Date.now() : 0;
}

const TFLITE_MAGIC_ASCII = 'TFL3';

export function resolveModelsDirectory(overrideDir?: string): string {
  const raw = (overrideDir || process.env.KIOSK_MODELS_DIR || '').trim();
  return raw ? path.resolve(raw) : path.resolve(process.cwd(), 'models');
}

export function inspectSingleModelFile(spec: KioskModelSpec, modelsDir: string): InspectedModelInfo {
  const fullPath = path.join(modelsDir, spec.filename);
  if (!fs.existsSync(fullPath)) {
    return {
      key: spec.key,
      filename: spec.filename,
      architecture: spec.architecture,
      status: 'MISSING',
      size_bytes: null,
      expected_sha256: spec.expectedSha256,
      actual_sha256: null,
      input_shape: spec.inputShape,
      layout: spec.layout,
      color_order: spec.colorOrder,
      output_shape: spec.outputShape,
      live_class_index: spec.liveClassIndex,
      reason: `Model binary "${spec.filename}" is missing from ${modelsDir}.`,
    };
  }

  const buf = fs.readFileSync(fullPath);
  const magic = buf.length >= 8 ? buf.subarray(4, 8).toString('ascii') : '';
  const sha256 = crypto.createHash('sha256').update(buf).digest('hex');

  if (magic !== TFLITE_MAGIC_ASCII) {
    return {
      key: spec.key,
      filename: spec.filename,
      architecture: spec.architecture,
      status: 'INVALID_HEADER',
      size_bytes: buf.length,
      expected_sha256: spec.expectedSha256,
      actual_sha256: sha256,
      input_shape: spec.inputShape,
      layout: spec.layout,
      color_order: spec.colorOrder,
      output_shape: spec.outputShape,
      live_class_index: spec.liveClassIndex,
      reason: `File "${spec.filename}" does not contain a valid FlatBuffers TFL3 header.`,
    };
  }

  if (sha256 !== spec.expectedSha256) {
    return {
      key: spec.key,
      filename: spec.filename,
      architecture: spec.architecture,
      status: 'HASH_MISMATCH',
      size_bytes: buf.length,
      expected_sha256: spec.expectedSha256,
      actual_sha256: sha256,
      input_shape: spec.inputShape,
      layout: spec.layout,
      color_order: spec.colorOrder,
      output_shape: spec.outputShape,
      live_class_index: spec.liveClassIndex,
      reason: `SHA-256 mismatch for "${spec.filename}" (expected ${spec.expectedSha256.slice(0, 12)}..., got ${sha256.slice(0, 12)}...).`,
    };
  }

  return {
    key: spec.key,
    filename: spec.filename,
    architecture: spec.architecture,
    status: 'VERIFIED_ON_DISK',
    size_bytes: buf.length,
    expected_sha256: spec.expectedSha256,
    actual_sha256: sha256,
    input_shape: spec.inputShape,
    layout: spec.layout,
    color_order: spec.colorOrder,
    output_shape: spec.outputShape,
    live_class_index: spec.liveClassIndex,
    reason: 'Verified TFL3 binary with pinned SHA-256.',
  };
}

export function inspectKioskModels(overrideDir?: string): KioskModelsInspectionResult {
  const modelsDir = resolveModelsDirectory(overrideDir);
  const pad = inspectSingleModelFile(KIOSK_MODEL_SPECS.anti_spoofing_pad, modelsDir);
  const liveness = inspectSingleModelFile(KIOSK_MODEL_SPECS.liveness_detection, modelsDir);
  const recognition = inspectSingleModelFile(KIOSK_MODEL_SPECS.face_recognition, modelsDir);

  const allVerified =
    pad.status === 'VERIFIED_ON_DISK' &&
    liveness.status === 'VERIFIED_ON_DISK' &&
    recognition.status === 'VERIFIED_ON_DISK';

  // BUILD 42: Runtime must pass an actual trusted-worker health probe recently.
  // Do not confuse installed model files with verified server-side inference.
  const serverInferenceAvailable = trustedRuntimeLastVerifiedMs > 0 &&
    Date.now() - trustedRuntimeLastVerifiedMs < 90_000;
  // Explicit calibration approval is NEVER inferred from a successful smoke/probe.
  const calibrationApproved = process.env.KIOSK_BIOMETRIC_CALIBRATION_APPROVED === 'YES_VERIFIED';

  const blockingReasons: string[] = [];
  if (pad.status !== 'VERIFIED_ON_DISK') blockingReasons.push(pad.reason);
  if (liveness.status !== 'VERIFIED_ON_DISK') blockingReasons.push(liveness.reason);
  if (recognition.status !== 'VERIFIED_ON_DISK') blockingReasons.push(recognition.reason);
  if (!serverInferenceAvailable) {
    blockingReasons.push(
      'Trusted server-side biometric attestation and calibrated camera-frame verification are not integrated; diagnostic-only LiteRT inference cannot authorize attendance.'
    );
  }

  if (!calibrationApproved) blockingReasons.push(
    'PAD, liveness and identity thresholds require approved real-device calibration before official attendance.'
  );

  return {
    models_dir: modelsDir,
    all_models_verified_on_disk: allVerified,
    server_inference_available: serverInferenceAvailable,
    production_attendance_ready: allVerified && serverInferenceAvailable && calibrationApproved,
    blocking_reasons: blockingReasons,
    models: {
      anti_spoofing_pad: pad,
      liveness_detection: liveness,
      face_recognition: recognition,
    },
  };
}

// ============================================================================
// BUILD 20 EXACT TENSOR PREPROCESSING & OUTPUT DECODING UTILITIES
// ============================================================================

/**
 * MiniFASNetV1 Anti-Spoofing PAD:
 * float32 [1, 80, 80, 3] RGB NHWC, normalized via (px / 128.0) - 1.0
 */
export function encodePadRgbNhwc(rgbaPixels: Uint8ClampedArray | Uint8Array, width = 80, height = 80): Float32Array {
  if (rgbaPixels.length < width * height * 4) {
    throw new Error(`Expected RGBA buffer of at least ${width * height * 4} bytes for PAD 80x80.`);
  }
  const out = new Float32Array(width * height * 3);
  let dst = 0;
  for (let i = 0; i < width * height * 4; i += 4) {
    out[dst++] = rgbaPixels[i] / 128.0 - 1.0; // R
    out[dst++] = rgbaPixels[i + 1] / 128.0 - 1.0; // G
    out[dst++] = rgbaPixels[i + 2] / 128.0 - 1.0; // B
  }
  return out;
}

/**
 * MiniFASNetV2 Passive Liveness Detection:
 * float32 [1, 3, 80, 80] BGR NCHW, normalized via px / 255.0
 */
export function encodeLivenessBgrNchw(rgbaPixels: Uint8ClampedArray | Uint8Array, width = 80, height = 80): Float32Array {
  const planeSize = width * height;
  if (rgbaPixels.length < planeSize * 4) {
    throw new Error(`Expected RGBA buffer of at least ${planeSize * 4} bytes for Liveness 80x80.`);
  }
  const out = new Float32Array(planeSize * 3);
  for (let p = 0; p < planeSize; p++) {
    const base = p * 4;
    out[p] = rgbaPixels[base + 2] / 255.0; // Channel 0 = B
    out[planeSize + p] = rgbaPixels[base + 1] / 255.0; // Channel 1 = G
    out[planeSize * 2 + p] = rgbaPixels[base] / 255.0; // Channel 2 = R
  }
  return out;
}

/**
 * MobileFaceNet Face Recognition:
 * float32 [1, 112, 112, 3] RGB NHWC, normalized via (px / 128.0) - 1.0
 */
export function encodeRecognitionRgbNhwc(
  rgbaPixels: Uint8ClampedArray | Uint8Array,
  width = 112,
  height = 112
): Float32Array {
  if (rgbaPixels.length < width * height * 4) {
    throw new Error(`Expected RGBA buffer of at least ${width * height * 4} bytes for Recognition 112x112.`);
  }
  const out = new Float32Array(width * height * 3);
  let dst = 0;
  for (let i = 0; i < width * height * 4; i += 4) {
    out[dst++] = rgbaPixels[i] / 128.0 - 1.0; // R
    out[dst++] = rgbaPixels[i + 1] / 128.0 - 1.0; // G
    out[dst++] = rgbaPixels[i + 2] / 128.0 - 1.0; // B
  }
  return out;
}

export interface DecodedClassifierResult {
  valid: boolean;
  liveProbability: number;
  probabilities: number[];
  wasAlreadyProbability: boolean;
  reason?: string;
}

/**
 * Decodes a 3-class PAD / Liveness model output tensor.
 * - Rejects NaN / Infinity / malformed lengths fail-closed.
 * - Preserves outputs that are already valid probability distributions (all in [0,1] and sum ~= 1.0).
 * - Applies numerically stabilized softmax to raw logits.
 */
export function decodeClassifierLiveScore(
  rawValues: ArrayLike<number>,
  liveClassIndex: number
): DecodedClassifierResult {
  if (!rawValues || rawValues.length !== 3) {
    return {
      valid: false,
      liveProbability: 0,
      probabilities: [],
      wasAlreadyProbability: false,
      reason: `Expected 3-class output vector, got length ${rawValues ? rawValues.length : 0}.`,
    };
  }
  if (liveClassIndex < 0 || liveClassIndex >= 3) {
    return {
      valid: false,
      liveProbability: 0,
      probabilities: [],
      wasAlreadyProbability: false,
      reason: `Invalid liveClassIndex ${liveClassIndex}.`,
    };
  }

  const values = [Number(rawValues[0]), Number(rawValues[1]), Number(rawValues[2])];
  if (values.some((v) => !Number.isFinite(v))) {
    return {
      valid: false,
      liveProbability: 0,
      probabilities: [],
      wasAlreadyProbability: false,
      reason: 'Model output contains NaN or Infinity (fail-closed).',
    };
  }

  const allInUnitRange = values.every((v) => v >= 0 && v <= 1);
  const sum = values[0] + values[1] + values[2];
  if (allInUnitRange && Math.abs(sum - 1.0) <= 0.015) {
    const normalized = values.map((v) => v / sum);
    return {
      valid: true,
      liveProbability: normalized[liveClassIndex],
      probabilities: normalized,
      wasAlreadyProbability: true,
    };
  }

  // Stabilized softmax for raw logits
  const maxVal = Math.max(...values);
  const exps = values.map((v) => Math.exp(v - maxVal));
  const expSum = exps[0] + exps[1] + exps[2];
  if (!Number.isFinite(expSum) || expSum <= 0) {
    return {
      valid: false,
      liveProbability: 0,
      probabilities: [],
      wasAlreadyProbability: false,
      reason: 'Softmax normalization overflowed (fail-closed).',
    };
  }
  const probs = exps.map((e) => e / expSum);
  return {
    valid: true,
    liveProbability: probs[liveClassIndex],
    probabilities: probs,
    wasAlreadyProbability: false,
  };
}

// ============================================================================
// EMBEDDING NORMALIZATION, COSINE MATCHING & AES-256-GCM TEMPLATE STORAGE
// ============================================================================

export function computeL2Norm(vec: ArrayLike<number>): number {
  let sumSq = 0;
  for (let i = 0; i < vec.length; i++) {
    const v = vec[i];
    if (!Number.isFinite(v)) return Number.NaN;
    sumSq += v * v;
  }
  return Math.sqrt(sumSq);
}

export function validateL2NormalizedEmbedding(raw: unknown): {
  valid: boolean;
  embedding?: number[];
  norm?: number;
  reason?: string;
} {
  if (!Array.isArray(raw) || raw.length !== EMBEDDING_DIMENSION) {
    return {
      valid: false,
      reason: `Face embedding must be an array of exactly ${EMBEDDING_DIMENSION} finite numbers.`,
    };
  }
  const vec: number[] = new Array(EMBEDDING_DIMENSION);
  for (let i = 0; i < EMBEDDING_DIMENSION; i++) {
    const val = Number(raw[i]);
    if (!Number.isFinite(val)) {
      return { valid: false, reason: `Face embedding contains non-finite value at index ${i}.` };
    }
    vec[i] = val;
  }
  const norm = computeL2Norm(vec);
  if (!Number.isFinite(norm) || Math.abs(norm - 1.0) > BIOMETRIC_THRESHOLDS.L2_NORM_TOLERANCE) {
    return {
      valid: false,
      norm,
      reason: `Face embedding must be L2-normalized (norm ~= 1.0 +/- ${BIOMETRIC_THRESHOLDS.L2_NORM_TOLERANCE}, got ${Number.isFinite(norm) ? norm.toFixed(4) : 'NaN'}).`,
    };
  }
  return { valid: true, embedding: vec, norm };
}

export function cosineSimilarity(a: ArrayLike<number>, b: ArrayLike<number>): number {
  if (a.length !== b.length || a.length === 0) return -1;
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    const va = a[i];
    const vb = b[i];
    if (!Number.isFinite(va) || !Number.isFinite(vb)) return -1;
    dot += va * vb;
    normA += va * va;
    normB += vb * vb;
  }
  if (normA <= 0 || normB <= 0) return -1;
  return dot / (Math.sqrt(normA) * Math.sqrt(normB));
}

export function averageAndNormalizeEmbeddings(vectors: number[][]): number[] {
  if (!vectors.length) {
    throw new Error('Cannot average zero embeddings.');
  }
  const acc = new Float64Array(EMBEDDING_DIMENSION);
  for (const vec of vectors) {
    if (vec.length !== EMBEDDING_DIMENSION) {
      throw new Error(`Expected ${EMBEDDING_DIMENSION}D embedding.`);
    }
    for (let i = 0; i < EMBEDDING_DIMENSION; i++) {
      acc[i] += vec[i];
    }
  }
  for (let i = 0; i < EMBEDDING_DIMENSION; i++) {
    acc[i] /= vectors.length;
  }
  let normSq = 0;
  for (let i = 0; i < EMBEDDING_DIMENSION; i++) {
    normSq += acc[i] * acc[i];
  }
  const norm = Math.sqrt(normSq);
  if (!Number.isFinite(norm) || norm <= 1e-8) {
    throw new Error('Averaged embedding collapsed to zero vector.');
  }
  return Array.from(acc, (v) => v / norm);
}

let ephemeralNonProdKey: Buffer | null = null;

export interface ResolvedTemplateKey {
  key: Buffer;
  ephemeralNonProduction: boolean;
}

export function resolveTemplateEncryptionKey(appMode: AppMode): ResolvedTemplateKey | null {
  const raw = (process.env.KIOSK_TEMPLATE_ENCRYPTION_KEY || '').trim();
  if (/^[0-9a-fA-F]{64}$/.test(raw)) {
    return { key: Buffer.from(raw, 'hex'), ephemeralNonProduction: false };
  }
  // Fail closed in production or staging when explicit 64-hex key is absent
  if (appMode === 'production' || appMode === 'staging') {
    return null;
  }
  // In local development / automated test only, derive a deterministic-per-process ephemeral key
  // so developers can test encryption end-to-end without storing plaintext vectors or hardcoding keys.
  if (!ephemeralNonProdKey) {
    const seed = (process.env.SESSION_SECRET || '').trim();
    if (seed.length >= 16) {
      ephemeralNonProdKey = crypto.createHash('sha256').update(`savage-dev-kiosk-tpl:${seed}`).digest();
    } else {
      ephemeralNonProdKey = crypto.randomBytes(32);
    }
  }
  return { key: ephemeralNonProdKey, ephemeralNonProduction: true };
}

export interface EncryptedTemplatePayload {
  templateSha256: string;
  encryptedEmbeddingB64: string;
  ivHex: string;
  tagHex: string;
}

export function encryptFaceEmbedding(
  key: Buffer,
  employeeCode: string,
  embedding: number[]
): EncryptedTemplatePayload {
  const canonicalFloat32 = Buffer.from(new Float32Array(embedding).buffer);
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  cipher.setAAD(Buffer.from(employeeCode, 'utf8'));
  const encrypted = Buffer.concat([cipher.update(canonicalFloat32), cipher.final()]);
  const tag = cipher.getAuthTag();
  const templateSha256 = crypto.createHash('sha256').update(canonicalFloat32).digest('hex');

  return {
    templateSha256,
    encryptedEmbeddingB64: encrypted.toString('base64'),
    ivHex: iv.toString('hex'),
    tagHex: tag.toString('hex'),
  };
}

export function decryptFaceEmbedding(
  key: Buffer,
  employeeCode: string,
  encryptedEmbeddingB64: string,
  ivHex: string,
  tagHex: string
): number[] | null {
  try {
    const iv = Buffer.from(ivHex, 'hex');
    const tag = Buffer.from(tagHex, 'hex');
    const ciphertext = Buffer.from(encryptedEmbeddingB64, 'base64');
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAAD(Buffer.from(employeeCode, 'utf8'));
    decipher.setAuthTag(tag);
    const plain = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
    if (plain.byteLength !== EMBEDDING_DIMENSION * 4) {
      return null;
    }
    const floats = new Float32Array(plain.buffer, plain.byteOffset, EMBEDDING_DIMENSION);
    return Array.from(floats);
  } catch {
    return null;
  }
}

export interface StoredTemplateRecord {
  employee_id: number;
  employee_code: string;
  full_name: string;
  status: string;
  template_sha256: string;
  encrypted_embedding: string;
  iv_hex: string;
  tag_hex: string;
  enrolled_at_utc: string;
}

export interface TemplateMatchResult {
  matched: boolean;
  employee_id: number | null;
  employee_code: string | null;
  full_name: string | null;
  similarity: number;
  second_best_similarity: number;
  evaluated_templates: number;
  decryption_failures: number;
}

export function matchEmbeddingAgainstTemplates(
  db: Database.Database,
  key: Buffer,
  probeEmbedding: number[],
  minSimilarity: number,
  excludeEmployeeId?: number
): TemplateMatchResult {
  const rows = db
    .prepare(
      `SELECT t.employee_id, e.employee_code, e.full_name, e.status,
              t.template_sha256, t.encrypted_embedding, t.iv_hex, t.tag_hex, t.enrolled_at_utc
       FROM kiosk_face_templates t
       JOIN employees e ON e.id = t.employee_id
       WHERE e.status = 'Active'`
    )
    .all() as StoredTemplateRecord[];

  let bestRow: StoredTemplateRecord | null = null;
  let bestSim = -1;
  let secondBestSim = -1;
  let evaluated = 0;
  let decryptFailures = 0;

  for (const row of rows) {
    if (excludeEmployeeId !== undefined && row.employee_id === excludeEmployeeId) continue;
    const storedVec = decryptFaceEmbedding(
      key,
      row.employee_code,
      row.encrypted_embedding,
      row.iv_hex,
      row.tag_hex
    );
    if (!storedVec) {
      decryptFailures += 1;
      continue;
    }
    evaluated += 1;
    const sim = cosineSimilarity(probeEmbedding, storedVec);
    if (sim > bestSim) {
      secondBestSim = bestSim;
      bestSim = sim;
      bestRow = row;
    } else if (sim > secondBestSim) {
      secondBestSim = sim;
    }
  }

  const matched = Boolean(bestRow && bestSim >= minSimilarity);
  return {
    matched,
    employee_id: matched && bestRow ? bestRow.employee_id : null,
    employee_code: matched && bestRow ? bestRow.employee_code : null,
    full_name: matched && bestRow ? bestRow.full_name : null,
    similarity: bestSim >= 0 ? Number(bestSim.toFixed(4)) : 0,
    second_best_similarity: secondBestSim >= 0 ? Number(secondBestSim.toFixed(4)) : 0,
    evaluated_templates: evaluated,
    decryption_failures: decryptFailures,
  };
}
