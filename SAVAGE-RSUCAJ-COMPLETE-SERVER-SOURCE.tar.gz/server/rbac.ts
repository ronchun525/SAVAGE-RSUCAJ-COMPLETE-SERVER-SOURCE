export type RoleName =
  | 'Administrator'
  | 'HR Officer'
  | 'Payroll Officer'
  | 'Department Head'
  | 'Employee'
  | 'Kiosk Device';

export const CANONICAL_ROLES: Array<{ name: RoleName; description: string }> = [
  {
    name: 'Administrator',
    description: 'Full campus system administration, security, devices, payroll, backups, and user management.',
  },
  {
    name: 'HR Officer',
    description: 'Manages employees, campus org setup, attendance, corrections, leaves, and HR reports.',
  },
  {
    name: 'Payroll Officer',
    description: 'Computes, finalizes, and releases payroll batches and views payroll/attendance summaries.',
  },
  {
    name: 'Department Head',
    description: 'Views department personnel/attendance and reviews department corrections and leave requests.',
  },
  {
    name: 'Employee',
    description: 'Self-service access to own attendance records and submission of own correction and leave requests.',
  },
  {
    name: 'Kiosk Device',
    description: 'Hardware machine identity authenticated via x-kiosk-token for heartbeat and attendance punch only.',
  },
];

export type PermissionCode =
  | 'dashboard:read'
  | 'employees:read'
  | 'employees:write'
  | 'org:read'
  | 'org:write'
  | 'attendance:read'
  | 'attendance:read_self'
  | 'attendance:write'
  | 'corrections:read'
  | 'corrections:read_self'
  | 'corrections:create'
  | 'corrections:approve'
  | 'leaves:read'
  | 'leaves:read_self'
  | 'leaves:create'
  | 'leaves:approve'
  | 'leaves:delete'
  | 'payroll:read'
  | 'payroll:read_self'
  | 'payroll:policy_manage'
  | 'payroll:compute'
  | 'payroll:finalize'
  | 'payroll:finance_signoff'
  | 'payroll:release'
  | 'reports:read'
  | 'reports:payroll'
  | 'reports:audit'
  | 'devices:read'
  | 'devices:write'
  | 'audit:read'
  | 'notifications:read'
  | 'notifications:write'
  | 'settings:read'
  | 'settings:write'
  | 'backup:export'
  | 'users:manage'
  | 'kiosk:heartbeat'
  | 'kiosk:punch'
  | 'kiosk:sync';

export const CANONICAL_PERMISSIONS: Array<{
  code: PermissionCode;
  resource: string;
  action: string;
  description: string;
}> = [
  { code: 'dashboard:read', resource: 'dashboard', action: 'read', description: 'View campus attendance dashboard summary' },
  { code: 'employees:read', resource: 'employees', action: 'read', description: 'View employee directory' },
  { code: 'employees:write', resource: 'employees', action: 'write', description: 'Create, update, import, and delete employees' },
  { code: 'org:read', resource: 'org', action: 'read', description: 'View departments, positions, shifts, and holidays' },
  { code: 'org:write', resource: 'org', action: 'write', description: 'Manage departments, positions, shifts, and holidays' },
  { code: 'attendance:read', resource: 'attendance', action: 'read', description: 'View employee attendance records' },
  { code: 'attendance:read_self', resource: 'attendance', action: 'read_self', description: 'View own attendance records' },
  { code: 'attendance:write', resource: 'attendance', action: 'write', description: 'Record or delete manual attendance entries' },
  { code: 'corrections:read', resource: 'corrections', action: 'read', description: 'View attendance correction requests' },
  { code: 'corrections:read_self', resource: 'corrections', action: 'read_self', description: 'View own correction requests' },
  { code: 'corrections:create', resource: 'corrections', action: 'create', description: 'Submit attendance correction requests' },
  { code: 'corrections:approve', resource: 'corrections', action: 'approve', description: 'Approve or reject attendance corrections' },
  { code: 'leaves:read', resource: 'leaves', action: 'read', description: 'View leave applications and balances' },
  { code: 'leaves:read_self', resource: 'leaves', action: 'read_self', description: 'View own leave applications and balances' },
  { code: 'leaves:create', resource: 'leaves', action: 'create', description: 'Submit leave applications' },
  { code: 'leaves:approve', resource: 'leaves', action: 'approve', description: 'Approve or reject leave applications' },
  { code: 'leaves:delete', resource: 'leaves', action: 'delete', description: 'Delete leave applications' },
  { code: 'payroll:read', resource: 'payroll', action: 'read', description: 'View payroll runs, policies, and payslip items' },
  { code: 'payroll:read_self', resource: 'payroll', action: 'read_self', description: 'View own released payslips only' },
  { code: 'payroll:policy_manage', resource: 'payroll', action: 'policy_manage', description: 'Create and manage draft institutional payroll policies' },
  { code: 'payroll:compute', resource: 'payroll', action: 'compute', description: 'Compute and recompute payroll batches' },
  { code: 'payroll:finalize', resource: 'payroll', action: 'finalize', description: 'Finalize computed payroll batches (maker-checker enforced)' },
  { code: 'payroll:finance_signoff', resource: 'payroll', action: 'finance_signoff', description: 'Record Finance approval on payroll policies and finalized runs' },
  { code: 'payroll:release', resource: 'payroll', action: 'release', description: 'Release Finance-approved finalized payroll batches' },
  { code: 'reports:read', resource: 'reports', action: 'read', description: 'Generate attendance, DTR, leave, and employee reports' },
  { code: 'reports:payroll', resource: 'reports', action: 'payroll', description: 'Generate payroll ledger reports' },
  { code: 'reports:audit', resource: 'reports', action: 'audit', description: 'Generate security audit log reports' },
  { code: 'devices:read', resource: 'devices', action: 'read', description: 'View registered kiosk devices' },
  { code: 'devices:write', resource: 'devices', action: 'write', description: 'Register, configure, toggle, or revoke kiosk devices' },
  { code: 'audit:read', resource: 'audit', action: 'read', description: 'View system security audit logs' },
  { code: 'notifications:read', resource: 'notifications', action: 'read', description: 'View system notifications' },
  { code: 'notifications:write', resource: 'notifications', action: 'write', description: 'Mark read, dismiss, or clear notifications' },
  { code: 'settings:read', resource: 'settings', action: 'read', description: 'View system settings' },
  { code: 'settings:write', resource: 'settings', action: 'write', description: 'Modify system settings' },
  { code: 'backup:export', resource: 'backup', action: 'export', description: 'Export full SQLite JSON backup' },
  { code: 'users:manage', resource: 'users', action: 'manage', description: 'Manage portal user accounts and role assignments' },
  { code: 'kiosk:heartbeat', resource: 'kiosk', action: 'heartbeat', description: 'Send kiosk terminal heartbeat' },
  { code: 'kiosk:punch', resource: 'kiosk', action: 'punch', description: 'Submit attendance punch from authenticated kiosk terminal' },
  { code: 'kiosk:sync', resource: 'kiosk', action: 'sync', description: 'Submit encrypted offline batch sync from authenticated kiosk terminal' },
];

export const ROLE_PERMISSION_MATRIX: Record<RoleName, PermissionCode[]> = {
  Administrator: [
    'dashboard:read',
    'employees:read',
    'employees:write',
    'org:read',
    'org:write',
    'attendance:read',
    'attendance:read_self',
    'attendance:write',
    'corrections:read',
    'corrections:read_self',
    'corrections:create',
    'corrections:approve',
    'leaves:read',
    'leaves:read_self',
    'leaves:create',
    'leaves:approve',
    'leaves:delete',
    'payroll:read',
    'payroll:read_self',
    'payroll:policy_manage',
    'payroll:compute',
    'payroll:finalize',
    'payroll:finance_signoff',
    'payroll:release',
    'reports:read',
    'reports:payroll',
    'reports:audit',
    'devices:read',
    'devices:write',
    'audit:read',
    'notifications:read',
    'notifications:write',
    'settings:read',
    'settings:write',
    'backup:export',
    'users:manage',
  ],
  'HR Officer': [
    'dashboard:read',
    'employees:read',
    'employees:write',
    'org:read',
    'org:write',
    'attendance:read',
    'attendance:write',
    'corrections:read',
    'corrections:create',
    'corrections:approve',
    'leaves:read',
    'leaves:create',
    'leaves:approve',
    'leaves:delete',
    'reports:read',
    'notifications:read',
    'notifications:write',
  ],
  'Payroll Officer': [
    'dashboard:read',
    'employees:read',
    'org:read',
    'attendance:read',
    'leaves:read',
    'payroll:read',
    'payroll:policy_manage',
    'payroll:compute',
    'payroll:finalize',
    'payroll:finance_signoff',
    'payroll:release',
    'reports:read',
    'reports:payroll',
    'notifications:read',
  ],
  'Department Head': [
    'dashboard:read',
    'employees:read',
    'org:read',
    'attendance:read',
    'corrections:read',
    'corrections:create',
    'corrections:approve',
    'leaves:read',
    'leaves:create',
    'leaves:approve',
    'reports:read',
    'notifications:read',
  ],
  Employee: [
    'org:read',
    'attendance:read_self',
    'corrections:read_self',
    'corrections:create',
    'leaves:read_self',
    'leaves:create',
    'payroll:read_self',
  ],
  'Kiosk Device': ['kiosk:heartbeat', 'kiosk:punch', 'kiosk:sync'],
};

export function isValidRole(role: string): role is RoleName {
  return role in ROLE_PERMISSION_MATRIX;
}
