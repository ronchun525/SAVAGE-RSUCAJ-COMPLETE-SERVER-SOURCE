/** Pure Android/backend protocol logic for standalone Node contract tests. */
import crypto from 'node:crypto';

export function computeAndroidAttendanceDigest(
  eventId: string, employeeCode: string, action: 'TIME_IN' | 'TIME_OUT',
  capturedAtMs: number, deviceName: string,
): string {
  return crypto.createHash('sha256')
    .update(`${eventId}|${employeeCode}|${action}|${capturedAtMs}|${deviceName}`)
    .digest('hex');
}

/** Compatible with Kotlin ByteBuffer LITTLE_ENDIAN and FloatArray SHA-256 digest. */
export function computeAndroidEnrollmentHash(employeeCode: string, employeeName: string, embedding: number[]): string {
  const bytes = Buffer.allocUnsafe(embedding.length * 4);
  embedding.forEach((num, idx) => bytes.writeFloatLE(num, idx * 4));
  return crypto.createHash('sha256')
    .update(employeeCode, 'utf8').update(Buffer.from([0]))
    .update(employeeName, 'utf8').update(Buffer.from([0]))
    .update(bytes).digest('hex');
}

export function proofBindingHmac(token: string, fields: {
  deviceId: number; bootId: string; sequence: number; eventId: string;
  employeeCode: string; punchType: string; isoTimestamp: string;
  evidenceHash: string; nonce: string; liveness: boolean; match: boolean;
}): string {
  const domain = 'savage-rsucaj-kiosk-biometric-binding-v1';
  const canonical = [domain, String(fields.deviceId), fields.bootId, String(fields.sequence), fields.eventId,
    fields.employeeCode.trim().toUpperCase(), fields.punchType.trim().toUpperCase(),
    fields.isoTimestamp, fields.evidenceHash, fields.nonce,
    fields.liveness ? '1' : '0', fields.match ? '1' : '0'].join('|');
  const derived = crypto.createHmac('sha256', token).update(domain).digest();
  return crypto.createHmac('sha256', derived).update(canonical).digest('hex');
}


/** Canonical fail-closed validation shared with the HTTP bridge and runnable without a DB. */
export function validateAndroidPunch(
  raw: unknown,
  headers: { idempotencyKey?: string; eventTimestamp?: string; digest?: string },
  provisionedDeviceName: string,
  serverNowMs: number,
): { valid: true } | { valid: false; code: string } {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { valid: false, code: 'INVALID_PUNCH_PAYLOAD' };
  const data = raw as Record<string, unknown>;
  const { event_id, employee_id, action, kiosk_device_id, captured_at_ms,
    biometric_confidence, liveness_score, anti_spoofing_score, offline_queued } = data;
  if (kiosk_device_id !== provisionedDeviceName || typeof event_id !== 'string' || !/^[\w-]{8,128}$/.test(event_id) ||
    typeof employee_id !== 'string' || !/^[\w-]{1,100}$/.test(employee_id) ||
    (action !== 'TIME_IN' && action !== 'TIME_OUT') ||
    !Number.isSafeInteger(captured_at_ms) || (captured_at_ms as number) <= 0 ||
    !Number.isSafeInteger(serverNowMs) ||
    (captured_at_ms as number) > serverNowMs + 5 * 60_000 ||
    (captured_at_ms as number) < serverNowMs - 73 * 3600_000 ||
    (offline_queued !== undefined && typeof offline_queued !== 'boolean') ||
    ![biometric_confidence, liveness_score, anti_spoofing_score].every(
      x => typeof x === 'number' && Number.isFinite(x) && x >= 0 && x <= 1)) {
    return { valid: false, code: 'INVALID_PUNCH_PAYLOAD' };
  }
  if ((biometric_confidence as number) < 0.75 || (liveness_score as number) < 0.80 || (anti_spoofing_score as number) < 0.80) {
    return { valid: false, code: 'BIOMETRIC_THRESHOLD_FAILED' };
  }
  // BUILD 29: a replay-time token HMAC is not proof that PAD/face matching occurred
  // when the offline event was originally captured. Preserve the event for manual
  // authorized correction rather than silently crediting un-attested attendance.
  if (offline_queued === true) {
    return { valid: false, code: 'OFFLINE_CAPTURE_ATTESTATION_REQUIRED' };
  }
  const expectedDigest = computeAndroidAttendanceDigest(event_id, employee_id, action,
    captured_at_ms as number, kiosk_device_id as string);
  if (headers.idempotencyKey !== event_id || headers.eventTimestamp !== String(captured_at_ms) ||
    typeof headers.digest !== 'string' || !/^[a-fA-F0-9]{64}$/.test(headers.digest)) {
    return { valid: false, code: 'EVENT_INTEGRITY_MISMATCH' };
  }
  if (!crypto.timingSafeEqual(Buffer.from(headers.digest.toLowerCase()), Buffer.from(expectedDigest))) {
    return { valid: false, code: 'EVENT_INTEGRITY_MISMATCH' };
  }
  return { valid: true };
}

/** Enrollment acceptance remains conditional on backend employee and kiosk authorization. */
export function validateAndroidEnrollment(
  raw: unknown, idempotencyKey: string | undefined, provisionedDeviceName: string, serverNowMs: number,
): { valid: true } | { valid: false; code: string } {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { valid: false, code: 'INVALID_TEMPLATE' };
  const data = raw as Record<string, unknown>;
  const { employee_id, employee_name, kiosk_device_id, embedding_sha256, composite_embedding, enrolled_at_ms } = data;
  if (kiosk_device_id !== provisionedDeviceName || typeof employee_id !== 'string' || !/^[\w-]{1,100}$/.test(employee_id) ||
    typeof employee_name !== 'string' || employee_name.trim().length < 2 || employee_name.length > 200 ||
    typeof embedding_sha256 !== 'string' || !/^[a-fA-F0-9]{64}$/.test(embedding_sha256) ||
    !Number.isSafeInteger(enrolled_at_ms) || Math.abs(serverNowMs - (enrolled_at_ms as number)) > 10 * 60_000 ||
    !Array.isArray(composite_embedding) || composite_embedding.length !== 192 ||
    !composite_embedding.every((x: unknown) => typeof x === 'number' && Number.isFinite(x) && Math.abs(x) <= 1.00001)) {
    return { valid: false, code: 'INVALID_TEMPLATE' };
  }
  // MobileFaceNet produces 192-dimensional L2-normalized embeddings. Reject
  // all-zero, corrupted or incompatible (legacy model) vectors at the boundary.
  const squaredNorm = composite_embedding.reduce((sum: number, value: number) => sum + value * value, 0);
  if (!Number.isFinite(squaredNorm) || squaredNorm < 0.95 * 0.95 || squaredNorm > 1.05 * 1.05) {
    return { valid: false, code: 'INVALID_EMBEDDING_NORM' };
  }
  if (idempotencyKey !== `${employee_id}-${embedding_sha256}`) return { valid: false, code: 'ENROLLMENT_INTEGRITY_MISMATCH' };
  const digest = computeAndroidEnrollmentHash(employee_id, employee_name, composite_embedding);
  if (!crypto.timingSafeEqual(Buffer.from(digest), Buffer.from(embedding_sha256.toLowerCase()))) {
    return { valid: false, code: 'TEMPLATE_HASH_MISMATCH' };
  }
  return { valid: true };
}
