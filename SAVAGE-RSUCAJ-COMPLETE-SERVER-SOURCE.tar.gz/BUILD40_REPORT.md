# SAVAGE-RSUCAJ BUILD 40 — Admin Input Focus Fix + Employee Password

Date: 2026-11-23 (Asia/Manila)

## 1. Overview

Fix Admin Portal dialogs in which typing one character causes the input to lose focus. Add optional Employee Portal login credentials directly to the **Add New Employee** modal without breaking the existing personnel-only creation flow.

## 2. Architecture

This targeted ZIP is built against the latest **confirmed deployed** application: original Hostinger source plus BUILD 39's admin-login UI patch. BUILD 38's broader server and component changes were **not** deployed by the BUILD 39 login-only patch, hence the fix was missing on the live site.

Frontend: React / TSX. Backend: Express + SQLite. Passwords: existing salted `hashPassword` helper. Admin permissions: `employees:write` required for personnel, `users:manage` additionally required to create portal credentials. Backend uses a single SQLite transaction to create both employee and user, rolling both back on failure. Database migrations are not needed.

## 3. UI/UX Design

Original teal/emerald/gold styling, logo, navigation, and login design preserved. On Add New Employee, admins with user-management permission can now see the Portal Username, Temporary Password (Show/Hide), and Confirm Temporary Password fields. Password is optional: leaving it empty creates only the employee personnel record; entering it selects portal-account provisioning. The server requires a strong password, valid employee email, and an active employee. A first-login password rotation is required. Validation errors display in the modal instead of invisibly behind it.

## 4. Implementation — exact paths

- `src/components/ModuleFrame.tsx`: fixes focus loss by retaining the current `onClose` in a ref and running the modal focus lifecycle only when `open` changes.
- `src/components/EmployeesView.tsx`: visible optional password/confirmation, automatic account flag, username auto-fill, in-modal validation, and existing account-creation flow preservation.
- `server/api.ts`: upgrades only the `POST /api/employees` handler to securely provision a linked Employee Portal user **atomically** if optional `portal_account` is supplied. The rest of the backend is untouched.
- `tests/build40-employee-typing.test.mjs`: six source-contract regression checks.
- `deployment/hostinger-vps/build40-employee-typing-deploy.sh`: strict checksums, backup, preflight, tests, lint, build, HTTP health polling and rollback.

## 5. Error analysis

The old `ModuleFrame.Modal` used `useEffect(..., [open, onClose])`, but callers passed `onClose={() => ...}` inline, changing identity on each state update. The effect cleanup refocused the previous element, and the new effect focused the dialog again; typing one character could therefore remove focus from the input. BUILD 38 had a fix in its full source, but the deployed BUILD 39 login-only patch did not include `ModuleFrame.tsx` or the Employee Portal account backend. This patch adds the missing functionality specifically to the confirmed deployed baseline.

## 6. Testing — actual results

- `node --test tests/build40-employee-typing.test.mjs`: **6 passed, 0 failed** (source-contract checks).
- Global TypeScript `transpileModule` syntax check of the three modified TS/TSX files: **3 passed**.
- `bash -n` deploy script: **passed**.
- SHA-256 checksum targets embedded in the installer match packaged files.
- ZIP integrity: tested after package generation.
- Full `npm run lint`, `npm run build`, real browser typing, authenticated employee creation, and production tests: **not run locally**, because project npm dependencies and the live VPS aren't available in this workspace. The installer runs lint/build and live health checks on the VPS; a human must test actual form input in the browser.

## 7. Deployment — Hostinger VPS

1. From Windows PowerShell (file saved in Downloads):
   `scp "$env:USERPROFILE\Downloads\SAVAGE-RSUCAJ-BUILD40-EMPLOYEE-TYPING-PATCH.zip" root@201.18.218.208:/root/`
2. SSH: `ssh root@201.18.218.208`
3. Extract installer:
   `unzip -p /root/SAVAGE-RSUCAJ-BUILD40-EMPLOYEE-TYPING-PATCH.zip deployment/hostinger-vps/build40-employee-typing-deploy.sh > /root/savage-build40-deploy.sh`
4. `chmod 700 /root/savage-build40-deploy.sh`
5. `sudo bash /root/savage-build40-deploy.sh`
6. After success, Ctrl+Shift+R on `https://attendance.rsu-cajidiocan.tech/`, test typing multiple characters in all Add/Edit forms and the optional Employee Portal password creation. Test personnel-only creation on a staging copy or with an approved real record.

**Safety:** Installer checks three pre-deployment source hashes, refuses unknown source versions, backs up original source + `dist` under `/root/SAVAGE-RSUCAJ-BUILD40-BEFORE-*.tar.gz`, and restores on lint/build/startup errors. Do not force past `SOURCE MISMATCH` or manually overwrite the working app if the preflight rejects it. `.env`, database, biometric models, Caddy, kiosk activation and speaker are not modified.

## 8. Final report

Implemented: targeted modal focus repair, optional employee password and account creation in one transaction, secure password hashing, permission checks, first-login rotation and local validation. Pending: full lint/build on VPS, browser focus and password-provisioning verification with authorized accounts. This update does not change the independent biometric attendance readiness gate.
