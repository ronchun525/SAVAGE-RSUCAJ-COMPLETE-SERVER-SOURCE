# SAVAGE-RSUCAJ BUILD 36 — COMPLETE 16-SCREEN WEB FACE RECOGNITION KIOSK (`/kiosk`) REPORT

**Project:** SAVAGE-RSUCAJ Smart Attendance System (Romblon State University – Cajidiocan Campus)  
**Build Number:** `BUILD 36` *(continued directly from verified BUILD 35 / v1.13.0 source)*  
**Target Domain & Route:** `https://rsu-cajidiocan.tech/kiosk`  
**Source Version:** `1.14.0` (Schema `011` — idempotent `web_kiosk_sessions`, `web_kiosk_challenges`, additive `devices` & `settings` keys)  
**Date:** `2026-11-22`  
**Production Readiness Verdict:** **`NOT PRODUCTION READY`** *(All 16 Web Kiosk screens, backend security/activation/PIN/enrollment/attendance contracts, BUILD 20 tensor codecs, Playwright 16-screen × 4-viewport Chromium E2E, and core unit/attendance/payroll/employee regressions PASS; however, the three real `.tflite` model binaries are absent from the workspace/ZIP, server-side TFLite neural inference is not yet deployed in Node.js, production biometric endpoints fail closed with `503`, and physical Windows/Android/Raspberry Pi 3B camera & anti-spoofing trials remain BLOCKED)*

---

## 1. OVERVIEW & MANDATORY BEHAVIORAL COMPLIANCE

BUILD 36 implements, integrates, audits, and verifies the complete **16-screen Browser-Based Web Face Recognition Kiosk** at `/kiosk` (and `/?portal=kiosk`) inside the existing SAVAGE-RSUCAJ Express + Vite + React 19 + TypeScript + SQLite monolith while preserving the Admin Portal (`/`), 18-screen Employee Portal (`/employee`), Android Bridge (`/api/v1/kiosk/*`), canonical attendance engine (`server/attendanceEngine.ts`), payroll rules, and SQLite database.

- **FRONT FACE ONLY (Mandatory Rule):** Zero left/right enrollment capture steps, zero head-turn prompts during enrollment or attendance, and zero manual shutter/capture buttons during touchless enrollment.
- **Admin-Authorized Enrollment Only:** Unknown faces on attendance scan return `404 NOT_ENROLLED` -> Screen `08` (`Not Enrolled`) and NEVER self-enroll. Touchless enrollment executes strictly after Screen `09` (`Admin PIN Access`, scrypt-verified with 5-strike 15-minute lockout) and Screen `10` (`Enrollment — Select Employee`).
- **Biometric Honesty & Fail-Closed Production Guard:** Browser clients NEVER submit trusted `employee_id` or `match_verified` booleans; server resolves identity strictly via 1:N cosine matching against AES-256-GCM encrypted `kiosk_face_templates`. Because `anti_spoofing_pad.tflite`, `liveness_detection.tflite`, and `face_recognition.tflite` are absent from disk and server-side TFLite inference is not deployed, `APP_MODE=production` fails closed (`503 PRODUCTION_BIOMETRIC_ATTESTATION_BLOCKED`) and locks `liveness_enforced=true` (`403 PRODUCTION_LIVENESS_LOCKED`).
- **Strict Attendance-Only Voice Prompts:** `KioskVoiceController` speaks `"Thank you."` (attendance success) and `"Try again."` (attendance failure) ONLY on actual attendance outcomes — never during enrollment, idle scanning, loading, or settings. Duplicate punches display `"Already taken attendance"` strictly when confirmed by backend `409 ALREADY_TAKEN`.

## 2. ARCHITECTURE, SCHEMA MIGRATION `011` & API SURFACE

- **Security Headers (`/server/security.ts`):** Route-scoped `Permissions-Policy`: `/kiosk` and `/kiosk/*` emit `camera=(self), microphone=(), geolocation=()`, while Admin (`/`) and Employee (`/employee`) routes retain `camera=(), microphone=(), geolocation=()`.
- **Database Migration `011` (`/server/db.ts`):** Idempotent transactional migration adding `web_kiosk_sessions` (signed `HttpOnly; SameSite=Lax; Path=/` session cookie `savage_kiosk_session` with server-side admin unlock window & instant revocation), `web_kiosk_challenges` (30s single-use enrollment/attendance nonces), additive `devices` columns (`activation_code_hash`, `activation_code_expires_at`, `activation_code_used_at`, `face_capture_enabled`, `voice_prompt_enabled`, `liveness_enforced`, `camera_health`, `model_readiness_json`, `kiosk_app_version`), and `settings` keys (`kiosk_admin_pin_hash`, `kiosk_admin_pin_salt`, `kiosk_admin_pin_failed_attempts`, `kiosk_admin_pin_locked_until`, `kiosk_require_server_biometric_attestation`).
- **BUILD 20 Biometric Core (`/server/webKioskBiometrics.ts`):** Pinned SHA-256 model specs & `TFL3` magic disk inspection (`inspectKioskModels`), deterministic tensor encoders (`encodePadRgbNhwc` `[1,80,80,3]` RGB `[0,1]`, `encodeLivenessBgrNchw` `[1,3,80,80]` BGR `[0,255]`, `encodeRecognitionRgbNhwc` `[1,112,112,3]` RGB `(p-127.5)/128.0`), stabilized softmax + probability preservation + NaN fail-closed decoder (`decodeClassifierLiveScore`), 192D L2-norm validation & cosine 1:N matcher, and AES-256-GCM template encryption (AAD=`employee_code`, fail-closed without 64-hex `KIOSK_TEMPLATE_ENCRYPTION_KEY` in staging/production).
- **Web Kiosk Endpoints (`/server/webKioskRoutes.ts`, mounted in `/server/api.ts`):**
  - Public/Kiosk-Cookie: `GET /api/kiosk/web/models/status`, `GET /api/kiosk/web/models/:filename`, `GET /api/kiosk/web/session`, `POST /api/kiosk/web/activate`, `POST /api/kiosk/web/deactivate`, `POST /api/kiosk/web/heartbeat`, `POST /api/kiosk/web/sync`, `POST /api/kiosk/web/admin/unlock`, `POST /api/kiosk/web/admin/lock`, `PATCH /api/kiosk/web/settings`, `GET /api/kiosk/web/employees`, `POST /api/kiosk/web/challenge`, `POST /api/kiosk/web/enroll`, `POST /api/kiosk/web/attendance`.
  - Admin Provisioning (`devices:write`/`devices:read`, wired into `DevicesView` in `/src/components/SystemAdminViews.tsx`): `POST /api/devices/:id/activation-code`, `GET /api/kiosk/web/admin-pin/status`, `PUT /api/kiosk/web/admin-pin`, plus immediate `web_kiosk_sessions` invalidation on `POST /api/devices/:id/revoke`.

## 3. UI/UX DESIGN & 16-SCREEN AUDIT

All 16 approved Web Kiosk PNG references (`01_Splash_Screen` through `16_Attendance_Scan_Ready`) were reproduced in `/src/components/kiosk/KioskPrimitives.tsx`, `/src/components/kiosk/KioskScreens.tsx`, `/src/components/kiosk/types.ts`, `/src/lib/kioskBiometrics.ts`, and `/src/components/WebKioskPortal.tsx` with the original uncropped SAVAGE-RSUCAJ Attendance Shield (`/assets/aistudio/Savage-Rsucaj_Attendance_Shield_bca5b40c.png`), deep emerald (`#043D22`–`#0A7742`) and gold (`#F4B400`–`#FEF08A`) sweeping waves, live Online/Offline dot, gear icon, and zero-overflow responsive layout across `1024×600` (Raspberry Pi 7"/10" touchscreen), `390×844` (Android mobile), `768×1024` (Android tablet), and `1366×768` (Windows desktop).

## 4. ROOT-CAUSE BUGS FOUND & FIXED DURING BUILD 36 VERIFICATION

1. **Swapped `verifyPassword` Arguments (`/server/webKioskRoutes.ts`):** `POST /api/kiosk/web/admin/unlock` initially passed `(submittedPin, pinSalt, pinHash)` instead of `(submittedPin, pinHash, pinSalt)`, causing valid Admin PINs to fail with `401`. Caught by `tests/web-kiosk-build36.test.mjs` and fixed immediately.
2. **`1024×600` Raspberry Pi Fold Clipping (`/src/components/kiosk/KioskScreens.tsx`):** Visual inspection of captured `1024×600` Playwright screenshots identified minor bottom-button clipping on Screens `03` (`Start Attendance Scan`), `11` (`Cancel Enrollment`), and `15` (`Back`). Tightened vertical rhythm and card padding, rebuilt, re-captured, and visually confirmed all 3 screens fit cleanly above `600px`.

## 5. REMAINING BLOCKERS FOR PRODUCTION (`NOT PRODUCTION READY`)

1. **Missing `.tflite` Model Binaries:** `anti_spoofing_pad.tflite`, `liveness_detection.tflite`, and `face_recognition.tflite` (with pinned BUILD 20 SHA-256 hashes) are absent from workspace and source ZIP.
2. **Server-Side Neural Inference Not Deployed:** Node.js backend has no native TFLite/LiteRT inference runtime; production enrollment and attendance fail closed (`503`) until models and verified server-side biometric attestation are deployed.
3. **Physical Hardware & Anti-Spoofing Acceptance (`BLOCKED`):** Live camera acquisition, thermal/FPS soak, and printed-photo/phone-screen/video-replay spoof trials on physical Windows PC, Android phone/tablet, and Raspberry Pi 3 Model B hardware have not been executed in this container.
4. **Institutional & Hosting Gates (`RG-05`–`RG-10`):** Production VPS HTTPS/TLS (`https://rsu-cajidiocan.tech`), `KIOSK_TEMPLATE_ENCRYPTION_KEY`, HRMO CS Form 48, and Finance payroll sign-offs remain externally gated.

---

# EMPLOYEE PORTAL MASTER PROMPT 03 — REAL FUNCTIONALITY, BACKEND HARDENING & REGRESSION REPORT (v1.13.0)

**Project:** SAVAGE-RSUCAJ Smart Attendance System (Romblon State University – Cajidiocan Campus)  
**Scope:** Real End-to-End Workflows, Duplicate Correction Prevention, Supporting-Document Policy Validation, Realtime Notification Coalescing, WCAG Accessibility Audit, Credential Hygiene, and Full Regression Verification  
**Source Version:** `1.13.0` (Schema `010` + `employee_notification_reads`)  
**Date:** 2026-11-22  
**Production Verdict:** **`NOT PRODUCTION READY`** *(All 18 Employee Portal screens, API/RBAC/SSE/PDF/Duplicate-Prevention/Accessibility suites PASS; institutional, biometric, and physical hardware release gates `RG-05`–`RG-10` remain `BLOCKED`)*

- **Master Prompt 03 Code Repairs Implemented:**
  - `/.env.example`: Sanitized literal credentials back to empty placeholders (`ADMIN_INITIAL_EMAIL=`, `ADMIN_INITIAL_PASSWORD=`, `ADMIN_INITIAL_USERNAME=`).
  - `/server/correctionsLeavesEngine.ts`: Added server-side future-date guard (`400 FUTURE_DATE_NOT_ALLOWED`) and atomic `BEGIN IMMEDIATE` duplicate Pending correction guard (`409 DUPLICATE_PENDING_CORRECTION`).
  - `/src/components/employee/RequestsScreens.tsx`: Added weekend-to-weekday defaulting & dynamic `requires_document_after_days` enforcement on Screen `10`, dynamic required supporting-document validation for `Full Day` corrections on Screen `12`, and `Cancelled` status filter on Screen `13`.
  - `/src/components/EmployeeMobilePortal.tsx`: Added dedicated `createRefreshCoalescer` for `employee:notification` SSE frames to prevent burst fetch duplication.
  - `/src/components/employee/EmployeeEntryFlow.tsx`: Added explicit `id`/`htmlFor` association on Screen `05` Remember Me checkbox (`0` unlabeled controls across all 18 screens).
  - `/tests/employee-portal-master-audit.test.mjs`: Expanded with live `employee:notification` SSE approval delivery + persistent Mark All Read, duplicate Pending correction UI+API rejection, future-date rejection, Full Day supporting-document SQLite persistence, and all-18 WCAG accessibility checks.

---

# EMPLOYEE PORTAL MASTER PROMPT 02 — COMPLETE FUNCTIONAL & VISUAL AUDIT REPORT (v1.13.0)

**Project:** SAVAGE-RSUCAJ Smart Attendance System (Romblon State University – Cajidiocan Campus)  
**Scope:** Screen-by-Screen Visual Audit (All 18 PNGs), Complete Navigation & Browser Back Audit, All 18 Employee Functions (including Overnight Shift & Live SSE), Frontend/Backend Security Audit, Responsive Audit (All 18 Screens × Mobile/Tablet/Desktop), and Build/Code Quality Verification  
**Source Version:** `1.13.0` (Schema `010` + `employee_notification_reads`)  
**Date:** 2026-11-22  
**Audit Verdict:** **ALL 18 EMPLOYEE PORTAL SCREENS VERIFIED (`PASS`)** across automated UI screenshot comparison, navigation/Browser Back, API/overnight-shift/SSE functionality, security/RBAC isolation, and 4-viewport responsiveness (`0` page errors, `0` console errors, `0` broken images, `0px` overflow). **Production Go-Live Verdict remains formally `NO-GO / BLOCKED`** on institutional & physical hardware release gates (`RG-05`–`RG-10`).

- **Audit Fixes Applied (9 Verified Findings Resolved):**
  - `A1` Logo Framing (`EmployeePrimitives.tsx`, `EmployeeEntryFlow.tsx`, `ProfileAndUtilityScreens.tsx`): Removed opaque white boxes around the transparent RGBA SAVAGE-RSUCAJ shield on emerald/white surfaces.
  - `A2` Screen 06 Today Dashboard (`TodayAndAttendanceScreens.tsx`): Added solid emerald `Home` icon, stacked `LogIn`/`LogOut` icons above `Time In`/`Time Out`, `BarChart3` + `This Month` header, and semantic monthly summary row icons.
  - `A3` Screen 09 My Profile (`ProfileAndUtilityScreens.tsx`): Added `My Profile` title row, neutral circular avatar silhouette, and emerald outline icons on every profile attribute row.
  - `A4` Screen 16 Account Security (`ProfileAndUtilityScreens.tsx`): Aligned centered shield emblem and exact row subtitles while preserving honest disabled 2FA toggle and real session revocation.
  - `A5` Screen 17 Notifications (`ProfileAndUtilityScreens.tsx`): Aligned notification category icons (`Bell`, `FileText`, `ClipboardEdit`, `Wallet`, `CalendarDays`) with `17_Notifications.png`.
  - `A6` Screen 18 About (`EmployeeMobilePortal.tsx`, `ProfileAndUtilityScreens.tsx`): Aligned header title to `"About"`, unboxed shield, `"Version {v} ({build})"` + `"Employee Portal"`, and exact institutional copy.
  - `A7` Screens 10 & 12 Date/Time Inputs (`RequestsScreens.tsx`): Moved decorative Lucide icons from right (`pr-10`) to left (`pl-10`) to eliminate collision with native Chromium/Edge/Safari pickers.
  - `N1` Browser Back Navigation (`EmployeeMobilePortal.tsx`, `EmployeeEntryFlow.tsx`): Added History API `pushState`/`replaceState`/`popstate` sync across onboarding and all portal screens.
  - `N2` Session Expiration UX (`App.tsx`, `EmployeeEntryFlow.tsx`): Redirects expired Employee sessions (`401`) cleanly to `/employee` Screen 05 with `"Your session has expired. Please sign in again."` banner.
- **New Automated Verification Suite:** `/tests/employee-portal-master-audit.test.mjs` (`4/4` PASS — Security RBAC, Overnight Shift, Live SSE, Browser Back, Session Expiration, Password Rotation, All-18 Responsive Matrix & 21 runtime PNG screenshots captured and inspected).

---

# EMPLOYEE PORTAL 18-SCREEN REBUILD REPORT (Continuation on v1.13.0)

**Project:** SAVAGE-RSUCAJ Smart Attendance System (Romblon State University – Cajidiocan Campus)  
**Scope:** Complete 18-Screen Employee Portal UI/UX Rebuild + Self-Service API Hardening  
**Source Version:** `1.13.0` (Schema `010` + idempotent `employee_notification_reads` table)  
**Date:** 2026-11-22  
**Status:** **EMPLOYEE PORTAL 18-SCREEN REBUILD COMPLETE & VERIFIED** (`tsc --noEmit` PASS, `vite build` PASS, `tests/employee-portal-18screens.test.mjs` PASS, `tests/employee-portal-browser-e2e.test.mjs` 18-screen × 5-viewport Chromium E2E PASS, `test:unit` 15/15 PASS, `test:payroll` 10/10 PASS; Production Go-Live remains formally **NO-GO / BLOCKED** on institutional & physical hardware gates).

- **Verified Added/Updated Frontend Modules:** `src/components/employee/types.ts`, `src/components/employee/EmployeePrimitives.tsx`, `src/components/employee/EmployeeEntryFlow.tsx`, `src/components/employee/TodayAndAttendanceScreens.tsx`, `src/components/employee/RequestsScreens.tsx`, `src/components/employee/PayslipsScreens.tsx`, `src/components/employee/ProfileAndUtilityScreens.tsx`, `src/components/EmployeeMobilePortal.tsx`, `src/App.tsx`, `src/components/LoginView.tsx`.
- **Verified Backend Additions:** `server/db.ts` (`employee_notification_reads`), `server/realtimeHub.ts` (`employee:notification` channel), `server/api.ts` (Employee ID login, self-scoped notifications & read persistence, self-scoped account security sessions & revocation, official `pdfkit` Payslip PDF export).
- **Verified Automated Test Suites:** `tests/employee-portal-18screens.test.mjs` (PASS), `tests/employee-portal-browser-e2e.test.mjs` (PASS across `360×800`, `393×852`, `412×915`, `768×1024`, `1440×900` with 0 page errors, 0 broken images, 0px overflow).

---

# BUILD 17 REPORT — SAVAGE-RSUCAJ Smart Attendance Admin Portal

**Project:** SAVAGE-RSUCAJ Smart Attendance System (Romblon State University – Cajidiocan Campus)  
**Build Number:** `BUILD 17` *(cumulative continuation incorporating BUILD 15 + BUILD 16 + BUILD 17)*  
**Source Version:** `1.13.0` (continued directly from verified BUILD 01–14 source; Schema `009`)  
**Date:** 2026-11-21  
**Mandatory Go/No-Go Decision:** **`NO-GO` — PRODUCTION DEPLOYMENT BLOCKED**  
**Status:** **142/142 AUTOMATED SOFTWARE, PLAYWRIGHT 16-SCREEN/4-VIEWPORT E2E, STAGING SECURITY/IMPAIRMENT/LOAD & DR CHECKS PASS (`0` VULNERABILITIES, `0` PAGE/CONSOLE ERRORS) — PRODUCTION RELEASE STATUS: `NO-GO` / BLOCKED** *(pending BUILD 09 real biometric verification & anti-spoofing, physical Raspberry Pi/Android kiosk/Android employee/Windows staging acceptance, RSU Cajidiocan Finance written payroll policy sign-off, RSU Cajidiocan HRMO official CS Form 48 confirmation, production Linux VPS/DNS/TLS provisioning, offsite encrypted backup replication, on-call roster, and Project Owner Go-Live sign-off)*

---

## 1. OVERVIEW

BUILD 17 executes the **Mandatory Go/No-Go Release Gate Evaluation** and delivers the complete **Production Deployment, Operations, Security, Release Notes & Staging Acceptance Pack** on top of the verified **BUILD 15** (16-screen Playwright Chromium E2E + WCAG 2.1 AA accessibility & 4-viewport responsive polish) and **BUILD 16** (production-like staging runtime, `X-Request-Id` structured JSON logging, controllable staging-only network impairment, server-confirmed kiosk duplicate voice cue, live security audit, 200-read/50-punch load & DR benchmark, and a critical cross-module audit hash-chain bugfix).

Every existing BUILD 01–14 module, authentication/RBAC mechanism, live SQLite database (`/data/savage_rsucaj.db` untouched at Schema `009`), branding, official RSU emblem, and all 16 approved UI/UX reference screens are preserved intact with **zero redesign** and **zero Admin Biometrics sidebar**.

### Mandatory Go/No-Go Verdict (`npm run release:gate` -> Exit Code `2`)

| Gate ID | Category | Status | Summary Evidence |
|---|---|---|---|
| `RG-01` | Build Integrity | **PASS** | `tsc --noEmit` 0 errors, `vite build` `754 ms`, `bun audit` 0 vulnerabilities (277 packages) |
| `RG-02` | Staging, Security, Impairment, Load & DR | **PASS** | `7/7` PASS; 200 reads `p95=585.17 ms` (`295.9 req/s`), 50 punches `p95=199.31 ms` (`25/25` dedup, `0` 5xx), encrypted backup `69.09 ms`, guarded live restore `261.98 ms`, `auditChainValid=true` |
| `RG-03` | Playwright Chromium Browser E2E & Accessibility | **PASS** | `22/22` PASS across all 16 reference screens × 4 viewports (`41` audited screenshots, `0` page errors, `0` blocking console errors, `0px` overflow) |
| `RG-04` | Database Integrity | **PASS** | Live `savage_rsucaj.db` at Schema `009`, `PRAGMA integrity_check=ok`, `FK violations=0`, migration rollback dry-run PASS |
| `RG-05` | Production Host, TLS & Secrets | **BLOCKED** | No live production VPS `.env`, DNS/TLS certificate, or reverse proxy attached |
| `RG-06` | Institutional HR Policy (CS Form 48) | **BLOCKED** | `cs_form_48_reference_verified=false` (pending written RSU Cajidiocan HRMO approval) |
| `RG-07` | Institutional Finance Policy (Payroll) | **BLOCKED** | `0` Finance-approved institutional policies in live DB (pending RSU Finance written sign-off) |
| `RG-08` | Biometric Trust (BUILD 09) | **BLOCKED** | Real neural face recognition & anti-spoof PAD liveness not yet integrated (`liveness_verified=false`, `match_verified=false`) |
| `RG-09` | Physical Hardware & External Apps | **BLOCKED** | Separate Raspberry Pi kiosk, Android kiosk APK, Android employee APK, and Windows desktop browser not supplied (`NOT TESTED / BLOCKED`) |
| `RG-10` | Operations & Project Owner Go-Live Sign-Off | **BLOCKED** | Offsite encrypted backup replication, verified DNS/TLS, named on-call roster, RPO/RTO approval, and Project Owner Go-Live sign-off pending |

**Final Go/No-Go Decision:** **`NO-GO` (`PASS=4`, `FAIL=0`, `BLOCKED=6`) — Do NOT deploy to production or claim `PRODUCTION-READY`.**

---

## 2. ARCHITECTURE

- **Preserved Full-Stack Core:** React 19 + TypeScript + Tailwind CSS v4 + Vite 8 + Node.js (`v22.23.2`) / Express + SQLite (`better-sqlite3`, WAL mode, `PRAGMA foreign_keys = ON`, `synchronous = FULL`, Schema `009`) + `pdfkit` + Authenticated SSE (`server/realtimeHub.ts`).
- **BUILD 15–17 Architectural Additions:**
  - `/server/stagingRuntime.ts`: `StructuredLogStore` (JSON/pretty logging with strict secret redaction, `X-Request-Id` correlation, live p50/p95/p99 latency stats), `createStructuredLoggerMiddleware`, and `StagingImpairmentController` (deterministic `nowProvider`-backed `503` drop / latency injection, **strictly forbidden** in `APP_MODE=production` returning `403 STAGING_ONLY_ENDPOINT`).
  - `/server/env.ts` & `/.env.example`: Added `APP_MODE=staging`, `LOG_FORMAT`, `STAGING_PUBLIC_URL`, `STAGING_LOG_FILE`, and fail-secure rejection of `STAGING_IMPAIRMENT_ENABLED=true` when `NODE_ENV=production` or `APP_MODE=production`.
  - `/server/api.ts` & `/server.ts`: Wired structured request logging & staging impairment middleware; added server-authoritative `backend_confirmed: true`, `voice_cue` (`DUPLICATE_ALREADY_RECORDED`, `TIME_IN_RECORDED`, `TIME_OUT_RECORDED`, `ESCALATED_TO_HR`, `PUNCH_REJECTED`), and `request_id` on `/api/kiosk/punch`; added staging-only `GET/PUT /api/staging/impairment` and `GET /api/staging/logs`; preserved `appMode` across guarded live restore rebinding; bumped `/api/health` to `version: "1.13.0"`, `build: "BUILD 17"`, `schemaVersion: "009"`.
  - `/server/correctionsLeavesEngine.ts`: Replaced raw `INSERT INTO audit_logs` inside `recordGeneralAudit()` with `logAudit()` from `./auditHelpers.ts` so every correction and leave audit entry maintains the unbroken SHA-256 hash chain.
  - `/scripts/staging-setup.ts` (`npm run staging:setup`): Sanitized staging DB bootstrapper refusing to modify live `./data/savage_rsucaj.db` and labeling staging payroll policy `[STAGING TEST-ONLY — FAKE CURRENCY]`.
  - `/scripts/release-gate.ts` (`npm run release:gate`): Automated 10-gate Go/No-Go evaluator writing `/test-results/release-gate-report.json` and exiting with code `2` on `NO-GO`.
  - `/tests/e2e.browser.test.ts` (`npm run test:browser`): Real headless Chromium Playwright 16-screen, 4-viewport E2E + WCAG/overflow/error suite capturing 41 audited screenshots under `/test-results/e2e-screenshots/`.
  - `/tests/staging-security-load.test.ts` (`npm run test:staging`): 7-group automated staging integration, impairment, security audit, concurrency load, and DR benchmark suite writing `/test-results/staging-evidence.json`.

---

## 3. UI/UX DESIGN

All **16 primary UI/UX reference PNGs** under `/public/assets/aistudio/` (`01_Login_2679c12f.png` through `16_System_Settings_38594b82.png`) and the official RSU emblem (`SAVAGE-RSUCAJ_Smart_Attendance_Emblem_39488c28.png`) were visually inspected before edits, preserved without redesign, and visually verified against captured Playwright screenshots across desktop (`1366×768`, `1920×1080`), tablet (`768×1024`), and mobile (`390×844`):
- **Visual Fidelity Confirmed:** Mint/emerald/gold palette, official RSU emblem, wave accents, 6 gradient KPI cards, Today's Attendance donut SVG, Weekly Trend chart, Payroll 3-step stepper, Monthly DTR A4 preview, Devices masked credentials/badges, Audit Logs SHA-256 verification banner, and System Settings 6-tab layout all match the reference PNGs cleanly.
- **Accessibility & Responsive Polish (Zero Redesign):** Added `:focus-visible` keyboard focus rings (`src/index.css`), skip-to-main-content link, modal Escape/focus handling (`src/components/ModuleFrame.tsx`), explicit `htmlFor`/`id` and `aria-label` associations across visible form inputs and icon buttons, mobile drawer Escape dismissal, weekend weekday-defaulting in the Leave filing modal (`src/components/CorrectionsLeavesViews.tsx`), and preserved DTR sign-off confirmation banner (`src/components/PayrollReportsViews.tsx`).
- **Audited Playwright DOM Checks (41/41 Captures):** `0px` horizontal overflow, `0` broken images, `0` unlabeled visible inputs, `0` nameless buttons, `100%` `<html lang="en">` / `<main>` / `<h1>`, and **0 Admin Biometrics sidebar links**.

---

## 4. IMPLEMENTATION

### Added Files (BUILD 15–17)
- `/server/stagingRuntime.ts` — `X-Request-Id` structured logging with secret redaction, latency percentiles, and staging-only controllable network impairment controller.
- `/scripts/staging-setup.ts` — Isolated sanitized staging database & test-account bootstrapper (`npm run staging:setup`).
- `/scripts/release-gate.ts` — Automated 10-gate Go/No-Go evaluator (`npm run release:gate`).
- `/tests/e2e.browser.test.ts` — 22-test Playwright Chromium 16-screen & 4-viewport E2E + WCAG/overflow audit suite (`npm run test:browser`).
- `/tests/staging-security-load.test.ts` — 7-group staging security, impairment, offline queue, SSE, load & DR benchmark suite (`npm run test:staging`).
- `/DEPLOYMENT.md` — Linux VPS (`systemd`, Nginx/Caddy TLS, UFW, logrotate, cron backups), Hostinger Single static alternative, Windows PowerShell SOP, and rollback rehearsal guide.
- `/OPERATIONS_RUNBOOK.md` — Proposed SLO/RPO/RTO targets, daily/weekly/monthly checklists, incident playbooks, and on-call roster template.
- `/SECURITY.md` — Verified security architecture, dependency audit summary, and remaining trust blockers.
- `/RELEASE_NOTES.md` — Cumulative BUILD 15–17 (`v1.13.0`) release notes and `NO-GO` notice.
- `/docs/STAGING_ACCEPTANCE_MATRIX.md` — Recorded `X-Request-Id` evidence table & explicit `NOT TESTED / BLOCKED` hardware/institutional rows.

### Modified Files (BUILD 15–17)
- `/server/correctionsLeavesEngine.ts` — Fixed `recordGeneralAudit()` to delegate to `logAudit()`, preserving SHA-256 audit hash-chain continuity across correction/leave approvals.
- `/server/env.ts`, `/.env.example` — Added `APP_MODE=staging`, logging/impairment env variables, and fail-secure production guardrails.
- `/server/api.ts`, `/server.ts`, `/server/backup.ts`, `/server/reportsEngine.ts` — Wired structured logging, staging-only endpoints (`403` in production), server-confirmed kiosk `voice_cue`/`backend_confirmed`/`request_id`, restore `appMode` preservation, and version `1.13.0` / `BUILD 17`.
- `/src/index.css`, `/src/App.tsx`, `/src/components/ModuleFrame.tsx`, `/src/components/LoginView.tsx`, `/src/components/AdminDashboardView.tsx`, `/src/components/EmployeesView.tsx`, `/src/components/AttendanceView.tsx`, `/src/components/CorrectionsLeavesViews.tsx`, `/src/components/OrgSetupViews.tsx`, `/src/components/PayrollReportsViews.tsx`, `/src/components/SystemAdminViews.tsx` — WCAG 2.1 AA accessibility/focus/labels, responsive polish, weekend leave modal default, DTR sign-off banner fix, and `v1.13.0` / `BUILD 17` version labels.
- `/package.json`, `/package-lock.json`, `/scripts/run-tests.mjs`, `/scripts/verify-startup.mjs`, `/tests/api.test.ts`, `/tests/admin-ops.test.ts` — Added `playwright-core` devDependency, registered `staging:setup`, `test:staging`, `test:browser`, `release:gate`, and aligned assertions to `1.13.0` / `BUILD 17`.
- `/docs/RELEASE_CHECKLIST.md`, `/docs/TEST_INVENTORY.md`, `/BUILD_REPORT.md`, `/TEST_RESULTS.md`, `/CHANGELOG.md`, `/README.md`.

---

## 5. ERROR ANALYSIS

### Real Defects Found & Resolved During BUILD 15–17 Verification
1. **Critical Production Audit Hash-Chain Break (`server/correctionsLeavesEngine.ts`):** End-to-end staging restore verification caught `GET /api/audit-logs/verify` returning HTTP `409` after approving an HR correction. Root cause: `recordGeneralAudit()` executed a raw `INSERT INTO audit_logs` bypassing `logAudit()`, leaving `prev_hash`/`entry_hash` empty. **Fix:** Delegated `recordGeneralAudit()` to `logAudit()`, verified `auditChainValid: true` across both staging and Playwright E2E (`47/47` intact entries).
2. **DTR Sign-Off Confirmation Banner Immediately Cleared (`src/components/PayrollReportsViews.tsx`):** Playwright E2E (`09_Reports`) caught that `handleSignDtr` and `handleRevokeDtr` called `setSuccessMsg(...)` before `await runReport('dtr', ...)`, and `runReport()` immediately cleared `setSuccessMsg(null)`. **Fix:** Moved `setSuccessMsg(...)` after `await runReport(...)` so users see the confirmation banner reliably.
3. **Weekend Leave Modal Auto-Preview 400 Flash (`src/components/CorrectionsLeavesViews.tsx`):** Opening **New Leave** on a Saturday (`2026-11-21`) defaulted `start_date`/`end_date` to Saturday and immediately triggered a `400 NO_ELIGIBLE_LEAVE_DAYS` preview error before user input. **Fix:** Defaulted modal dates to the nearest Mon–Fri weekday when opened on Saturday/Sunday, yielding `0` console errors.
4. **Deterministic Clock Sync on Staging Impairment (`server/stagingRuntime.ts`, `server/api.ts`):** `StagingImpairmentController.middleware()` checked `Date.now()` instead of `this.nowProvider()`, causing deterministic clock tests to expire impairment windows early. **Fix:** Standardized expiration checks on `this.nowProvider()`.
5. **Playwright E2E Harness Fixes (`tests/e2e.browser.test.ts`):** Resolved `tsx` esbuild `__name` helper inside `page.evaluate`, replaced `networkidle` (incompatible with persistent SSE `/api/events/stream`) with `domcontentloaded`, provisioned ephemeral `SESSION_SECRET`/`BACKUP_ENCRYPTION_KEY`, switched `06_Attendance_Corrections` to deterministic `Full Day` regardless of wall-clock Manila hour, and tightened strict Playwright button/toast locators (`Sign In`, `Approve`, `Verify Chain`, `Export Logs`, `Create Account`).

---

## 6. TESTING

See `TEST_RESULTS.md`, `docs/TEST_INVENTORY.md`, and `docs/STAGING_ACCEPTANCE_MATRIX.md` for complete executed outputs:
- `npm run lint` (`tsc --noEmit`): **PASS** (`0` errors)
- `npm run build` (`vite build`): **PASS** (`754 ms`)
- `bun audit` (277 packages): **PASS** (`0` vulnerabilities)
- `npm test` (10 suites): **115 / 115 PASS** (`unit` 15, `db` 10, `attendance` 18, `sync` 6, `corrections-leaves` 13, `payroll` 10, `reports` 8, `admin-ops` 8, `api` 20, `staging-security-load` 7)
- `npm run test:startup`: **5 / 5 PASS** (`v1.13.0`, `BUILD 17`, `mode: "production"`, `schemaVersion: "009"`)
- `npm run test:browser`: **22 / 22 PASS** (`41` audited screenshots across all 16 screens & 4 viewports, `0` page errors, `0` blocking console errors)
- `npm run db:migrate -- --dry-run --db ./data/savage_rsucaj.db`: **PASS** (`009 -> 009 -> 009`, `Integrity Check: ok`, `FK Violations: 0`, `Exact Row Counts Match: true`, live DB untouched)
- `npm run staging:setup -- --db /tmp/savage-b17-setup-smoke.db --reset`: **PASS**
- `npm run check:env`: **PASS (Fail-Secure)** — returns `INVALID` (exit `1`) without `SESSION_SECRET`
- `npm run release:gate`: **EXIT 2 — DETERMINISTIC `NO-GO`** (`PASS=4`, `FAIL=0`, `BLOCKED=6`, saved to `/test-results/release-gate-report.json`)
- **Total Automated Software Checks Executed:** **142 / 142 PASS**
- **Explicitly NOT TESTED / BLOCKED:** Physical Raspberry Pi 3B+ Kiosk (`NOT TESTED / BLOCKED`), Android Kiosk APK (`NOT TESTED / BLOCKED`), Android Employee Mobile APK (`NOT TESTED / BLOCKED`), Windows Desktop Browser (`NOT TESTED`), BUILD 09 Real Biometrics & Anti-Spoofing (`BLOCKED`), Official RSU CS Form 48 Approval (`BLOCKED`), RSU Finance Payroll Policy Sign-Off (`BLOCKED`), Live Production VPS / DNS / TLS / Offsite Backup / On-Call Roster / Project Owner Go-Live Sign-Off (`BLOCKED`).

---

## 7. DEPLOYMENT

**PRODUCTION DEPLOYMENT IS CURRENTLY BLOCKED (`NO-GO`).**  
Full deployment, staging, backup/restore, TLS/reverse-proxy (Nginx & Caddy), Hostinger Single static hosting alternative, Windows PowerShell, and rollback rehearsal procedures are documented in:
- [`DEPLOYMENT.md`](DEPLOYMENT.md)
- [`OPERATIONS_RUNBOOK.md`](OPERATIONS_RUNBOOK.md)
- [`SECURITY.md`](SECURITY.md)
- [`RELEASE_NOTES.md`](RELEASE_NOTES.md)

Do **NOT** run production deployment or tag a production release until `npm run release:gate` reports **`GO` (`PASS=10, FAIL=0, BLOCKED=0`)**.

---

## 8. FINAL REPORT & REQUIRED BUILD HANDOFF

```text
BUILD NUMBER:           BUILD 17 (cumulative with BUILD 15 & BUILD 16)
PROJECT NAME:           SAVAGE-RSUCAJ Smart Attendance Admin Portal (Romblon State University – Cajidiocan Campus)
SOURCE VERSION:         1.13.0 (Schema 009)
STATUS:                 NO-GO — PRODUCTION DEPLOYMENT BLOCKED (142/142 automated software/E2E/staging checks PASS; 4/10 release gates PASS, 0 FAIL, 6 BLOCKED)
COMPLETED FEATURES:     BUILD 15: WCAG 2.1 AA keyboard/focus/ARIA/responsive polish across all 16 reference screens + 22-test Playwright Chromium E2E suite (41 audited screenshots across 1366x768, 1920x1080, 768x1024, 390x844; 0 errors, 0 overflow, 0 Admin Biometrics links) + DTR sign-off banner fix + weekend leave default fix. BUILD 16: Production-like APP_MODE=staging runtime, X-Request-Id structured JSON logging with secret redaction, staging-only controllable network impairment (403 in production), server-confirmed kiosk duplicate voice_cue/backend_confirmed, sanitized staging:setup CLI, 7-domain live security audit, 200-read/50-punch load & AES-256-GCM backup/restore benchmark, and critical audit hash-chain bugfix in server/correctionsLeavesEngine.ts. BUILD 17: Automated 10-gate release:gate evaluator (NO-GO exit 2) + complete DEPLOYMENT.md, OPERATIONS_RUNBOOK.md, SECURITY.md, RELEASE_NOTES.md, docs/STAGING_ACCEPTANCE_MATRIX.md, and updated release/test governance docs.
MODIFIED FILES:         /server/correctionsLeavesEngine.ts, /server/env.ts, /server/api.ts, /server.ts, /server/backup.ts, /server/reportsEngine.ts, /.env.example, /src/index.css, /src/App.tsx, /src/components/ModuleFrame.tsx, /src/components/LoginView.tsx, /src/components/AdminDashboardView.tsx, /src/components/EmployeesView.tsx, /src/components/AttendanceView.tsx, /src/components/CorrectionsLeavesViews.tsx, /src/components/OrgSetupViews.tsx, /src/components/PayrollReportsViews.tsx, /src/components/SystemAdminViews.tsx, /package.json, /package-lock.json, /scripts/run-tests.mjs, /scripts/verify-startup.mjs, /tests/api.test.ts, /tests/admin-ops.test.ts, /docs/RELEASE_CHECKLIST.md, /docs/TEST_INVENTORY.md, /BUILD_REPORT.md, /TEST_RESULTS.md, /CHANGELOG.md, /README.md
ADDED FILES:            /server/stagingRuntime.ts, /scripts/staging-setup.ts, /scripts/release-gate.ts, /tests/e2e.browser.test.ts, /tests/staging-security-load.test.ts, /DEPLOYMENT.md, /OPERATIONS_RUNBOOK.md, /SECURITY.md, /RELEASE_NOTES.md, /docs/STAGING_ACCEPTANCE_MATRIX.md
TESTS EXECUTED:         npm run lint (0 errors); npm run build (754ms); bun audit (0 vulnerabilities / 277 pkgs); npm test (10 suites = 115/115 PASS); npm run test:startup (5/5 PASS); npm run test:browser (22/22 PASS, 41 screenshots, 0 errors); npm run db:migrate -- --dry-run --db ./data/savage_rsucaj.db (PASS, live DB untouched); npm run staging:setup (PASS); npm run check:env (fail-secure INVALID without SESSION_SECRET); npm run release:gate (NO-GO exit 2: PASS=4, FAIL=0, BLOCKED=6)
TEST RESULTS:           142/142 automated software checks PASS; Build/Lint/Audit/Dry-Run/Staging-Setup PASS; Release Gate = NO-GO (6 operational/biometric/hardware/institutional gates BLOCKED)
UNRESOLVED ISSUES:      (1) BUILD 09 real neural face recognition & anti-spoof PAD liveness not yet implemented; (2) Separate Raspberry Pi kiosk, Android kiosk APK, Android employee APK, and Windows desktop browser not supplied (NOT TESTED / BLOCKED); (3) RSU Cajidiocan HRMO CS Form 48 written confirmation pending (cs_form_48_reference_verified=false); (4) RSU Cajidiocan Finance written payroll policy & golden output sign-off pending; (5) Live production VPS, DNS/TLS, offsite encrypted backup replication, on-call contacts & Project Owner Go-Live sign-off pending; (6) No standalone .zip archive artifact was generated in this workspace environment (source files updated directly in workspace).
SECURITY LIMITATIONS:   Kiosk HMAC biometric envelopes currently validate transport/device authenticity only (liveness_verified=false, match_verified=false until BUILD 09). Production TLS 1.2+, HSTS, UFW firewall, secret-store injection, Google SSO OAuth, outbound SMTP, and offsite backup replication require live production infrastructure.
DEPLOYMENT STATUS:      NO-GO / BLOCKED (do not deploy to production until RG-05 through RG-10 pass and npm run release:gate outputs GO)
NEXT BUILD REQUIREMENTS: Complete BUILD 09 biometric recognition & anti-spoof liveness with measured FAR/FRR/PAD evidence; attach real Raspberry Pi kiosk, Android kiosk, Android employee app & Windows desktop browser to an HTTPS staging host and close docs/STAGING_ACCEPTANCE_MATRIX.md; secure written RSU HRMO CS Form 48 & RSU Finance payroll policy sign-offs; provision production Linux VPS per DEPLOYMENT.md with offsite encrypted backup drill & named on-call roster; re-run npm run release:gate to achieve GO before Go-Live.
```
