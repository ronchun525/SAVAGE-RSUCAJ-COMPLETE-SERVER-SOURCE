# SAVAGE-RSUCAJ Smart Attendance Admin Portal — Deployment Guide

**Target Build:** `BUILD 17` (`v1.13.0`, Schema `009`)  
**Current Release Gate Status:** **NO-GO — PRODUCTION DEPLOYMENT BLOCKED**  
> **MANDATORY WARNING:** Do **NOT** execute production deployment or declare `PRODUCTION-READY` until `npm run release:gate` returns `GO` and every institutional, biometric (BUILD 09), hardware, and Project Owner sign-off gate in `docs/RELEASE_CHECKLIST.md` passes in the target environment.

---

## 1. Hosting Architecture & Runtime Requirements

This application is a **full-stack Node.js + Express + SQLite (WAL) + Server-Sent Events (SSE) + React 19 SPA** application (`server.ts` serves both `/api/*` and the compiled `dist/` frontend).

- **Supported Runtime:** Node.js `^20.19.0 || >=22.12.0` (LTS 22.x recommended), npm `>=10.0.0`
- **Native Addon:** `better-sqlite3` (requires C++ build toolchain if prebuilt binaries are unavailable for the host ABI)
- **Required Hosting Tier:** A **Node.js-capable Linux VPS or campus server** (Ubuntu 22.04/24.04 LTS, Debian 12, or RHEL/Rocky 9) with:
  - Persistent local SSD/NVMe storage (NEVER SQLite on NFS/SMB network shares — WAL locking requires POSIX local filesystem semantics)
  - Reverse proxy supporting HTTPS/TLS 1.2+ and unbuffered SSE streaming (Nginx or Caddy)
  - Process supervisor (`systemd`) and firewall (`ufw`/`nftables`)

### Note on Shared Static Hosting (e.g., Hostinger Single Shared Plan)
Ordinary shared PHP/static hosting plans (such as Hostinger Single Shared Web Hosting) **do NOT provide persistent Node.js Express process supervision, local SQLite WAL reliability, or long-lived SSE connections**.
If the campus must use a Hostinger Single plan for the web domain:
1. Build the static frontend (`npm run build`) and deploy ONLY `dist/` to the static web host, configuring `VITE_API_BASE_URL` or reverse-proxy routing to a **separately hosted Node.js VPS** running `server.ts` + SQLite over HTTPS.
2. Configure `ALLOWED_ORIGINS=https://<frontend-domain>` and `COOKIE_DOMAIN` / HTTPS `SameSite` settings on the Node API host, and verify cross-origin cookie/CSRF behavior end-to-end before go-live.
3. **Recommended Architecture:** Host both the compiled `dist/` SPA and Express API behind a single HTTPS origin (e.g., `https://attendance.rsu-cajidiocan.tech` — **only after DNS ownership and TLS issuance are verified**) on a single Node-capable Linux VPS to preserve strict same-origin cookies and CSRF protection.

---

## 2. Production Directory & Storage Separation (Linux VPS)

Keep the production SQLite database, encrypted backups, and logs **strictly outside** the application deploy directory (`/opt/savage-rsucaj/app`) so release upgrades or `npm run clean` can never overwrite live data.

```bash
# 1. Create dedicated non-root service user and separated persistent directories
sudo useradd --system --home /opt/savage-rsucaj --shell /usr/sbin/nologin savage || true
sudo mkdir -p /opt/savage-rsucaj/app \
              /var/lib/savage-rsucaj/data \
              /var/backups/savage-rsucaj \
              /var/log/savage-rsucaj \
              /etc/savage-rsucaj

sudo chown -R savage:savage /opt/savage-rsucaj /var/lib/savage-rsucaj /var/backups/savage-rsucaj /var/log/savage-rsucaj
sudo chown root:savage /etc/savage-rsucaj
sudo chmod 0750 /var/lib/savage-rsucaj /var/lib/savage-rsucaj/data /var/backups/savage-rsucaj /var/log/savage-rsucaj /etc/savage-rsucaj
```

---

## 3. Secrets & Production Environment Configuration

Provision `/etc/savage-rsucaj/production.env` from your approved secret store (`chmod 0640`, owned by `root:savage`). **Never commit `.env` files or print secret values in terminal logs or build reports.**

```ini
# /etc/savage-rsucaj/production.env (chmod 0640 root:savage)
NODE_ENV=production
APP_MODE=production
PORT=3000
TRUST_PROXY=true
DISABLE_HMR=true
LOG_FORMAT=json

# Persistent storage outside deployment directory
DATABASE_PATH=/var/lib/savage-rsucaj/data/savage_rsucaj.db
BACKUP_DIR=/var/backups/savage-rsucaj
BACKUP_RETENTION_COUNT=30
SQLITE_BUSY_TIMEOUT_MS=5000
SQLITE_WAL_AUTOCHECKPOINT=1000

# Mandatory high-entropy secrets (generate with: openssl rand -hex 48)
SESSION_SECRET=<INJECT_FROM_SECRET_STORE>
BACKUP_ENCRYPTION_KEY=<INJECT_FROM_SECRET_STORE>
# Optional during key rotation window only:
# SESSION_SECRET_PREVIOUS=<PRIOR_SECRET>

# Same-origin HTTPS allowlist (verify DNS ownership first)
ALLOWED_ORIGINS=https://attendance.rsu-cajidiocan.tech

# Lockout & Rate Limiting
MAX_FAILED_LOGIN_ATTEMPTS=5
LOCKOUT_DURATION_MINUTES=15
LOGIN_RATE_LIMIT_MAX=20

# Fresh database bootstrap ONLY (remove after first forced password rotation)
# ADMIN_INITIAL_USERNAME=rsu_sysadmin
# ADMIN_INITIAL_EMAIL=mis@rsucaj.edu.ph
# ADMIN_INITIAL_PASSWORD=<INJECT_FROM_SECRET_STORE>

# Staging impairment MUST remain unset/false in production
STAGING_IMPAIRMENT_ENABLED=false
```

Validate environment configuration before booting:
```bash
set -a && source /etc/savage-rsucaj/production.env && set +a
cd /opt/savage-rsucaj/app
npm run check:env -- --strict
```

---

## 4. Reproducible Build & Migration Procedure (Maintenance Window)

Execute ONLY during an approved maintenance window after `GO` sign-off:

```bash
# 1. Extract immutable release artifact into versioned directory
cd /opt/savage-rsucaj/app
npm ci
npm run lint
npm run build

# 2. Take verified encrypted pre-upgrade backup snapshot (if upgrading an existing DB)
sudo -u savage env $(grep -v '^#' /etc/savage-rsucaj/production.env | xargs) npm run db:backup

# 3. Execute isolated migration + rollback dry run (live DB untouched)
sudo -u savage env $(grep -v '^#' /etc/savage-rsucaj/production.env | xargs) \
  npm run db:migrate -- --dry-run --db /var/lib/savage-rsucaj/data/savage_rsucaj.db

# 4. Apply transactional schema migrations (001 -> 009)
sudo -u savage env $(grep -v '^#' /etc/savage-rsucaj/production.env | xargs) npm run db:migrate
```

---

## 5. Systemd Process Supervision (`/etc/systemd/system/savage-rsucaj.service`)

```ini
[Unit]
Description=SAVAGE-RSUCAJ Smart Attendance Admin Portal
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=savage
Group=savage
WorkingDirectory=/opt/savage-rsucaj/app
EnvironmentFile=/etc/savage-rsucaj/production.env
ExecStart=/usr/bin/node /opt/savage-rsucaj/app/scripts/start.mjs
Restart=on-failure
RestartSec=5
TimeoutStopSec=15
KillSignal=SIGTERM

# Security hardening
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/savage-rsucaj /var/backups/savage-rsucaj /var/log/savage-rsucaj
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX

StandardOutput=append:/var/log/savage-rsucaj/app.log
StandardError=append:/var/log/savage-rsucaj/error.log

[Install]
WantedBy=multi-user.target
```

Enable and verify:
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now savage-rsucaj
sudo systemctl status savage-rsucaj
curl -fsS http://127.0.0.1:3000/api/health
```

---

## 6. Reverse Proxy (Nginx or Caddy), TLS & Firewall

### Option A — Nginx (`/etc/nginx/sites-available/savage-rsucaj.conf`)
```nginx
server {
    listen 80;
    server_name attendance.rsu-cajidiocan.tech;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name attendance.rsu-cajidiocan.tech;

    ssl_certificate /etc/letsencrypt/live/attendance.rsu-cajidiocan.tech/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/attendance.rsu-cajidiocan.tech/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers off;

    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    client_max_body_size 5m;

    # Unbuffered Server-Sent Events (SSE) stream
    location /api/events/stream {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_buffering off;
        proxy_cache off;
        proxy_read_timeout 3600s;
    }

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### Option B — Caddy (`/etc/caddy/Caddyfile`)
```caddy
attendance.rsu-cajidiocan.tech {
    header {
        Strict-Transport-Security "max-age=31536000; includeSubDomains"
        X-Content-Type-Options "nosniff"
        Referrer-Policy "strict-origin-when-cross-origin"
    }
    reverse_proxy 127.0.0.1:3000 {
        flush_interval -1
    }
}
```

### Restrictive Firewall (`ufw`) & Log Rotation (`/etc/logrotate.d/savage-rsucaj`)
```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
# NEVER expose port 3000 publicly
sudo ufw enable
```

```text
# /etc/logrotate.d/savage-rsucaj
/var/log/savage-rsucaj/*.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
    copytruncate
    create 0640 savage savage
}
```

---

## 7. Scheduled Encrypted Backups & Offsite Sync

```bash
# /etc/cron.d/savage-rsucaj-backup (runs every 6 hours)
0 */6 * * * savage set -a && . /etc/savage-rsucaj/production.env && set +a && cd /opt/savage-rsucaj/app && /usr/bin/npm run db:backup >> /var/log/savage-rsucaj/backup.log 2>&1
```
Sync `/var/backups/savage-rsucaj/*.sqlite.enc` + `*.manifest.json` to institutional offsite NAS or encrypted object storage after each run, and perform a monthly bare-metal restore drill (`npm run db:restore -- --archive <file> --target /tmp/drill.db`).

---

## 8. Windows Server / Admin PowerShell Commands (When Administered on Windows)

```powershell
# Verify Node & npm
node -v
npm -v

# Reproducible build
npm ci
npm run lint
npm run build

# Validate production environment (load secrets from Windows Credential Manager / Vault)
$env:NODE_ENV = "production"
$env:APP_MODE = "production"
$env:DATABASE_PATH = "C:\ProgramData\SAVAGE-RSUCAJ\data\savage_rsucaj.db"
$env:BACKUP_DIR = "C:\ProgramData\SAVAGE-RSUCAJ\backups"
npm run check:env -- --strict

# Backup, dry-run migration, migrate, and health check
npm run db:backup
npm run db:migrate -- --dry-run --db $env:DATABASE_PATH
npm run db:migrate
npm run health

# Isolated Staging Bootstrap (NEVER copies production data)
npm run staging:setup -- --db "C:\ProgramData\SAVAGE-RSUCAJ-Staging\staging.db" --reset
```

---

## 9. Rollback Rehearsal Procedure

1. Stop service: `sudo systemctl stop savage-rsucaj`
2. Verify target pre-upgrade archive:
   `npm run db:restore -- --archive /var/backups/savage-rsucaj/<archive>.sqlite.enc --target /tmp/verify.db`
3. Restore live database:
   `npm run db:restore -- --archive /var/backups/savage-rsucaj/<archive>.sqlite.enc --target /var/lib/savage-rsucaj/data/savage_rsucaj.db --apply`
4. Switch `/opt/savage-rsucaj/app` symlink back to the prior immutable release tag.
5. Start service: `sudo systemctl start savage-rsucaj`, verify `GET /api/health` and `GET /api/audit-logs/verify`.
