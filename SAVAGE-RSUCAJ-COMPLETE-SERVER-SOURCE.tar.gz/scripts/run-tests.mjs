import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import path from 'node:path';

const require = createRequire(import.meta.url);
const tsxCli = require.resolve('tsx/cli');
const rootDir = process.cwd();

const suites = [
  {
    category: 'Unit Tests (Env Validation, Mode Separation, Security & Auth Crypto)',
    script: path.join(rootDir, 'tests', 'unit.test.ts'),
  },
  {
    category: 'Database Durability, Migrations, WAL, Concurrency, Encrypted Backup & Restore Tests',
    script: path.join(rootDir, 'tests', 'db.test.ts'),
  },
  {
    category: 'Attendance Policy, Asia/Manila Timezone, 03:00 Cutoff, Reconciliation & Immutability Tests',
    script: path.join(rootDir, 'tests', 'attendance.test.ts'),
  },
  {
    category: 'Kiosk Offline Queue, Batch Sync, Heartbeat Telemetry & Authenticated SSE Tests (BUILD 10)',
    script: path.join(rootDir, 'tests', 'sync.test.ts'),
  },
  {
    category: 'Corrections Immutability/Reversal, Configurable Leave Policies, Multi-Day Propagation & Reports Tests (BUILD 11)',
    script: path.join(rootDir, 'tests', 'corrections-leaves.test.ts'),
  },
  {
    category: 'Institutional Payroll Policies, Split-Month Proration, Maker-Checker, Immutability & Payslip/CSV Security Tests (BUILD 12)',
    script: path.join(rootDir, 'tests', 'payroll.test.ts'),
  },
  {
    category: 'Reports, Monthly DTR Calendar/Overnight/Leave/Corrections, PDF Structure, Streaming CSV & RBAC Tests (BUILD 13)',
    script: path.join(rootDir, 'tests', 'reports.test.ts'),
  },
  {
    category: 'System Settings, Live Restore, Retention Dry-Run/Purge, Device Rotation/Alerts, Role Notifications & Tamper-Evident Audit Tests (BUILD 14)',
    script: path.join(rootDir, 'tests', 'admin-ops.test.ts'),
  },
  {
    category: 'API, Security, RBAC, Backup Endpoints & SQLite Integration Tests',
    script: path.join(rootDir, 'tests', 'api.test.ts'),
  },
  {
    category: 'BUILD 16 Staging Integration, Network Impairment, Security Audit, Load & Recovery Tests',
    script: path.join(rootDir, 'tests', 'staging-security-load.test.ts'),
  },
];

let failedSuites = 0;

for (const suite of suites) {
  console.log(`\n=== ${suite.category} ===`);
  const res = spawnSync(process.execPath, [tsxCli, suite.script], {
    stdio: 'inherit',
    env: process.env,
  });
  if (res.status !== 0) {
    failedSuites++;
  }
}

console.log('\n=== Non-Executed Verification Categories (Explicit Status) ===');
console.log('INFO        Local Production Startup Smoke: run `npm run build && npm run test:startup`');
console.log('INFO        Browser E2E (Playwright Chromium, 16/16 screens & 4 viewports): run `npm run build && npm run test:browser`');
console.log('BLOCKED     Official CS Form 48 Reference Verification: pending RSU Cajidiocan approved Civil Service Form 48 layout confirmation.');
console.log('BLOCKED     Institutional Finance Sign-Off on Written Payroll Policy & Actual Scenario Outputs: pending RSU Cajidiocan Finance approval.');
console.log('BLOCKED     Real Biometric Verification & Anti-Spoofing (BUILD 09 reserved / hardware unavailable).');
console.log('BLOCKED     Physical Hardware & External Apps (Raspberry Pi Kiosk, Android Kiosk, Android Employee App, Windows Browser): separate repos/APKs/devices not supplied.');
console.log('BLOCKED     External Auth/Mail (Google SSO OAuth / Outbound SMTP): credentials not configured.');
console.log('BLOCKED     Offsite Cloud/NAS Backup Transfer & Production Persistent Volume Permissions: no live production server attached.');

if (failedSuites > 0) {
  console.error(`\nOverall Test Runner Result: FAIL (${failedSuites} suite(s) failed).`);
  process.exit(1);
}

console.log('\nOverall Test Runner Result: PASS (all automated unit, DB, attendance, sync/SSE, corrections/leaves, payroll, reports, admin-ops, API & staging/security/load suites passed).');
