import 'dotenv/config';
import path from 'node:path';
import { closeDatabaseSafely, getDatabaseStatus, initDatabase } from '../server/db.ts';
import { runMigrationRollbackDryRun } from '../server/backup.ts';

function getArg(flag: string): string | undefined {
  const idx = process.argv.indexOf(flag);
  if (idx !== -1 && idx + 1 < process.argv.length) {
    return process.argv[idx + 1];
  }
  return undefined;
}

function main(): void {
  const dbPath =
    getArg('--db') || process.env.DATABASE_PATH?.trim() || path.resolve(process.cwd(), 'data', 'savage_rsucaj.db');
  const dryRun = process.argv.includes('--dry-run');

  if (dryRun) {
    const dryRes = runMigrationRollbackDryRun(dbPath);
    console.log('SAVAGE-RSUCAJ Migration & Rollback Dry Run (Isolated Temp Copy — Live DB Untouched)');
    console.log(`  Source Schema Version:   ${dryRes.sourceSchemaVersion}`);
    console.log(`  Migrated Schema Version: ${dryRes.migratedSchemaVersion}`);
    console.log(`  Restored Schema Version: ${dryRes.restoredSchemaVersion}`);
    console.log(`  Snapshot SHA-256:        ${dryRes.snapshotSha256}`);
    console.log(`  Integrity Check:         ${dryRes.integrityCheck}`);
    console.log(`  FK Violations:           ${dryRes.foreignKeyViolations}`);
    console.log(`  Exact Row Counts Match:  ${dryRes.rowCountsMatchExact}`);
    console.log(`  Status:                  ${dryRes.ok ? 'PASS' : 'FAIL'}`);
    if (!dryRes.ok) process.exit(1);
    return;
  }

  const db = initDatabase(dbPath, {
    mode: 'production',
    seedDemoData: false,
    skipAdminBootstrap: true,
  });

  try {
    const status = getDatabaseStatus(db, dbPath);
    console.log('SAVAGE-RSUCAJ Versioned SQLite Migration Completed');
    console.log(`  Database Path:        ${status.databasePath}`);
    console.log(`  Schema Version:       ${status.schemaVersion}`);
    console.log(`  Journal Mode:         ${status.journalMode}`);
    console.log(`  Foreign Keys:         ${status.foreignKeys}`);
    console.log(`  Integrity Check:      ${status.integrityCheck}`);
    console.log(`  FK Violations:        ${status.foreignKeyViolations}`);
    console.log('  Applied Migrations:');
    for (const m of status.appliedMigrations) {
      console.log(`    - ${m.version}: ${m.name} (${m.applied_at})`);
    }
  } finally {
    closeDatabaseSafely(db);
  }
}

try {
  main();
} catch (err) {
  console.error('Database migration failed:', err instanceof Error ? err.message : err);
  process.exit(1);
}
