import 'dotenv/config';
import path from 'node:path';
import { closeDatabaseSafely, initDatabase } from '../server/db.ts';
import { createOnlineSqliteBackup } from '../server/backup.ts';

function getArg(flag: string): string | undefined {
  const idx = process.argv.indexOf(flag);
  if (idx !== -1 && idx + 1 < process.argv.length) {
    return process.argv[idx + 1];
  }
  return undefined;
}

function main(): void {
  const dbPath =
    getArg('--db') || process.env.DATABASE_PATH?.trim() || path.resolve(process.cwd(), 'data', 'savage_rsucaj.db');
  const backupDir =
    getArg('--out') ||
    process.env.BACKUP_DIR?.trim() ||
    path.resolve(path.dirname(path.resolve(dbPath)), 'backups');
  const retentionCount = Number(process.env.BACKUP_RETENTION_COUNT) || 14;
  const encryptionKey = process.env.BACKUP_ENCRYPTION_KEY?.trim() || undefined;

  const db = initDatabase(dbPath, {
    mode: 'production',
    seedDemoData: false,
    skipAdminBootstrap: true,
  });

  try {
    const result = createOnlineSqliteBackup(db, {
      backupDir,
      createdBy: 'cli:db-backup',
      encryptionKey,
      retentionCount,
      recordInHistory: true,
    });

    console.log('SAVAGE-RSUCAJ Online SQLite Backup Completed (BUILD 06)');
    console.log(`  Backup ID:            ${result.manifest.backupId}`);
    console.log(`  Schema Version:       ${result.manifest.schemaVersion}`);
    console.log(`  SQLite Snapshot:      ${result.sqlitePath}`);
    console.log(`  SQLite SHA-256:       ${result.manifest.sqliteSha256}`);
    console.log(`  SQLite Size (bytes):  ${result.manifest.sqliteSizeBytes}`);
    console.log(`  Manifest File:        ${result.manifestPath}`);
    console.log(`  Encrypted Offsite:    ${result.encryptedPath ? result.encryptedPath : '[NOT ENCRYPTED - BACKUP_ENCRYPTION_KEY unset]'}`);
    console.log(`  Integrity Check:      ${result.manifest.integrityCheck}`);
    console.log(`  FK Violations:        ${result.manifest.foreignKeyViolations}`);
    console.log(`  Pruned Old Files:     ${result.prunedFiles.length}`);
  } finally {
    closeDatabaseSafely(db);
  }
}

try {
  main();
} catch (err) {
  console.error('Online SQLite backup failed:', err instanceof Error ? err.message : err);
  process.exit(1);
}
