function parseArg(prefix, fallback) {
  const match = process.argv.find((arg) => arg.startsWith(`${prefix}=`));
  return match ? match.slice(prefix.length + 1) : fallback;
}

const port = parseArg('--port', process.env.PORT || '3000');
const url = parseArg('--url', `http://127.0.0.1:${port}/api/health`);
const retries = Math.max(1, Number(parseArg('--retries', '5')) || 5);
const intervalMs = Math.max(100, Number(parseArg('--interval-ms', '500')) || 500);
const timeoutMs = Math.max(500, Number(parseArg('--timeout-ms', '3000')) || 3000);

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function probeOnce() {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal });
    const text = await res.text();
    let payload = null;
    try {
      payload = JSON.parse(text);
    } catch {
      throw new Error(`Non-JSON health response (HTTP ${res.status}): ${text.slice(0, 120)}`);
    }
    if (res.status !== 200) {
      throw new Error(`Unexpected HTTP status ${res.status}: ${JSON.stringify(payload)}`);
    }
    if (payload?.status !== 'ok' || payload?.database !== 'connected') {
      throw new Error(`Unhealthy payload: ${JSON.stringify(payload)}`);
    }
    return { status: res.status, payload };
  } finally {
    clearTimeout(timer);
  }
}

async function main() {
  let lastError = null;
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const result = await probeOnce();
      console.log(
        `HEALTH PASS (${url}) HTTP ${result.status}: ${JSON.stringify(result.payload)}`
      );
      process.exit(0);
    } catch (err) {
      lastError = err instanceof Error ? err.message : String(err);
      if (attempt < retries) {
        await sleep(intervalMs);
      }
    }
  }
  console.error(`HEALTH FAIL (${url}) after ${retries} attempt(s): ${lastError}`);
  process.exit(1);
}

main();
