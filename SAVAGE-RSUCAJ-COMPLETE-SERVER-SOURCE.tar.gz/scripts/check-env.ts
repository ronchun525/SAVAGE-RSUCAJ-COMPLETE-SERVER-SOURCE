import 'dotenv/config';
import { formatEnvValidationReport, validateEnv } from '../server/env.ts';

const strict = process.argv.includes('--strict');
const result = validateEnv(process.env, { strict, requireInitialAdmin: strict });

console.log(formatEnvValidationReport(result));

if (!result.valid) {
  process.exit(1);
}
