import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
import path from 'node:path';

const require = createRequire(import.meta.url);
const tsxCli = require.resolve('tsx/cli');
const serverEntry = path.resolve(process.cwd(), 'server.ts');

const env = {
  ...process.env,
  NODE_ENV: 'production',
};

const child = spawn(process.execPath, [tsxCli, serverEntry], {
  stdio: 'inherit',
  env,
});

const forwardSignal = (signal) => {
  if (!child.killed) {
    child.kill(signal);
  }
};

process.on('SIGINT', () => forwardSignal('SIGINT'));
process.on('SIGTERM', () => forwardSignal('SIGTERM'));

child.on('error', (err) => {
  console.error('Failed to start production server:', err);
  process.exit(1);
});

child.on('exit', (code, signal) => {
  if (signal) {
    process.exit(0);
    return;
  }
  process.exit(code ?? 0);
});
