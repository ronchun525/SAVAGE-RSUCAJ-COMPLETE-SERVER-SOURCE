/**
 * BUILD 30: fail-closed release evidence inventory.
 * This is an inventory verifier, NOT an independent test attestation authority.
 * No code path emits 'PRODUCTION_READY'; final decision requires human review.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const descriptions = JSON.parse(fs.readFileSync(path.join(repo, 'BUILD29_GATE_DESCRIPTIONS.json'), 'utf8'));
const HEX64 = /^[a-f0-9]{64}$/i;

/** Files are kept alongside status.json, cannot be symlinks or duplicated across gates. */
export function verifyBuild30Evidence(manifestPath) {
  const problems = [];
  const checks = [];
  let manifest;
  try { manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8')); }
  catch { return { status: 'NO_GO', problems: ['Evidence manifest missing or unreadable JSON'], checks }; }
  if (manifest?.schema !== 'SAVAGE_BUILD30_EVIDENCE_V1' ||
      !manifest?.gates || Array.isArray(manifest.gates) || typeof manifest.gates !== 'object') {
    problems.push('Missing/invalid BUILD30 schema and gates');
  }
  const root = path.dirname(path.resolve(manifestPath));
  const usedFiles = new Set();
  const usedDigests = new Set();
  const expected = Object.keys(descriptions);
  for (const key of Object.keys(manifest.gates || {})) {
    if (!expected.includes(key)) problems.push(`Unknown gate: ${key}`);
  }
  for (const [key, description] of Object.entries(descriptions)) {
    const gate = manifest.gates?.[key];
    const status = gate?.status ?? 'NOT_RUN';
    let evidenceDigest = null;
    if (status !== 'PASS') {
      problems.push(`${key}: ${status}`);
    } else {
      const f = gate.evidence_file;
      const expectedHash = gate.evidence_sha256;
      if (typeof gate.reviewer !== 'string' || gate.reviewer.trim().length < 3) problems.push(`${key}: missing named reviewer`);
      if (typeof f !== 'string' || !f || path.isAbsolute(f) || f.includes('\\') || f.includes('\0') ||
          f.split('/').some(segment => !segment || segment === '.' || segment === '..')) {
        problems.push(`${key}: invalid evidence relative path`);
      } else {
        const full = path.resolve(root, f);
        const relative = path.relative(root, full);
        if (relative.startsWith('..') || path.isAbsolute(relative)) {
          problems.push(`${key}: evidence path escapes directory`);
        } else {
          try {
            const stat = fs.lstatSync(full);
            const real = fs.realpathSync(full);
            if (!stat.isFile() || stat.isSymbolicLink() || stat.size === 0 ||
                !(real === full) && !real.startsWith(root + path.sep)) {
              problems.push(`${key}: missing/empty/linked evidence file`);
            } else {
              evidenceDigest = crypto.createHash('sha256').update(fs.readFileSync(full)).digest('hex');
              if (usedFiles.has(real)) problems.push(`${key}: evidence file reused for another gate`);
              if (usedDigests.has(evidenceDigest)) problems.push(`${key}: identical evidence reused across gates`);
              usedFiles.add(real);
              usedDigests.add(evidenceDigest);
              if (!HEX64.test(expectedHash ?? '') ||
                  !crypto.timingSafeEqual(Buffer.from(evidenceDigest), Buffer.from(expectedHash.toLowerCase()))) {
                problems.push(`${key}: missing/mismatched evidence SHA256`);
              }
            }
          } catch { problems.push(`${key}: evidence file unavailable`); }
        }
      }
    }
    checks.push({ key, description, status, observed_sha256: evidenceDigest });
  }
  return {
    status: problems.length ? 'NO_GO' : 'EVIDENCE_PRESENT_REVIEW_REQUIRED',
    problems, checks,
    notice: 'Evidence inventory integrity is not evidence authenticity. Review every artifact and obtain independent production approval.',
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const manifestPath = path.resolve(process.argv[2] || path.join(repo, 'build30_evidence', 'status.json'));
  const result = verifyBuild30Evidence(manifestPath);
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  process.exitCode = result.status === 'NO_GO' ? 2 : 0;
}
