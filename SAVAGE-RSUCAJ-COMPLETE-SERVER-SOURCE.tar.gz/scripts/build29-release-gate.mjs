import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const descriptions=JSON.parse(fs.readFileSync(path.join(root,'BUILD29_GATE_DESCRIPTIONS.json'),'utf8'));
export function checkEvidence(manifestPath) {
  const problems=[];
  if (!fs.existsSync(manifestPath)) return {status:'NO_GO', problems:['Evidence manifest not found: '+manifestPath],checks:[]};
  let manifest;
  try { manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8')); }
  catch { return {status:'NO_GO',problems:['Evidence manifest invalid JSON'],checks:[]}; }
  if (manifest.schema !== 'SAVAGE_BUILD29_EVIDENCE_V1') problems.push('Incorrect evidence schema.');
  const dirname=path.dirname(path.resolve(manifestPath));
  const checks=[];
  for (const [key,description] of Object.entries(descriptions)) {
    const item=manifest.gates?.[key];
    const status=item?.status ?? 'NOT_RUN';
    const file=item?.evidence_file;
    let digest=null;
    if (status !== 'PASS') problems.push(`${key}: ${status}`);
    if (status === 'PASS') {
      if (typeof file !== 'string' || !file.trim()) problems.push(`${key}: missing evidence_file`);
      else {
        const full=path.resolve(dirname,file);
        const relative=path.relative(dirname,full);
        if (relative.startsWith('..') || path.isAbsolute(relative)) problems.push(`${key}: evidence path escapes evidence directory`);
        else if (!fs.existsSync(full) || !fs.statSync(full).isFile() || !fs.statSync(full).size) problems.push(`${key}: missing/empty evidence file`);
        else digest=crypto.createHash('sha256').update(fs.readFileSync(full)).digest('hex');
      }
      if (!item?.reviewer || !String(item.reviewer).trim()) problems.push(`${key}: reviewer/owner not recorded`);
    }
    checks.push({key,description,status,evidence_sha256:digest});
  }
  return {status:problems.length?'NO_GO':'EVIDENCE_PRESENT_REVIEW_REQUIRED',problems,checks,
    notice:'Even evidence-completeness PASS is not certification. Qualified reviewers must validate underlying tests, physical equipment, and approvals.'};
}
if (process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const manifestPath=path.resolve(process.argv[2]||path.join(root,'build29_evidence','status.json'));
  const result=checkEvidence(manifestPath);
  process.stdout.write(JSON.stringify(result,null,2)+'\n');
  process.exitCode=result.status==='NO_GO'?2:0;
}
