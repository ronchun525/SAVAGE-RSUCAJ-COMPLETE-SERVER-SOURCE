// Build 24 source-wide TypeScript / TSX parser audit (syntax only, not type checking).
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {execFileSync} from 'node:child_process';
const require = createRequire(import.meta.url);
let ts;
try { ts = require('typescript'); }
catch {
  try { ts = require(path.join(execFileSync('npm', ['root', '-g'], {encoding:'utf8'}).trim(), 'typescript')); }
  catch { console.error('BLOCKED: TypeScript compiler not installed. Run npm install or install typescript.'); process.exit(2); }
}
const roots = [path.resolve('src'), path.resolve('server'), path.resolve('scripts'), path.resolve('tests'), path.resolve('server.ts'), path.resolve('vite.config.ts')];
let files = []; let problems = [];
function walk(p) {
  if (!fs.existsSync(p)) return;
  if (fs.statSync(p).isDirectory()) {for (const n of fs.readdirSync(p)) walk(path.join(p, n));return;}
  if (!/\.tsx?$/.test(p)) return;
  files.push(p);
  const sf = ts.createSourceFile(p, fs.readFileSync(p,'utf8'),ts.ScriptTarget.Latest,true,p.endsWith('tsx') ? ts.ScriptKind.TSX : ts.ScriptKind.TS);
  for (const diag of sf.parseDiagnostics) {
    const loc = sf.getLineAndCharacterOfPosition(diag.start ?? 0);
    problems.push(`${path.relative(process.cwd(),p)}:${loc.line+1}:${loc.character+1}: ${ts.flattenDiagnosticMessageText(diag.messageText,' ')}`);
  }
}
for (const p of roots) walk(p);
const rels = ['.ts','.tsx','.mjs','.js','/index.ts','/index.tsx'];
for (const p of files) {
  const sf = ts.createSourceFile(p, fs.readFileSync(p,'utf8'),ts.ScriptTarget.Latest,true);
  for (const st of sf.statements) {
    if (!ts.isImportDeclaration(st) && !ts.isExportDeclaration(st)) continue;
    if (!st.moduleSpecifier || !ts.isStringLiteral(st.moduleSpecifier)) continue;
    const val = st.moduleSpecifier.text;
    if (!val.startsWith('.')) continue;
    const dest = path.resolve(path.dirname(p), val);
    const targets=[dest,...rels.map(e=>dest+e)];
    if (!targets.some(x => fs.existsSync(x) && fs.statSync(x).isFile())) {
      problems.push(`${path.relative(process.cwd(),p)}: unresolved relative module ${val}`);
    }
  }
}
const summary={checked_ts_tsx_files:files.length,parse_and_local_import_errors:problems.length,errors:problems};
console.log(JSON.stringify(summary,null,2));
if(problems.length) process.exitCode=1;
