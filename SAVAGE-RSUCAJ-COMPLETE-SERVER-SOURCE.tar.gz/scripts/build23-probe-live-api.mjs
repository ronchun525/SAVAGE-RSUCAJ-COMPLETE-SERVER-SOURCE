#!/usr/bin/env node
/**
 * BUILD 23 — read-only deployment diagnostics.
 * Does not create attendance, enroll templates, or mutate production data.
 * Set SAVAGE_KIOSK_PROBE_TOKEN in the environment, NEVER on the command line.
 */
import { pathToFileURL } from 'node:url';

export const DEFAULT_BASE_URL = 'https://rsu-cajidiocan.tech';
const CONTRACT = 'SAVAGE_ANDROID_V1';

function baseUrl(input, allowLocalHttp = false) {
  let parsed;
  try { parsed = new URL(input); } catch { throw new Error('INVALID_BASE_URL'); }
  const loopback = ['localhost', '127.0.0.1', '[::1]'].includes(parsed.hostname.toLowerCase());
  if (!((parsed.protocol === 'https:') || (allowLocalHttp && parsed.protocol === 'http:' && loopback)) ||
    parsed.username || parsed.password || parsed.search || parsed.hash || (parsed.pathname !== '/' && parsed.pathname !== '')) {
    throw new Error('INVALID_BASE_URL');
  }
  return parsed.origin;
}

async function getJson(url, headers, request = fetch) {
  let res;
  try {
    res = await request(url, {
      method: 'GET', headers: { Accept: 'application/json', ...headers },
      redirect: 'manual', signal: AbortSignal.timeout(10_000),
    });
  } catch { return { ok: false, reason: 'NETWORK_OR_TLS_UNREACHABLE' }; }
  if (res.status >= 300 && res.status < 400) return { ok: false, reason: 'HTTP_REDIRECT', httpStatus: res.status };
  if (!res.ok) return { ok: false, reason: 'HTTP_ERROR', httpStatus: res.status };
  if (!res.headers.get('content-type')?.toLowerCase().startsWith('application/json')) {
    return { ok: false, reason: 'NOT_JSON_API', httpStatus: res.status };
  }
  try {
    return { ok: true, data: await res.json(), httpStatus: res.status };
  } catch { return { ok: false, reason: 'INVALID_JSON_RESPONSE', httpStatus: res.status }; }
}

/** Diagnostics are based exclusively on responses, never assumed from domain or credentials. */
export async function probeLiveApi({
  url = DEFAULT_BASE_URL,
  deviceName = '',
  token = '',
  allowLocalHttp = false,
  request = fetch,
} = {}) {
  let origin;
  try { origin = baseUrl(url, allowLocalHttp); }
  catch { return { verdict: 'FAIL', baseUrl: null, health: 'INVALID_BASE_URL', device: 'NOT_CHECKED' }; }

  const health = await getJson(`${origin}/api/health`, {}, request);
  if (!health.ok) return { verdict: 'FAIL', baseUrl: origin, health: health.reason, httpStatus: health.httpStatus || null, device: 'NOT_CHECKED' };
  if (health.data?.status !== 'ok' || health.data?.database !== 'connected') {
    return { verdict: 'FAIL', baseUrl: origin, health: 'WRONG_API_HEALTH_CONTRACT', device: 'NOT_CHECKED' };
  }
  if (!token || !deviceName) return { verdict: 'PARTIAL', baseUrl: origin, health: 'PASS', device: 'NOT_PROVISIONED_OR_NOT_REQUESTED' };
  if (token.length < 10 || token.length > 512 || /\s/.test(token) || deviceName.length > 100) {
    return { verdict: 'FAIL', baseUrl: origin, health: 'PASS', device: 'INVALID_LOCAL_DEVICE_CONFIG' };
  }
  const info = await getJson(`${origin}/api/v1/kiosk/device-info`, {
    Authorization: `Bearer ${token}`, 'X-Kiosk-Device-Id': deviceName,
  }, request);
  if (!info.ok) return { verdict: 'FAIL', baseUrl: origin, health: 'PASS', device: info.reason, httpStatus: info.httpStatus || null };
  if (info.data?.bridge_contract !== CONTRACT) {
    return { verdict: 'FAIL', baseUrl: origin, health: 'PASS', device: 'BRIDGE_CONTRACT_NOT_DEPLOYED' };
  }
  if (info.data?.device_name !== deviceName || !Number.isSafeInteger(info.data?.device_id) || info.data.device_id <= 0) {
    return { verdict: 'FAIL', baseUrl: origin, health: 'PASS', device: 'DEVICE_ID_MISMATCH' };
  }
  return { verdict: 'PASS', baseUrl: origin, health: 'PASS', device: 'PASS' };
}

async function main() {
  const args = process.argv.slice(2);
  if (args.some((arg) => arg.startsWith('--token'))) {
    process.stderr.write('Never put a kiosk token on the command line. Use SAVAGE_KIOSK_PROBE_TOKEN environment variable.\n');
    process.exitCode = 2; return;
  }
  const urlIdx = args.indexOf('--base-url');
  const deviceIdx = args.indexOf('--device-id');
  const allowHttp = args.includes('--allow-local-http');
  const url = urlIdx >= 0 ? args[urlIdx + 1] : DEFAULT_BASE_URL;
  const deviceName = deviceIdx >= 0 ? args[deviceIdx + 1] : process.env.SAVAGE_KIOSK_PROBE_DEVICE_ID || '';
  const result = await probeLiveApi({ url, deviceName,
    token: process.env.SAVAGE_KIOSK_PROBE_TOKEN || '', allowLocalHttp: allowHttp });
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  process.exitCode = result.verdict === 'FAIL' ? 1 : result.verdict === 'PASS' ? 0 : 3;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  await main();
}
