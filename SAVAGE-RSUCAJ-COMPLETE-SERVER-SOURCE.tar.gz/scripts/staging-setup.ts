import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { initDatabase, closeDatabaseSafely } from '../server/db.ts';
import { hashPassword } from '../server/auth.ts';
import { formatMaskedKioskToken, hashKioskToken } from '../server/adminOpsEngine.ts';
import {
  createPayrollPolicy,
  approvePayrollPolicyByFinance,
  getPayrollPolicyTemplate,
} from '../server/payrollEngine.ts';
import { logAudit } from '../server/auditHelpers.ts';

function parseArg(flag: string): string | undefined {
  const idx = process.argv.indexOf(flag);
  if (idx !== -1 && idx + 1 < process.argv.length) {
    return process.argv[idx + 1];
  }
  return undefined;
}

const requestedDb =
  parseArg('--db') ||
  process.env.STAGING_DATABASE_PATH?.trim() ||
  path.resolve(process.cwd(), 'data', 'staging', 'savage_rsucaj_staging.db');

const resolvedTarget = path.resolve(requestedDb);
const liveProdPath = path.resolve(process.cwd(), 'data', 'savage_rsucaj.db');

if (resolvedTarget === liveProdPath) {
  console.error(
    `REFUSED: Staging bootstrap will NEVER write to the live database path (${liveProdPath}). Pass an isolated --db path.`
  );
  process.exit(1);
}

const resetFlag = process.argv.includes('--reset');
if (resetFlag && fs.existsSync(resolvedTarget)) {
  for (const suffix of ['', '-wal', '-shm']) {
    const p = `${resolvedTarget}${suffix}`;
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
}

const stagingAdminPw =
  process.env.STAGING_ADMIN_PASSWORD?.trim() || 'StgAdmin!2026#RSU';
const stagingRolePw =
  process.env.STAGING_ROLE_PASSWORD?.trim() || 'StgUser!2026#RSU';

const db = initDatabase(resolvedTarget, {
  mode: 'staging',
  seedDemoData: false,
  initialAdmin: {
    username: 'stg_admin',
    email: 'stg_admin@staging.rsucaj.local',
    password: stagingAdminPw,
  },
});

try {
  // Mark initial admin as ready for staging automation (must_change_password=0 on staging fixture)
  db.prepare(`UPDATE users SET full_name = ?, must_change_password = 0 WHERE username = 'stg_admin'`).run(
    '[STAGING-TEST-ONLY] Primary Administrator'
  );

  // Create sanitized [STAGING-TEST-ONLY] org structure (ZERO production data copied)
  const ensureDept = (code: string, name: string, headName: string): number => {
    const existing = db.prepare('SELECT id FROM departments WHERE code = ?').get(code) as { id: number } | undefined;
    if (existing) return existing.id;
    const res = db
      .prepare('INSERT INTO departments (code, name, head_name) VALUES (?, ?, ?)')
      .run(code, name, headName);
    return Number(res.lastInsertRowid);
  };

  const deptIt = ensureDept('STG-CICT', '[STAGING-TEST-ONLY] Info Tech & Systems', 'Staging Dean IT');
  const deptHr = ensureDept('STG-HR', '[STAGING-TEST-ONLY] Human Resources', 'Staging HR Head');

  const ensurePos = (code: string, name: string, baseSalary: number): number => {
    const existing = db
      .prepare('SELECT id FROM positions WHERE code = ?')
      .get(code) as { id: number } | undefined;
    if (existing) return existing.id;
    const res = db
      .prepare(`INSERT INTO positions (code, name, type, base_salary, allowance) VALUES (?, ?, 'Regular', ?, 0)`)
      .run(code, name, baseSalary);
    return Number(res.lastInsertRowid);
  };

  const posInst = ensurePos('STG-INST1', '[STAGING-TEST-ONLY] Instructor I', 28000);
  const posStaff = ensurePos('STG-AIDE1', '[STAGING-TEST-ONLY] Admin Aide', 18000);

  const ensureShift = (name: string, timeIn: string, timeOut: string, grace: number, restDays: string): number => {
    const existing = db.prepare('SELECT id FROM shifts WHERE name = ?').get(name) as { id: number } | undefined;
    if (existing) return existing.id;
    const res = db
      .prepare('INSERT INTO shifts (name, time_in, time_out, grace_minutes, rest_days, status) VALUES (?, ?, ?, ?, ?, ?)')
      .run(name, timeIn, timeOut, grace, restDays, 'Active');
    return Number(res.lastInsertRowid);
  };

  const dayShift = ensureShift('[STAGING-TEST-ONLY] Regular Day Shift', '08:00 AM', '05:00 PM', 15, 'Sat,Sun');
  ensureShift('[STAGING-TEST-ONLY] Overnight Security Shift', '10:00 PM', '07:00 AM', 15, 'Sun');

  const ensureEmployee = (
    code: string,
    fullName: string,
    email: string,
    departmentId: number,
    positionId: number,
    shiftId: number,
    monthlySalary: number
  ): number => {
    const existing = db.prepare('SELECT id FROM employees WHERE employee_code = ?').get(code) as { id: number } | undefined;
    if (existing) return existing.id;
    const res = db
      .prepare(
        `INSERT INTO employees
         (employee_code, full_name, email, department_id, position_id, shift_id,
          status, hired_date, monthly_salary, monthly_allowance)
         VALUES (?, ?, ?, ?, ?, ?, 'Active', '2026-01-01', ?, 0)`
      )
      .run(code, fullName, email, departmentId, positionId, shiftId, monthlySalary);
    return Number(res.lastInsertRowid);
  };

  const emp1 = ensureEmployee(
    'STG-EMP-001',
    '[STAGING-TEST-ONLY] Juan Dela Cruz',
    'stg_emp001@staging.rsucaj.local',
    deptIt,
    posInst,
    dayShift,
    28000
  );
  ensureEmployee(
    'STG-EMP-002',
    '[STAGING-TEST-ONLY] Maria Santos',
    'stg_emp002@staging.rsucaj.local',
    deptHr,
    posStaff,
    dayShift,
    18000
  );

  // Least-privilege test accounts across all roles
  const ensureUser = (
    username: string,
    email: string,
    fullName: string,
    role: string,
    departmentId: number | null,
    employeeId: number | null
  ) => {
    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username) as { id: number } | undefined;
    if (existing) return existing.id;
    const { hash, salt } = hashPassword(stagingRolePw);
    const res = db
      .prepare(
        `INSERT INTO users
         (username, email, full_name, role, department_id, employee_id, password_hash, salt, must_change_password, is_active)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 1)`
      )
      .run(username, email, fullName, role, departmentId, employeeId, hash, salt);
    return Number(res.lastInsertRowid);
  };

  const checkerId = ensureUser(
    'stg_checker',
    'stg_checker@staging.rsucaj.local',
    '[STAGING-TEST-ONLY] Secondary Admin / Finance Approver',
    'Administrator',
    null,
    null
  );
  ensureUser('stg_hr', 'stg_hr@staging.rsucaj.local', '[STAGING-TEST-ONLY] HR Officer', 'HR Officer', deptHr, null);
  ensureUser('stg_payroll', 'stg_payroll@staging.rsucaj.local', '[STAGING-TEST-ONLY] Payroll Officer', 'Payroll Officer', null, null);
  ensureUser('stg_depthead', 'stg_depthead@staging.rsucaj.local', '[STAGING-TEST-ONLY] Dept Head IT', 'Department Head', deptIt, null);
  ensureUser('stg_employee', 'stg_emp001@staging.rsucaj.local', '[STAGING-TEST-ONLY] Juan Dela Cruz', 'Employee', deptIt, emp1);

  // Least-privilege kiosk device credentials (start Offline until real heartbeat)
  const provisionedTokens: Array<{ name: string; type: string; tokenMasked: string; oneTimeToken: string }> = [];
  const ensureDevice = (name: string, type: 'Raspberry Pi' | 'Android', model: string, location: string) => {
    const existing = db.prepare('SELECT id, token_masked FROM devices WHERE name = ?').get(name) as
      | { id: number; token_masked: string }
      | undefined;
    if (existing) {
      provisionedTokens.push({ name, type, tokenMasked: existing.token_masked, oneTimeToken: '[EXISTING — ROTATE TO REVEAL]' });
      return;
    }
    const rawToken = `savage-stg-${crypto.randomBytes(20).toString('hex')}`;
    const tokenHash = hashKioskToken(rawToken);
    const tokenMasked = formatMaskedKioskToken(rawToken);
    db.prepare(
      `INSERT INTO devices
       (name, device_type, model_info, ip_address, location, api_token, token_hash, token_masked, status, last_heartbeat, last_heartbeat_utc)
       VALUES (?, ?, ?, '10.0.0.10', ?, ?, ?, ?, 'Offline', 'Never', NULL)`
    ).run(name, type, model, location, rawToken, tokenHash, tokenMasked);
    provisionedTokens.push({ name, type, tokenMasked, oneTimeToken: rawToken });
  };

  ensureDevice('STG-RPI-01', 'Raspberry Pi', 'Raspberry Pi 3B+ (Staging Slot)', 'Staging Gate A');
  ensureDevice('STG-AND-KIOSK-01', 'Android', 'Android Kiosk Tablet (Staging Slot)', 'Staging Gate B');

  // Explicitly labeled TEST-ONLY FAKE CURRENCY staging payroll policy
  const existingPolicy = db
    .prepare(`SELECT id FROM payroll_policies WHERE policy_code = 'STG-TEST-FAKE-PHP-2026'`)
    .get() as { id: number } | undefined;

  if (!existingPolicy) {
    const adminRow = db.prepare(`SELECT id, username FROM users WHERE username = 'stg_admin'`).get() as {
      id: number;
      username: string;
    };
    const templateFields = getPayrollPolicyTemplate().fields;
    const nowMs = Date.now();
    const created = createPayrollPolicy(
      db,
      {
        policy_code: 'STG-TEST-FAKE-PHP-2026',
        policy_name: '[STAGING TEST-ONLY — FAKE CURRENCY, NOT APPROVED FOR PRODUCTION PAYROLL]',
        effective_from: '2026-01-01',
        effective_to: null,
        notes: 'STAGING-SYNTHETIC-TEST-ONLY-NO-INSTITUTIONAL-VALIDITY',
        rules: templateFields.rules,
      },
      { userId: adminRow.id, username: adminRow.username, role: 'Administrator', ipAddress: '127.0.0.1' },
      nowMs
    );

    approvePayrollPolicyByFinance(
      db,
      created.id,
      {
        approval_reference: 'STG-SYNTHETIC-TEST-APPROVAL-001',
        notes: 'STAGING TEST-ONLY FAKE CURRENCY — NOT APPROVED FOR PRODUCTION PAYROLL',
      },
      { userId: checkerId, username: 'stg_checker', role: 'Administrator', ipAddress: '127.0.0.1' },
      nowMs
    );
  }

  logAudit(
    db,
    'staging-setup',
    'Bootstrapped isolated sanitized STAGING database (zero production data copied)',
    'Settings',
    'Success',
    '127.0.0.1',
    { actionType: 'STAGING_BOOTSTRAP', targetType: 'database', isSecurityEvent: true }
  );

  console.log('SAVAGE-RSUCAJ Isolated Staging Environment Provisioned (BUILD 16)');
  console.log(`  Staging DB Path:     ${resolvedTarget}`);
  console.log('  Production Data:     NONE COPIED (100% synthetic [STAGING-TEST-ONLY] fixtures)');
  console.log('  Payroll Policy:      STG-TEST-FAKE-PHP-2026 (TEST-ONLY FAKE CURRENCY)');
  console.log('  Test Accounts:       stg_admin, stg_checker, stg_hr, stg_payroll, stg_depthead, stg_employee');
  console.log('  Kiosk Device Slots:');
  for (const d of provisionedTokens) {
    console.log(`    - ${d.name} (${d.type}) | masked=${d.tokenMasked} | status=Offline (awaiting real heartbeat)`);
  }
} finally {
  closeDatabaseSafely(db);
}
