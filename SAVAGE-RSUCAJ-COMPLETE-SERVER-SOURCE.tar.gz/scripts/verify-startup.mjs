import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';

function getFreePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.unref();
    srv.on('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const addr = srv.address();
      if (!addr || typeof addr === 'string') {
        srv.close(() => reject(new Error('Could not determine ephemeral port.')));
        return;
      }
      const { port } = addr;
      srv.close((err) => (err ? reject(err) : resolve(port)));
    });
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForHealth(url, attempts = 30, delayMs = 300) {
  let lastErr = '';
  for (let i = 1; i <= attempts; i++) {
    try {
      const res = await fetch(url);
      const data = await res.json();
      if (res.status === 200 && data?.status === 'ok' && data?.database === 'connected') {
        return { status: res.status, data };
      }
      lastErr = `HTTP ${res.status}: ${JSON.stringify(data)}`;
    } catch (err) {
      lastErr = err instanceof Error ? err.message : String(err);
    }
    await sleep(delayMs);
  }
  throw new Error(`Health check failed at ${url}: ${lastErr}`);
}

async function main() {
  const rootDir = process.cwd();
  const distIndex = path.join(rootDir, 'dist', 'index.html');
  if (!fs.existsSync(distIndex)) {
    console.error('STARTUP SMOKE FAIL: dist/index.html not found. Run `npm run build` first.');
    process.exit(1);
  }

  const port = Number(process.env.VERIFY_PORT) || (await getFreePort());
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-rsucaj-smoke-'));
  const tmpDbPath = path.join(tmpDir, 'smoke.db');
  const tmpBackupDir = path.join(tmpDir, 'backups');
  const startScript = path.join(rootDir, 'scripts', 'start.mjs');

  // Generate ephemeral cryptographically random test secrets strictly for this isolated smoke run
  const ephemeralSecret = crypto.randomBytes(48).toString('hex');
  const ephemeralAdminPass = `Smk!${crypto.randomBytes(8).toString('hex')}9A`;
  const rotatedAdminPass = `Rot!${crypto.randomBytes(8).toString('hex')}7Z`;

  const child = spawn(process.execPath, [startScript], {
    cwd: rootDir,
    env: {
      ...process.env,
      NODE_ENV: 'production',
      APP_MODE: 'production',
      PORT: String(port),
      DATABASE_PATH: tmpDbPath,
      BACKUP_DIR: tmpBackupDir,
      SESSION_SECRET: ephemeralSecret,
      ADMIN_INITIAL_USERNAME: 'smoke_admin',
      ADMIN_INITIAL_EMAIL: 'smoke_admin@rsucaj.edu.ph',
      ADMIN_INITIAL_PASSWORD: ephemeralAdminPass,
      DISABLE_HMR: 'true',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  let stdout = '';
  let stderr = '';
  child.stdout.on('data', (chunk) => {
    stdout += chunk.toString();
  });
  child.stderr.on('data', (chunk) => {
    stderr += chunk.toString();
  });

  const stopChild = () =>
    new Promise((resolve) => {
      if (child.exitCode !== null) {
        resolve();
        return;
      }
      const timeout = setTimeout(() => {
        try {
          child.kill('SIGKILL');
        } catch {
          // ignore
        }
        resolve();
      }, 4000);
      child.once('exit', () => {
        clearTimeout(timeout);
        resolve();
      });
      child.kill('SIGTERM');
    });

  try {
    const baseUrl = `http://127.0.0.1:${port}`;
    const health = await waitForHealth(`${baseUrl}/api/health`);
    if (
      health.data.version !== '1.13.0' ||
      health.data.build !== 'BUILD 17' ||
      health.data.schemaVersion !== '009' ||
      health.data.mode !== 'production' ||
      health.data.timezone !== 'Asia/Manila'
    ) {
      throw new Error(`Unexpected health metadata: ${JSON.stringify(health.data)}`);
    }
    console.log(`PASS  Production startup GET /api/health (HTTP ${health.status}): ${JSON.stringify(health.data)}`);

    const rootRes = await fetch(`${baseUrl}/`);
    const rootHtml = await rootRes.text();
    if (rootRes.status !== 200 || !rootHtml.includes('SAVAGE-RSUCAJ')) {
      throw new Error(`Expected built SPA HTML at /, got HTTP ${rootRes.status}`);
    }
    console.log(`PASS  Production static SPA GET / (HTTP ${rootRes.status})`);

    const emblemPath = '/assets/aistudio/SAVAGE-RSUCAJ_Smart_Attendance_Emblem_39488c28.png';
    const emblemRes = await fetch(`${baseUrl}${emblemPath}`);
    if (emblemRes.status !== 200) {
      throw new Error(`Expected RSU emblem PNG at ${emblemPath}, got HTTP ${emblemRes.status}`);
    }
    console.log(`PASS  Official RSU emblem asset GET ${emblemPath} (HTTP ${emblemRes.status})`);

    // Verify end-to-end login + forced initial password change + authentic empty production dashboard + logout
    const loginRes = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier: 'smoke_admin', password: ephemeralAdminPass }),
    });
    const loginBody = await loginRes.json();
    const setCookies = loginRes.headers.getSetCookie ? loginRes.headers.getSetCookie() : [];
    const sessionCookie = setCookies.find((c) => c.startsWith('savage_rsucaj_session='))?.split(';')[0];
    if (loginRes.status !== 200 || !sessionCookie || !loginBody.csrfToken || !loginBody.user?.must_change_password) {
      throw new Error(`Expected 200 login with HttpOnly cookie & must_change_password=true, got ${loginRes.status}`);
    }
    if ('token' in loginBody) {
      throw new Error('Security violation: /api/auth/login must not expose raw session token in JSON body');
    }

    // Rotate initial password to unlock dashboard and verify zero demo auto-seeding in production
    const rotRes = await fetch(`${baseUrl}/api/auth/change-password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: sessionCookie,
        'X-CSRF-Token': loginBody.csrfToken,
      },
      body: JSON.stringify({ currentPassword: ephemeralAdminPass, newPassword: rotatedAdminPass }),
    });
    const rotBody = await rotRes.json();
    const rotCookies = rotRes.headers.getSetCookie ? rotRes.headers.getSetCookie() : [];
    const rotatedCookie = rotCookies.find((c) => c.startsWith('savage_rsucaj_session='))?.split(';')[0] || sessionCookie;
    if (rotRes.status !== 200 || !rotBody.csrfToken) {
      throw new Error(`Expected 200 password rotation, got ${rotRes.status}`);
    }

    const dashRes = await fetch(`${baseUrl}/api/dashboard`, {
      headers: { Cookie: rotatedCookie },
    });
    const dashBody = await dashRes.json();
    if (
      dashRes.status !== 200 ||
      dashBody.kpis.totalEmployees !== 0 ||
      dashBody.kpis.totalDevices !== 0 ||
      dashBody.unreadNotifications !== 0
    ) {
      throw new Error(`Production fresh install must have authentic empty state, got ${JSON.stringify(dashBody.kpis)}`);
    }
    console.log('PASS  Production fresh install authentic empty state (0 employees, 0 devices, 0 demo notifications)');

    const logoutRes = await fetch(`${baseUrl}/api/auth/logout`, {
      method: 'POST',
      headers: { Cookie: rotatedCookie, 'X-CSRF-Token': rotBody.csrfToken },
    });
    if (logoutRes.status !== 200) {
      throw new Error(`Expected 200 logout, got ${logoutRes.status}`);
    }
    const postLogoutMe = await fetch(`${baseUrl}/api/auth/me`, {
      headers: { Cookie: rotatedCookie },
    });
    if (postLogoutMe.status !== 401) {
      throw new Error(`Expected 401 after logout session revocation, got ${postLogoutMe.status}`);
    }
    console.log('PASS  Production E2E login -> password rotation -> logout -> server revocation (401)');

    console.log('Summary: 5/5 startup smoke checks passed (isolated temp DB; live data/ untouched).');
  } catch (err) {
    console.error('STARTUP SMOKE FAIL:', err instanceof Error ? err.message : String(err));
    if (stdout.trim()) console.error('--- Server stdout ---\n' + stdout.trim());
    if (stderr.trim()) console.error('--- Server stderr ---\n' + stderr.trim());
    process.exitCode = 1;
  } finally {
    await stopChild();
    try {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    } catch {
      // ignore temp cleanup errors on locked Windows handles
    }
  }
}

main();
