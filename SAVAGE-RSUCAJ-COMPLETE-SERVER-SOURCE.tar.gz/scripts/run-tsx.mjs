import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const args = process.argv.slice(2);

if (args.length === 0) {
  console.error('Usage: node scripts/run-tsx.mjs <script.ts> [...args]');
  process.exit(1);
}

const tsxCli = require.resolve('tsx/cli');
const child = spawn(process.execPath, [tsxCli, ...args], {
  stdio: 'inherit',
  env: process.env,
});

child.on('error', (err) => {
  console.error('Failed to launch tsx runner:', err);
  process.exit(1);
});

child.on('exit', (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal);
    return;
  }
  process.exit(code ?? 1);
});
