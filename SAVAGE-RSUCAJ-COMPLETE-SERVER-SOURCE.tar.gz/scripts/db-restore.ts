import 'dotenv/config';
import path from 'node:path';
import { restoreSqliteBackup } from '../server/backup.ts';

function getArg(flag: string): string | undefined {
  const idx = process.argv.indexOf(flag);
  if (idx !== -1 && idx + 1 < process.argv.length) {
    return process.argv[idx + 1];
  }
  return undefined;
}

function main(): void {
  const archivePath = getArg('--archive');
  if (!archivePath) {
    console.error(
      'Usage: npm run db:restore -- --archive <path/to/backup.sqlite[.enc]> [--target <db-path>] [--manifest <manifest.json>] [--apply]'
    );
    console.error('Note: Runs in safe --dry-run verification mode unless --apply is explicitly passed.');
    process.exit(1);
  }

  const targetDbPath =
    getArg('--target') || process.env.DATABASE_PATH?.trim() || path.resolve(process.cwd(), 'data', 'savage_rsucaj.db');
  const manifestPath = getArg('--manifest');
  const apply = process.argv.includes('--apply');
  const encryptionKey = process.env.BACKUP_ENCRYPTION_KEY?.trim() || undefined;

  const result = restoreSqliteBackup(archivePath, targetDbPath, {
    encryptionKey,
    manifestPath,
    dryRun: !apply,
  });

  console.log(`SAVAGE-RSUCAJ SQLite Restore ${result.dryRun ? '(DRY RUN DRILL)' : '(LIVE APPLY)'}`);
  console.log(`  Target Database:      ${result.targetDbPath}`);
  console.log(`  Archive Encrypted:    ${result.verification.encrypted}`);
  console.log(`  SQLite SHA-256:       ${result.verification.sqliteSha256 ?? 'n/a'}`);
  console.log(`  Manifest Matched:     ${result.verification.manifestMatched ?? 'no manifest'}`);
  console.log(`  Integrity Check:      ${result.verification.integrityCheck ?? 'n/a'}`);
  console.log(`  FK Violations:        ${result.verification.foreignKeyViolations}`);
  console.log(`  Schema Version:       ${result.verification.schemaVersion ?? 'n/a'}`);
  if (result.preRestoreBackupPath) {
    console.log(`  Pre-Restore Snapshot: ${result.preRestoreBackupPath}`);
  }
  console.log(`  Rolled Back:          ${result.rolledBack}`);
  console.log(`  Result:               ${result.ok ? 'PASS' : 'FAIL'}`);

  if (result.errors.length > 0) {
    console.error('Errors:');
    for (const err of result.errors) {
      console.error(`  - ${err}`);
    }
    process.exit(1);
  }
}

try {
  main();
} catch (err) {
  console.error('Restore failed:', err instanceof Error ? err.message : err);
  process.exit(1);
}
