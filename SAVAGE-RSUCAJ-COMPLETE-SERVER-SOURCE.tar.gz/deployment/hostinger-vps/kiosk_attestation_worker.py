#!/usr/bin/env python3
"""BUILD 42: server-owned frame detection + LiteRT inference for staged Web Kiosk verification.

Never trust client scores, bounding boxes, face identities, or embeddings. This process
accepts only JPEG frames; it decodes/detects/crops/aligns/evaluates locally using
OpenCV YuNet + three SHA256-pinned LiteRT models. Response is consumed only by Node.

Production still requires an explicit calibration approval and real-device evaluation.
Browser camera provenance cannot be proven from submitted JPEG frames alone.
"""
import argparse
import base64
import binascii
import hashlib
import json
import math
from pathlib import Path
import sys

from biometric_inference_worker import (
    SPECS, DiagnosticError, load_interpreters, preprocess_rgba,
    invoke_all, live_probabilities, normalized_embedding,
)

MIN_FRAMES = 3
MAX_FRAMES = 5
MAX_INPUT_BYTES = 1_950_000
MAX_FRAME_BYTES = 580_000
MAX_IMAGE_PIXELS = 1_300_000


def load_detector(model_file, cv2):
    p = Path(model_file)
    if not p.is_file() or p.stat().st_size < 100_000 or p.suffix != '.onnx':
        raise DiagnosticError('YU_NET_MISSING: OpenCV YuNet face detector not deployed')
    try:
        return cv2.FaceDetectorYN.create(str(p), '', (640, 480), 0.8, 0.3, 5000)
    except Exception as exc:
        raise DiagnosticError('YU_NET_UNAVAILABLE: cannot initialize OpenCV face detector') from exc


def parse_frames(message, np, cv2):
    if not isinstance(message, dict) or set(message) != {'frames'}:
        raise DiagnosticError('INVALID_FRAMES: expected only frames')
    values = message.get('frames')
    if not isinstance(values, list) or not MIN_FRAMES <= len(values) <= MAX_FRAMES:
        raise DiagnosticError('INVALID_FRAMES: 3 to 5 frames required')
    seen = set()
    decoded = []
    last_ts = -math.inf
    first_ts = None
    for frame in values:
        if not isinstance(frame, dict) or set(frame) != {'jpeg_b64', 'captured_at_ms'}:
            raise DiagnosticError('INVALID_FRAME: expected jpeg_b64 and captured_at_ms')
        txt = frame['jpeg_b64']
        ts = frame['captured_at_ms']
        if not isinstance(txt, str) or len(txt) > MAX_FRAME_BYTES * 2 or not isinstance(ts, (int, float)) or isinstance(ts, bool) or not math.isfinite(ts):
            raise DiagnosticError('INVALID_FRAME: corrupt timestamp or image size')
        if ts <= last_ts or (last_ts != -math.inf and ts - last_ts < 80):
            raise DiagnosticError('FROZEN_FRAME: timestamps are duplicated or too close')
        if first_ts is None:
            first_ts = ts
        if ts - first_ts > 4000:
            raise DiagnosticError('STALE_FRAME: capture sequence exceeds 4 seconds')
        last_ts = ts
        try:
            blob = base64.b64decode(txt, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise DiagnosticError('INVALID_FRAME: JPEG base64 decoding failed') from exc
        if len(blob) > MAX_FRAME_BYTES or len(blob) < 100 or blob[:3] != b'\xff\xd8\xff' or blob[-2:] != b'\xff\xd9':
            raise DiagnosticError('INVALID_FRAME: not a bounded JPEG image')
        h = hashlib.sha256(blob).digest()
        if h in seen:
            raise DiagnosticError('FROZEN_FRAME: repeated identical image')
        seen.add(h)
        data = cv2.imdecode(np.frombuffer(blob, dtype=np.uint8), cv2.IMREAD_COLOR)
        if data is None or data.ndim != 3 or data.shape[2] != 3:
            raise DiagnosticError('INVALID_FRAME: invalid decoded camera image')
        height, width = data.shape[:2]
        if width < 240 or height < 180 or width * height > MAX_IMAGE_PIXELS:
            raise DiagnosticError('INVALID_FRAME: camera image dimensions outside accepted range')
        decoded.append((data, ts))
    return decoded


def expanded_crop(img, x, y, w, h, factor, cv2):
    height, width = img.shape[:2]
    center_x = x + w / 2.0
    center_y = y + h / 2.0
    side = max(w, h) * factor
    left = int(max(0, center_x - side / 2))
    top = int(max(0, center_y - side / 2))
    right = int(min(width, center_x + side / 2))
    bottom = int(min(height, center_y + side / 2))
    if right - left < 32 or bottom - top < 32:
        raise DiagnosticError('LOW_QUALITY: face is too close to frame edge')
    return cv2.resize(img[top:bottom, left:right], (80, 80), interpolation=cv2.INTER_AREA)


def aligned_face(img, face, np, cv2):
    # YuNet returns right eye, left eye, nose, right mouth, left mouth.
    src = face[4:14].reshape((5, 2)).astype(np.float32)
    dst = np.array([
        [38.2946, 51.6963], [73.5318, 51.5014], [56.0252, 71.7366],
        [41.5493, 92.3655], [70.7299, 92.2041],
    ], dtype=np.float32)
    # Landmark orientation must be validated on actual kiosk samples before production approval.
    matrix, _ = cv2.estimateAffinePartial2D(src, dst, method=cv2.LMEDS)
    if matrix is None or not np.all(np.isfinite(matrix)):
        raise DiagnosticError('OCCLUSION_OR_POSE: cannot align face landmarks')
    return cv2.warpAffine(img, matrix, (112, 112), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT_101)


def analyze_camera_frame(img, ts, detector, interpreters, np, cv2):
    height, width = img.shape[:2]
    detector.setInputSize((width, height))
    _, candidates = detector.detect(img)
    faces = [] if candidates is None else [row for row in candidates if math.isfinite(float(row[14])) and float(row[14]) >= 0.80]
    if not faces:
        raise DiagnosticError('NO_FACE: point the camera at one centered face, not the floor')
    if len(faces) > 1:
        raise DiagnosticError('MULTIPLE_FACES: one face only')
    face = faces[0]
    x, y, w, h = [float(z) for z in face[:4]]
    if w <= 0 or h <= 0 or w / width < 0.17 or h / height < 0.22:
        raise DiagnosticError('LOW_QUALITY: face is too small or far from camera')
    bbox = {
        'x': max(0., x / width), 'y': max(0., y / height),
        'width': min(1., w / width), 'height': min(1., h / height),
    }
    center_x = (x + w / 2) / width
    center_y = (y + h / 2) / height
    if abs(center_x - 0.5) > 0.24 or abs(center_y - 0.5) > 0.25:
        raise DiagnosticError('LOW_QUALITY: position face inside the green frame')
    x1, y1, x2, y2 = max(0, int(x)), max(0, int(y)), min(width, int(x + w)), min(height, int(y + h))
    region = img[y1:y2, x1:x2]
    if region.size == 0:
        raise DiagnosticError('LOW_QUALITY: invalid face crop')
    gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
    brightness = float(np.mean(gray))
    sharpness = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    if not 48 <= brightness <= 220:
        raise DiagnosticError('LOW_LIGHT: face illumination too dark or bright')
    if sharpness < 35:
        raise DiagnosticError('BLURRY_IMAGE: hold still and clean camera lens')

    # PAD needs context around the face; liveness same 80x80 crop; recognition 5-point aligned face.
    crop80_bgr = expanded_crop(img, x, y, w, h, 2.7, cv2)
    crop112_bgr = aligned_face(img, face, np, cv2)
    crop80_rgba = cv2.cvtColor(crop80_bgr, cv2.COLOR_BGR2RGBA)
    crop112_rgba = cv2.cvtColor(crop112_bgr, cv2.COLOR_BGR2RGBA)
    tensors = preprocess_rgba(crop80_rgba.tobytes(), crop112_rgba.tobytes(), np)
    outputs = invoke_all(interpreters, tensors, np)
    pad = live_probabilities(outputs['anti_spoofing_pad'], 0)[0]
    liveness = live_probabilities(outputs['liveness_detection'], 1)[1]
    embedding = normalized_embedding(outputs['face_recognition'], np)
    quality = float(min(1., max(0., (sharpness - 20) / 150))) * 0.35 + float(1 - abs(brightness - 135) / 140) * 0.25 + min(1., w / (width * 0.35)) * 0.20 + min(1., h / (height * 0.38)) * 0.20
    evidence = {
        'timestamp_ms': int(ts), 'face_count': 1,
        'detection_confidence': float(face[14]),
        'quality_score': float(max(0., min(1., quality))),
        'lighting_ok': True, 'sharpness_ok': True, 'frozen_frame': False,
        'occlusion_suspected': False, 'bounding_box': bbox,
        'pad_score': pad, 'liveness_score': liveness,
    }
    return evidence, embedding


def run(args):
    import numpy as np
    import cv2
    from ai_edge_litert.interpreter import Interpreter
    engine = load_interpreters(args.models_dir, Interpreter, np)
    detector = load_detector(args.detector, cv2)
    if args.mode == 'probe':
        # Runtime probe only; validates loading & execution. Not face acceptance.
        zeros = {key: np.zeros(spec[2], dtype=np.float32) for key, spec in SPECS.items()}
        invoke_all(engine, zeros, np)
        return {'ok': True, 'mode': 'probe', 'models_executed': list(SPECS),
                'server_owned_inference': True, 'face_detector_ready': True,
                'calibration_approved': False}

    raw = sys.stdin.buffer.read(MAX_INPUT_BYTES + 1)
    if len(raw) > MAX_INPUT_BYTES:
        raise DiagnosticError('INVALID_FRAMES: request exceeds maximum frame bundle size')
    try:
        payload = json.loads(raw.decode('utf-8'))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise DiagnosticError('INVALID_FRAMES: request is not valid JSON') from exc
    decoded = parse_frames(payload, np, cv2)
    all_evidence, all_embeddings = [], []
    for frame, ts in decoded:
        evidence, embedding = analyze_camera_frame(frame, ts, detector, engine, np, cv2)
        all_evidence.append(evidence)
        all_embeddings.append(np.asarray(embedding, dtype=np.float32))
    # Cross-frame identity consistency; threshold requires real-device calibration.
    for i in range(1, len(all_embeddings)):
        cosine = float(np.dot(all_embeddings[i-1], all_embeddings[i]))
        if not math.isfinite(cosine) or cosine < 0.70:
            raise DiagnosticError('FACE_MISMATCH: different faces or unstable recognition across frames')
    mean = np.mean(all_embeddings, axis=0)
    norm = float(np.linalg.norm(mean))
    if norm < 1e-8 or not math.isfinite(norm):
        raise DiagnosticError('MODEL_ERROR: invalid face embedding')
    mean = (mean / norm).astype(np.float32)
    return {'ok': True, 'mode': 'infer', 'server_owned_inference': True,
            'face_detector_ready': True, 'models_executed': list(SPECS),
            'frames': all_evidence, 'embedding': mean.tolist(),
            'calibration_approved': False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['probe', 'infer'], required=True)
    parser.add_argument('--models-dir', required=True)
    parser.add_argument('--detector', required=True)
    args = parser.parse_args()
    try:
        result = run(args)
        print(json.dumps(result, allow_nan=False, separators=(',', ':')))
        return 0
    except Exception as exc:
        # Fail closed. No raw images or embeddings in error messages.
        detail = str(exc)[:180]
        if ':' in detail:
            code, msg = detail.split(':', 1)
        else:
            code, msg = 'INFERENCE_UNAVAILABLE', detail
        print(json.dumps({'ok': False, 'code': code.strip(), 'error': msg.strip()}))
        return 1


if __name__ == '__main__':
    sys.exit(main())
