#!/usr/bin/env bash
# BUILD 39 deployment health-check fix: wait for actual application readiness.
# Existing application and database remain intact; rollback covers UI source and dist.
set -Eeuo pipefail
APP="/opt/savage-rsucaj/app"
PATCH="/root/SAVAGE-RSUCAJ-BUILD39-ADMIN-LOGIN-PATCH-HEALTHFIX.zip"
SERVICE="savage-rsucaj.service"
HEALTH="http://127.0.0.1:3100/api/health"
BACKUP="/root/SAVAGE-RSUCAJ-BUILD39-BEFORE-$(date +%Y%m%d-%H%M%S).tar.gz"

show_diagnostics() {
  echo "--- systemd service ---" >&2
  systemctl status "$SERVICE" --no-pager -l >&2 || true
  echo "--- recent application logs ---" >&2
  journalctl -u "$SERVICE" -n 60 --no-pager >&2 || true
  echo "--- listener port 3100 ---" >&2
  ss -ltnp 2>/dev/null | grep ':3100' >&2 || true
}

wait_for_ready() {
  local tries="${1:-45}" i
  for ((i=1; i<=tries; i++)); do
    # Require a real HTTP 2xx response with a connected database, not just active systemd.
    if curl -fsS --connect-timeout 1 --max-time 3 "$HEALTH" 2>/dev/null \
      | python3 -c 'import json,sys; r=json.load(sys.stdin); sys.exit(0 if r.get("status")=="ok" and r.get("database")=="connected" else 1)' 2>/dev/null; then
      echo "Application health ready on check ${i}/${tries}."
      return 0
    fi
    sleep 1
  done
  return 1
}

if [[ "$(id -u)" -ne 0 ]]; then echo "ERROR: run as root" >&2; exit 1; fi
if [[ ! -d "$APP/src/components" || ! -f "$APP/package.json" || ! -d "$APP/dist" ]]; then
  echo "ERROR: existing application folders not found. No changes made." >&2
  exit 1
fi
if [[ ! -f "$PATCH" ]]; then echo "ERROR: missing patch: $PATCH" >&2; exit 1; fi
unzip -tq "$PATCH" || { echo "ERROR: ZIP integrity failed" >&2; exit 1; }

# Do not change a deployment already unhealthy: first establish baseline.
if ! systemctl is-active --quiet "$SERVICE" || ! wait_for_ready 6; then
  echo "ERROR: current application is not healthy. BUILD 39 NOT installed." >&2
  show_diagnostics
  exit 2
fi

cd "$APP"
tar -czf "$BACKUP" \
  src/components/LoginView.tsx src/components/SavageLogo.tsx \
  public/assets/aistudio/Savage-Rsucaj_Attendance_Shield_bca5b40c.png dist
printf 'Backup saved: %s\n' "$BACKUP"

restore_on_error() {
  local code=$?
  trap - ERR
  set +e
  echo "ERROR: BUILD 39 validation failed. Restoring prior UI files and dist..." >&2
  if ! tar -xzf "$BACKUP" -C "$APP"; then
    echo "CRITICAL: backup restore failed; manual recovery needed: $BACKUP" >&2
  fi
  if systemctl restart "$SERVICE" && wait_for_ready 45; then
    echo "Rollback completed; application is healthy on the original version." >&2
  else
    echo "WARNING: rollback files restored, but application health is NOT confirmed." >&2
    show_diagnostics
  fi
  echo "Backup: $BACKUP" >&2
  exit "$code"
}
trap restore_on_error ERR

unzip -oq "$PATCH" -d "$APP"
chown savage:savage \
  "$APP/src/components/LoginView.tsx" \
  "$APP/src/components/SavageLogo.tsx" \
  "$APP/public/assets/aistudio/Savage-Rsucaj_Attendance_Shield_bca5b40c.png" \
  "$APP/tests/build39-admin-login.test.mjs"
sudo -u savage -H node --test tests/build39-admin-login.test.mjs
sudo -u savage -H npm run lint
sudo -u savage -H npm run build
systemctl restart "$SERVICE"
if ! wait_for_ready 45; then
  echo "ERROR: service failed to become HTTP-ready after restart." >&2
  show_diagnostics
  false  # triggers automatic rollback via ERR trap
fi
trap - ERR
printf 'BUILD 39 deployed and health verified. Backup: %s\n' "$BACKUP"
printf 'Admin Login: https://attendance.rsu-cajidiocan.tech/\n'
printf 'Employee Portal: https://attendance.rsu-cajidiocan.tech/employee\n'
