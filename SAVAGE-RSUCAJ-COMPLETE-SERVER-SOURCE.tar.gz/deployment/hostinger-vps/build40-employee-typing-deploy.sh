#!/usr/bin/env bash
# SAVAGE-RSUCAJ BUILD 40 — narrowly-scoped Admin modal focus and Employee Login patch
# Requires existing BUILD39 website deployment; does not modify production data or secrets.
set -Eeuo pipefail
umask 077
APP="/opt/savage-rsucaj/app"
PATCH="/root/SAVAGE-RSUCAJ-BUILD40-EMPLOYEE-TYPING-PATCH.zip"
SERVICE="savage-rsucaj.service"
HEALTH="http://127.0.0.1:3100/api/health"
BACKUP="/root/SAVAGE-RSUCAJ-BUILD40-BEFORE-$(date +%Y%m%d-%H%M%S).tar.gz"

wait_for_ready() {
  local attempts="${1:-45}" i
  for ((i=1;i<=attempts;i++)); do
    if curl -fsS --connect-timeout 1 --max-time 3 "$HEALTH" 2>/dev/null |
      python3 -c 'import sys,json; o=json.load(sys.stdin); sys.exit(0 if o.get("status")=="ok" and o.get("database")=="connected" else 1)' 2>/dev/null; then
      echo "Database-connected application ready on check $i/$attempts"
      return 0
    fi
    sleep 1
  done
  return 1
}

show_logs() {
  systemctl status "$SERVICE" -l --no-pager >&2 || true
  journalctl -u "$SERVICE" -n 50 -l --no-pager >&2 || true
}

if (( EUID != 0 )); then echo 'Run as root.' >&2; exit 1; fi
for cmd in unzip tar sha256sum curl python3 node; do command -v "$cmd" >/dev/null || { echo "Missing dependency: $cmd" >&2; exit 1; }; done
[[ -f "$PATCH" && -f "$APP/package.json" && -d "$APP/dist" ]] || { echo 'Missing patch or application.' >&2; exit 1; }
unzip -tq "$PATCH" || { echo 'ZIP integrity failed' >&2; exit 1; }
if ! systemctl is-active --quiet "$SERVICE" || ! wait_for_ready 8; then
  echo 'Refusing to modify an unhealthy application.' >&2
  show_logs
  exit 2
fi
# Guard against overwriting unexpected modifications from a different build.
while read -r rel old_sha target_sha; do
  [[ -n "$rel" ]] || continue
  [[ -f "$APP/$rel" ]] || { echo "Missing expected source: $rel" >&2; exit 3; }
  current=$(sha256sum "$APP/$rel"); current=${current%% *}
  if [[ "$current" != "$old_sha" && "$current" != "$target_sha" ]]; then
    echo "SOURCE MISMATCH: $rel has changed since BUILD39. No files modified." >&2
    echo "Actual SHA-256: $current" >&2
    echo 'Do not force install. Compare source first to preserve newer changes.' >&2
    exit 3
  fi
done <<'CHECKSUMS'
  server/api.ts ff202881c4baa46a58caa822fd60e8d645256fb65614833f631777f56b59f2ef e731cee5350edecba88bb03cdc95383d00351a7d7119802dcabe6b17d9e61df8
  src/components/ModuleFrame.tsx f3554800d677f4f6c686fd7e6da73a03b6a4b58434d68ab48667eb77a0d32b56 fa06c30fba1c2a6f93f58d22c41ce9d614421a9710460c8bb8f48842a69d0ab4
  src/components/EmployeesView.tsx 787d703dca7ce2231979f2f591262dd823b1c62a885a9f5a3c55e87c72c85c71 e4efac1f255d4925393f023003581a547c71ac3db0343d5494c5cb6a53c8bdb0
CHECKSUMS

cd "$APP"
tar -czf "$BACKUP" server/api.ts src/components/ModuleFrame.tsx src/components/EmployeesView.tsx dist
printf 'Backup created: %s\n' "$BACKUP"

rollback() {
  local code=$?
  trap - ERR
  set +e
  echo 'BUILD40 FAILED — rolling back source and dist...' >&2
  tar -xzf "$BACKUP" -C "$APP" || echo "CRITICAL: unable to restore backup $BACKUP" >&2
  systemctl restart "$SERVICE"
  if wait_for_ready 45; then echo "Rollback health verified. Backup: $BACKUP" >&2
  else echo 'Rollback files restored; service NOT healthy. Check journal.' >&2; show_logs; fi
  exit "$code"
}
trap rollback ERR
unzip -oq "$PATCH" -d "$APP"
chown savage:savage \
  "$APP/server/api.ts" \
  "$APP/src/components/ModuleFrame.tsx" \
  "$APP/src/components/EmployeesView.tsx" \
  "$APP/tests/build40-employee-typing.test.mjs"
sudo -u savage -H node --test tests/build40-employee-typing.test.mjs
sudo -u savage -H npm run lint
sudo -u savage -H npm run build
systemctl restart "$SERVICE"
if ! wait_for_ready 45; then
  echo 'Service did not become ready after restart.' >&2
  show_logs
  false
fi
# Confirm production HTTPS reverse proxy can still return the portal page.
status=$(curl -sSI -o /dev/null -w '%{http_code}' --max-time 10 https://attendance.rsu-cajidiocan.tech/)
[[ "$status" == "200" ]] || { echo "HTTPS root returned $status" >&2; false; }
echo "HTTPS root: HTTP $status"
trap - ERR
echo "BUILD40 deployed and healthy. Backup: $BACKUP"
echo 'Admin Login: https://attendance.rsu-cajidiocan.tech/'
echo 'Employee Portal: https://attendance.rsu-cajidiocan.tech/employee'
