import base64
import io
import sys
import unittest
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from kiosk_attestation_worker import parse_frames, analyze_camera_frame, DiagnosticError

class NoFaceDetector:
    def setInputSize(self, size): self.size = size
    def detect(self, img): return 1, None

class TestBuild42(unittest.TestCase):
    def setUp(self):
        self.img = np.zeros((240, 320, 3), dtype=np.uint8)
        _, jpeg = cv2.imencode('.jpg', self.img)
        self.b64 = base64.b64encode(jpeg.tobytes()).decode('ascii')

    def payload(self, three=None):
        if three is None:
            three = [self.b64, self.b64, self.b64]
        return {'frames': [
            {'jpeg_b64': b, 'captured_at_ms': 1000 + i * 320}
            for i, b in enumerate(three)
        ]}

    def test_must_have_three_frames(self):
        with self.assertRaisesRegex(DiagnosticError, '3 to 5'):
            parse_frames({'frames': self.payload()['frames'][:2]}, np, cv2)

    def test_replay_duplicate_bytes_rejected(self):
        with self.assertRaisesRegex(DiagnosticError, 'repeated identical image'):
            parse_frames(self.payload(), np, cv2)

    def test_duplicate_timestamp_rejected(self):
        p = self.payload()
        p['frames'][1]['captured_at_ms'] = 1000
        with self.assertRaisesRegex(DiagnosticError, 'timestamps'):
            parse_frames(p, np, cv2)

    def test_non_jpeg_rejected(self):
        p = self.payload()
        p['frames'][0]['jpeg_b64'] = base64.b64encode(b'not a jpeg file').decode()
        with self.assertRaisesRegex(DiagnosticError, 'JPEG'):
            parse_frames(p, np, cv2)

    def test_face_not_detected_fail_closed(self):
        with self.assertRaisesRegex(DiagnosticError, 'NO_FACE'):
            analyze_camera_frame(self.img, 1000, NoFaceDetector(), {}, np, cv2)

    def test_invalid_shape_rejected(self):
        p = self.payload()
        p['frames'][0]['unexpected'] = 'x'
        with self.assertRaisesRegex(DiagnosticError, 'expected jpeg_b64'):
            parse_frames(p, np, cv2)

    def test_decode_distinct_frames(self):
        data=[]
        for k in (4, 8, 12):
            image=self.img.copy()
            cv2.putText(image, str(k), (k+20, k+30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255),2)
            _, jpg=cv2.imencode('.jpg', image)
            data.append(base64.b64encode(jpg.tobytes()).decode('ascii'))
        out=parse_frames(self.payload(data),np,cv2)
        self.assertEqual(len(out),3)
        self.assertEqual(out[0][0].shape,(240,320,3))

if __name__ == '__main__': unittest.main()
