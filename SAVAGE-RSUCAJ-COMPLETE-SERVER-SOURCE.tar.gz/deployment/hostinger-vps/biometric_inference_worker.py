#!/usr/bin/env python3
"""BUILD 37: real *diagnostic-only* LiteRT inference over strict cropped camera pixels.

Never use this program's outputs as production attendance attestation. This worker
cannot prove image provenance, face detection, image freshness or calibrated PAD.
The calling Express route must authenticate kiosk admin and NEVER persist attendance.

Usage:
  python biometric_inference_worker.py --models-dir /opt/savage-rsucaj/models --mode probe
  printf '%s' '{"rgba80_b64":"...","rgba112_b64":"..."}' | python ... --mode infer

Response: exactly one JSON object on stdout; errors go only to stderr.
"""
import argparse
import base64
import binascii
import hashlib
import json
import math
import os
from pathlib import Path
import sys

SPECS = {
    "anti_spoofing_pad": (
        "anti_spoofing_pad.tflite",
        "5d573d20b795a19d7b2a0f67cc4c1130ce8ec30d5f6aa06b2c788a344a49d4dd",
        (1, 80, 80, 3), (1, 3), 0,
    ),
    "liveness_detection": (
        "liveness_detection.tflite",
        "4ff758f470b757d9005b418c9978693f09b8f2a5e7b7ee848c160db21208e1b2",
        (1, 3, 80, 80), (1, 3), 1,
    ),
    "face_recognition": (
        "face_recognition.tflite",
        "be4bc7cfc53f7bc336d0f28b1ab92535f618c913a422b683210750f6b5354854",
        (1, 112, 112, 3), (1, 192), None,
    ),
}
MAX_JSON_BYTES = 160_000


class DiagnosticError(ValueError):
    pass


def validate_pixels_base64(value, width, height):
    """Exactly RGBA bytes from one rectangular crop; never accept arbitrary tensor scores."""
    if not isinstance(value, str) or len(value) > width * height * 8:
        raise DiagnosticError("Invalid base64 pixel buffer length")
    try:
        raw = base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise DiagnosticError("Invalid base64 pixel encoding") from exc
    if len(raw) != width * height * 4:
        raise DiagnosticError("RGBA crop dimensions do not match expected buffer length")
    return raw


def preprocess_rgba(rgba80, rgba112, np):
    """Matches server/webKioskBiometrics.ts BUILD 20 contracts exactly."""
    a = np.frombuffer(rgba80, dtype=np.uint8).reshape(80, 80, 4)
    b = np.frombuffer(rgba112, dtype=np.uint8).reshape(112, 112, 4)
    pad = (a[:, :, :3].astype(np.float32) / np.float32(128.0)) - np.float32(1.0)
    # BGR NCHW [1,3,80,80]
    liv = np.transpose(a[:, :, [2, 1, 0]].astype(np.float32) / np.float32(255.0), (2, 0, 1))
    rec = (b[:, :, :3].astype(np.float32) / np.float32(128.0)) - np.float32(1.0)
    return {
        "anti_spoofing_pad": pad.reshape(1, 80, 80, 3),
        "liveness_detection": liv.reshape(1, 3, 80, 80),
        "face_recognition": rec.reshape(1, 112, 112, 3),
    }


def live_probabilities(raw, index):
    vals = [float(x) for x in raw]
    if len(vals) != 3 or not all(map(math.isfinite, vals)) or index not in (0, 1, 2):
        raise DiagnosticError("Classifier output invalid or nonfinite")
    if all(0.0 <= x <= 1.0 for x in vals) and abs(sum(vals) - 1.0) < 0.01:
        return vals
    max_val = max(vals)
    exp = [math.exp(x - max_val) for x in vals]
    total = sum(exp)
    if not math.isfinite(total) or total <= 0:
        raise DiagnosticError("Invalid softmax output")
    return [v / total for v in exp]


def normalized_embedding(raw, np):
    v = np.asarray(raw, dtype=np.float32).reshape(-1)
    if v.shape != (192,) or not np.all(np.isfinite(v)):
        raise DiagnosticError("Recognition embedding dimension or values invalid")
    norm = float(np.linalg.norm(v.astype(np.float64)))
    if not math.isfinite(norm) or norm <= 1e-8:
        raise DiagnosticError("Recognition output has zero or invalid norm")
    return (v / np.float32(norm)).tolist()


def load_interpreters(models_dir, interpreter_class, np):
    results = {}
    for key, (filename, expected_sha, input_shape, output_shape, _) in SPECS.items():
        p = Path(models_dir) / filename
        if not p.is_file():
            raise DiagnosticError(f"{filename}: missing")
        blob = p.read_bytes()
        if len(blob) < 8 or blob[4:8] != b"TFL3":
            raise DiagnosticError(f"{filename}: invalid TFL3 header")
        if hashlib.sha256(blob).hexdigest() != expected_sha:
            raise DiagnosticError(f"{filename}: model hash mismatch")
        worker = interpreter_class(model_path=str(p))
        worker.allocate_tensors()
        inp = worker.get_input_details()
        out = worker.get_output_details()
        if len(inp) != 1 or len(out) != 1:
            raise DiagnosticError(f"{filename}: expected single input and output")
        if tuple(map(int, inp[0]["shape"])) != input_shape or tuple(map(int, out[0]["shape"])) != output_shape:
            raise DiagnosticError(f"{filename}: tensor shape mismatch")
        if inp[0]["dtype"] != np.float32 or out[0]["dtype"] != np.float32:
            raise DiagnosticError(f"{filename}: expected float32 I/O")
        results[key] = (worker, inp[0]["index"], out[0]["index"])
    return results


def invoke_all(interpreters, tensors, np):
    raw_results = {}
    for key, (worker, input_id, output_id) in interpreters.items():
        worker.set_tensor(input_id, tensors[key])
        worker.invoke()
        raw = np.asarray(worker.get_tensor(output_id))
        if not np.all(np.isfinite(raw)):
            raise DiagnosticError(f"{key}: nonfinite model output")
        raw_results[key] = raw.reshape(-1)
    return raw_results


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--models-dir", required=True)
    parser.add_argument("--mode", required=True, choices=["probe", "infer"])
    args = parser.parse_args(argv)
    try:
        # Reject invalid inputs *before* loading AI models.
        crops = None
        if args.mode == "infer":
            raw = sys.stdin.buffer.read(MAX_JSON_BYTES + 1)
            if len(raw) > MAX_JSON_BYTES:
                raise DiagnosticError("Diagnostic request too large")
            message = json.loads(raw.decode("utf-8"))
            if not isinstance(message, dict) or set(message) != {"rgba80_b64", "rgba112_b64"}:
                raise DiagnosticError("Expected only rgba80_b64 and rgba112_b64 fields")
            crops = (
                validate_pixels_base64(message["rgba80_b64"], 80, 80),
                validate_pixels_base64(message["rgba112_b64"], 112, 112),
            )
        import numpy as np
        from ai_edge_litert.interpreter import Interpreter
        engines = load_interpreters(args.models_dir, Interpreter, np)
        if args.mode == "probe":
            tensors = {key: np.zeros(spec[2], dtype=np.float32) for key, spec in SPECS.items()}
        else:
            tensors = preprocess_rgba(*crops, np)
        outputs = invoke_all(engines, tensors, np)
        result = {
            "ok": True,
            "mode": args.mode,
            "real_litert_execution": True,
            "diagnostic_only": True,
            "production_attestation": False,
            "models_executed": list(SPECS),
        }
        if args.mode == "infer":
            pad = live_probabilities(outputs["anti_spoofing_pad"], 0)
            liv = live_probabilities(outputs["liveness_detection"], 1)
            # Validate the 192D embedding but DO NOT return face biometric vectors to the web browser.
            embed = normalized_embedding(outputs["face_recognition"], np)
            result.update({
                "pad_live_probability": pad[0],
                "liveness_live_probability": liv[1],
                "embedding_dimension": len(embed),
                "embedding_l2_norm": math.sqrt(sum(x * x for x in embed)),
                "calibration_status": "UNCALIBRATED_STAGING_ONLY",
            })
        print(json.dumps(result, allow_nan=False, separators=(",", ":")))
        return 0
    except (DiagnosticError, ImportError, OSError, RuntimeError, json.JSONDecodeError, UnicodeDecodeError, ValueError, TypeError) as exc:
        # Never echo raw image bytes, model embeddings, or secrets to logs/errors.
        message = str(exc)[:300]
        print(json.dumps({"ok": False, "code": "DIAGNOSTIC_UNAVAILABLE", "error": message}))
        return 1


if __name__ == "__main__":
    sys.exit(main())
