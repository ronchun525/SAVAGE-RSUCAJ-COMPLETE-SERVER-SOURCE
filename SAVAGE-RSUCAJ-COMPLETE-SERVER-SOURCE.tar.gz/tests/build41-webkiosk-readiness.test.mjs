import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { getKioskReadinessNotice } from '../src/lib/kioskReadiness.ts';
const read = f => readFileSync(new URL('../'+f, import.meta.url), 'utf8');
const m = (verified, active, ready) => ({
  all_models_verified_on_disk: verified,
  server_inference_available: active,
  production_attendance_ready: ready,
  models: Object.fromEntries(['anti_spoofing_pad', 'liveness_detection','face_recognition'].map((k,i) => [k, {status: verified ? 'VERIFIED_ON_DISK' : i === 0 ? 'MISSING' : 'VERIFIED_ON_DISK'}]))
});
test('missing model is not described as installed', () => {
  const value=getKioskReadinessNotice(m(false,false,false),true);
  assert.equal(value.kind,'models_missing'); assert.match(value.title,/2\/3/);
});
test('all models installed and no attestation is reported correctly', () => {
  const value=getKioskReadinessNotice(m(true,false,false),true);
  assert.equal(value.kind,'attestation_inactive');
  assert.match(value.title,/All 3 biometric AI models are installed/);
  assert.doesNotMatch(value.detail,/model files are missing/);
});
test('model inference alone does not certify attendance', () => {
  assert.equal(getKioskReadinessNotice(m(true,true,false),true).kind,'not_certified');
});
test('a server-reported ready state has no warning banner', () => {
  assert.equal(getKioskReadinessNotice(m(true,true,true),false),null);
});
test('a policy block takes priority over model readiness', () => {
  assert.equal(getKioskReadinessNotice(m(true,true,true),true).kind,'not_certified');
});
test('Kiosk scans show accurate model versus attestation warning', () => {
  const s=read('src/components/kiosk/KioskScreens.tsx');
  assert.match(s,/getKioskReadinessNotice\(models, productionBlocked\)/);
  assert.doesNotMatch(s,/Biometric TFLite models are not deployed on this server/);
  assert.match(s,/trusted inference-backed enrollment/);
});
test('Kiosk refreshes actual models from server, no-store, on visibility and interval', () => {
  const s=read('src/components/WebKioskPortal.tsx');
  assert.match(s,/fetch\('\/api\/kiosk\/web\/models\/status'/);
  assert.match(s,/cache: 'no-store'/);
  assert.match(s,/setInterval\(\(\) =>/);
  assert.match(s,/visibilitychange/);
});
test('Production session and write endpoints distinguish missing files from attestation', () => {
  const s=read('server/webKioskRoutes.ts');
  assert.match(s,/trusted inference-backed enrollment is not yet active/);
  assert.match(s,/trusted inference-backed attendance is not yet active/);
  assert.match(s,/Cache-Control', 'no-store'/);
});
test('Server remains fail-closed and never uses fake biometric success', () => {
  const s=read('server/webKioskBiometrics.ts');
  assert.match(s,/const serverInferenceAvailable = false/);
  assert.match(read('server/webKioskRoutes.ts'),/!models\.production_attendance_ready/);
});
