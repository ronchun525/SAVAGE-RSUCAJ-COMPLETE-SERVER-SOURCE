import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import express from 'express';
import { chromium, type Browser, type BrowserContext, type Page } from 'playwright-core';
import { initDatabase, closeDatabaseSafely } from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import { RealtimeHub } from '../server/realtimeHub.ts';
import { getManilaDateString as getManilaTodayIso } from '../server/attendanceEngine.ts';

const ROOT_DIR = process.cwd();
const DIST_DIR = path.join(ROOT_DIR, 'dist');
const SCREENSHOT_ROOT = path.join(ROOT_DIR, 'test-results', 'e2e-screenshots');

const INITIAL_ADMIN_PW = 'InitCampus!2026#15';
const ROTATED_ADMIN_PW = 'RotatedAdmin!2026#99';
const CHECKER_ADMIN_PW = 'CheckerAdmin!2026#77';

interface AuditFinding {
  screen: string;
  viewport: string;
  overflowPx: number;
  brokenImages: string[];
  unlabeledInputs: string[];
  namelessButtons: string[];
  hasMain: boolean;
  hasH1: boolean;
  hasLangEn: boolean;
  hasAdminBiometricsLink: boolean;
  screenshotPath: string;
}

function resolveChromiumExecutable(): string | null {
  const candidates: string[] = [];
  if (process.env.PLAYWRIGHT_EXECUTABLE_PATH) {
    candidates.push(process.env.PLAYWRIGHT_EXECUTABLE_PATH);
  }
  candidates.push('/ms-playwright/chrome-headless-shell-linux64/chrome-headless-shell');

  if (fs.existsSync('/ms-playwright')) {
    try {
      for (const entry of fs.readdirSync('/ms-playwright')) {
        const sub1 = path.join('/ms-playwright', entry, 'chrome-headless-shell-linux64', 'chrome-headless-shell');
        const sub2 = path.join('/ms-playwright', entry, 'chrome-linux', 'chrome');
        candidates.push(sub1, sub2);
      }
    } catch {
      // ignore unreadable dirs
    }
  }

  candidates.push(
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    '/usr/bin/google-chrome',
    '/usr/bin/google-chrome-stable'
  );

  for (const c of candidates) {
    if (c && fs.existsSync(c)) return c;
  }

  try {
    const pwDefault = chromium.executablePath();
    if (pwDefault && fs.existsSync(pwDefault)) return pwDefault;
  } catch {
    // ignore
  }
  return null;
}

function getNextWeekdayInCurrentMonth(todayIso: string): string {
  const [y, m, d] = todayIso.split('-').map(Number);
  const daysInMonth = new Date(Date.UTC(y, m, 0)).getUTCDate();
  // Try a day in the same month strictly different from todayIso and Mon-Fri
  for (let delta = 1; delta <= 14; delta++) {
    const candidateDay = d + delta <= daysInMonth ? d + delta : Math.max(1, d - delta);
    if (candidateDay === d) continue;
    const dt = new Date(Date.UTC(y, m - 1, candidateDay));
    const dow = dt.getUTCDay();
    if (dow >= 1 && dow <= 5) {
      return `${y}-${String(m).padStart(2, '0')}-${String(candidateDay).padStart(2, '0')}`;
    }
  }
  return todayIso;
}

async function waitForStableUi(page: Page, ms = 250): Promise<void> {
  await page.waitForLoadState('domcontentloaded').catch(() => {});
  await page.waitForTimeout(ms);
}

async function auditScreen(
  page: Page,
  screenId: string,
  viewportName: string,
  findings: AuditFinding[],
  options?: { fullPage?: boolean }
): Promise<void> {
  await waitForStableUi(page, 250);

  const metrics = await page.evaluate(`(() => {
    const overflowPx = Math.max(
      0,
      Math.round(document.documentElement.scrollWidth - window.innerWidth)
    );

    const isVisible = (el) => {
      if (!el || el.hidden) return false;
      const style = window.getComputedStyle(el);
      if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) {
        return false;
      }
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    };

    const brokenImages = [];
    for (const img of Array.from(document.querySelectorAll('img'))) {
      if (!isVisible(img)) continue;
      if (!img.complete || img.naturalWidth === 0) {
        brokenImages.push(img.getAttribute('src') || img.alt || 'unknown-img');
      }
    }

    const unlabeledInputs = [];
    for (const ctrl of Array.from(document.querySelectorAll('input, select, textarea'))) {
      if (ctrl.type === 'hidden' || !isVisible(ctrl)) continue;
      const hasAria =
        Boolean((ctrl.getAttribute('aria-label') || '').trim()) ||
        Boolean((ctrl.getAttribute('aria-labelledby') || '').trim());
      const hasForLabel = Boolean(
        ctrl.id && document.querySelector('label[for="' + CSS.escape(ctrl.id) + '"]')
      );
      const hasParentLabel = Boolean(ctrl.closest('label'));
      if (!hasAria && !hasForLabel && !hasParentLabel) {
        unlabeledInputs.push(
          ctrl.tagName.toLowerCase() + '[type=' + (ctrl.type || 'text') + '][placeholder="' + (ctrl.placeholder || '') + '"]'
        );
      }
    }

    const namelessButtons = [];
    for (const btn of Array.from(document.querySelectorAll('button'))) {
      if (!isVisible(btn)) continue;
      const hasName =
        Boolean((btn.textContent || '').trim()) ||
        Boolean((btn.getAttribute('aria-label') || '').trim()) ||
        Boolean((btn.getAttribute('aria-labelledby') || '').trim()) ||
        Boolean((btn.getAttribute('title') || '').trim());
      if (!hasName) {
        namelessButtons.push(btn.outerHTML.slice(0, 80));
      }
    }

    const mainEl = document.querySelector('main');
    const h1El = document.querySelector('h1');
    const navText = Array.from(document.querySelectorAll('nav'))
      .map((n) => n.textContent || '')
      .join(' ');

    return {
      overflowPx,
      brokenImages,
      unlabeledInputs,
      namelessButtons,
      hasMain: Boolean(mainEl && isVisible(mainEl)),
      hasH1: Boolean(h1El && isVisible(h1El)),
      hasLangEn: document.documentElement.lang === 'en',
      title: document.title,
      hasAdminBiometricsLink: /admin\\s+biometrics/i.test(navText),
    };
  })()`) as {
    overflowPx: number;
    brokenImages: string[];
    unlabeledInputs: string[];
    namelessButtons: string[];
    hasMain: boolean;
    hasH1: boolean;
    hasLangEn: boolean;
    title: string;
    hasAdminBiometricsLink: boolean;
  };

  const dir = path.join(SCREENSHOT_ROOT, viewportName);
  fs.mkdirSync(dir, { recursive: true });
  const screenshotPath = path.join(dir, `${screenId}.png`);
  await page.screenshot({ path: screenshotPath, fullPage: Boolean(options?.fullPage) });

  const finding: AuditFinding = {
    screen: screenId,
    viewport: viewportName,
    overflowPx: metrics.overflowPx,
    brokenImages: metrics.brokenImages,
    unlabeledInputs: metrics.unlabeledInputs,
    namelessButtons: metrics.namelessButtons,
    hasMain: metrics.hasMain,
    hasH1: metrics.hasH1,
    hasLangEn: metrics.hasLangEn,
    hasAdminBiometricsLink: metrics.hasAdminBiometricsLink,
    screenshotPath: path.relative(ROOT_DIR, screenshotPath),
  };
  findings.push(finding);

  assert.equal(metrics.hasLangEn, true, `[${viewportName}/${screenId}] <html lang="en"> required`);
  assert.ok(metrics.title.includes('SAVAGE-RSUCAJ'), `[${viewportName}/${screenId}] title missing brand`);
  assert.equal(metrics.hasMain, true, `[${viewportName}/${screenId}] visible <main> landmark required`);
  assert.equal(metrics.hasH1, true, `[${viewportName}/${screenId}] visible <h1> heading required`);
  assert.equal(
    metrics.hasAdminBiometricsLink,
    false,
    `[${viewportName}/${screenId}] Admin Biometrics sidebar item must NOT exist`
  );
  assert.ok(
    metrics.overflowPx <= 1,
    `[${viewportName}/${screenId}] Horizontal overflow detected: ${metrics.overflowPx}px`
  );
  assert.deepEqual(
    metrics.brokenImages,
    [],
    `[${viewportName}/${screenId}] Broken images: ${metrics.brokenImages.join(', ')}`
  );
  assert.deepEqual(
    metrics.unlabeledInputs,
    [],
    `[${viewportName}/${screenId}] Unlabeled visible form controls: ${metrics.unlabeledInputs.join(', ')}`
  );
  assert.deepEqual(
    metrics.namelessButtons,
    [],
    `[${viewportName}/${screenId}] Buttons without accessible name: ${metrics.namelessButtons.join(', ')}`
  );
}

async function navTo(page: Page, label: string): Promise<void> {
  const sidebarNav = page.locator('aside nav[aria-label="Primary sidebar navigation"]');
  if (await sidebarNav.isVisible()) {
    await sidebarNav.getByRole('button', { name: new RegExp(`^${label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\s*\\d+)?$`) }).click();
  } else {
    // Mobile/tablet drawer path
    await page.getByRole('button', { name: 'Toggle sidebar navigation' }).click();
    const drawer = page.locator('div[role="dialog"][aria-label="Mobile navigation menu"]');
    await drawer.waitFor({ state: 'visible' });
    await drawer.getByRole('button', { name: new RegExp(`^${label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\s*\\d+)?$`) }).click();
    await drawer.waitFor({ state: 'hidden' });
  }
  await waitForStableUi(page, 200);
}

async function run(): Promise<void> {
  if (!fs.existsSync(path.join(DIST_DIR, 'index.html'))) {
    console.error('FAIL  Built SPA not found at dist/index.html. Run `npm run build` first.');
    process.exit(1);
  }

  const executablePath = resolveChromiumExecutable();
  if (!executablePath) {
    console.error('BLOCKED  Playwright Chromium browser binary is unavailable on this host.');
    console.error('         Install Chromium or set PLAYWRIGHT_EXECUTABLE_PATH and re-run `npm run test:browser`.');
    process.exit(2);
  }

  // Clean previous run screenshots
  fs.rmSync(SCREENSHOT_ROOT, { recursive: true, force: true });
  fs.mkdirSync(SCREENSHOT_ROOT, { recursive: true });

  // Ephemeral strong secrets strictly for this isolated E2E test process
  process.env.SESSION_SECRET = crypto.randomBytes(48).toString('hex');
  process.env.BACKUP_ENCRYPTION_KEY = crypto.randomBytes(48).toString('hex');

  // Isolated temporary SQLite database and backup directory (NEVER touches ./data/savage_rsucaj.db)
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-b15-e2e-'));
  const dbPath = path.join(tmpDir, 'e2e.db');
  const backupDir = path.join(tmpDir, 'backups');
  fs.mkdirSync(backupDir, { recursive: true });

  const db = initDatabase(dbPath, {
    mode: 'production',
    initialAdmin: {
      username: 'admin',
      email: 'admin@rsucaj.edu.ph',
      password: INITIAL_ADMIN_PW,
    },
  });
  const realtimeHub = new RealtimeHub();

  const app = express();
  app.disable('x-powered-by');
  app.use(
    '/api',
    createApiRouter(db, {
      dbPath,
      backupDir,
      appMode: 'production',
      realtimeHub,
    })
  );
  app.use(express.static(DIST_DIR));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(DIST_DIR, 'index.html'));
  });

  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  const addr = server.address();
  assert.ok(addr && typeof addr !== 'string');
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  let passed = 0;
  let failed = 0;
  const findings: AuditFinding[] = [];
  const pageErrors: string[] = [];
  const blockingConsoleErrors: string[] = [];
  let expectedHttp4xxWindow = false;

  const test = async (name: string, fn: () => Promise<void>) => {
    try {
      await fn();
      passed++;
      console.log(`PASS  ${name}`);
    } catch (err) {
      failed++;
      console.error(`FAIL  ${name}`);
      console.error(`      ${err instanceof Error ? err.stack || err.message : String(err)}`);
      if (page) {
        await page.keyboard.press('Escape').catch(() => {});
        await page.waitForTimeout(150).catch(() => {});
      }
    }
  };

  let browser: Browser | null = null;
  let context: BrowserContext | null = null;
  let page: Page | null = null;

  try {
    console.log(`INFO  Launching real Chromium headless shell: ${executablePath}`);
    console.log(`INFO  Isolated E2E Server: ${baseUrl} (DB: ${dbPath})`);

    browser = await chromium.launch({
      executablePath,
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
    });

    context = await browser.newContext({
      viewport: { width: 1366, height: 768 },
      acceptDownloads: true,
    });
    page = await context.newPage();
    page.setDefaultTimeout(12000);

    // Instrument window.print so print actions verify real invocation without blocking headless Chromium
    await page.addInitScript(`
      window.__printCalls = 0;
      window.__name = function(fn) { return fn; };
      window.print = function() { window.__printCalls += 1; };
    `);

    page.on('pageerror', (err) => {
      pageErrors.push(err.message);
    });
    page.on('response', async (res) => {
      if (res.status() >= 400 && !expectedHttp4xxWindow && !res.url().endsWith('/api/auth/me')) {
        const txt = await res.text().catch(() => '');
        console.error(`HTTP  ${res.status()} ${res.request().method()} ${res.url()} -> ${txt.slice(0, 240)}`);
      }
    });
    page.on('console', (msg) => {
      if (msg.type() === 'error') {
        const text = msg.text();
        // Allow intentional negative-test 400/401/403 network responses logged by Chromium during negative assertions
        if (expectedHttp4xxWindow && /status of 40[013]/i.test(text)) {
          return;
        }
        // Ignore initial unauthenticated /api/auth/me 401 probe on cold login page
        if (/status of 401/i.test(text) && page?.url().startsWith(baseUrl)) {
          return;
        }
        blockingConsoleErrors.push(text);
      }
    });

    const todayIso = getManilaTodayIso();
    const leaveIso = getNextWeekdayInCurrentMonth(todayIso);
    let provisionedKioskToken = '';

    // =========================================================================
    // 01 — LOGIN SCREEN & FORCED PASSWORD ROTATION GATE
    // =========================================================================
    await test('01_Login — branding, disabled Google SSO, recovery modal, keyboard/Escape, invalid login error, real auth & password rotation', async () => {
      assert.ok(page);
      await page.goto(baseUrl, { waitUntil: 'load' });
      await auditScreen(page, '01_Login', 'desktop-1366x768', findings);

      // Verify disabled Google SSO button
      const googleBtn = page.getByRole('button', { name: /Sign in with Google/i });
      assert.equal(await googleBtn.isDisabled(), true, 'Google SSO button should be disabled when unconfigured');

      // Keyboard Tab navigation check
      await page.keyboard.press('Tab');
      const focusedTag = await page.evaluate(() => document.activeElement?.tagName.toLowerCase());
      assert.ok(['input', 'button', 'a'].includes(focusedTag || ''), `Expected focusable element on Tab, got ${focusedTag}`);

      // Open Password Recovery Help modal & close with Escape
      await page.getByRole('button', { name: /Password Recovery Help/i }).click();
      const dialog = page.locator('[role="dialog"][aria-modal="true"]');
      await dialog.waitFor({ state: 'visible' });
      assert.ok((await dialog.textContent())?.includes('Email Password Reset Not Configured'));
      await page.keyboard.press('Escape');
      await dialog.waitFor({ state: 'hidden' });

      // Negative test: wrong password yields truthful alert
      expectedHttp4xxWindow = true;
      await page.getByLabel('Username or Email').fill('admin');
      await page.getByLabel('Password', { exact: true }).fill('WrongPassword!999');
      await page.getByRole('button', { name: 'Sign In', exact: true }).click();
      const alertBox = page.locator('[role="alert"]');
      await alertBox.waitFor({ state: 'visible' });
      assert.ok((await alertBox.textContent())?.toLowerCase().includes('invalid'));
      expectedHttp4xxWindow = false;

      // Valid login -> hits mandatory initial password rotation screen
      await page.getByLabel('Password', { exact: true }).fill(INITIAL_ADMIN_PW);
      await page.getByRole('button', { name: 'Sign In', exact: true }).click();
      await page.getByRole('heading', { name: 'Update Initial Password' }).waitFor({ state: 'visible' });

      await page.getByLabel('Current Password').fill(INITIAL_ADMIN_PW);
      await page.getByLabel('New Strong Password').fill(ROTATED_ADMIN_PW);
      await page.getByLabel('Confirm New Password').fill(ROTATED_ADMIN_PW);
      await page.getByRole('button', { name: 'Save New Password' }).click();

      await page.getByRole('heading', { name: 'Admin Dashboard' }).waitFor({ state: 'visible' });
    });

    // =========================================================================
    // 02 — ADMIN DASHBOARD (INITIAL STATE)
    // =========================================================================
    await test('02_Admin_Dashboard — KPI cards, donut SVG, weekly trend toggle, device status, notifications panel', async () => {
      assert.ok(page);
      await page.getByRole('heading', { name: 'Admin Dashboard' }).waitFor({ state: 'visible' });
      const trendSelect = page.getByLabel('Attendance trend timeframe');
      await trendSelect.selectOption('lastWeek');
      await waitForStableUi(page, 180);
      await trendSelect.selectOption('week');
      await waitForStableUi(page, 180);
      await auditScreen(page, '02_Admin_Dashboard_initial', 'desktop-1366x768', findings);
    });

    // =========================================================================
    // 11 — DEPARTMENTS (CRUD + SEARCH)
    // =========================================================================
    await test('11_Departments — Add, Edit, Search filter persisted in SQLite', async () => {
      assert.ok(page);
      await navTo(page, 'Departments');
      await page.getByRole('heading', { name: 'Departments' }).waitFor({ state: 'visible' });

      // Add BSIT
      await page.getByRole('button', { name: 'Add Department' }).click();
      const modal = page.locator('[role="dialog"]');
      await modal.locator('input[placeholder="BSIT"]').fill('BSIT');
      await modal.locator('input[placeholder="Information Technology"]').fill('Information Technology');
      await modal.locator('input[placeholder="Dr. / Engr. Name"]').fill('Engr. Roberto M. Santos');
      await modal.getByRole('button', { name: 'Save Department' }).click();
      await modal.waitFor({ state: 'hidden' });

      // Add ADMIN
      await page.getByRole('button', { name: 'Add Department' }).click();
      await modal.locator('input[placeholder="BSIT"]').fill('ADMIN');
      await modal.locator('input[placeholder="Information Technology"]').fill('Campus Administration');
      await modal.locator('input[placeholder="Dr. / Engr. Name"]').fill('Dr. Elena R. Villanueva');
      await modal.getByRole('button', { name: 'Save Department' }).click();
      await modal.waitFor({ state: 'hidden' });

      // Edit ADMIN
      await page.getByRole('button', { name: 'Edit Campus Administration' }).click();
      await modal.locator('input[placeholder="Dr. / Engr. Name"]').fill('Dr. Elena R. Villanueva, PhD');
      await modal.getByRole('button', { name: 'Save Department' }).click();
      await modal.waitFor({ state: 'hidden' });

      // Search filter
      const searchBox = page.getByLabel('Search departments');
      await searchBox.fill('BSIT');
      assert.equal(await page.locator('tbody tr').count(), 1);
      await searchBox.fill('');

      await auditScreen(page, '11_Departments', 'desktop-1366x768', findings);
    });

    // =========================================================================
    // 12 — POSITIONS (CRUD + SEARCH)
    // =========================================================================
    await test('12_Positions — Add, Edit, Search filter persisted in SQLite', async () => {
      assert.ok(page);
      await navTo(page, 'Positions');
      await page.getByRole('heading', { name: 'Positions' }).waitFor({ state: 'visible' });

      const modal = page.locator('[role="dialog"]');
      await page.getByRole('button', { name: 'Add Position' }).click();
      await modal.locator('input[placeholder="INST"]').fill('INST');
      await modal.locator('input[placeholder="Instructor I"]').fill('Instructor I');
      await modal.locator('input[type="number"]').nth(0).fill('32000');
      await modal.locator('input[type="number"]').nth(1).fill('2000');
      await modal.getByRole('button', { name: 'Save Position' }).click();
      await modal.waitFor({ state: 'hidden' });

      await page.getByRole('button', { name: 'Add Position' }).click();
      await modal.locator('input[placeholder="INST"]').fill('ASST');
      await modal.locator('input[placeholder="Instructor I"]').fill('Administrative Assistant');
      await modal.locator('input[type="number"]').nth(0).fill('24000');
      await modal.locator('input[type="number"]').nth(1).fill('1500');
      await modal.getByRole('button', { name: 'Save Position' }).click();
      await modal.waitFor({ state: 'hidden' });

      // Edit & Search
      await page.getByRole('button', { name: 'Edit Administrative Assistant' }).click();
      await modal.locator('input[type="number"]').nth(1).fill('2000');
      await modal.getByRole('button', { name: 'Save Position' }).click();
      await modal.waitFor({ state: 'hidden' });

      const searchBox = page.getByLabel('Search positions');
      await searchBox.fill('INST');
      assert.equal(await page.locator('tbody tr').count(), 1);
      await searchBox.fill('');

      await auditScreen(page, '12_Positions', 'desktop-1366x768', findings);
    });

    // =========================================================================
    // 10 — SHIFTS & SCHEDULES (CRUD + SEARCH)
    // =========================================================================
    await test('10_Shifts_and_Schedules — Add, Edit, Search filter persisted in SQLite', async () => {
      assert.ok(page);
      await navTo(page, 'Shifts & Schedules');
      await page.getByRole('heading', { name: 'Shifts & Schedules' }).waitFor({ state: 'visible' });

      const modal = page.locator('[role="dialog"]');
      await page.getByRole('button', { name: 'Add Shift' }).click();
      await modal.locator('input[type="text"]').nth(0).fill('Regular Shift');
      await modal.getByRole('button', { name: 'Save Shift' }).click();
      await modal.waitFor({ state: 'hidden' });

      await page.getByRole('button', { name: 'Add Shift' }).click();
      await modal.locator('input[type="text"]').nth(0).fill('Night Watch');
      await modal.locator('input[type="text"]').nth(1).fill('10:00 PM');
      await modal.locator('input[type="text"]').nth(2).fill('06:00 AM');
      await modal.locator('input[type="number"]').fill('10');
      await modal.getByRole('button', { name: 'Save Shift' }).click();
      await modal.waitFor({ state: 'hidden' });

      await page.getByRole('button', { name: 'Edit Night Watch' }).click();
      await modal.locator('input[type="number"]').fill('15');
      await modal.getByRole('button', { name: 'Save Shift' }).click();
      await modal.waitFor({ state: 'hidden' });

      const searchBox = page.getByLabel('Search shifts');
      await searchBox.fill('Regular');
      assert.equal(await page.locator('tbody tr').count(), 1);
      await searchBox.fill('');

      await auditScreen(page, '10_Shifts_and_Schedules', 'desktop-1366x768', findings);
    });

    // =========================================================================
    // 13 — HOLIDAYS (CRUD + SEARCH)
    // =========================================================================
    await test('13_Holidays — Add, Edit, Search filter persisted in SQLite', async () => {
      assert.ok(page);
      await navTo(page, 'Holidays');
      await page.getByRole('heading', { name: 'Holidays' }).waitFor({ state: 'visible' });

      const modal = page.locator('[role="dialog"]');
      await page.getByRole('button', { name: 'Add Holiday' }).click();
      await modal.locator('input[type="date"]').fill('2026-06-12');
      await modal.locator('input[placeholder="Independence Day"]').fill('Independence Day');
      await modal.getByRole('button', { name: 'Save Holiday' }).click();
      await modal.waitFor({ state: 'hidden' });

      await page.getByRole('button', { name: 'Edit Independence Day' }).click();
      await modal.locator('input[placeholder="Independence Day"]').fill('Philippine Independence Day');
      await modal.getByRole('button', { name: 'Save Holiday' }).click();
      await modal.waitFor({ state: 'hidden' });

      const searchBox = page.getByLabel('Search holidays');
      await searchBox.fill('Independence');
      assert.equal(await page.locator('tbody tr').count(), 1);
      await searchBox.fill('');

      await auditScreen(page, '13_Holidays', 'desktop-1366x768', findings);
    });

    // =========================================================================
    // 04 — EMPLOYEES MANAGEMENT (ADD, VIEW, EDIT, CSV IMPORT, FILTER, EXPORT)
    // =========================================================================
    await test('04_Employees_Management — Add, View/Escape, Edit, CSV Import, Department Filter, Search & CSV Export', async () => {
      assert.ok(page);
      await navTo(page, 'Employees');
      await page.getByRole('heading', { name: 'Employees Management' }).waitFor({ state: 'visible' });

      const modal = page.locator('[role="dialog"]');
      await page.getByRole('button', { name: 'Add Employee' }).click();
      await modal.locator('input[type="text"]').nth(0).fill('EMP-2026-001');
      await modal.locator('input[placeholder="Dela Cruz, Maria S."]').fill('Dela Cruz, Maria S.');
      await modal.locator('input[placeholder="name@rsucaj.edu.ph"]').fill('maria.delacruz@rsucaj.edu.ph');
      await modal.getByRole('button', { name: 'Create Employee' }).click();
      await modal.waitFor({ state: 'hidden' });

      // View modal + Escape close
      await page.getByRole('button', { name: 'View Dela Cruz, Maria S.' }).click();
      await modal.waitFor({ state: 'visible' });
      assert.ok((await modal.textContent())?.includes('EMP-2026-001'));
      await page.keyboard.press('Escape');
      await modal.waitFor({ state: 'hidden' });

      // Edit employee
      await page.getByRole('button', { name: 'Edit Dela Cruz, Maria S.' }).click();
      await modal.locator('input[placeholder="name@rsucaj.edu.ph"]').fill('m.delacruz@rsucaj.edu.ph');
      await modal.getByRole('button', { name: 'Save Changes' }).click();
      await modal.waitFor({ state: 'hidden' });

      // CSV Import (2 employees)
      await page.getByRole('button', { name: 'Import' }).click();
      await modal.getByLabel('Employee CSV data').fill(
        [
          'employee_code,full_name,email,department_code,position_code,status',
          'EMP-2026-002,Reyes, Juan P.,juan.reyes@rsucaj.edu.ph,ADMIN,ASST,Active',
          'EMP-2026-003,Mendoza, Ana L.,ana.mendoza@rsucaj.edu.ph,BSIT,INST,Active',
        ].join('\n')
      );
      await modal.getByRole('button', { name: 'Run CSV Import' }).click();
      await modal.waitFor({ state: 'hidden' });
      await page.getByText(/CSV Import complete: 2 inserted/i).waitFor({ state: 'visible' });

      // Export CSV
      const [download] = await Promise.all([
        page.waitForEvent('download'),
        page.getByRole('button', { name: 'Export' }).click(),
      ]);
      assert.ok(download.suggestedFilename().includes('savage-rsucaj-employees'));

      // Filter by search then clear
      const searchBox = page.getByLabel('Search employees by ID, name, or department');
      await searchBox.fill('EMP-2026-002');
      await waitForStableUi(page, 250);
      assert.equal(await page.locator('tbody tr').count(), 1);
      await searchBox.fill('');
      await waitForStableUi(page, 250);

      await auditScreen(page, '04_Employees_Management', 'desktop-1366x768', findings);
    });

    // =========================================================================
    // 15 — DEVICES (KIOSK) — REGISTER, ONE-TIME TOKEN, REAL HEARTBEAT, TEST API, TELEMETRY, ROTATE, REVOKE/RESTORE
    // =========================================================================
    await test('15_Devices_Kiosk — Register, One-Time Secret reveal, Heartbeat -> Online, Test API Punch, Telemetry, Rotate & Revoke/Restore', async () => {
      assert.ok(page);
      await navTo(page, 'Devices (Kiosk)');
      await page.getByRole('heading', { name: 'Devices (Kiosk)' }).waitFor({ state: 'visible' });

      const modal = page.locator('[role="dialog"]');
      await page.getByRole('button', { name: 'Add Device' }).click();
      await modal.locator('input[placeholder="Kiosk - Library Entrance"]').fill('Kiosk - Main Gate');
      await modal.getByRole('button', { name: 'Register Device' }).click();

      // One-Time Secret Modal opens automatically
      await page.getByText('One-Time Kiosk Token Provisioned').waitFor({ state: 'visible' });
      provisionedKioskToken = (await modal.locator('code').textContent())?.trim() || '';
      assert.ok(provisionedKioskToken.startsWith('ksk_'), `Expected ksk_ token, got ${provisionedKioskToken}`);
      await modal.getByRole('button', { name: 'I Have Saved This Token' }).click();
      await modal.waitFor({ state: 'hidden' });

      // Confirm initial state is Offline (never fabricated Online)
      assert.ok((await page.locator('tbody').textContent())?.includes('Offline'));

      // Send real authenticated kiosk heartbeat so status becomes Online
      const hbRes = await fetch(`${baseUrl}/api/kiosk/heartbeat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-kiosk-token': provisionedKioskToken,
        },
        body: JSON.stringify({
          device_timestamp: new Date().toISOString(),
          pending_queue_count: 0,
        }),
      });
      assert.equal(hbRes.status, 200);
      await waitForStableUi(page, 350);
      assert.ok((await page.locator('tbody').textContent())?.includes('Online'));

      // Test API Punch Modal (real POST /api/kiosk/punch TIME_IN for EMP-2026-001)
      await page.getByRole('button', { name: 'Test API' }).click();
      await modal.waitFor({ state: 'visible' });
      await modal.getByRole('button', { name: 'Send Kiosk Punch' }).click();
      await modal.waitFor({ state: 'hidden' });
      await page.getByText(/Kiosk API response/i).waitFor({ state: 'visible' });

      // Inspect Telemetry modal + Escape close
      await page.getByRole('button', { name: 'Inspect telemetry for Kiosk - Main Gate' }).click();
      await modal.waitFor({ state: 'visible' });
      assert.ok((await modal.textContent())?.includes('Kiosk Sync & Heartbeat Telemetry'));
      await page.keyboard.press('Escape');
      await modal.waitFor({ state: 'hidden' });

      // Rotate Token
      await page.getByRole('button', { name: 'Rotate credential token for Kiosk - Main Gate' }).click();
      await modal.getByRole('button', { name: 'Rotate Token Now' }).click();
      await page.getByText('One-Time Kiosk Token Rotated').waitFor({ state: 'visible' });
      const rotatedToken = (await modal.locator('code').textContent())?.trim() || '';
      assert.ok(rotatedToken.startsWith('ksk_') && rotatedToken !== provisionedKioskToken);
      provisionedKioskToken = rotatedToken;
      await modal.getByRole('button', { name: 'I Have Saved This Token' }).click();
      await modal.waitFor({ state: 'hidden' });

      // Revoke & Restore
      await page.getByRole('button', { name: 'Revoke access for Kiosk - Main Gate' }).click();
      await page.getByText(/Revoked credentials for Kiosk - Main Gate/i).waitFor({ state: 'visible' });
      await page.getByRole('button', { name: 'Restore access for Kiosk - Main Gate' }).click();
      await page.getByText(/Restored credential access for Kiosk - Main Gate/i).waitFor({ state: 'visible' });

      // Re-heartbeat with rotated token so kiosk is Online for Dashboard screenshot
      const hb2 = await fetch(`${baseUrl}/api/kiosk/heartbeat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-kiosk-token': provisionedKioskToken,
        },
        body: JSON.stringify({ device_timestamp: new Date().toISOString(), pending_queue_count: 0 }),
      });
      assert.equal(hb2.status, 200);
      await waitForStableUi(page, 300);

      await auditScreen(page, '15_Devices_Kiosk', 'desktop-1366x768', findings);
    });

    // =========================================================================
    // 05 — ATTENDANCE RECORDS (VIEW KIOSK PUNCH, LOG MANUAL, RECONCILE, FILTER, EXPORT)
    // =========================================================================
    await test('05_Attendance_Records — Verify kiosk punch, Log Attendance, Reconcile Day, Details/Immutable trail, Filter & Export CSV', async () => {
      assert.ok(page);
      await navTo(page, 'Attendance');
      await page.getByRole('heading', { name: 'Attendance Records' }).waitFor({ state: 'visible' });

      // Kiosk punch for EMP-2026-001 should already be listed
      assert.ok((await page.locator('tbody').textContent())?.includes('EMP-2026-001'));

      // Log manual attendance for EMP-2026-002
      const modal = page.locator('[role="dialog"]');
      await page.getByRole('button', { name: 'Log Attendance' }).click();
      const empSelect = modal.locator('select').nth(0);
      const emp2Val = await empSelect.locator('option', { hasText: 'EMP-2026-002' }).getAttribute('value');
      assert.ok(emp2Val);
      await empSelect.selectOption(emp2Val);
      await modal.getByRole('button', { name: 'Save Attendance' }).click();
      await modal.waitFor({ state: 'hidden' });
      await page.getByText(/Attendance saved for/i).waitFor({ state: 'visible' });

      // View Details modal with Immutable Punch & Audit Event Trail
      await page.getByRole('button', { name: /View details for Dela Cruz, Maria S\./i }).click();
      await modal.waitFor({ state: 'visible' });
      assert.ok((await modal.textContent())?.includes('Immutable Punch & Audit Event Trail'));
      await page.keyboard.press('Escape');
      await modal.waitFor({ state: 'hidden' });

      // Reconcile Day
      await page.getByRole('button', { name: 'Reconcile Day' }).click();
      await page.getByText(/Reconciled/i).waitFor({ state: 'visible' });

      // Search filter
      const searchBox = page.getByLabel('Search attendance by employee ID or name');
      await searchBox.fill('EMP-2026-001');
      await page.getByRole('button', { name: 'Search' }).click();
      await waitForStableUi(page, 250);
      assert.equal(await page.locator('tbody tr').count(), 1);
      await searchBox.fill('');
      await page.getByRole('button', { name: 'Search' }).click();
      await waitForStableUi(page, 250);

      // Export CSV
      const [dl] = await Promise.all([
        page.waitForEvent('download'),
        page.getByRole('button', { name: 'Export CSV' }).click(),
      ]);
      assert.ok(dl.suggestedFilename().includes('savage-rsucaj-attendance'));

      await auditScreen(page, '05_Attendance_Records', 'desktop-1366x768', findings);
    });

    // =========================================================================
    // 06 — ATTENDANCE CORRECTIONS (FILE, APPROVE, REVERSE, RE-FILE & APPROVE)
    // =========================================================================
    await test('06_Attendance_Corrections — File correction, Approve & Sync, Reverse with reason, and verify Audit Trail', async () => {
      assert.ok(page);
      await navTo(page, 'Corrections');
      await page.getByRole('heading', { name: 'Corrections' }).waitFor({ state: 'visible' });

      const modal = page.locator('[role="dialog"]');
      // File Full Day correction for EMP-2026-001 (deterministic regardless of wall-clock Manila hour)
      await page.getByRole('button', { name: 'New Correction' }).click();
      await modal.locator('select').nth(1).selectOption('Full Day');
      await modal.locator('input[placeholder="08:05 AM"]').fill('08:00 AM');
      await modal.locator('input[placeholder="05:00 PM"]').fill('05:05 PM');
      await modal.locator('textarea').fill('Verified arrival and departure against signed main gate logbook');
      await modal.locator('input[placeholder*="MEMO-2026-042"]').fill('MEMO-2026-015');
      await modal.getByRole('button', { name: 'Submit Request' }).click();
      await modal.waitFor({ state: 'hidden' });
      await page.getByText(/Attendance correction request created/i).waitFor({ state: 'visible' });

      // Open details modal -> Approve & Sync Attendance
      await page.getByRole('button', { name: /View correction details for Dela Cruz, Maria S\./i }).first().click();
      await modal.waitFor({ state: 'visible' });
      await modal.getByRole('button', { name: 'Approve & Sync Attendance' }).click();
      await modal.waitFor({ state: 'hidden' });
      await page.getByText(/Correction approved and synced/i).waitFor({ state: 'visible' });

      // Switch to Approved tab -> Reverse with mandatory reason
      await page.getByRole('button', { name: /^Approved \(/ }).click();
      await waitForStableUi(page, 200);
      await page.getByRole('button', { name: 'Reverse' }).first().click();
      await modal.waitFor({ state: 'visible' });
      await modal.locator('input[placeholder*="Mandatory reversal reason"]').fill('Re-verifying actual logbook timestamp');
      await modal.getByRole('button', { name: 'Reverse Correction' }).click();
      await modal.waitFor({ state: 'hidden' });
      await page.getByText(/Approved correction reversed/i).waitFor({ state: 'visible' });

      // File & approve final valid Full Day so EMP-2026-001 has complete In+Out for Payroll/DTR
      await page.getByRole('button', { name: 'New Correction' }).click();
      await modal.locator('select').nth(1).selectOption('Full Day');
      await modal.locator('input[placeholder="08:05 AM"]').fill('08:00 AM');
      await modal.locator('input[placeholder="05:00 PM"]').fill('05:00 PM');
      await modal.locator('textarea').fill('Confirmed shift 08:00 AM - 05:00 PM per campus director logbook');
      await modal.locator('input[placeholder*="MEMO-2026-042"]').fill('MEMO-2026-016');
      await modal.getByRole('button', { name: 'Submit Request' }).click();
      await modal.waitFor({ state: 'hidden' });

      await page.getByRole('button', { name: 'Approve', exact: true }).first().click();
      await page.getByText(/Correction approved and synced/i).waitFor({ state: 'visible' });

      // View All tab so both Approved & Reversed rows display cleanly
      await page.getByRole('button', { name: /^All/ }).click();
      await waitForStableUi(page, 200);
      await auditScreen(page, '06_Attendance_Corrections', 'desktop-1366x768', findings);
    });

    // =========================================================================
    // 07 — LEAVES MANAGEMENT (PREVIEW, FILE, APPROVE, BALANCES, POLICIES)
    // =========================================================================
    await test('07_Leaves_Management — Live eligibility preview, File leave, Approve & Propagate, Leave Balances & Policies tabs', async () => {
      assert.ok(page);
      await navTo(page, 'Leaves');
      await page.getByRole('heading', { name: 'Leaves Management' }).waitFor({ state: 'visible' });

      const modal = page.locator('[role="dialog"]');
      await page.getByRole('button', { name: 'New Leave' }).click();
      const empSelect = modal.locator('select').nth(0);
      const emp3Val = await empSelect.locator('option', { hasText: 'EMP-2026-003' }).getAttribute('value');
      assert.ok(emp3Val);
      await empSelect.selectOption(emp3Val);
      await modal.locator('input[type="date"]').nth(0).fill(leaveIso);
      await modal.locator('input[type="date"]').nth(1).fill(leaveIso);
      await modal.locator('textarea').fill('Scheduled personal vacation leave request for E2E check');
      await modal.getByText(/Balance:/i).waitFor({ state: 'visible' });
      await modal.getByRole('button', { name: 'Submit Leave' }).click();
      await modal.waitFor({ state: 'hidden' });
      await page.getByText(/Leave application submitted/i).waitFor({ state: 'visible' });

      // View Details & Approve
      await page.getByRole('button', { name: /View leave details/i }).first().click();
      await modal.waitFor({ state: 'visible' });
      await modal.getByRole('button', { name: 'Approve & Propagate Attendance' }).click();
      await modal.waitFor({ state: 'hidden' });
      await page.getByText(/Leave approved and propagated/i).waitFor({ state: 'visible' });

      // Switch to Leave Balances & Policies tabs
      await page.getByRole('button', { name: 'Leave Balances' }).click();
      await waitForStableUi(page, 200);
      assert.ok((await page.locator('tbody').textContent())?.includes('EMP-2026-003'));

      await page.getByRole('button', { name: 'Policies' }).click();
      await waitForStableUi(page, 200);
      assert.ok((await page.locator('tbody').textContent())?.includes('Vacation Leave'));

      await page.getByRole('button', { name: 'Applications' }).click();
      await waitForStableUi(page, 200);
      await auditScreen(page, '07_Leaves_Management', 'desktop-1366x768', findings);
    });

    // =========================================================================
    // 08 — PAYROLL PROCESSING (POLICY TEMPLATE -> FINANCE APPROVE -> PRECHECK -> COMPUTE -> PAYSLIP/PRINT -> CSV -> AUDIT)
    // =========================================================================
    await test('08_Payroll_Processing — Institutional Policy creation & Finance Approval, Precheck, Compute, Payslip Print, Server CSV Export & Audit', async () => {
      assert.ok(page);
      await navTo(page, 'Payroll');
      await page.getByRole('heading', { name: 'Payroll Processing' }).waitFor({ state: 'visible' });

      const modal = page.locator('[role="dialog"]');

      // Create & Finance-Approve institutional policy via UI
      await page.getByRole('button', { name: /Policies \(/ }).click();
      await modal.waitFor({ state: 'visible' });
      await modal.getByRole('button', { name: 'New Draft Policy' }).click();
      await modal.getByRole('button', { name: 'Save Draft Policy' }).click();
      await page.getByText(/Draft payroll policy/i).waitFor({ state: 'visible' });

      await modal.getByRole('button', { name: 'Finance Approve' }).first().click();
      await modal.locator('input[placeholder*="RSU-FIN-MEMO"]').fill('RSU-FIN-MEMO-2026-E2E-01');
      await modal.getByRole('button', { name: 'Confirm Finance Approval' }).click();
      await page.getByText(/Institutional payroll policy approved by Finance/i).waitFor({ state: 'visible' });
      await page.keyboard.press('Escape');
      await modal.waitFor({ state: 'hidden' });

      // Compute Payroll Batch
      await page.getByRole('button', { name: 'Compute Payroll' }).click();
      await modal.waitFor({ state: 'visible' });
      await modal.getByText(/Reconciliation passed/i).waitFor({ state: 'visible' });
      await modal.getByRole('button', { name: 'Run Computation' }).click();
      await modal.waitFor({ state: 'hidden' });
      await page.getByText(/Payroll computed for/i).waitFor({ state: 'visible' });

      // Open Payslip modal, verify Print trigger, close with Escape
      const printBefore = await page.evaluate(() => (window as unknown as { __printCalls: number }).__printCalls);
      await page.getByRole('button', { name: 'Payslip' }).first().click();
      await modal.waitFor({ state: 'visible' });
      await modal.getByRole('button', { name: 'Print / Save PDF' }).click();
      const printAfter = await page.evaluate(() => (window as unknown as { __printCalls: number }).__printCalls);
      assert.equal(printAfter, printBefore + 1, 'Expected window.print() to be invoked from Payslip modal');
      await page.keyboard.press('Escape');
      await modal.waitFor({ state: 'hidden' });

      // Export Payroll CSV (real server endpoint)
      const [csvDl] = await Promise.all([
        page.waitForEvent('download'),
        page.getByRole('button', { name: 'Export CSV' }).click(),
      ]);
      assert.ok(csvDl.suggestedFilename().includes('SAVAGE-RSUCAJ-Payroll'));

      // Open Payroll Audit Modal & close with Escape
      await page.getByRole('button', { name: /Audit \(/ }).click();
      await modal.waitFor({ state: 'visible' });
      await page.keyboard.press('Escape');
      await modal.waitFor({ state: 'hidden' });

      await auditScreen(page, '08_Payroll_Processing', 'desktop-1366x768', findings);
    });

    // =========================================================================
    // 09 — REPORTS (ALL 6 CARDS + MONTHLY DTR A4 PREVIEW, VERIFY & SIGN, PRINT, PDF & CSV EXPORTS)
    // =========================================================================
    await test('09_Reports — All 6 Report Cards, Monthly DTR A4 Sheet, Verify & Sign, Print A4, Server PDF & CSV Exports', async () => {
      assert.ok(page);
      await navTo(page, 'Reports');
      await page.getByRole('heading', { name: 'Reports' }).waitFor({ state: 'visible' });

      // Exercise all 6 report cards
      for (const cardName of [
        'Attendance Report',
        'Leave Report',
        'Payroll Report',
        'Employee Report',
        'Audit Logs Report',
        'DTR (Daily Time Record)',
      ]) {
        await page.getByRole('button', { name: new RegExp(cardName.replace(/[()]/g, '\\$&')) }).click();
        await waitForStableUi(page, 250);
      }

      // Verify Monthly DTR A4 preview & official emblem
      assert.ok((await page.locator('main').textContent())?.includes('ROMBLON STATE UNIVERSITY — CAJIDIOCAN CAMPUS'));

      // Verify & Sign DTR (if ready)
      const signBtn = page.getByRole('button', { name: 'Verify & Sign DTR' });
      if (await signBtn.isVisible()) {
        await signBtn.click();
        await page.getByText(/Verified and signed Monthly DTR/i).waitFor({ state: 'visible' });
      }

      // Print A4
      const pBefore = await page.evaluate(() => (window as unknown as { __printCalls: number }).__printCalls);
      await page.getByRole('button', { name: 'Print A4' }).click();
      const pAfter = await page.evaluate(() => (window as unknown as { __printCalls: number }).__printCalls);
      assert.equal(pAfter, pBefore + 1);

      // Download authenticated PDF & CSV from real Express streaming routes
      const [pdfDl] = await Promise.all([
        page.waitForEvent('download'),
        page.getByRole('button', { name: 'Download PDF' }).click(),
      ]);
      assert.ok(pdfDl.suggestedFilename().endsWith('.pdf'));

      const [csvDl] = await Promise.all([
        page.waitForEvent('download'),
        page.getByRole('button', { name: 'Download CSV' }).click(),
      ]);
      assert.ok(csvDl.suggestedFilename().endsWith('.csv'));

      await auditScreen(page, '09_Reports', 'desktop-1366x768', findings);
    });

    // =========================================================================
    // 03 — NOTIFICATIONS (EVENT-TRIGGERED, FILTERS, BULK SELECT, MARK READ, DISMISS)
    // =========================================================================
    await test('03_Notifications — Real event notifications, Filter tabs, Bulk Select, Mark Selected Read & Dismiss', async () => {
      assert.ok(page);
      await navTo(page, 'Notifications');
      await page.getByRole('heading', { name: 'Notifications' }).waitFor({ state: 'visible' });

      // Verify tabs work
      for (const tabPrefix of ['Unread', 'Attendance Alerts', 'Device Alerts', 'System Notices', 'All']) {
        await page.getByRole('button', { name: new RegExp(`^${tabPrefix} \\(`) }).click();
        await waitForStableUi(page, 180);
      }

      await auditScreen(page, '03_Notifications', 'desktop-1366x768', findings);

      // Bulk select page & mark selected read
      const selectPageBtn = page.getByRole('button', { name: 'Select Page' });
      if (await selectPageBtn.isVisible()) {
        await selectPageBtn.click();
        await page.getByRole('button', { name: /Mark Selected/i }).click();
        await waitForStableUi(page, 250);
      }

      // Dismiss one notification
      const dismissBtn = page.getByRole('button', { name: 'Dismiss' }).first();
      if (await dismissBtn.isVisible()) {
        await dismissBtn.click();
        await waitForStableUi(page, 200);
      }
    });

    // =========================================================================
    // 14 — AUDIT LOGS (VERIFY HASH CHAIN, FILTER, SEARCH, EXPAND, EXPORT CSV)
    // =========================================================================
    await test('14_Audit_Logs — Verify SHA-256 Hash Chain, Module Filter, Search & Authenticated CSV Export', async () => {
      assert.ok(page);
      await navTo(page, 'Audit Logs');
      await page.getByRole('heading', { name: 'Audit Logs' }).waitFor({ state: 'visible' });

      await page.getByRole('button', { name: /Verify Chain/i }).click();
      await page.getByText(/SHA-256 hash chain verified intact/i).waitFor({ state: 'visible' });

      const modSelect = page.getByLabel('Filter by module');
      await modSelect.selectOption('Devices');
      await waitForStableUi(page, 200);
      assert.ok((await page.locator('tbody tr').count()) >= 1);
      await modSelect.selectOption('All');
      await waitForStableUi(page, 200);

      const [auditDl] = await Promise.all([
        page.waitForEvent('download'),
        page.getByRole('button', { name: /Export Logs/i }).click(),
      ]);
      assert.ok(/audit-logs.*\.csv$/i.test(auditDl.suggestedFilename()));

      await auditScreen(page, '14_Audit_Logs', 'desktop-1366x768', findings);
    });

    // =========================================================================
    // 16 — SYSTEM SETTINGS (ALL 6 TABS: INVALID ERROR + SAVE, MASKED SECRETS, CREATE USER, BACKUP/DRILL, RETENTION DRY RUN, ABOUT)
    // =========================================================================
    await test('16_System_Settings — General validation/save, API masked secrets, Security create user, Backup/Restore Drill, Retention Dry Run & About v1.13.0', async () => {
      assert.ok(page);
      await navTo(page, 'System Settings');
      await page.getByRole('heading', { name: 'System Settings' }).waitFor({ state: 'visible' });

      // Negative test: invalid timezone produces truthful error
      expectedHttp4xxWindow = true;
      await page.getByLabel('Timezone (IANA)').fill('Invalid/Zone');
      await page.getByRole('button', { name: 'Save General Settings' }).click();
      await page.getByText(/valid IANA timezone|Invalid/i).waitFor({ state: 'visible' });
      expectedHttp4xxWindow = false;

      // Restore valid timezone & set Campus Director
      await page.getByLabel('Timezone (IANA)').fill('Asia/Manila');
      await page.getByLabel(/Campus Director/).fill('Dr. Merian P. Catajay-Mani');
      await page.getByRole('button', { name: 'Save General Settings' }).click();
      await page.getByText(/Saved validated configuration/i).waitFor({ state: 'visible' });
      await auditScreen(page, '16_System_Settings', 'desktop-1366x768', findings);

      // Tab 2: API (Masked secrets)
      await page.getByRole('button', { name: 'API (Backend Configuration)' }).click();
      await waitForStableUi(page, 200);
      assert.ok((await page.locator('main').textContent())?.includes('Environment Secret Status (Masked)'));

      // Tab 3: Security & Access -> create second Administrator (checker_admin) for Maker-Checker verification
      await page.getByRole('button', { name: 'Security & Access' }).click();
      await waitForStableUi(page, 200);
      await page.getByRole('button', { name: 'Add Portal User' }).click();
      const modal = page.locator('[role="dialog"]');
      await modal.locator('input[type="text"]').nth(0).fill('checker_admin');
      await modal.locator('select').nth(0).selectOption('Administrator');
      await modal.locator('input[type="text"]').nth(1).fill('Campus Finance Reviewer');
      await modal.locator('input[type="email"]').fill('checker@rsucaj.edu.ph');
      await modal.locator('input[type="password"]').fill(CHECKER_ADMIN_PW);
      // Uncheck must_change_password so second admin logs straight in for maker-checker check
      const mustRotateCb = modal.locator('input[type="checkbox"]');
      if (await mustRotateCb.isChecked()) await mustRotateCb.uncheck();
      await modal.getByRole('button', { name: 'Create Account' }).click();
      await modal.waitFor({ state: 'hidden' });
      await page.getByText(/Created new portal user account/i).waitFor({ state: 'visible' });

      // Tab 4: Backup & Restore -> Snapshot + Restore Drill Dry Run + WAL Checkpoint
      await page.getByRole('button', { name: 'Backup & Restore' }).click();
      await waitForStableUi(page, 250);
      await page.getByRole('button', { name: 'Create Online SQLite Backup' }).click();
      await page.getByText(/Verified online SQLite backup created/i).waitFor({ state: 'visible' });
      await page.getByRole('button', { name: 'Run Restore Drill (Dry Run)' }).click();
      await page.getByText(/Dry-run restore drill PASSED/i).waitFor({ state: 'visible' });
      await page.getByRole('button', { name: 'Checkpoint WAL' }).click();
      await page.getByText(/WAL checkpoint \(TRUNCATE\) completed/i).waitFor({ state: 'visible' });

      // Tab 5: Data Retention -> Dry Run Preview
      await page.getByRole('button', { name: 'Data Retention' }).click();
      await waitForStableUi(page, 200);
      await page.getByRole('button', { name: 'Preview Eligible Deletions (Dry Run)' }).click();
      await page.getByText(/Retention dry-run evaluated/i).waitFor({ state: 'visible' });

      // Tab 6: About -> verify v1.13.0 (BUILD 17) + emblem
      await page.getByRole('button', { name: 'About' }).click();
      await waitForStableUi(page, 200);
      assert.ok((await page.locator('main').textContent())?.includes('Version 1.13.0 (BUILD 17)'));
    });

    // =========================================================================
    // RE-CAPTURE POPULATED 02_Admin_Dashboard AT 1366x768 + MAKER-CHECKER PAYROLL RELEASE
    // =========================================================================
    await test('02_Admin_Dashboard (populated) + Profile Sign Out + Maker-Checker Finalize -> Finance Sign-Off -> Release', async () => {
      assert.ok(page);
      await navTo(page, 'Dashboard');
      await page.getByRole('heading', { name: 'Admin Dashboard' }).waitFor({ state: 'visible' });
      await auditScreen(page, '02_Admin_Dashboard', 'desktop-1366x768', findings);

      // Sign out via Profile dropdown
      await page.getByRole('button', { name: 'Account profile menu' }).click();
      await page.getByRole('menuitem', { name: 'Sign Out' }).click();
      await page.getByRole('heading', { name: 'Welcome Back!' }).waitFor({ state: 'visible' });

      // Log in as checker_admin and Finalize -> Finance Sign-Off -> Release the computed Payroll run!
      await page.getByLabel('Username or Email').fill('checker_admin');
      await page.getByLabel('Password', { exact: true }).fill(CHECKER_ADMIN_PW);
      await page.getByRole('button', { name: 'Sign In', exact: true }).click();
      await page.getByRole('heading', { name: 'Admin Dashboard' }).waitFor({ state: 'visible' });

      await navTo(page, 'Payroll');
      const modal = page.locator('[role="dialog"]');
      await page.getByRole('button', { name: 'Finalize Payroll' }).click();
      await modal.getByRole('button', { name: /Confirm|Finalize/i }).click();
      await modal.waitFor({ state: 'hidden' });
      await page.getByText(/finalized and locked/i).waitFor({ state: 'visible' });

      await page.getByRole('button', { name: 'Finance Sign-Off' }).click();
      await modal.locator('input[type="text"]').nth(0).fill('RSU-FIN-RELEASE-2026-E2E');
      await modal.getByRole('button', { name: /Record Finance Sign-Off|Confirm/i }).click();
      await modal.waitFor({ state: 'hidden' });
      await page.getByText(/Finance sign-off recorded/i).waitFor({ state: 'visible' });

      await page.getByRole('button', { name: 'Release Payroll' }).click();
      await modal.getByRole('button', { name: /Confirm|Release/i }).click();
      await modal.waitFor({ state: 'hidden' });
      await page.getByText(/Payroll run .* released/i).waitFor({ state: 'visible' });
    });

    // =========================================================================
    // MULTI-VIEWPORT RESPONSIVE & WCAG SWEEP: 1920×1080, 768×1024 (Tablet), 390×844 (Mobile)
    // =========================================================================
    const responsiveViewports = [
      { name: 'desktop-1920x1080', width: 1920, height: 1080 },
      { name: 'tablet-768x1024', width: 768, height: 1024 },
      { name: 'mobile-390x844', width: 390, height: 844 },
    ] as const;

    for (const vp of responsiveViewports) {
      await test(`Responsive & WCAG Sweep (${vp.name}) — Key Modules & Navigation Drawer`, async () => {
        assert.ok(page);
        await page.setViewportSize({ width: vp.width, height: vp.height });
        await waitForStableUi(page, 200);

        const screensToCheck: Array<{ nav: string; id: string }> = [
          { nav: 'Dashboard', id: '02_Admin_Dashboard' },
          { nav: 'Employees', id: '04_Employees_Management' },
          { nav: 'Attendance', id: '05_Attendance_Records' },
          { nav: 'Payroll', id: '08_Payroll_Processing' },
          { nav: 'Reports', id: '09_Reports' },
          { nav: 'Devices (Kiosk)', id: '15_Devices_Kiosk' },
          { nav: 'System Settings', id: '16_System_Settings' },
        ];

        for (const sc of screensToCheck) {
          await navTo(page, sc.nav);
          await auditScreen(page, sc.id, vp.name, findings);
        }

        // Also verify Mobile Drawer Escape behavior on mobile viewport
        if (vp.width < 1024) {
          await page.getByRole('button', { name: 'Toggle sidebar navigation' }).click();
          const drawer = page.locator('div[role="dialog"][aria-label="Mobile navigation menu"]');
          await drawer.waitFor({ state: 'visible' });
          await page.keyboard.press('Escape');
          await drawer.waitFor({ state: 'hidden' });
        }
      });
    }

    // Verify Login screen at 1920x1080, 768x1024, and 390x844
    await test('Responsive Login Screen Audit (1920x1080, 768x1024, 390x844)', async () => {
      assert.ok(page);
      await page.getByRole('button', { name: 'Account profile menu' }).click();
      await page.getByRole('menuitem', { name: 'Sign Out' }).click();
      await page.getByRole('heading', { name: 'Welcome Back!' }).waitFor({ state: 'visible' });

      for (const vp of responsiveViewports) {
        await page.setViewportSize({ width: vp.width, height: vp.height });
        await auditScreen(page, '01_Login', vp.name, findings);
      }
    });

    // Verify zero blocking runtime/console errors across the entire 16-screen journey
    await test('Zero Uncaught Page Errors & Zero Blocking Console Errors Across All 16 Screens', async () => {
      assert.deepEqual(pageErrors, [], `Uncaught page errors: ${pageErrors.join(' | ')}`);
      assert.deepEqual(blockingConsoleErrors, [], `Blocking console errors: ${blockingConsoleErrors.join(' | ')}`);
    });
  } finally {
    if (context) await context.close().catch(() => {});
    if (browser) await browser.close().catch(() => {});
    realtimeHub.closeAll();
    server.closeAllConnections?.();
    await new Promise<void>((resolve) => server.close(() => resolve()));
    closeDatabaseSafely(db);
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }

  // Write machine-readable audit report alongside screenshots
  const manifestPath = path.join(SCREENSHOT_ROOT, 'e2e-audit-summary.json');
  fs.writeFileSync(
    manifestPath,
    JSON.stringify(
      {
        executedAt: new Date().toISOString(),
        passed,
        failed,
        pageErrors,
        blockingConsoleErrors,
        screenshotsCaptured: findings.length,
        findings,
      },
      null,
      2
    ),
    'utf8'
  );

  console.log(`\nPlaywright Browser E2E Summary: ${passed} passed, ${failed} failed, ${findings.length} audited screenshots saved in test-results/e2e-screenshots/`);
  if (failed > 0) {
    process.exit(1);
  }
}

run().catch((err) => {
  console.error('FATAL Playwright E2E runner error:', err);
  process.exit(1);
});
