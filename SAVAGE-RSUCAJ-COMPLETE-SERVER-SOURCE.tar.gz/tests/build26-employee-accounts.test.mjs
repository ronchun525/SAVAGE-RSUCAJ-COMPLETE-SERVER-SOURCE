import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveEmployeeAccountLink } from '../server/employeeAccounts.ts';

const employee = { id: 41, employee_code: 'EMP-041', full_name: 'Test Employee', department_id: 3, status: 'Active' };
function dbWith({ profile = employee, linked = undefined } = {}) {
  return { prepare(sql) {
    if (sql.includes('FROM employees WHERE id')) return { get(id) { assert.equal(id, 41); return profile; } };
    if (sql.includes('FROM users WHERE employee_id')) return { get(id, excluded) { assert.equal(id, 41); assert.ok(Number.isInteger(excluded)); return linked?.id === excluded ? undefined : linked; } };
    throw Error('Unexpected SQL: '+sql);
  }};
}
test('employee account requires an integer linked employee id', () => {
  for(const val of [undefined, null, '', '1.5', 'abc', -5, 0, '9007199254740992']) {
    const result = resolveEmployeeAccountLink(dbWith(), val);
    assert.equal(result.ok, false);
    assert.equal(result.code, 'EMPLOYEE_LINK_REQUIRED');
  }
});
test('employee account link resolves existing active personnel and returns authoritative identity', () => {
  const result = resolveEmployeeAccountLink(dbWith(), 41);
  assert.equal(result.ok, true);
  assert.equal(result.employee.full_name, employee.full_name);
  assert.equal(result.employee.department_id, 3);
});
test('missing record rejects with 404', () => {
  const db = { prepare(sql) { return { get() { return undefined; } }; } };
  const result = resolveEmployeeAccountLink(db, 41);
  assert.equal(result.ok, false);
  assert.equal(result.status, 404);
});
test('inactive employee cannot receive a login', () => {
  const result = resolveEmployeeAccountLink(dbWith({ profile: {...employee, status:'Inactive'} }), 41);
  assert.equal(result.ok, false);
  assert.equal(result.code, 'EMPLOYEE_INACTIVE');
});
test('already-linked employee cannot get another employee portal account', () => {
  const result = resolveEmployeeAccountLink(dbWith({linked:{id:8}}), 41);
  assert.equal(result.ok, false);
  assert.equal(result.status, 409);
});
test('account updates can retain their own employee link', () => {
  const result = resolveEmployeeAccountLink(dbWith({linked:{id:8}}), 41, 8);
  assert.equal(result.ok, true);
});
