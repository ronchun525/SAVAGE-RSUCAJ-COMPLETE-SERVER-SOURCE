import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const login = fs.readFileSync(path.join(root, 'src/components/LoginView.tsx'), 'utf8');
const logo = fs.readFileSync(path.join(root, 'src/components/SavageLogo.tsx'), 'utf8');
const app = fs.readFileSync(path.join(root, 'src/App.tsx'), 'utf8');

test('admin login excludes Google SSO control and separator', () => {
  assert.doesNotMatch(login, /Sign in with Google|Google OAuth|googleSsoConfigured|my-5 flex items-center gap-3/);
});

test('admin login excludes Employee Portal navigation control', () => {
  assert.doesNotMatch(login, /Employee Portal \(Mobile Self-Service\)/);
  assert.doesNotMatch(login, /onClick=\{onOpenEmployeePortal\}/);
  assert.match(app, /onOpenEmployeePortal=/); // Existing caller remains compatible.
});

test('local admin username-password login and password recovery remain', () => {
  assert.match(login, /\/api\/auth\/login/);
  assert.match(login, /handleSubmit/);
  assert.match(login, /autoComplete="username"/);
  assert.match(login, /autoComplete="current-password"/);
  assert.match(login, /rememberMe/);
  assert.match(login, /forgot-password/);
});

test('the dedicated employee portal route remains', () => {
  assert.match(app, /path\.startsWith\('\/employee'\)/);
  assert.match(app, /<EmployeeEntryFlow/);
});

test('admin logo references bundled original transparent PNG without opaque wrapper', () => {
  assert.match(logo, /Savage-Rsucaj_Attendance_Shield_bca5b40c\.png/);
  assert.doesNotMatch(logo, /mix-blend-multiply|bg-white p-1\.5/);
  const file = path.join(root, 'public/assets/aistudio/Savage-Rsucaj_Attendance_Shield_bca5b40c.png');
  const data = fs.readFileSync(file);
  assert.equal(data.subarray(1, 4).toString('ascii'), 'PNG');
  assert.equal(data.readUInt8(25), 6, 'PNG must be RGBA');
});
