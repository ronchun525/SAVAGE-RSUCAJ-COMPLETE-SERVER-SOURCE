import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (path) => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const modal = read('src/components/ModuleFrame.tsx');
const form = read('src/components/EmployeesView.tsx');
const api = read('server/api.ts');
const employeeRoute = api.split("router.post('/employees',")[1]?.split("router.put('/employees/:id',")[0] ?? '';

test('Modal focus effect remains stable across keystroke rerenders', () => {
  assert.match(modal, /const onCloseRef = useRef\(onClose\)/);
  assert.match(modal, /onCloseRef\.current\(\)/);
  assert.match(modal, /\}, \[open\]\);/);
  assert.doesNotMatch(modal, /\}, \[open, onClose\]\);/);
});

test('Employee form shows optional portal password controls without breaking personnel-only creation', () => {
  assert.match(form, /setCreateLoginWithEmployee\(false\)/);
  assert.match(form, /Create Employee Portal Login \(optional\)/);
  assert.match(form, /Temporary Password \*/);
  assert.match(form, /Confirm Temporary Password \*/);
  assert.match(form, /showNewEmployeeLoginPassword/);
  assert.match(form, /minLength=\{10\}/);
  assert.match(form, /setCreateLoginWithEmployee\(Boolean\(password\)\)/);
});

test('Employee password mismatch and API errors are shown inside the modal', () => {
  assert.match(form, /newEmployeeLogin\.password !== newEmployeeLogin\.confirmPassword/);
  assert.match(form, /employeeFormError &&/);
  assert.match(form, /role="alert"/);
});

test('Account creation is optional for employees without account-management permissions', () => {
  assert.match(form, /!editing && canCreateAccounts &&/);
  assert.match(form, /portal_account: createLoginWithEmployee \?/);
  assert.match(employeeRoute, /users:manage/);
});

test('Employee + login creation uses a single transaction and passwords are salted/hashed', () => {
  assert.match(employeeRoute, /db\.transaction\(\(\) =>/);
  assert.match(employeeRoute, /hashPassword\(newAccount\.password\)/);
  assert.match(employeeRoute, /validatePasswordStrength\(password\)/);
  assert.match(employeeRoute, /must_change_password, is_active/);
  assert.match(employeeRoute, /VALUES \(\?, \?, \?, 'Employee', \?, \?, \?, \?, 1, 1\)/);
});

test('Creating an employee account rejects duplicate accounts and inactive employees', () => {
  assert.match(employeeRoute, /Cannot provision an account for an inactive employee/);
  assert.match(employeeRoute, /SELECT id FROM users WHERE lower\(username\) = lower\(\?\) OR lower\(email\) = lower\(\?\)/);
  assert.match(employeeRoute, /Employee ID, portal username, or email already exists/);
});
