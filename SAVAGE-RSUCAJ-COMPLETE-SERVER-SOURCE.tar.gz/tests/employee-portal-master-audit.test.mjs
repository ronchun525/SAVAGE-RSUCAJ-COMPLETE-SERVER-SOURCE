/**
 * SAVAGE-RSUCAJ — MASTER PROMPT 02 COMPLETE FUNCTIONAL, SECURITY, RESPONSIVE & VISUAL AUDIT SUITE
 *
 * Audits all 18 Employee Portal screens against the real Express API, SQLite DB, RealtimeHub SSE,
 * and built production bundle in headless Chromium:
 * - AUDIT 01: Captures actual runtime PNG screenshots of all 18 screens when AUDIT_CAPTURE_DIR is set.
 * - AUDIT 02: Verifies every navigation path, Browser Back (History API), Sign Out, and Session Expiration.
 * - AUDIT 03: Verifies all 18 employee workflows including overnight-shift handling, live SSE attendance updates,
 *             DTR & Payslip PDF binary verification, leave/correction lifecycle, password change, and session revocation.
 * - AUDIT 04: Verifies frontend & backend security boundaries (Admin routes, official Time In/Out immutability,
 *             cross-employee isolation, leave/correction approval enforcement, logout invalidation, honest 2FA state).
 * - AUDIT 05: Verifies responsive layout (0px horizontal overflow, 0 broken images, 0 console/page errors)
 *             across ALL 18 screens on mobile (360x800, 393x852), tablet (768x1024), and desktop (1440x900).
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import { chromium } from 'playwright-core';
import { initDatabase, closeDatabaseSafely } from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import { RealtimeHub } from '../server/realtimeHub.ts';
import { hashPassword } from '../server/auth.ts';

function findBrowserExecutable() {
  const candidates = [
    process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,
    '/ms-playwright/chromium_headless_shell-1247/chrome-headless-shell-linux64/chrome-headless-shell',
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    '/usr/bin/google-chrome',
  ].filter(Boolean);
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

class CookieClient {
  constructor(baseUrl) {
    this.baseUrl = baseUrl;
    this.cookies = new Map();
    this.csrfToken = null;
  }

  captureSetCookies(res) {
    const list = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : [];
    for (const entry of list) {
      const pair = entry.split(';')[0];
      const idx = pair.indexOf('=');
      if (idx > 0) {
        const name = pair.slice(0, idx).trim();
        const val = pair.slice(idx + 1).trim();
        if (!val) this.cookies.delete(name);
        else this.cookies.set(name, val);
      }
    }
  }

  cookieHeader() {
    return Array.from(this.cookies.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join('; ');
  }

  async request(method, urlPath, body) {
    const headers = {};
    const cookie = this.cookieHeader();
    if (cookie) headers.cookie = cookie;
    if (body !== undefined) headers['content-type'] = 'application/json';
    if (this.csrfToken && !['GET', 'HEAD', 'OPTIONS'].includes(method.toUpperCase())) {
      headers['x-csrf-token'] = this.csrfToken;
    }
    const res = await fetch(`${this.baseUrl}${urlPath}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    this.captureSetCookies(res);
    const ct = res.headers.get('content-type') || '';
    const data = ct.includes('application/json') ? await res.json() : await res.arrayBuffer();
    if (data && typeof data === 'object' && !ArrayBuffer.isView(data) && !(data instanceof ArrayBuffer) && data.csrfToken) {
      this.csrfToken = data.csrfToken;
    }
    return { status: res.status, headers: res.headers, data };
  }
}

function getManilaDateIso(nowMs) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Manila',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date(nowMs));
  const y = parts.find((p) => p.type === 'year')?.value;
  const m = parts.find((p) => p.type === 'month')?.value;
  const d = parts.find((p) => p.type === 'day')?.value;
  return `${y}-${m}-${d}`;
}

test('Master Prompt 02 Audit: Complete Security, Overnight Shift, Realtime SSE, Browser Back, Session Expiration, All-18 Responsive & Screenshot Capture', async (t) => {
  const execPath = findBrowserExecutable();
  assert.ok(execPath, 'Chromium executable must be available for browser audit');

  const distDir = path.resolve(process.cwd(), 'dist');
  assert.ok(fs.existsSync(path.join(distDir, 'index.html')), 'dist/index.html must exist');

  const captureDir = process.env.AUDIT_CAPTURE_DIR || '';
  if (captureDir) {
    fs.mkdirSync(captureDir, { recursive: true });
  }

  const prevSecret = process.env.SESSION_SECRET;
  process.env.SESSION_SECRET = crypto.randomBytes(48).toString('hex');

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-master-audit-'));
  const dbPath = path.join(tmpDir, 'audit.db');
  const adminPass = `Admin!${crypto.randomBytes(8).toString('hex')}9A`;
  const emp1Pass = `EmpOne!${crypto.randomBytes(8).toString('hex')}7Z`;
  const emp1NewPass = `EmpNew!${crypto.randomBytes(8).toString('hex')}8Q`;
  const emp2Pass = `EmpTwo!${crypto.randomBytes(8).toString('hex')}5X`;

  // Controlled clock: 2026-11-22 02:30:00 Asia/Manila (18:30 UTC on 2026-11-21)
  // This lets us authentically verify overnight-shift date handling!
  let currentNowMs = Date.parse('2026-11-21T18:30:00.000Z');
  const todayIso = getManilaDateIso(currentNowMs); // 2026-11-22
  const yesterdayIso = '2026-11-21';

  const db = initDatabase(dbPath, {
    mode: 'development',
    seedDemoData: false,
    initialAdmin: {
      username: 'sysadmin',
      email: 'sysadmin@rsucaj.edu.ph',
      password: adminPass,
    },
  });

  const deptId = Number(
    db.prepare(`INSERT INTO departments (code, name, head_name) VALUES ('ICT', 'ICT Office', 'ICT Head')`).run().lastInsertRowid
  );
  const posId = Number(
    db.prepare(`INSERT INTO positions (code, name, type, base_salary, allowance) VALUES ('ITS', 'IT Staff', 'Regular', 22000, 3000)`).run().lastInsertRowid
  );
  const dayShiftId = Number(
    db.prepare(`INSERT INTO shifts (name, time_in, time_out, grace_minutes, rest_days, status) VALUES ('Regular Day', '08:00', '17:00', 15, 'Saturday,Sunday', 'Active')`).run().lastInsertRowid
  );
  const nightShiftId = Number(
    db.prepare(`INSERT INTO shifts (name, time_in, time_out, grace_minutes, rest_days, status) VALUES ('Night Security', '22:00', '06:00', 15, 'Sunday', 'Active')`).run().lastInsertRowid
  );

  // Employee 1: Regular Day Shift (RSU-0001)
  const emp1Id = Number(
    db.prepare(
      `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status, hired_date, monthly_salary, monthly_allowance)
       VALUES ('RSU-0001', 'Juan Dela Cruz', 'juan.delacruz@rsucaj.edu.ph', ?, ?, ?, 'Active', '2024-01-15', 22000, 3000)`
    ).run(deptId, posId, dayShiftId).lastInsertRowid
  );
  const h1 = hashPassword(emp1Pass);
  const emp1UserId = Number(
    db.prepare(
      `INSERT INTO users (username, email, full_name, password_hash, salt, role, department_id, employee_id, must_change_password, is_active)
       VALUES ('jdelacruz', 'juan.delacruz@rsucaj.edu.ph', 'Juan Dela Cruz', ?, ?, 'Employee', ?, ?, 0, 1)`
    ).run(h1.hash, h1.salt, deptId, emp1Id).lastInsertRowid
  );

  // Employee 2: Overnight Shift (RSU-0002) with open shift from yesterday (22:05 Time In, no Time Out yet)
  const emp2Id = Number(
    db.prepare(
      `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status, hired_date, monthly_salary, monthly_allowance)
       VALUES ('RSU-0002', 'Maria Santos', 'maria.santos@rsucaj.edu.ph', ?, ?, ?, 'Active', '2024-03-01', 20000, 2000)`
    ).run(deptId, posId, nightShiftId).lastInsertRowid
  );
  const h2 = hashPassword(emp2Pass);
  db.prepare(
    `INSERT INTO users (username, email, full_name, password_hash, salt, role, department_id, employee_id, must_change_password, is_active)
     VALUES ('msantos', 'maria.santos@rsucaj.edu.ph', 'Maria Santos', ?, ?, 'Employee', ?, ?, 0, 1)`
  ).run(h2.hash, h2.salt, deptId, emp2Id);

  // Seed historical attendance for Employee 1 (so Screen 07 has rich rows)
  db.prepare(
    `INSERT INTO attendance_records (employee_id, date, time_in, time_out, work_hours, status, device_name, remarks)
     VALUES (?, '2026-11-18', '08:02', '17:05', '8h 03m', 'Present', 'Campus Main Kiosk', 'Face verified'),
            (?, '2026-11-19', '08:25', '17:00', '7h 35m', 'Late', 'Campus Main Kiosk', 'Face verified'),
            (?, '2026-11-20', NULL, NULL, '-', 'Absent', 'System', 'No punch')`
  ).run(emp1Id, emp1Id, emp1Id);

  // Seed open overnight shift for Employee 2 on yesterdayIso (2026-11-21)
  const emp2NightRecId = Number(
    db.prepare(
      `INSERT INTO attendance_records (employee_id, date, time_in, time_out, work_hours, status, device_name, remarks)
       VALUES (?, ?, '22:05', NULL, '-', 'Present', 'Night Gate Kiosk', 'Overnight Time In')`
    ).run(emp2Id, yesterdayIso).lastInsertRowid
  );

  // Seed released payroll run containing both employees (for cross-employee payslip isolation tests!)
  const runId = Number(
    db.prepare(
      `INSERT INTO payroll_runs (period_label, start_date, end_date, status, total_basic_pay, total_allowances, total_deductions, total_net_pay, employee_count, created_by)
       VALUES ('November 2026', '2026-11-01', '2026-11-30', 'Computed', 42000, 5000, 3070, 43930, 2, 'sysadmin')`
    ).run().lastInsertRowid
  );
  db.prepare(
    `INSERT INTO payroll_items (payroll_run_id, employee_id, days_present, days_late, days_absent, basic_pay, allowances, deductions, net_pay, prorated_basic_pay, gross_pay, tax_deduction, other_deductions)
     VALUES (?, ?, 20, 1, 1, 22000, 3000, 1570, 23430, 22000, 25000, 1500, 70),
            (?, ?, 21, 0, 0, 20000, 2000, 1500, 20500, 20000, 22000, 1400, 100)`
  ).run(runId, emp1Id, runId, emp2Id);
  db.prepare(`UPDATE payroll_runs SET status = 'Released', released_at = datetime('now') WHERE id = ?`).run(runId);

  // Seed an announcement notification so Screen 17 has rich real entries
  db.prepare(
    `INSERT INTO notifications (title, message, category, priority, is_read, action_module)
     VALUES ('System Announcement', 'Scheduled campus biometric server maintenance on Saturday at 10:00 PM.', 'System Announcement', 'Normal', 0, 'dashboard')`
  ).run();

  const realtimeHub = new RealtimeHub();
  const app = express();
  app.use('/api', createApiRouter(db, { realtimeHub, dbPath, nowProvider: () => currentNowMs }));
  app.use(express.static(distDir));
  app.use((req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(path.join(distDir, 'index.html'));
  });

  const server = await new Promise((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const addr = server.address();
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  const browser = await chromium.launch({
    executablePath: execPath,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });

  const pageErrors = [];
  const consoleErrors = [];

  try {
    // =========================================================================
    // PART A: AUDIT 04 SECURITY & AUDIT 03 OVERNIGHT SHIFT API VERIFICATION
    // =========================================================================
    await t.test('Audit 04 Security & RBAC Boundaries (Backend Enforcement)', async () => {
      const emp1Client = new CookieClient(baseUrl);
      const login1 = await emp1Client.request('POST', '/api/auth/login', {
        identifier: 'RSU-0001',
        password: emp1Pass,
      });
      assert.equal(login1.status, 200);
      assert.equal(login1.data.user.role, 'Employee');
      assert.equal(login1.data.user.employee_id, emp1Id);

      // 1. Admin-only routes must return 403 Forbidden
      for (const adminRoute of [
        '/api/dashboard',
        '/api/employees',
        '/api/devices',
        '/api/settings',
        '/api/audit-logs',
        '/api/payroll',
      ]) {
        const r = await emp1Client.request('GET', adminRoute);
        assert.equal(r.status, 403, `Employee must get 403 on ${adminRoute}, got ${r.status}`);
      }

      // 2. Employee cannot modify official Time In/Out
      const postAtt = await emp1Client.request('POST', '/api/attendance', {
        employee_id: emp1Id,
        date: todayIso,
        time_in: '08:00',
        status: 'Present',
      });
      assert.equal(postAtt.status, 403, 'Employee cannot POST /api/attendance');

      const delAtt = await emp1Client.request('DELETE', `/api/attendance/${emp2NightRecId}`);
      assert.equal(delAtt.status, 403, 'Employee cannot DELETE /api/attendance/:id');

      const recAtt = await emp1Client.request('POST', '/api/attendance/reconcile', { date: todayIso });
      assert.equal(recAtt.status, 403, 'Employee cannot POST /api/attendance/reconcile');

      // 3. Employee cannot read another employee's attendance or punch events
      const otherAtt = await emp1Client.request('GET', `/api/attendance?date=${yesterdayIso}&employee_id=${emp2Id}`);
      assert.equal(otherAtt.status, 200);
      assert.equal(
        otherAtt.data.data.filter((row) => row.employee_id === emp2Id).length,
        0,
        'GET /api/attendance must never return another employee rows'
      );
      const otherEvents = await emp1Client.request('GET', `/api/attendance/${emp2NightRecId}/events`);
      assert.equal(otherEvents.status, 403, 'Employee cannot read another employee punch events');

      // 4. Employee cannot access another employee's payslip JSON or PDF
      const otherSlip = await emp1Client.request('GET', `/api/payroll/${runId}/payslip/${emp2Id}`);
      assert.equal(otherSlip.status, 403, 'Employee cannot read another employee payslip JSON');
      const otherSlipPdf = await emp1Client.request('GET', `/api/payroll/${runId}/payslip/${emp2Id}/pdf`);
      assert.equal(otherSlipPdf.status, 403, 'Employee cannot download another employee payslip PDF');

      // Self payslip PDF must succeed and return real %PDF-1. binary
      const selfSlipPdf = await emp1Client.request('GET', `/api/payroll/${runId}/payslip/${emp1Id}/pdf`);
      assert.equal(selfSlipPdf.status, 200);
      assert.ok((selfSlipPdf.headers.get('content-type') || '').includes('application/pdf'));
      const pdfMagic = Buffer.from(selfSlipPdf.data).subarray(0, 5).toString('ascii');
      assert.equal(pdfMagic, '%PDF-', 'Payslip PDF must start with %PDF- magic header');

      // Self DTR PDF must succeed and return real %PDF-1. binary
      const selfDtrPdf = await emp1Client.request('GET', '/api/reports/my-dtr/export.pdf?month=2026-11');
      assert.equal(selfDtrPdf.status, 200);
      assert.equal(Buffer.from(selfDtrPdf.data).subarray(0, 5).toString('ascii'), '%PDF-');

      // 5. Employee cannot file leave for another employee or self-approve leave
      const otherLeave = await emp1Client.request('POST', '/api/leaves', {
        employee_id: emp2Id,
        leave_type: 'Vacation Leave',
        start_date: '2026-11-26',
        end_date: '2026-11-26',
        reason: 'Cross employee attempt',
      });
      assert.equal(otherLeave.status, 403, 'Employee cannot submit leave for another employee');

      const forgedLeave = await emp1Client.request('POST', '/api/leaves', {
        leave_type: 'Vacation Leave',
        start_date: '2026-11-26',
        end_date: '2026-11-26',
        status: 'Approved',
        reason: 'Testing approval bypass enforcement',
      });
      assert.equal(forgedLeave.status, 201);
      assert.equal(forgedLeave.data.status, 'Pending', 'Forged status=Approved must be ignored and stored as Pending');

      const approveLeave = await emp1Client.request('PATCH', `/api/leaves/${forgedLeave.data.id}/status`, {
        status: 'Approved',
      });
      assert.equal(approveLeave.status, 403, 'Employee cannot approve own leave');

      // Cancel the test leave cleanly
      const cancelLeave = await emp1Client.request('POST', `/api/leaves/${forgedLeave.data.id}/cancel`, {
        cancel_reason: 'Cleanup after security test',
      });
      assert.equal(cancelLeave.status, 200);

      // 6. Employee cannot file correction for another employee or self-approve correction
      const otherCorr = await emp1Client.request('POST', '/api/corrections', {
        employee_id: emp2Id,
        attendance_date: '2026-11-18',
        request_type: 'Time Out',
        requested_time: '17:00',
        reason: 'Cross employee correction attempt',
      });
      assert.equal(otherCorr.status, 403, 'Employee cannot submit correction for another employee');

      const selfCorr = await emp1Client.request('POST', '/api/corrections', {
        attendance_date: '2026-11-19',
        request_type: 'Time Out',
        requested_time: '17:05',
        status: 'Approved',
        reason: 'Testing correction approval enforcement',
      });
      assert.equal(selfCorr.status, 201);
      assert.equal(selfCorr.data.status, 'Pending');

      const approveCorr = await emp1Client.request('PATCH', `/api/corrections/${selfCorr.data.id}/status`, {
        status: 'Approved',
      });
      assert.equal(approveCorr.status, 403, 'Employee cannot approve own correction');

      // 7. Honest 2FA capability flag on Account Security
      const sec = await emp1Client.request('GET', '/api/employee/security/sessions');
      assert.equal(sec.status, 200);
      assert.equal(sec.data.twoFactorSupported, false);
      assert.ok(typeof sec.data.twoFactorNotice === 'string' && sec.data.twoFactorNotice.length > 10);

      // 8. Logout invalidates session cookie
      const logoutRes = await emp1Client.request('POST', '/api/auth/logout');
      assert.equal(logoutRes.status, 200);
      const afterLogout = await emp1Client.request('GET', '/api/employee/today-attendance');
      assert.equal(afterLogout.status, 401, 'Logged-out session must be rejected with 401');
    });

    await t.test('Audit 03 Overnight-Shift Date Handling (API + UI)', async () => {
      const emp2Client = new CookieClient(baseUrl);
      const login2 = await emp2Client.request('POST', '/api/auth/login', {
        identifier: 'RSU-0002',
        password: emp2Pass,
      });
      assert.equal(login2.status, 200);
      const today2 = await emp2Client.request('GET', '/api/employee/today-attendance');
      assert.equal(today2.status, 200);
      assert.equal(today2.data.calendar_date, todayIso);
      assert.equal(today2.data.date, yesterdayIso, 'Open overnight shift from yesterday must remain active after midnight');
      assert.equal(today2.data.active_prior_shift, true);
      assert.equal(today2.data.attendance.time_in, '22:05');
      assert.equal(today2.data.read_only, true);
      assert.equal(today2.data.allow_manual_punch, false);
      await emp2Client.request('POST', '/api/auth/logout');
    });

    // =========================================================================
    // PART B: BROWSER E2E AUDIT — ALL 18 SCREENS, SCREENSHOTS, BACK NAV, SSE,
    //         PASSWORD CHANGE, SESSION EXPIRATION, AND ALL-18 RESPONSIVE CHECK
    // =========================================================================
    await t.test('Audit 01, 02, 03, 05: Full 18-Screen Browser Walkthrough, Screenshots, Browser Back, Live SSE, Session Expiry & Responsive Matrix', async () => {
      const context = await browser.newContext({ viewport: { width: 393, height: 852 } });
      const page = await context.newPage();
      page.on('pageerror', (err) => pageErrors.push(err.message));
      page.on('console', (msg) => {
        if (msg.type() === 'error') {
          const text = msg.text();
          // Ignore intentional 401s when testing unauthenticated / expired session transitions
          if (!text.includes('401') && !text.includes('Failed to load resource')) {
            consoleErrors.push(text);
          }
        }
      });

      const captureScreen = async (filename) => {
        if (!captureDir) return;
        await page.waitForTimeout(120);
        await page.screenshot({ path: path.join(captureDir, filename), fullPage: false });
      };

      const assertViewportClean = async (label, checkWidths = [393, 360, 768, 1440]) => {
        for (const w of checkWidths) {
          const h = w === 1440 ? 900 : w === 768 ? 1024 : w === 360 ? 800 : 852;
          await page.setViewportSize({ width: w, height: h });
          await page.waitForTimeout(45);
          const m = await page.evaluate(() => {
            const imgs = Array.from(document.querySelectorAll('img'));
            const brokenImgs = imgs.filter((img) => !img.complete || img.naturalWidth === 0).length;
            const zeroSizedLogos = imgs.filter((img) => {
              const r = img.getBoundingClientRect();
              return img.offsetParent !== null && (r.width === 0 || r.height === 0);
            }).length;
            const visibleButtons = Array.from(document.querySelectorAll('button')).filter(
              (btn) => btn.offsetParent !== null
            );
            const namelessButtons = visibleButtons.filter((btn) => {
              const text = (btn.textContent || '').trim();
              const aria = (btn.getAttribute('aria-label') || btn.getAttribute('title') || '').trim();
              return !text && !aria;
            }).length;
            const visibleControls = Array.from(
              document.querySelectorAll('input:not([type="hidden"]):not(.sr-only), select, textarea')
            ).filter((el) => el.offsetParent !== null);
            const unlabeledControls = visibleControls.filter((el) => {
              const id = el.getAttribute('id');
              const hasLabel = id ? Boolean(document.querySelector(`label[for="${id}"]`)) : false;
              const hasAria = Boolean(
                el.getAttribute('aria-label') ||
                  el.getAttribute('aria-labelledby') ||
                  el.getAttribute('placeholder')
              );
              return !hasLabel && !hasAria;
            }).length;
            return {
              lang: document.documentElement.lang,
              scrollWidth: document.documentElement.scrollWidth,
              innerWidth: window.innerWidth,
              brokenImgs,
              zeroSizedLogos,
              namelessButtons,
              unlabeledControls,
            };
          });
          assert.equal(m.lang, 'en', `Missing <html lang="en"> on ${label}`);
          assert.ok(
            m.scrollWidth <= m.innerWidth + 1,
            `Horizontal overflow on ${label} @ ${w}x${h}: scrollWidth=${m.scrollWidth} > innerWidth=${m.innerWidth}`
          );
          assert.equal(m.brokenImgs, 0, `Broken image on ${label} @ ${w}x${h}`);
          assert.equal(m.zeroSizedLogos, 0, `Zero-sized logo on ${label} @ ${w}x${h}`);
          assert.equal(m.namelessButtons, 0, `Nameless visible button on ${label} @ ${w}x${h}`);
          assert.equal(m.unlabeledControls, 0, `Unlabeled visible form control on ${label} @ ${w}x${h}`);
        }
        // Restore standard mobile 393x852 for subsequent flow steps
        await page.setViewportSize({ width: 393, height: 852 });
        await page.waitForTimeout(40);
      };

      // --- Screen 01: Splash Screen (hold first /api/auth/me briefly to inspect & capture Screen 01) ---
      let releaseAuthMe;
      const authMeHeld = new Promise((r) => {
        releaseAuthMe = r;
      });
      await page.route(
        '**/api/auth/me',
        async (route) => {
          await authMeHeld;
          await route.continue();
        },
        { times: 1 }
      );

      const gotoPromise = page.goto(`${baseUrl}/employee`, { waitUntil: 'domcontentloaded' });
      await page.getByText('SMART ATTENDANCE SYSTEM').waitFor({ timeout: 8000 });
      await captureScreen('01_splash.png');
      await assertViewportClean('Screen 01 Splash', [393, 360, 768, 1440]);
      releaseAuthMe();
      await gotoPromise;

      // --- Screen 02: Onboarding 1 ---
      await page.getByRole('heading', { name: 'Face Attendance' }).waitFor({ timeout: 8000 });
      await captureScreen('02_onboarding_1.png');
      await assertViewportClean('Screen 02 Onboarding 1');

      // --- Screen 03: Onboarding 2 + Browser Back test ---
      await page.getByRole('button', { name: 'Next' }).click();
      await page.getByRole('heading', { name: 'Track Your Records' }).waitFor();
      await captureScreen('03_onboarding_2.png');
      await assertViewportClean('Screen 03 Onboarding 2');

      // Test Browser Back from Slide 2 -> Slide 1
      await page.goBack();
      await page.getByRole('heading', { name: 'Face Attendance' }).waitFor({ timeout: 5000 });
      await page.getByRole('button', { name: 'Next' }).click();
      await page.getByRole('heading', { name: 'Track Your Records' }).waitFor();

      // --- Screen 04: Onboarding 3 ---
      await page.getByRole('button', { name: 'Next' }).click();
      await page.getByRole('heading', { name: 'Secure & Reliable' }).waitFor();
      await captureScreen('04_onboarding_3.png');
      await assertViewportClean('Screen 04 Onboarding 3');

      // --- Screen 05: Employee Login ---
      await page.getByRole('button', { name: 'Get Started' }).click();
      await page.getByPlaceholder('Employee ID').waitFor();
      await captureScreen('05_login.png');
      await assertViewportClean('Screen 05 Employee Login');

      // Sign in as Employee 1 (RSU-0001)
      await page.getByPlaceholder('Employee ID').fill('RSU-0001');
      await page.getByPlaceholder('Password').fill(emp1Pass);
      await page.getByRole('button', { name: 'Log In' }).click();

      // --- Screen 06: Today Dashboard + Live SSE Attendance Update ---
      await page.getByRole('heading', { name: 'Employee Dashboard' }).waitFor({ timeout: 8000 });
      await page.getByText('Not Recorded').waitFor({ timeout: 5000 });
      await captureScreen('06_today_dashboard.png');
      await assertViewportClean('Screen 06 Today Dashboard');

      // Trigger real-time attendance update via DB + realtimeHub (no manual reload!)
      db.prepare(
        `INSERT INTO attendance_records (employee_id, date, time_in, time_out, work_hours, status, device_name, remarks)
         VALUES (?, ?, '08:01', NULL, '-', 'Present', 'Campus Main Kiosk', 'Live SSE Kiosk Scan')`
      ).run(emp1Id, todayIso);
      realtimeHub.emitAttendanceUpdated({ employee_id: emp1Id, date: todayIso, source: 'kiosk' });
      await page.getByText('08:01 AM').waitFor({ timeout: 8000 });
      await captureScreen('06_today_dashboard_live_sse.png');

      // --- Screen 07: Attendance Records + Filtering + Monthly DTR Modal ---
      await page.getByRole('navigation', { name: 'Employee bottom navigation' }).getByRole('button', { name: 'Attendance' }).click();
      await page.getByRole('heading', { name: 'My Attendance' }).waitFor();
      await page.getByText('Nov 18, 2026').waitFor({ timeout: 5000 });
      await captureScreen('07_attendance.png');
      await assertViewportClean('Screen 07 Attendance Records');

      // Test Attendance Status Filtering
      await page.getByLabel('Filter attendance records').selectOption('Late');
      await page.getByText('Nov 19, 2026').waitFor();
      assert.equal(await page.getByText('Nov 18, 2026').count(), 0);
      await page.getByLabel('Filter attendance records').selectOption('All Records');

      // Test Monthly DTR preview modal
      await page.getByRole('button', { name: 'Monthly DTR' }).click();
      await page.getByRole('heading', { name: 'Monthly Daily Time Record (DTR)' }).waitFor({ timeout: 5000 });
      await page.getByRole('button', { name: 'Close DTR preview' }).click();

      // --- Screen 13: My Requests Tracking ---
      await page.getByRole('navigation', { name: 'Employee bottom navigation' }).getByRole('button', { name: 'Requests' }).click();
      await page.getByRole('heading', { name: 'My Requests' }).waitFor();
      await captureScreen('13_requests_tracking.png');
      await assertViewportClean('Screen 13 My Requests');

      // --- Screen 10: Leave Request Form -> Browser Back -> Reopen -> Submit -> Screen 11 ---
      await page.getByRole('button', { name: 'Leave Request', exact: true }).click();
      await page.getByRole('heading', { name: 'Leave Request' }).waitFor();
      await captureScreen('10_leave_form.png');
      await assertViewportClean('Screen 10 Leave Request Form');

      // Test Browser Back from Leave Form -> My Requests
      await page.goBack();
      await page.getByRole('heading', { name: 'My Requests' }).waitFor({ timeout: 5000 });

      // Reopen Leave Form and submit real leave request
      await page.getByRole('button', { name: 'Leave Request', exact: true }).click();
      await page.locator('#leave-start').fill('2026-11-24');
      await page.locator('#leave-end').fill('2026-11-25');
      await page.locator('#leave-reason').fill('Scheduled annual family vacation leave.');
      await page.getByRole('button', { name: 'Submit Request' }).click();
      await page.getByRole('heading', { name: 'Request Submitted!' }).waitFor({ timeout: 8000 });
      await captureScreen('11_leave_success.png');
      await assertViewportClean('Screen 11 Leave Request Success');
      await page.getByRole('button', { name: 'View Request' }).click();
      await page.getByRole('heading', { name: 'My Requests' }).waitFor();

      // --- Screen 12: Attendance Correction Form -> Full Day Doc Guard -> Submit -> Duplicate Rejection ---
      await page.getByRole('button', { name: 'Correction', exact: true }).click();
      await page.getByRole('heading', { name: 'Attendance Correction' }).waitFor();
      await captureScreen('12_correction_form.png');
      await assertViewportClean('Screen 12 Attendance Correction Form');

      // Verify Full Day requires supporting document in UI
      await page.locator('#corr-type').selectOption('Full Day');
      await page.locator('#corr-date').fill('2026-11-18');
      await page.locator('#corr-reason').fill('Official campus workshop requiring full day adjustment.');
      await page.getByRole('button', { name: 'Submit Correction' }).click();
      await page.getByText(/Supporting documentation \(attachment\) is required/i).waitFor({ timeout: 5000 });

      // Switch to Missing Time Out, submit first correction -> Screen 11 Success -> back to Screen 12 and attempt duplicate!
      await page.locator('#corr-type').selectOption('Time Out');
      await page.locator('#corr-date').fill('2026-11-18');
      await page.locator('#corr-time-out').fill('17:05');
      await page.locator('#corr-reason').fill('Forgot to scan out after evening department meeting.');
      await page.getByRole('button', { name: 'Submit Correction' }).click();
      await page.getByRole('heading', { name: 'Request Submitted!' }).waitFor({ timeout: 8000 });
      await page.getByRole('button', { name: 'Back to Requests' }).click();
      await page.getByRole('heading', { name: 'My Requests' }).waitFor({ timeout: 5000 });

      // Attempt duplicate Pending Time Out correction for same date -> backend rejects 409 DUPLICATE_PENDING_CORRECTION
      await page.getByRole('button', { name: 'Correction', exact: true }).click();
      await page.locator('#corr-type').selectOption('Time Out');
      await page.locator('#corr-date').fill('2026-11-18');
      await page.locator('#corr-time-out').fill('17:10');
      await page.locator('#corr-reason').fill('Duplicate correction attempt for same date.');
      await page.getByRole('button', { name: 'Submit Correction' }).click();
      await page.getByText(/already exists for 2026-11-18/i).waitFor({ timeout: 5000 });

      await page.goBack();
      await page.getByRole('heading', { name: 'My Requests' }).waitFor({ timeout: 5000 });

      // --- Screen 08: My Payslips -> Screen 14: Payslip Details -> Browser Back ---
      await page.getByRole('navigation', { name: 'Employee bottom navigation' }).getByRole('button', { name: 'Payslips' }).click();
      await page.getByRole('heading', { name: 'My Payslips' }).waitFor();
      await page.getByText('Payslip – November 2026').waitFor({ timeout: 5000 });
      await captureScreen('08_payslips.png');
      await assertViewportClean('Screen 08 My Payslips');

      await page.getByText('Payslip – November 2026').click();
      await page.getByRole('heading', { name: 'Payslip Details' }).waitFor();
      await page.getByText('Net Pay').waitFor();
      await captureScreen('14_payslip_details.png');
      await assertViewportClean('Screen 14 Payslip Details');

      // Browser Back from Payslip Details -> My Payslips
      await page.goBack();
      await page.getByRole('heading', { name: 'My Payslips' }).waitFor({ timeout: 5000 });

      // --- Live Realtime employee:notification SSE Delivery + Screen 17 Read Persistence ---
      // Admin approves Employee 1's newly filed leave request -> SSE pushes live notification WITHOUT page reload
      db.prepare(`UPDATE users SET must_change_password = 0 WHERE username = 'sysadmin'`).run();
      const adminClient = new CookieClient(baseUrl);
      const adminLogin = await adminClient.request('POST', '/api/auth/login', {
        identifier: 'sysadmin',
        password: adminPass,
      });
      assert.equal(adminLogin.status, 200, 'Admin login must succeed');
      const pendingLeaveRow = db
        .prepare(`SELECT id FROM leaves WHERE employee_id = ? AND status = 'Pending' ORDER BY id DESC LIMIT 1`)
        .get(emp1Id);
      assert.ok(pendingLeaveRow, 'Expected Employee 1 pending leave row in DB');
      const approveRes = await adminClient.request('PATCH', `/api/leaves/${pendingLeaveRow.id}/status`, {
        status: 'Approved',
        reviewer_notes: 'Approved in live SSE audit',
      });
      assert.equal(approveRes.status, 200, 'Admin approval must succeed');

      // Wait briefly for live employee:notification SSE refresh, then open Notifications and verify approval appears + mark read persists
      await page.waitForTimeout(450);
      await page.getByRole('button', { name: /Open notifications/i }).click();
      await page.getByRole('heading', { name: 'Notifications' }).waitFor();
      await page.getByText(/Approved/i).first().waitFor({ timeout: 6000 });
      await captureScreen('17_notifications.png');
      await assertViewportClean('Screen 17 Notifications');

      // Persist Mark All Read and confirm unread count stays 0 across a fresh server check
      const markAllBtn = page.getByRole('button', { name: /Mark all read/i });
      if ((await markAllBtn.count()) > 0) {
        await markAllBtn.click();
        await page.waitForTimeout(300);
      }
      const emp1ClientPre = new CookieClient(baseUrl);
      assert.equal(
        (await emp1ClientPre.request('POST', '/api/auth/login', { identifier: 'RSU-0001', password: emp1Pass })).status,
        200
      );
      const postReadNotif = await emp1ClientPre.request('GET', '/api/employee/notifications');
      assert.equal(postReadNotif.status, 200);
      assert.equal(postReadNotif.data.unreadCount, 0, 'Persisted mark-all-read must yield unreadCount=0');

      await page.goBack();
      await page.getByRole('heading', { name: 'My Payslips' }).waitFor({ timeout: 5000 });

      // --- Screen 09: My Profile ---
      await page.getByRole('navigation', { name: 'Employee bottom navigation' }).getByRole('button', { name: 'Profile' }).click();
      await page.getByRole('heading', { name: 'My Profile' }).waitFor();
      await captureScreen('09_profile.png');
      await assertViewportClean('Screen 09 My Profile');

      // --- Screen 15: Change Password (real password update!) + Browser Back ---
      await page.getByRole('button', { name: 'Change Password' }).click();
      await page.getByRole('heading', { name: 'Change Password' }).waitFor();
      await captureScreen('15_change_password.png');
      await assertViewportClean('Screen 15 Change Password');

      await page.locator('#cp-current').fill(emp1Pass);
      await page.locator('#cp-new').fill(emp1NewPass);
      await page.locator('#cp-confirm').fill(emp1NewPass);
      await page.getByRole('button', { name: 'Update Password' }).click();
      await page.getByText('Your password has been updated successfully.').waitFor({ timeout: 8000 });

      await page.goBack();
      await page.getByRole('heading', { name: 'My Profile' }).waitFor({ timeout: 5000 });

      // --- Screen 16: Account Security + Browser Back ---
      await page.getByRole('button', { name: 'Account Security' }).click();
      await page.getByRole('heading', { name: 'Account Security' }).waitFor();
      const twoFaBtn = page.getByRole('button', { name: /Two-Factor Authentication unavailable/i });
      assert.equal(await twoFaBtn.isDisabled(), true, '2FA button must be honestly disabled');
      await captureScreen('16_account_security.png');
      await assertViewportClean('Screen 16 Account Security');

      await page.goBack();
      await page.getByRole('heading', { name: 'My Profile' }).waitFor({ timeout: 5000 });

      // --- Screen 18: About + Browser Back ---
      await page.getByRole('button', { name: 'About System' }).click();
      await page.getByRole('heading', { name: 'About', exact: true }).waitFor();
      await page.getByText('A secure, reliable, and efficient attendance and payroll system').waitFor();
      await captureScreen('18_about.png');
      await assertViewportClean('Screen 18 About');

      await page.goBack();
      await page.getByRole('heading', { name: 'My Profile' }).waitFor({ timeout: 5000 });

      // --- Audit 02 & 04: Session Expiration Flow ---
      // Navigate to Today Dashboard, expire all sessions for emp1UserId in SQLite, click Refresh -> must redirect to Screen 05 with session expired notice!
      await page.getByRole('navigation', { name: 'Employee bottom navigation' }).getByRole('button', { name: 'Today' }).click();
      await page.getByRole('heading', { name: 'Employee Dashboard' }).waitFor();
      db.prepare(`DELETE FROM user_sessions WHERE user_id = ?`).run(emp1UserId);
      await page.getByRole('button', { name: 'Refresh today attendance' }).click();
      await page.getByPlaceholder('Employee ID').waitFor({ timeout: 8000 });
      await page.getByText('Your session has expired. Please sign in again.').waitFor({ timeout: 5000 });
      await captureScreen('05_login_session_expired.png');

      // Verify old password fails & new password succeeds after Screen 15 change!
      await page.getByPlaceholder('Employee ID').fill('RSU-0001');
      await page.getByPlaceholder('Password').fill(emp1Pass);
      await page.getByRole('button', { name: 'Log In' }).click();
      await page.getByRole('alert').waitFor({ timeout: 5000 });

      await page.getByPlaceholder('Password').fill(emp1NewPass);
      await page.getByRole('button', { name: 'Log In' }).click();
      await page.getByRole('heading', { name: 'Employee Dashboard' }).waitFor({ timeout: 8000 });

      // Capture desktop 1440x900 view for visual verification too
      await page.setViewportSize({ width: 1440, height: 900 });
      await page.waitForTimeout(100);
      await captureScreen('06_today_dashboard_desktop.png');

      // Sign Out confirmation -> returns cleanly to Screen 05
      await page.getByRole('complementary', { name: 'Employee desktop navigation' }).getByRole('button', { name: 'Sign Out' }).click();
      await page.getByRole('dialog').getByRole('button', { name: 'Sign Out' }).click();
      await page.getByPlaceholder('Employee ID').waitFor({ timeout: 8000 });

      // --- Verify Overnight Shift Banner visually for Employee 2 ---
      await page.setViewportSize({ width: 393, height: 852 });
      await page.getByPlaceholder('Employee ID').fill('RSU-0002');
      await page.getByPlaceholder('Password').fill(emp2Pass);
      await page.getByRole('button', { name: 'Log In' }).click();
      await page.getByRole('heading', { name: 'Employee Dashboard' }).waitFor({ timeout: 8000 });
      await page.getByText(/Showing active overnight shift from/i).waitFor({ timeout: 5000 });
      await page.getByText('10:05 PM').waitFor({ timeout: 5000 });

      // --- Verify Future-Date Correction Rejection & Supporting Document Persistence via Real API ---
      const emp1PostRotateClient = new CookieClient(baseUrl);
      assert.equal(
        (await emp1PostRotateClient.request('POST', '/api/auth/login', { identifier: 'RSU-0001', password: emp1NewPass })).status,
        200
      );
      const futureCorr = await emp1PostRotateClient.request('POST', '/api/corrections', {
        attendance_date: '2026-11-28',
        request_type: 'Time Out',
        requested_time: '17:00',
        reason: 'Attempting to file a correction for a future date.',
      });
      assert.equal(futureCorr.status, 400);
      assert.equal(futureCorr.data.code, 'FUTURE_DATE_NOT_ALLOWED');

      const fullDayDocCorr = await emp1PostRotateClient.request('POST', '/api/corrections', {
        attendance_date: '2026-11-17',
        request_type: 'Full Day',
        requested_time: '08:00',
        requested_time_out: '17:00',
        reason: 'Official campus training with travel memo attached.',
        attachment_name: 'campus_memo.txt',
        attachment_mime: 'text/plain',
        attachment_data: Buffer.from('RSU Cajidiocan Official Memo #2026-11').toString('base64'),
      });
      assert.equal(fullDayDocCorr.status, 201, 'Full Day correction with attachment must persist');
      const corrRowCheck = db
        .prepare(`SELECT attachment_name, attachment_mime FROM corrections WHERE id = ?`)
        .get(fullDayDocCorr.data.id);
      assert.equal(corrRowCheck.attachment_name, 'campus_memo.txt');

      assert.equal(pageErrors.length, 0, `Uncaught page errors: ${pageErrors.join('; ')}`);
      assert.equal(consoleErrors.length, 0, `Console errors: ${consoleErrors.join('; ')}`);
    });
  } finally {
    await browser.close();
    await new Promise((resolve) => server.close(resolve));
    realtimeHub.closeAll();
    closeDatabaseSafely(db);
    fs.rmSync(tmpDir, { recursive: true, force: true });
    if (prevSecret === undefined) {
      delete process.env.SESSION_SECRET;
    } else {
      process.env.SESSION_SECRET = prevSecret;
    }
  }
});
