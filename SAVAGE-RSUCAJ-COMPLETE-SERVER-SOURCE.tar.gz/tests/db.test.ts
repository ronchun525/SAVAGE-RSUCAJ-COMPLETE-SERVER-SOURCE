import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import Database from 'better-sqlite3';
import express from 'express';
import type { AddressInfo } from 'node:net';
import {
  checkpointWal,
  closeDatabaseSafely,
  collectTableRowCounts,
  CURRENT_SCHEMA_VERSION,
  DatabaseUnavailableError,
  DemoSeedForbiddenError,
  getDatabaseStatus,
  initDatabase,
  seedDemoDataExplicit,
} from '../server/db.ts';
import {
  createOnlineSqliteBackup,
  restoreSqliteBackup,
  runMigrationRollbackDryRun,
  verifyBackupArchive,
} from '../server/backup.ts';
import { createApiRouter } from '../server/api.ts';
import { hashPassword } from '../server/auth.ts';

interface DbTestResult {
  name: string;
  passed: boolean;
  error?: string;
}

const results: DbTestResult[] = [];

async function runDbTest(name: string, fn: () => void | Promise<void>) {
  try {
    await fn();
    results.push({ name, passed: true });
    console.log(`PASS  ${name}`);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    results.push({ name, passed: false, error: message });
    console.error(`FAIL  ${name}: ${message}`);
  }
}

const ADMIN_CREDS = {
  username: 'b06_admin',
  email: 'b06_admin@rsucaj.edu.ph',
  password: `DbTest!${crypto.randomBytes(6).toString('hex')}9A`,
};

async function main() {
  const rootTmp = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-b06-dbtests-'));

  try {
    // -------------------------------------------------------------------------
    // TEST 1: Fresh install in production mode -> ZERO seeded business data + forbids demo seeding
    // -------------------------------------------------------------------------
    await runDbTest('Fresh install in production mode has zero seeded business records and rejects seedDemoData', () => {
      const prevNodeEnv = process.env.NODE_ENV;
      const dbPath = path.join(rootTmp, 'prod-fresh.db');
      try {
        process.env.NODE_ENV = 'production';
        assert.throws(
          () =>
            initDatabase(dbPath, {
              mode: 'production',
              seedDemoData: true,
              initialAdmin: ADMIN_CREDS,
            }),
          DemoSeedForbiddenError
        );

        const db = initDatabase(dbPath, {
          mode: 'production',
          seedDemoData: false,
          initialAdmin: ADMIN_CREDS,
        });
        try {
          const counts = collectTableRowCounts(db);
          assert.equal(counts.users, 1, 'Only initial admin user should exist');
          assert.equal(counts.departments, 0);
          assert.equal(counts.positions, 0);
          assert.equal(counts.shifts, 0);
          assert.equal(counts.employees, 0);
          assert.equal(counts.attendance_records, 0);
          assert.equal(counts.devices, 0);
          assert.equal(counts.payroll_runs, 0);
          assert.equal(counts.notifications, 0);

          assert.throws(() => seedDemoDataExplicit(db, 'production'), DemoSeedForbiddenError);
        } finally {
          closeDatabaseSafely(db);
        }
      } finally {
        if (prevNodeEnv === undefined) delete process.env.NODE_ENV;
        else process.env.NODE_ENV = prevNodeEnv;
      }
    });

    // -------------------------------------------------------------------------
    // TEST 2: Explicit isolated demo seeding works ONLY in non-production mode
    // -------------------------------------------------------------------------
    await runDbTest('Explicit isolated demo seeding populates non-production sandbox DB without touching live data/', () => {
      const prevNodeEnv = process.env.NODE_ENV;
      const dbPath = path.join(rootTmp, 'demo-sandbox.db');
      try {
        process.env.NODE_ENV = 'development';
        const db = initDatabase(dbPath, {
          mode: 'demo',
          seedDemoData: true,
          initialAdmin: ADMIN_CREDS,
        });
        try {
          const counts = collectTableRowCounts(db);
          assert.equal(counts.employees, 18);
          assert.equal(counts.devices, 2);
          assert.ok(counts.attendance_records >= 18);
          assert.equal(counts.payroll_runs, 1);
          assert.equal(counts.notifications, 6);
        } finally {
          closeDatabaseSafely(db);
        }
      } finally {
        if (prevNodeEnv === undefined) delete process.env.NODE_ENV;
        else process.env.NODE_ENV = prevNodeEnv;
      }
    });

    // -------------------------------------------------------------------------
    // TEST 3: Non-destructive versioned migration on old BUILD 01/03 snapshot (001 -> 002 -> 003 -> 004)
    // -------------------------------------------------------------------------
    await runDbTest('Versioned migrations upgrade legacy BUILD 01/03 snapshot to schema v004 preserving all rows', () => {
      const legacyPath = path.join(rootTmp, 'legacy-b03.db');
      const legacy = new Database(legacyPath);
      const { hash, salt } = hashPassword('LegacyCampus!2024');
      legacy.exec(`
        CREATE TABLE users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL UNIQUE,
          email TEXT NOT NULL UNIQUE,
          full_name TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'Administrator',
          password_hash TEXT NOT NULL,
          salt TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE TABLE departments (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          code TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          head_name TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE TABLE positions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          code TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          type TEXT NOT NULL DEFAULT 'Regular',
          base_salary REAL NOT NULL DEFAULT 25000,
          allowance REAL NOT NULL DEFAULT 2000,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE TABLE shifts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL UNIQUE,
          time_in TEXT NOT NULL,
          time_out TEXT NOT NULL,
          grace_minutes INTEGER NOT NULL DEFAULT 15,
          status TEXT NOT NULL DEFAULT 'Active',
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE TABLE employees (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          employee_code TEXT NOT NULL UNIQUE,
          full_name TEXT NOT NULL,
          email TEXT NOT NULL DEFAULT '',
          department_id INTEGER NOT NULL,
          position_id INTEGER NOT NULL,
          shift_id INTEGER NOT NULL,
          status TEXT NOT NULL DEFAULT 'Active',
          hired_date TEXT NOT NULL DEFAULT '2024-01-15',
          monthly_salary REAL NOT NULL DEFAULT 25000,
          monthly_allowance REAL NOT NULL DEFAULT 2000,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        INSERT INTO departments (code, name, head_name) VALUES ('BSIT', 'BS Information Technology', 'Dr. Reyes');
        INSERT INTO positions (code, name, type, base_salary, allowance) VALUES ('INST', 'Instructor', 'Regular', 34500, 2500);
        INSERT INTO shifts (name, time_in, time_out, grace_minutes, status) VALUES ('Regular Shift', '08:00 AM', '05:00 PM', 15, 'Active');
        INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status, monthly_salary, monthly_allowance)
        VALUES ('EMP-LEG-001', 'Santos, Ana M.', 'ana.santos@rsucaj.edu.ph', 1, 1, 1, 'Active', 34500, 2500);
      `);
      legacy
        .prepare(
          `INSERT INTO users (username, email, full_name, role, password_hash, salt)
           VALUES ('admin', 'admin@rsucaj.edu.ph', 'Campus Admin', 'Administrator', ?, ?)`
        )
        .run(hash, salt);
      legacy.close();

      // Upgrade twice to verify strict idempotency
      const db1 = initDatabase(legacyPath, { mode: 'production', seedDemoData: false });
      const status1 = getDatabaseStatus(db1, legacyPath);
      assert.equal(status1.schemaVersion, CURRENT_SCHEMA_VERSION);
      assert.equal(status1.integrityCheck, 'ok');
      assert.equal(status1.foreignKeyViolations, 0);
      assert.equal(status1.tableCounts.employees, 1);
      assert.equal(status1.tableCounts.users, 1);
      closeDatabaseSafely(db1);

      const db2 = initDatabase(legacyPath, { mode: 'production', seedDemoData: false });
      const status2 = getDatabaseStatus(db2, legacyPath);
      assert.equal(status2.schemaVersion, CURRENT_SCHEMA_VERSION);
      assert.equal(status2.appliedMigrations.length, 9);
      assert.equal(status2.tableCounts.employees, 1);
      closeDatabaseSafely(db2);
    });

    // -------------------------------------------------------------------------
    // TEST 4: Foreign-key enforcement, UNIQUE event identity, and DB-level CHECK triggers
    // -------------------------------------------------------------------------
    await runDbTest('Enforces foreign_keys=ON, UNIQUE attendance/event identity, and DB constraint triggers', () => {
      const dbPath = path.join(rootTmp, 'constraints.db');
      const db = initDatabase(dbPath, { mode: 'test', seedDemoData: true, initialAdmin: ADMIN_CREDS });
      try {
        assert.equal(db.pragma('foreign_keys', { simple: true }), 1);

        // FK RESTRICT: cannot delete department with active employees
        const dept = db.prepare('SELECT id FROM departments LIMIT 1').get() as { id: number };
        assert.throws(() => db.prepare('DELETE FROM departments WHERE id = ?').run(dept.id), /FOREIGN KEY/i);

        // UNIQUE(employee_id, date) on attendance_records
        const emp = db.prepare('SELECT id FROM employees LIMIT 1').get() as { id: number };
        db.prepare(
          `INSERT INTO attendance_records (employee_id, date, time_in, status) VALUES (?, '2026-06-01', '08:00 AM', 'Present')`
        ).run(emp.id);
        assert.throws(
          () =>
            db
              .prepare(
                `INSERT INTO attendance_records (employee_id, date, time_in, status) VALUES (?, '2026-06-01', '08:05 AM', 'Present')`
              )
              .run(emp.id),
          /UNIQUE/i
        );

        // UNIQUE(event_uid) and immutability on attendance_events
        db.prepare(
          `INSERT INTO attendance_events (event_uid, employee_id, attendance_date, punch_type, punch_time)
           VALUES ('evt-unique-001', ?, '2026-06-01', 'TIME_IN', '08:00 AM')`
        ).run(emp.id);
        assert.throws(
          () =>
            db
              .prepare(
                `INSERT INTO attendance_events (event_uid, employee_id, attendance_date, punch_type, punch_time)
                 VALUES ('evt-unique-001', ?, '2026-06-01', 'TIME_OUT', '05:00 PM')`
              )
              .run(emp.id),
          /UNIQUE/i
        );
        assert.throws(
          () => db.prepare(`UPDATE attendance_events SET punch_time = '07:00 AM' WHERE event_uid = 'evt-unique-001'`).run(),
          /IMMUTABLE_AUDIT_VIOLATION/i
        );
        assert.throws(
          () => db.prepare(`DELETE FROM attendance_events WHERE event_uid = 'evt-unique-001'`).run(),
          /IMMUTABLE_AUDIT_VIOLATION/i
        );

        // DB trigger: negative salary rejected
        assert.throws(
          () => db.prepare('UPDATE employees SET monthly_salary = -500 WHERE id = ?').run(emp.id),
          /non-negative/i
        );

        // DB trigger: invalid leave date range rejected
        assert.throws(
          () =>
            db
              .prepare(
                `INSERT INTO leaves (employee_id, leave_type, start_date, end_date, days_count)
                 VALUES (?, 'Sick Leave', '2026-07-10', '2026-07-05', 1)`
              )
              .run(emp.id),
          /end_date/i
        );

        // DB trigger: invalid device status rejected
        assert.throws(
          () =>
            db
              .prepare(
                `INSERT INTO devices (name, ip_address, api_token, status)
                 VALUES ('Bad Dev', '10.0.0.99', 'ksk_bad_tok_01', 'BrokenStatus')`
              )
              .run(),
          /Online or Offline/i
        );
      } finally {
        closeDatabaseSafely(db);
      }
    });

    // -------------------------------------------------------------------------
    // TEST 5: Concurrent SQLite access under WAL + busy_timeout
    // -------------------------------------------------------------------------
    await runDbTest('Concurrent multi-handle SQLite reads and writes succeed under WAL + busy_timeout', () => {
      const dbPath = path.join(rootTmp, 'concurrent.db');
      const connA = initDatabase(dbPath, {
        mode: 'test',
        seedDemoData: false,
        busyTimeoutMs: 5000,
        initialAdmin: ADMIN_CREDS,
      });
      const connB = new Database(dbPath);
      connB.pragma('foreign_keys = ON');
      connB.pragma('busy_timeout = 5000');

      try {
        const insA = connA.prepare(
          `INSERT INTO audit_logs (username, activity, module, status, ip_address) VALUES (?, ?, 'Concurrency', 'Success', '127.0.0.1')`
        );
        const insB = connB.prepare(
          `INSERT INTO audit_logs (username, activity, module, status, ip_address) VALUES (?, ?, 'Concurrency', 'Success', '127.0.0.1')`
        );
        const countA = connA.prepare(`SELECT COUNT(*) as c FROM audit_logs WHERE module = 'Concurrency'`);
        const countB = connB.prepare(`SELECT COUNT(*) as c FROM audit_logs WHERE module = 'Concurrency'`);

        for (let i = 0; i < 40; i++) {
          connA.transaction(() => {
            insA.run('workerA', `Write A #${i}`);
          })();
          connB.transaction(() => {
            insB.run('workerB', `Write B #${i}`);
          })();
          assert.ok((countA.get() as { c: number }).c >= (i + 1) * 2);
          assert.ok((countB.get() as { c: number }).c >= (i + 1) * 2);
        }

        const total = (countA.get() as { c: number }).c;
        assert.equal(total, 80);
      } finally {
        connB.close();
        closeDatabaseSafely(connA);
      }
    });

    // -------------------------------------------------------------------------
    // TEST 6: WAL Checkpointing & Restart Persistence
    // -------------------------------------------------------------------------
    await runDbTest('WAL checkpointing truncates WAL cleanly and committed records persist across restarts', () => {
      const dbPath = path.join(rootTmp, 'wal-persist.db');
      const db1 = initDatabase(dbPath, { mode: 'production', seedDemoData: false, initialAdmin: ADMIN_CREDS });
      db1.prepare("INSERT INTO departments (code, name, head_name) VALUES ('CICT', 'Computing', 'Dr. Cruz')").run();
      db1
        .prepare("INSERT INTO positions (code, name, type, base_salary, allowance) VALUES ('DEV', 'Developer', 'Regular', 30000, 2000)")
        .run();
      db1
        .prepare("INSERT INTO shifts (name, time_in, time_out, grace_minutes, status) VALUES ('Day', '08:00 AM', '05:00 PM', 15, 'Active')")
        .run();
      db1
        .prepare(
          `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status, monthly_salary, monthly_allowance)
           VALUES ('EMP-PER-001', 'Persist, Juan D.', 'juan@rsucaj.edu.ph', 1, 1, 1, 'Active', 30000, 2000)`
        )
        .run();

      // Write burst to ensure WAL has frames, then checkpoint with TRUNCATE
      const cp = checkpointWal(db1, 'TRUNCATE');
      assert.equal(cp.busy, 0);
      closeDatabaseSafely(db1);

      const walPath = `${dbPath}-wal`;
      const walBytesAfterClose = fs.existsSync(walPath) ? fs.statSync(walPath).size : 0;
      assert.equal(walBytesAfterClose, 0, 'WAL should be 0 bytes or removed after safe checkpoint + close');

      // Re-open database after restart and verify records persist identically
      const db2 = initDatabase(dbPath, { mode: 'production', seedDemoData: false });
      try {
        const emp = db2
          .prepare('SELECT full_name, monthly_salary FROM employees WHERE employee_code = ?')
          .get('EMP-PER-001') as { full_name: string; monthly_salary: number } | undefined;
        assert.ok(emp);
        assert.equal(emp.full_name, 'Persist, Juan D.');
        assert.equal(emp.monthly_salary, 30000);
      } finally {
        closeDatabaseSafely(db2);
      }
    });

    // -------------------------------------------------------------------------
    // TEST 7: Online SQLite Backup (VACUUM INTO) + SHA-256 Checksum + AES-256-GCM Encryption + Tamper Rejection
    // -------------------------------------------------------------------------
    await runDbTest('Online SQLite backup, SHA-256 manifest, AES-256-GCM encryption, and tamper detection', () => {
      const dbPath = path.join(rootTmp, 'backup-src.db');
      const backupDir = path.join(rootTmp, 'backups');
      const encKey = crypto.randomBytes(32).toString('hex');
      const wrongKey = crypto.randomBytes(32).toString('hex');

      const db = initDatabase(dbPath, { mode: 'test', seedDemoData: true, initialAdmin: ADMIN_CREDS });
      try {
        const backup = createOnlineSqliteBackup(db, {
          backupDir,
          createdBy: 'qa-runner',
          encryptionKey: encKey,
          retentionCount: 5,
        });

        assert.equal(backup.manifest.integrityCheck, 'ok');
        assert.equal(backup.manifest.foreignKeyViolations, 0);
        assert.equal(backup.manifest.encrypted, true);
        assert.ok(backup.encryptedPath && fs.existsSync(backup.encryptedPath));
        assert.ok(fs.existsSync(backup.sqlitePath));
        assert.ok(fs.existsSync(backup.manifestPath));

        // Verify plaintext snapshot checksum & row counts
        const plainVerify = verifyBackupArchive(backup.sqlitePath);
        assert.equal(plainVerify.valid, true);
        assert.equal(plainVerify.manifestMatched, true);
        assert.equal(plainVerify.tableCounts.employees, 18);

        // Verify AES-256-GCM encrypted offsite archive with correct key
        const encVerify = verifyBackupArchive(backup.encryptedPath!, { encryptionKey: encKey });
        assert.equal(encVerify.valid, true);
        assert.equal(encVerify.encrypted, true);
        assert.equal(encVerify.tableCounts.employees, 18);

        // Wrong decryption key MUST fail cleanly
        const wrongKeyVerify = verifyBackupArchive(backup.encryptedPath!, { encryptionKey: wrongKey });
        assert.equal(wrongKeyVerify.valid, false);
        assert.ok(wrongKeyVerify.errors.some((e) => e.includes('decryption failed')));

        // Flip 1 byte in encrypted archive -> tamper detection MUST fail cleanly
        const tamperedEncPath = path.join(backupDir, 'tampered.sqlite.enc');
        const rawBytes = Buffer.from(fs.readFileSync(backup.encryptedPath!));
        rawBytes[rawBytes.length - 1] ^= 0xff;
        fs.writeFileSync(tamperedEncPath, rawBytes);
        const tamperVerify = verifyBackupArchive(tamperedEncPath, {
          encryptionKey: encKey,
          manifestPath: backup.manifestPath,
        });
        assert.equal(tamperVerify.valid, false);
        assert.ok(tamperVerify.errors.length > 0);
      } finally {
        closeDatabaseSafely(db);
      }
    });

    // -------------------------------------------------------------------------
    // TEST 8: Full Restore + Exact Row-Count Verification + Failed Restore Automatic Rollback
    // -------------------------------------------------------------------------
    await runDbTest('Encrypted restore matches exact row counts; corrupt/failed restore preserves or rolls back live DB', () => {
      const srcPath = path.join(rootTmp, 'restore-src.db');
      const liveTargetPath = path.join(rootTmp, 'restore-live.db');
      const backupDir = path.join(rootTmp, 'restore-backups');
      const encKey = crypto.randomBytes(32).toString('hex');

      const srcDb = initDatabase(srcPath, { mode: 'test', seedDemoData: true, initialAdmin: ADMIN_CREDS });
      const bkp = createOnlineSqliteBackup(srcDb, { backupDir, encryptionKey: encKey, createdBy: 'qa' });
      closeDatabaseSafely(srcDb);

      // 1. Live restore from AES-256-GCM encrypted backup to fresh target path
      const restoreOk = restoreSqliteBackup(bkp.encryptedPath!, liveTargetPath, {
        encryptionKey: encKey,
        manifestPath: bkp.manifestPath,
        dryRun: false,
      });
      assert.equal(restoreOk.ok, true);
      assert.equal(restoreOk.rolledBack, false);
      assert.equal(restoreOk.verification.tableCounts.employees, 18);

      // Add a unique sentinel department on liveTargetPath so we can prove rollback preserves live data
      const liveDb = initDatabase(liveTargetPath, { mode: 'production', seedDemoData: false });
      liveDb.prepare("INSERT INTO departments (code, name, head_name) VALUES ('SENTINEL', 'Live Sentinel Dept', 'Dr. Live')").run();
      closeDatabaseSafely(liveDb);

      // 2. Attempting restore with corrupt archive MUST abort BEFORE touching liveTargetPath
      const corruptArchive = path.join(backupDir, 'corrupt.sqlite');
      fs.writeFileSync(corruptArchive, 'NOT_A_VALID_SQLITE_DATABASE_FILE');
      const corruptRes = restoreSqliteBackup(corruptArchive, liveTargetPath, { dryRun: false });
      assert.equal(corruptRes.ok, false);
      assert.equal(corruptRes.rolledBack, false);

      // 3. Simulated post-restore verification failure MUST automatically roll back to pre-restore snapshot
      const rollbackRes = restoreSqliteBackup(bkp.encryptedPath!, liveTargetPath, {
        encryptionKey: encKey,
        manifestPath: bkp.manifestPath,
        dryRun: false,
        _simulatePostRestoreFailure: true,
      });
      assert.equal(rollbackRes.ok, false);
      assert.equal(rollbackRes.rolledBack, true);
      assert.ok(rollbackRes.preRestoreBackupPath && fs.existsSync(rollbackRes.preRestoreBackupPath));

      // Verify sentinel row on liveTargetPath is still 100% intact after rollback
      const postRollbackDb = initDatabase(liveTargetPath, { mode: 'production', seedDemoData: false });
      try {
        const sentinel = postRollbackDb.prepare("SELECT name FROM departments WHERE code = 'SENTINEL'").get() as
          | { name: string }
          | undefined;
        assert.ok(sentinel, 'Automatic rollback must preserve live pre-restore database state');
        assert.equal(sentinel.name, 'Live Sentinel Dept');
      } finally {
        closeDatabaseSafely(postRollbackDb);
      }
    });

    // -------------------------------------------------------------------------
    // TEST 9: Migration & Rollback Dry Run (Isolated Non-Destructive)
    // -------------------------------------------------------------------------
    await runDbTest('Migration rollback dry run snapshots, migrates, rolls back, and matches exact row counts', () => {
      const srcPath = path.join(rootTmp, 'mig-dryrun-src.db');
      const legacy = new Database(srcPath);
      const { hash, salt } = hashPassword('DryRun!2026Aa');
      legacy.exec(`
        CREATE TABLE users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL UNIQUE,
          email TEXT NOT NULL UNIQUE,
          full_name TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'Administrator',
          password_hash TEXT NOT NULL,
          salt TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE TABLE departments (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          code TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          head_name TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        INSERT INTO departments (code, name, head_name) VALUES ('DRY', 'Dry Run Dept', 'Dr. Test');
      `);
      legacy
        .prepare("INSERT INTO users (username, email, full_name, role, password_hash, salt) VALUES ('dryadmin', 'dry@rsucaj.edu.ph', 'Dry Admin', 'Administrator', ?, ?)")
        .run(hash, salt);
      legacy.close();

      const dryRes = runMigrationRollbackDryRun(srcPath);
      assert.equal(dryRes.ok, true);
      assert.equal(dryRes.sourceSchemaVersion, '000');
      assert.equal(dryRes.migratedSchemaVersion, CURRENT_SCHEMA_VERSION);
      assert.equal(dryRes.restoredSchemaVersion, '000');
      assert.equal(dryRes.rowCountsMatchExact, true);
      assert.equal(dryRes.integrityCheck, 'ok');
      assert.equal(dryRes.foreignKeyViolations, 0);
    });

    // -------------------------------------------------------------------------
    // TEST 10: Database Unavailable Handling (503 JSON + Typed DatabaseUnavailableError)
    // -------------------------------------------------------------------------
    await runDbTest('Database unavailable state throws typed error on invalid path and returns HTTP 503 on API routes', async () => {
      // Opening a directory path as a SQLite file must throw DatabaseUnavailableError cleanly
      const dirAsFile = path.join(rootTmp, 'not-a-db-file');
      fs.mkdirSync(dirAsFile);
      assert.throws(
        () => initDatabase(dirAsFile, { mode: 'production', seedDemoData: false, initialAdmin: ADMIN_CREDS }),
        DatabaseUnavailableError
      );

      // Closed DB on Express router returns HTTP 503 cleanly on /api/health and /api/auth/login
      const prevSecret = process.env.SESSION_SECRET;
      process.env.SESSION_SECRET = crypto.randomBytes(32).toString('hex');
      const db = initDatabase(':memory:', { mode: 'test', seedDemoData: false, initialAdmin: ADMIN_CREDS });
      const app = express();
      app.use('/api', createApiRouter(db, { appMode: 'test' }));
      const server = await new Promise<ReturnType<typeof app.listen>>((resolve) => {
        const s = app.listen(0, '127.0.0.1', () => resolve(s));
      });
      const port = (server.address() as AddressInfo).port;
      try {
        // Close DB to simulate database becoming unavailable
        db.close();

        const healthRes = await fetch(`http://127.0.0.1:${port}/api/health`);
        const healthBody = (await healthRes.json()) as { code: string; database: string };
        assert.equal(healthRes.status, 503);
        assert.equal(healthBody.code, 'DATABASE_UNAVAILABLE');
        assert.equal(healthBody.database, 'unavailable');

        const loginRes = await fetch(`http://127.0.0.1:${port}/api/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ identifier: ADMIN_CREDS.username, password: ADMIN_CREDS.password }),
        });
        const loginBody = (await loginRes.json()) as { code: string };
        assert.equal(loginRes.status, 503);
        assert.equal(loginBody.code, 'DATABASE_UNAVAILABLE');
      } finally {
        server.close();
        if (prevSecret === undefined) delete process.env.SESSION_SECRET;
        else process.env.SESSION_SECRET = prevSecret;
      }
    });
  } finally {
    fs.rmSync(rootTmp, { recursive: true, force: true });
  }

  const passed = results.filter((r) => r.passed).length;
  const failed = results.filter((r) => !r.passed).length;
  console.log(`\nDB Durability Summary: ${passed}/${results.length} passed, ${failed} failed.`);
  if (failed > 0) process.exit(1);
}

main().catch((err) => {
  console.error('DB test suite crashed:', err);
  process.exit(1);
});
