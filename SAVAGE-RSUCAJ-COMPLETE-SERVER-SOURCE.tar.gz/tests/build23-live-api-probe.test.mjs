import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { probeLiveApi } from '../scripts/build23-probe-live-api.mjs';

const TOKEN = 'test_token_only_not_real';
const DEVICE = 'TEST-KIOSK-01';
async function mockServer(routes, fn) {
  const server = http.createServer((req, res) => {
    const route = routes[req.url];
    if (!route) { res.writeHead(404).end('Not found'); return; }
    if (route.validate) {
      try { route.validate(req); } catch (e) { res.writeHead(500).end(String(e)); return; }
    }
    res.writeHead(route.status || 200, { 'Content-Type': route.contentType || 'application/json', ...(route.headers || {}) });
    res.end(typeof route.body === 'string' ? route.body : JSON.stringify(route.body));
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  try { await fn(`http://127.0.0.1:${server.address().port}`); }
  finally { await new Promise((resolve) => server.close(resolve)); }
}
const healthy = { status: 'ok', database: 'connected' };
const deviceInfo = { device_id: 42, device_name: DEVICE, bridge_contract: 'SAVAGE_ANDROID_V1' };
const routes = { '/api/health': { body: healthy }, '/api/v1/kiosk/device-info': { body: deviceInfo } };
const opts = (url) => ({ url, deviceName: DEVICE, token: TOKEN, allowLocalHttp: true });

test('real-style health + matching provisioned device yields PASS', async () => {
  await mockServer({ ...routes, '/api/v1/kiosk/device-info': { ...routes['/api/v1/kiosk/device-info'], validate(req) {
    assert.equal(req.headers.authorization, `Bearer ${TOKEN}`);
    assert.equal(req.headers['x-kiosk-device-id'], DEVICE);
  }} }, async (url) => {
    assert.deepEqual((await probeLiveApi(opts(url))).verdict, 'PASS');
  });
});
test('health-only cannot certify device integration', async () => {
  await mockServer(routes, async (url) => {
    const result = await probeLiveApi({ url, allowLocalHttp: true });
    assert.equal(result.verdict, 'PARTIAL');
    assert.equal(result.device, 'NOT_PROVISIONED_OR_NOT_REQUESTED');
  });
});
test('SPA HTML 200 is not a backend API', async () => {
  await mockServer({ ...routes, '/api/health': { body: '<html>Portal</html>', contentType: 'text/html' } }, async url => {
    const r = await probeLiveApi(opts(url)); assert.equal(r.health, 'NOT_JSON_API'); assert.equal(r.verdict, 'FAIL');
  });
});
test('HTTP redirect is blocked before sending device token', async () => {
  await mockServer({ ...routes, '/api/health': { status: 302, headers: { Location: 'https://example.com' }, body: '' } }, async url => {
    const r = await probeLiveApi(opts(url)); assert.equal(r.health, 'HTTP_REDIRECT'); assert.equal(r.verdict, 'FAIL');
  });
});
test('HTTP 403 does not claim success', async () => {
  await mockServer({ ...routes, '/api/health': { status: 403, body: { error: 'blocked' } } }, async url => {
    const r = await probeLiveApi(opts(url)); assert.equal(r.health, 'HTTP_ERROR'); assert.equal(r.httpStatus, 403);
  });
});
test('wrong health contract rejected', async () => {
  await mockServer({ ...routes, '/api/health': { body: { status: 'ok' } } }, async url => {
    const r = await probeLiveApi(opts(url)); assert.equal(r.health, 'WRONG_API_HEALTH_CONTRACT');
  });
});
test('authentication failure rejected', async () => {
  await mockServer({ ...routes, '/api/v1/kiosk/device-info': { status: 403, body: { code: 'INVALID_DEVICE' } } }, async url => {
    const r = await probeLiveApi(opts(url)); assert.equal(r.device, 'HTTP_ERROR'); assert.equal(r.verdict, 'FAIL');
  });
});
test('old backend without bridge contract is rejected', async () => {
  await mockServer({ ...routes, '/api/v1/kiosk/device-info': { body: { device_id: 42, device_name: DEVICE } } }, async url => {
    const r = await probeLiveApi(opts(url)); assert.equal(r.device, 'BRIDGE_CONTRACT_NOT_DEPLOYED');
  });
});
test('device id mismatch rejected', async () => {
  await mockServer({ ...routes, '/api/v1/kiosk/device-info': { body: { ...deviceInfo, device_name: 'WRONG' } } }, async url => {
    const r = await probeLiveApi(opts(url)); assert.equal(r.device, 'DEVICE_ID_MISMATCH');
  });
});
test('URL with extra /api path rejected', async () => {
  const r = await probeLiveApi({ url: 'https://rsu-cajidiocan.tech/api' });
  assert.equal(r.health, 'INVALID_BASE_URL');
});
test('user info embedded in URL rejected', async () => {
  const r = await probeLiveApi({ url: 'https://name:password@rsu-cajidiocan.tech/' });
  assert.equal(r.health, 'INVALID_BASE_URL');
});
test('non-loopback HTTP rejected', async () => {
  const r = await probeLiveApi({ url: 'http://rsu-cajidiocan.tech' });
  assert.equal(r.health, 'INVALID_BASE_URL');
});
