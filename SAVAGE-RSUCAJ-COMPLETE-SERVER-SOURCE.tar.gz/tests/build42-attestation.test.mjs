import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { validateCameraFrames, runWebKioskAttestation } from '../server/webKioskAttestation.ts';

const pixel = Buffer.from('ffd8ffe100000100ffd9','hex').toString('base64');
function frames(blob = Buffer.concat([Buffer.from('ffd8ff','hex'), Buffer.alloc(120,0), Buffer.from('ffd9','hex')]).toString('base64')) {
 return [0,1,2].map(i=>({captured_at_ms: 1000+i*320,jpeg_b64:blob}));
}
test('reject no frames',()=>assert.equal(validateCameraFrames([]),false));
test('reject malformed frame object and browser scores',()=>{
 const f=frames(); f[0].pad_score=1;
 assert.equal(validateCameraFrames(f),false);
});
test('reject duplicate timestamps',()=>{
 const f=frames(); f[1].captured_at_ms=f[0].captured_at_ms;
 assert.equal(validateCameraFrames(f),false);
});
test('reject invalid base64',()=>{
 const f=frames(); f[0].jpeg_b64='not!!base64';
 assert.equal(validateCameraFrames(f),false);
});
test('allow bounded valid-structure JPEG bundle',()=>assert.equal(validateCameraFrames(frames()),true));
test('probe checks genuine-process output contract and rejects fake success',async()=>{
 const dir=mkdtempSync(path.join(tmpdir(),'savage-build42-test-'));
 try {
  const worker=path.join(dir,'fixture.py');
  writeFileSync(worker,`import json\nprint(json.dumps({'ok': True, 'mode':'probe','server_owned_inference':False,'face_detector_ready':True,'models_executed':['anti_spoofing_pad','liveness_detection','face_recognition']}))\n`);
  const result=await runWebKioskAttestation('probe',undefined,{python:'python3',script:worker,timeoutMs:2000});
  assert.equal(result.ok,false);
  assert.equal(result.code,'UNVERIFIED_RESULT');
 } finally {rmSync(dir,{recursive:true,force:true});}
});
test('probe accepts fully validated worker contract, without production approval',async()=>{
 const dir=mkdtempSync(path.join(tmpdir(),'savage-build42-test-'));
 try {
  const worker=path.join(dir,'fixture.py');
  writeFileSync(worker,`import json\nprint(json.dumps({'ok': True, 'mode':'probe','server_owned_inference':True,'face_detector_ready':True,'models_executed':['anti_spoofing_pad','liveness_detection','face_recognition']}))\n`);
  const result=await runWebKioskAttestation('probe',undefined,{python:'python3',script:worker,timeoutMs:2000});
  assert.deepEqual(result,{ok:true,mode:'probe'});
 } finally {rmSync(dir,{recursive:true,force:true});}
});

test('unsupported Chromium FaceDetector leaves quality CHECKING, not falsely NO_FACE or PASS',async()=>{
 const {KioskVerificationStateMachine}=await import('../src/lib/kioskBiometrics.ts');
 const machine=new KioskVerificationStateMachine();
 const x=machine.evaluateFrame({timestampMs:Date.now(),cameraReady:true,backendOnline:true,
  modelsVerifiedOnDisk:true,serverInferenceAvailable:false,faceDetectionAvailable:false,
  faceCount:0,centered:false,sizeOk:false,lightingOk:true,sharpnessOk:true,
  frozenFrame:false,boundingBox:null,detectionConfidence:0,qualityScore:0});
 assert.equal(x.indicators.quality,'CHECKING');
 assert.match(x.guidance,/server will check/i);
});
