/**
 * SAVAGE-RSUCAJ Employee Portal (18-Screen Rebuild) — End-to-End API, RBAC & Data Isolation Tests
 * Verifies:
 *  - Employee login via Employee ID (employee_code), username, and email
 *  - Read-only today attendance contract (read_only=true, allow_manual_punch=false)
 *  - Strictly self-scoped profile, monthly attendance, DTR JSON, and DTR PDF export
 *  - Leave & Attendance Correction creation returning real server IDs, attachment support, and leave cancellation
 *  - Strictly self-scoped employee notifications, read persistence, and mark-all-read
 *  - Account Security endpoint (honest twoFactorSupported=false, real active sessions, cross-session revoke)
 *  - Official Released Payslip JSON + real PDF binary export (%PDF-) and 403 isolation against unreleased/other-employee payslips
 *  - Strict RBAC denial on admin-only routes
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import { initDatabase, closeDatabaseSafely } from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import { RealtimeHub } from '../server/realtimeHub.ts';
import { hashPassword } from '../server/auth.ts';

function extractCookieHeader(res) {
  const raw = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
  const pairs = raw.map((c) => c.split(';')[0].trim()).filter(Boolean);
  const csrfPair = pairs.find((p) => p.startsWith('savage_rsucaj_csrf='));
  const csrfToken = csrfPair ? decodeURIComponent(csrfPair.split('=').slice(1).join('=')) : '';
  return { cookie: pairs.join('; '), csrfToken };
}

async function loginAs(baseUrl, identifier, password, userAgent = 'EmployeePortalTest/1.0') {
  const res = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': userAgent,
    },
    body: JSON.stringify({ identifier, password, rememberMe: false }),
  });
  const body = await res.json();
  const { cookie, csrfToken } = extractCookieHeader(res);
  return { status: res.status, body, cookie, csrfToken: body.csrfToken || csrfToken };
}

test('Employee Portal 18-screen backend contracts, PDF exports, security controls, and strict employee isolation', async () => {
  const prevSecret = process.env.SESSION_SECRET;
  process.env.SESSION_SECRET = crypto.randomBytes(48).toString('hex');

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-emp18-'));
  const dbPath = path.join(tmpDir, 'test.db');
  const adminPass = `Admin!${crypto.randomBytes(8).toString('hex')}9A`;
  const empAPass = `EmpA!${crypto.randomBytes(8).toString('hex')}7B`;
  const empBPass = `EmpB!${crypto.randomBytes(8).toString('hex')}8C`;

  const db = initDatabase(dbPath, {
    mode: 'development',
    seedDemoData: false,
    initialAdmin: {
      username: 'sysadmin',
      email: 'sysadmin@rsucaj.edu.ph',
      password: adminPass,
    },
  });

  // Seed 1 department, 1 position, 1 shift, 2 employees, and 2 Employee user accounts
  const deptId = Number(
    db.prepare(`INSERT INTO departments (code, name, head_name) VALUES ('ICT', 'ICT Office', 'ICT Head')`).run().lastInsertRowid
  );
  const posId = Number(
    db.prepare(`INSERT INTO positions (code, name, type, base_salary, allowance) VALUES ('ITS', 'IT Staff', 'Regular', 22000, 3000)`).run().lastInsertRowid
  );
  const shiftId = Number(
    db.prepare(`INSERT INTO shifts (name, time_in, time_out, grace_minutes, rest_days, status) VALUES ('Regular Day', '08:00', '17:00', 15, 'Saturday,Sunday', 'Active')`).run().lastInsertRowid
  );

  const empAId = Number(
    db.prepare(
      `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status, hired_date, monthly_salary, monthly_allowance)
       VALUES ('RSU-0001', 'Juan Dela Cruz', 'juan.delacruz@rsucaj.edu.ph', ?, ?, ?, 'Active', '2024-01-15', 22000, 3000)`
    ).run(deptId, posId, shiftId).lastInsertRowid
  );
  const empBId = Number(
    db.prepare(
      `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status, hired_date, monthly_salary, monthly_allowance)
       VALUES ('RSU-0002', 'Maria Santos', 'maria.santos@rsucaj.edu.ph', ?, ?, ?, 'Active', '2024-02-01', 24000, 2500)`
    ).run(deptId, posId, shiftId).lastInsertRowid
  );

  const hashedA = hashPassword(empAPass);
  db.prepare(
    `INSERT INTO users (username, email, full_name, password_hash, salt, role, department_id, employee_id, must_change_password, is_active)
     VALUES ('jdelacruz', 'juan.delacruz@rsucaj.edu.ph', 'Juan Dela Cruz', ?, ?, 'Employee', ?, ?, 0, 1)`
  ).run(hashedA.hash, hashedA.salt, deptId, empAId);

  const hashedB = hashPassword(empBPass);
  db.prepare(
    `INSERT INTO users (username, email, full_name, password_hash, salt, role, department_id, employee_id, must_change_password, is_active)
     VALUES ('msantos', 'maria.santos@rsucaj.edu.ph', 'Maria Santos', ?, ?, 'Employee', ?, ?, 0, 1)`
  ).run(hashedB.hash, hashedB.salt, deptId, empBId);

  // Seed one holiday + one attendance record for Employee A
  db.prepare(`INSERT INTO holidays (date, name, type) VALUES ('2026-11-30', 'Bonifacio Day', 'Regular')`).run();
  db.prepare(
    `INSERT INTO attendance_records (employee_id, date, time_in, time_out, work_hours, status, device_name, remarks)
     VALUES (?, '2026-11-18', '08:02', '17:05', '8h 03m', 'Present', 'Campus Main Kiosk', 'Face verified')`
  ).run(empAId);

  // Seed two payroll runs: one Released (inserted as Computed first to honor immutability triggers), one Computed (unreleased)
  const releasedRunId = Number(
    db.prepare(
      `INSERT INTO payroll_runs (period_label, start_date, end_date, status, total_basic_pay, total_allowances, total_deductions, total_net_pay, employee_count, created_by)
       VALUES ('November 2026', '2026-11-01', '2026-11-30', 'Computed', 22000, 3000, 1570, 23430, 1, 'sysadmin')`
    ).run().lastInsertRowid
  );
  db.prepare(
    `INSERT INTO payroll_items (payroll_run_id, employee_id, days_present, days_late, days_absent, basic_pay, allowances, deductions, net_pay, prorated_basic_pay, gross_pay, tax_deduction, other_deductions)
     VALUES (?, ?, 20, 0, 0, 22000, 3000, 1570, 23430, 22000, 25000, 1500, 70)`
  ).run(releasedRunId, empAId);
  db.prepare(
    `UPDATE payroll_runs SET status = 'Released', released_at = datetime('now') WHERE id = ?`
  ).run(releasedRunId);

  const draftRunId = Number(
    db.prepare(
      `INSERT INTO payroll_runs (period_label, start_date, end_date, status, total_basic_pay, total_allowances, total_deductions, total_net_pay, employee_count, created_by)
       VALUES ('December 2026 Draft', '2026-12-01', '2026-12-31', 'Computed', 22000, 3000, 1500, 23500, 1, 'sysadmin')`
    ).run().lastInsertRowid
  );
  db.prepare(
    `INSERT INTO payroll_items (payroll_run_id, employee_id, days_present, days_late, days_absent, basic_pay, allowances, deductions, net_pay)
     VALUES (?, ?, 10, 0, 0, 22000, 3000, 1500, 23500)`
  ).run(draftRunId, empAId);

  const realtimeHub = new RealtimeHub();
  const app = express();
  app.use('/api', createApiRouter(db, { realtimeHub, dbPath }));

  const server = await new Promise((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const addr = server.address();
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  try {
    // 1. Login via Employee ID (RSU-0001) — Screen 05
    const empASession1 = await loginAs(baseUrl, 'RSU-0001', empAPass, 'Mozilla/5.0 (Linux; Android 14) Chrome/120');
    assert.equal(empASession1.status, 200, 'Employee must be able to sign in using Employee ID (employee_code)');
    assert.equal(empASession1.body.user.role, 'Employee');
    assert.equal(empASession1.body.user.employee_id, empAId);

    // Second login on another device to test Linked Devices + Revoke (Screen 16)
    const empASession2 = await loginAs(baseUrl, 'jdelacruz', empAPass, 'Mozilla/5.0 (Macintosh) Safari/17');
    assert.equal(empASession2.status, 200);

    const empBSession = await loginAs(baseUrl, 'RSU-0002', empBPass);
    assert.equal(empBSession.status, 200);

    // 2. Screen 06: Today Attendance is strictly read-only
    const todayRes = await fetch(`${baseUrl}/api/employee/today-attendance`, {
      headers: { Cookie: empASession1.cookie },
    });
    assert.equal(todayRes.status, 200);
    const todayJson = await todayRes.json();
    assert.equal(todayJson.read_only, true);
    assert.equal(todayJson.allow_manual_punch, false);
    assert.equal(todayJson.employee.employee_code, 'RSU-0001');

    // 3. Screen 07: Monthly attendance + DTR PDF export
    const monthRes = await fetch(`${baseUrl}/api/employee/attendance-month?month=2026-11`, {
      headers: { Cookie: empASession1.cookie },
    });
    assert.equal(monthRes.status, 200);
    const monthJson = await monthRes.json();
    assert.ok(monthJson.data.some((r) => r.date === '2026-11-18' && r.status === 'Present'));

    const dtrPdfRes = await fetch(`${baseUrl}/api/reports/my-dtr/export.pdf?month=2026-11`, {
      headers: { Cookie: empASession1.cookie },
    });
    assert.equal(dtrPdfRes.status, 200);
    assert.ok((dtrPdfRes.headers.get('content-type') || '').includes('application/pdf'));
    const dtrPdfBytes = Buffer.from(await dtrPdfRes.arrayBuffer());
    assert.equal(dtrPdfBytes.subarray(0, 5).toString('ascii'), '%PDF-');

    // 4. Screen 10 & 11 & 13: Leave request creation returns real ID, Employee B cannot see it, Employee A can cancel it
    const leaveCreateRes = await fetch(`${baseUrl}/api/leaves`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: empASession1.cookie,
        'X-CSRF-Token': empASession1.csrfToken,
      },
      body: JSON.stringify({
        leave_type: 'Vacation Leave',
        start_date: '2026-11-24',
        end_date: '2026-11-25',
        day_portion: 'FULL',
        reason: 'Scheduled family travel outside Romblon.',
      }),
    });
    assert.equal(leaveCreateRes.status, 201);
    const createdLeave = await leaveCreateRes.json();
    assert.ok(Number.isInteger(createdLeave.id) && createdLeave.id > 0);
    assert.equal(createdLeave.status, 'Pending');

    const empBLeavesRes = await fetch(`${baseUrl}/api/leaves`, {
      headers: { Cookie: empBSession.cookie },
    });
    assert.equal(empBLeavesRes.status, 200);
    const empBLeaves = await empBLeavesRes.json();
    assert.equal(empBLeaves.data.length, 0, 'Employee B must never see Employee A leaves');

    const cancelLeaveRes = await fetch(`${baseUrl}/api/leaves/${createdLeave.id}/cancel`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: empASession1.cookie,
        'X-CSRF-Token': empASession1.csrfToken,
      },
      body: JSON.stringify({ cancel_reason: 'Plans changed' }),
    });
    assert.equal(cancelLeaveRes.status, 200);

    // 5. Screen 12: Attendance correction creation returns real ID
    const corrCreateRes = await fetch(`${baseUrl}/api/corrections`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: empASession1.cookie,
        'X-CSRF-Token': empASession1.csrfToken,
      },
      body: JSON.stringify({
        attendance_date: '2026-11-18',
        request_type: 'Time Out',
        requested_time: '17:00',
        reason: 'Forgot to scan out at the kiosk after campus meeting.',
      }),
    });
    assert.equal(corrCreateRes.status, 201);
    const createdCorr = await corrCreateRes.json();
    assert.ok(Number.isInteger(createdCorr.id) && createdCorr.id > 0);

    // 6. Screen 08 & 14: Released payslip JSON & real PDF + strict isolation against unreleased/other employee
    const myPayslipsRes = await fetch(`${baseUrl}/api/payroll/my-payslips`, {
      headers: { Cookie: empASession1.cookie },
    });
    assert.equal(myPayslipsRes.status, 200);
    const myPayslipsJson = await myPayslipsRes.json();
    assert.equal(myPayslipsJson.payslips.length, 1, 'Only Released payslips may be listed');
    assert.equal(myPayslipsJson.payslips[0].payroll_run_id, releasedRunId);

    const slipPdfRes = await fetch(`${baseUrl}/api/payroll/${releasedRunId}/payslip/${empAId}/pdf`, {
      headers: { Cookie: empASession1.cookie },
    });
    assert.equal(slipPdfRes.status, 200);
    assert.ok((slipPdfRes.headers.get('content-type') || '').includes('application/pdf'));
    const slipPdfBytes = Buffer.from(await slipPdfRes.arrayBuffer());
    assert.equal(slipPdfBytes.subarray(0, 5).toString('ascii'), '%PDF-');

    // Unreleased payslip PDF must be blocked (403)
    const draftPdfRes = await fetch(`${baseUrl}/api/payroll/${draftRunId}/payslip/${empAId}/pdf`, {
      headers: { Cookie: empASession1.cookie },
    });
    assert.equal(draftPdfRes.status, 403);

    // Employee B requesting Employee A's released payslip PDF must be blocked (403)
    const crossEmpPdfRes = await fetch(`${baseUrl}/api/payroll/${releasedRunId}/payslip/${empAId}/pdf`, {
      headers: { Cookie: empBSession.cookie },
    });
    assert.equal(crossEmpPdfRes.status, 403);

    // 7. Screen 17: Employee notifications + read persistence + mark-all-read
    const notifRes = await fetch(`${baseUrl}/api/employee/notifications`, {
      headers: { Cookie: empASession1.cookie },
    });
    assert.equal(notifRes.status, 200);
    const notifJson = await notifRes.json();
    assert.ok(Array.isArray(notifJson.data) && notifJson.data.length >= 3);
    assert.ok(notifJson.unreadCount > 0);
    const firstKey = notifJson.data[0].key;

    const markOneRes = await fetch(
      `${baseUrl}/api/employee/notifications/${encodeURIComponent(firstKey)}/read`,
      {
        method: 'PATCH',
        headers: {
          Cookie: empASession1.cookie,
          'X-CSRF-Token': empASession1.csrfToken,
        },
      }
    );
    assert.equal(markOneRes.status, 200);

    const markAllRes = await fetch(`${baseUrl}/api/employee/notifications/mark-all-read`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: empASession1.cookie,
        'X-CSRF-Token': empASession1.csrfToken,
      },
      body: JSON.stringify({ keys: notifJson.data.map((n) => n.key) }),
    });
    assert.equal(markAllRes.status, 200);

    const notifAfterRes = await fetch(`${baseUrl}/api/employee/notifications`, {
      headers: { Cookie: empASession1.cookie },
    });
    const notifAfterJson = await notifAfterRes.json();
    assert.equal(notifAfterJson.unreadCount, 0, 'All notifications must persist as read');

    // 8. Screen 16: Account Security sessions (honest 2FA unavailable + real revoke of other device)
    const secRes = await fetch(`${baseUrl}/api/employee/security/sessions`, {
      headers: { Cookie: empASession1.cookie },
    });
    assert.equal(secRes.status, 200);
    const secJson = await secRes.json();
    assert.equal(secJson.twoFactorSupported, false);
    assert.ok(secJson.activeCount >= 2);
    const otherSession = secJson.sessions.find((s) => s.is_active && !s.is_current);
    assert.ok(otherSession, 'Should list the second active device session');

    const revokeRes = await fetch(
      `${baseUrl}/api/employee/security/sessions/${encodeURIComponent(otherSession.session_id)}`,
      {
        method: 'DELETE',
        headers: {
          Cookie: empASession1.cookie,
          'X-CSRF-Token': empASession1.csrfToken,
        },
      }
    );
    assert.equal(revokeRes.status, 200);

    // Revoked session 2 must now fail with 401
    const revokedCheck = await fetch(`${baseUrl}/api/employee/profile`, {
      headers: { Cookie: empASession2.cookie },
    });
    assert.equal(revokedCheck.status, 401, 'Revoked linked device session must immediately be rejected');

    // 9. Strict RBAC: Employee cannot access Admin Portal endpoints
    for (const adminPath of ['/api/employees', '/api/devices', '/api/settings', '/api/audit-logs']) {
      const r = await fetch(`${baseUrl}${adminPath}`, {
        headers: { Cookie: empASession1.cookie },
      });
      assert.equal(r.status, 403, `Employee must receive 403 on ${adminPath}`);
    }
  } finally {
    await new Promise((resolve) => server.close(resolve));
    realtimeHub.closeAll();
    closeDatabaseSafely(db);
    fs.rmSync(tmpDir, { recursive: true, force: true });
    if (prevSecret === undefined) {
      delete process.env.SESSION_SECRET;
    } else {
      process.env.SESSION_SECRET = prevSecret;
    }
  }
});
