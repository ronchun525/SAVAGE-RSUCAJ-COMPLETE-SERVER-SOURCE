import assert from 'node:assert/strict';
import { test } from 'node:test';
import { computeAndroidAttendanceDigest, computeAndroidEnrollmentHash,
  validateAndroidPunch, validateAndroidEnrollment } from '../server/androidBridgeProtocol.ts';
const now = Date.parse('2026-11-22T02:00:00.000Z');
const device = 'SAVAGE-RSUCAJ-KIOSK-01';
function makePunch(patch={}) {
  const base = { event_id:'event-99112233', employee_id:'EMP001',action:'TIME_IN',
    kiosk_device_id:device,captured_at_ms:now-4000, biometric_confidence:0.9,
    liveness_score:0.92,anti_spoofing_score:0.96,offline_queued:false, ...patch };
  return [base, {idempotencyKey:base.event_id,eventTimestamp:String(base.captured_at_ms),
    digest:computeAndroidAttendanceDigest(base.event_id,base.employee_id,base.action,base.captured_at_ms,base.kiosk_device_id)}];
}
test('live punch valid contract accepted; no evidence of actual camera is implied',()=>{
  const [payload,headers] = makePunch();
  assert.deepEqual(validateAndroidPunch(payload,headers,device,now),{valid:true});
});
test('reject invalid scores, future timestamps, device switching and unsupported action',()=>{
  for(const [key,value] of [['biometric_confidence',0.1],['liveness_score',NaN],['anti_spoofing_score',Infinity],
    ['captured_at_ms',now+3600_000],['kiosk_device_id','FAKE'],['action','BREAK_OUT'],['offline_queued','true']]) {
    const [p,h] = makePunch({[key]:value});
    assert.equal(validateAndroidPunch(p,h,device,now).valid,false,key);
  }
});
test('reject wrong or missing digest, replay id and timestamp headers',()=>{
  const [p,h] = makePunch();
  for(const patch of [{digest:'0'.repeat(64)},{digest:undefined},{idempotencyKey:'different'},
    {eventTimestamp:'123'}]) {
    assert.equal(validateAndroidPunch(p,{...h,...patch},device,now).valid,false);
  }
});
test('enrollment requires valid vector hash, idempotency key, fresh timestamp and device',()=>{
  const raw=Array.from({length:192},(_,i)=>Math.sin(i + 1));
  const magnitude=Math.sqrt(raw.reduce((sum,x)=>sum+x*x,0));
  const embedding=raw.map(x=>x/magnitude);
  const base={employee_id:'EMP001',employee_name:'Test Employee',kiosk_device_id:device,
    embedding_sha256:computeAndroidEnrollmentHash('EMP001','Test Employee',embedding),
    composite_embedding:embedding,enrolled_at_ms:now};
  const key=`EMP001-${base.embedding_sha256}`;
  assert.deepEqual(validateAndroidEnrollment(base,key,device,now),{valid:true});
  for(const [p,k] of [[{...base,composite_embedding:Array(192).fill(0.1)},key],
    [{...base,employee_name:'Changed Name'},key], [{...base,kiosk_device_id:'BAD'},key],
    [{...base,enrolled_at_ms:now-11*60_000},key], [base,'wrong']]) {
    assert.equal(validateAndroidEnrollment(p,k,device,now).valid,false);
  }
});

test('real backend envelope validator rejects tampered HMAC, identity, action, and spoof flags', async () => {
  const { createBiometricEvidenceEnvelope, verifyBiometricEvidenceEnvelope } = await import('../server/kioskOfflineQueue.ts');
  const apiToken='long-token-supplied-by-device-registration';
  const fields={deviceId:9,deviceBootId:'boot-test-2026',monotonicSeq:101,
    eventUid:'event-999999',employeeCode:'EMP001',punchType:'TIME_IN',
    capturedAtUtc:'2026-11-22T02:00:00.000Z',
    biometricTemplateHash:'a'.repeat(64),livenessVerified:true,matchVerified:true};
  const proof=createBiometricEvidenceEnvelope({apiToken,...fields});
  const expected={deviceId:9,eventUid:'event-999999',employeeCode:'EMP001',punchType:'TIME_IN',
    capturedAtUtc:'2026-11-22T02:00:00.000Z'};
  assert.equal(verifyBiometricEvidenceEnvelope(apiToken,expected,proof).valid,true);
  assert.equal(verifyBiometricEvidenceEnvelope('wrong-token',expected,proof).valid,false);
  assert.equal(verifyBiometricEvidenceEnvelope(apiToken, {...expected,punchType:'TIME_OUT'},proof).valid,false);
  assert.equal(verifyBiometricEvidenceEnvelope(apiToken, expected, {...proof, employee_code:'EMP002'}).valid,false);
  assert.equal(verifyBiometricEvidenceEnvelope(apiToken, expected, {...proof,liveness_verified:false}).valid,false);
  assert.equal(verifyBiometricEvidenceEnvelope(apiToken, expected, {...proof,evidence_hash:'b'.repeat(64)}).valid,false);
});
