import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import { closeDatabaseSafely, initDatabase } from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import {
  EncryptedKioskQueue,
  KioskSyncClient,
  createBiometricEvidenceEnvelope,
} from '../server/kioskOfflineQueue.ts';
import { RealtimeHub } from '../server/realtimeHub.ts';

let passed = 0;
let failed = 0;

async function test(name: string, fn: () => Promise<void> | void) {
  try {
    await fn();
    passed++;
    console.log(`PASS  ${name}`);
  } catch (err) {
    failed++;
    console.error(`FAIL  ${name}`);
    console.error('     ', err instanceof Error ? err.stack || err.message : err);
  }
}

interface SessionJar {
  sessionCookie: string;
  csrfToken: string;
}

function parseCookies(setCookieHeaders: string[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const raw of setCookieHeaders) {
    const first = raw.split(';')[0];
    const eq = first.indexOf('=');
    if (eq > 0) out[first.slice(0, eq).trim()] = first.slice(eq + 1).trim();
  }
  return out;
}

async function run() {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-b10-sync-'));
  const dbPath = path.join(tmpDir, 'sync.db');
  const queuePath = path.join(tmpDir, 'kiosk_queue.enc.json');
  const queueEncKey = crypto.randomBytes(24).toString('hex');
  const sessionSecret = crypto.randomBytes(48).toString('hex');
  const adminPass = `Sync!${crypto.randomBytes(6).toString('hex')}9A`;

  // Controllable virtual clock: Monday 2026-04-06 08:05:00 Asia/Manila (00:05:00 UTC)
  let virtualNowMs = Date.parse('2026-04-06T00:05:00.000Z');
  const nowProvider = () => virtualNowMs;

  process.env.SESSION_SECRET = sessionSecret;

  let db = initDatabase(dbPath, {
    mode: 'test',
    seedDemoData: true,
    initialAdmin: {
      username: 'sync_admin',
      email: 'sync_admin@rsucaj.edu.ph',
      password: adminPass,
    },
  });
  db.prepare(`UPDATE users SET must_change_password = 0 WHERE username = 'sync_admin'`).run();

  let hub = new RealtimeHub({ keepaliveIntervalMs: 60_000 });

  async function startTestServer() {
    const app = express();
    app.set('trust proxy', 1);
    app.use(express.json({ limit: '5mb' }));
    app.use('/api', createApiRouter(db, { nowProvider, realtimeHub: hub }));
    const srv = await new Promise<http.Server>((resolve) => {
      const s = app.listen(0, '127.0.0.1', () => resolve(s));
    });
    const addr = srv.address();
    assert.ok(addr && typeof addr !== 'string');
    return { server: srv, baseUrl: `http://127.0.0.1:${addr.port}` };
  }

  let { server, baseUrl } = await startTestServer();

  async function req(
    urlPath: string,
    options: RequestInit = {},
    jar?: SessionJar
  ): Promise<{ status: number; body: Record<string, unknown>; headers: Headers }> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...((options.headers as Record<string, string>) || {}),
    };
    if (jar?.sessionCookie) headers.Cookie = jar.sessionCookie;
    if (jar?.csrfToken && options.method && !['GET', 'HEAD', 'OPTIONS'].includes(options.method.toUpperCase())) {
      headers['X-CSRF-Token'] = jar.csrfToken;
    }
    const res = await fetch(`${baseUrl}${urlPath}`, { ...options, headers });
    const text = await res.text();
    let body: Record<string, unknown> = {};
    try {
      body = text ? JSON.parse(text) : {};
    } catch {
      body = { raw: text };
    }
    return { status: res.status, body, headers: res.headers };
  }

  async function login(identifier: string, password: string): Promise<SessionJar> {
    const res = await req('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier, password }),
    });
    assert.equal(res.status, 200, `Login failed for ${identifier}: ${JSON.stringify(res.body)}`);
    const setCookies = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    const cookies = parseCookies(setCookies);
    assert.ok(cookies.savage_rsucaj_session);
    return {
      sessionCookie: `savage_rsucaj_session=${cookies.savage_rsucaj_session}`,
      csrfToken: String(res.body.csrfToken || ''),
    };
  }

  try {
    const adminJar = await login('sync_admin', adminPass);

    // Fetch first kiosk device (masked on GET) & issue one-time token via rotation + employees
    const devsRes = await req('/api/devices', {}, adminJar);
    assert.equal(devsRes.status, 200);
    const devices = devsRes.body.data as Array<{ id: number; name: string; api_token?: string }>;
    assert.ok(devices.length >= 1);
    assert.equal('api_token' in devices[0], false, 'GET /api/devices must never expose plaintext api_token');
    const rotKiosk = await req(`/api/devices/${devices[0].id}/rotate-token`, { method: 'POST', body: JSON.stringify({}) }, adminJar);
    assert.equal(rotKiosk.status, 200);
    const kiosk = { ...devices[0], api_token: String(rotKiosk.body.api_token) };

    const empsRes = await req('/api/employees?limit=50', {}, adminJar);
    const employees = empsRes.body.data as Array<{ id: number; employee_code: string; department_id: number }>;
    assert.ok(employees.length >= 5);

    // -------------------------------------------------------------------------
    // TEST 1: AES-256-GCM Encrypted Queue Outage (1m -> 30m) & Device Reboot Durability
    // -------------------------------------------------------------------------
    await test('Encrypted offline queue stores AES-256-GCM ciphertext, survives simulated device reboot & 30m outage, and flushes cleanly', async () => {
      const queue = new EncryptedKioskQueue({
        queueFilePath: queuePath,
        encryptionKey: queueEncKey,
        apiToken: kiosk.api_token,
        deviceId: kiosk.id,
        deviceName: kiosk.name,
        nowProvider,
      });

      // Enqueue punches across 1m, 15m, and 30m outage window
      queue.enqueuePunch({
        employeeCode: employees[0].employee_code,
        punchType: 'TIME_IN',
        capturedAtUtc: new Date(virtualNowMs).toISOString(),
        offlineReplay: true,
      });
      virtualNowMs += 15 * 60_000;
      queue.enqueuePunch({
        employeeCode: employees[1].employee_code,
        punchType: 'TIME_IN',
        capturedAtUtc: new Date(virtualNowMs).toISOString(),
        offlineReplay: true,
      });
      virtualNowMs += 15 * 60_000;
      queue.enqueuePunch({
        employeeCode: employees[2].employee_code,
        punchType: 'TIME_IN',
        capturedAtUtc: new Date(virtualNowMs).toISOString(),
        offlineReplay: true,
      });

      assert.equal(queue.getPendingCount(), 3);

      // Verify file on disk is strictly encrypted (no plaintext employee codes)
      const rawDisk = fs.readFileSync(queuePath, 'utf8');
      assert.ok(rawDisk.includes('savage-kiosk-queue-aes256gcm-v1'));
      assert.equal(rawDisk.includes(employees[0].employee_code), false);

      // Simulate device power loss & reboot (new boot session reloads pending events & monotonic seq)
      const rebootedQueue = new EncryptedKioskQueue({
        queueFilePath: queuePath,
        encryptionKey: queueEncKey,
        apiToken: kiosk.api_token,
        deviceId: kiosk.id,
        deviceName: kiosk.name,
        newBootSession: true,
        nowProvider,
      });
      assert.equal(rebootedQueue.getPendingCount(), 3);
      assert.equal(rebootedQueue.getLastMonotonicSeq(), 3);

      const client = new KioskSyncClient({
        baseUrl,
        apiToken: kiosk.api_token,
        queue: rebootedQueue,
        nowProvider,
      });
      const flush = await client.flushQueue();
      assert.equal(flush.ok, true);
      assert.equal(flush.processedCount, 3);
      assert.equal(flush.remainingQueueCount, 0);

      // Replaying the exact same batch events must be idempotent (duplicate)
      const dupSync = await req('/api/kiosk/sync', {
        method: 'POST',
        headers: { 'x-kiosk-token': kiosk.api_token },
        body: JSON.stringify({
          batch_uid: 'dup-replay-batch-001',
          device_boot_id: rebootedQueue.getDeviceBootId(),
          device_timestamp: new Date(virtualNowMs).toISOString(),
          events: (flush.results || []).map((r, idx) => ({
            event_uid: r.event_uid,
            monotonic_seq: idx + 1,
            device_boot_id: rebootedQueue.getDeviceBootId(),
            employee_code: employees[idx].employee_code,
            punch_type: 'TIME_IN',
            captured_at_utc: new Date(virtualNowMs).toISOString(),
            offline_replay: true,
          })),
        }),
      });
      assert.equal(dupSync.status, 200);
      assert.equal((dupSync.body.summary as { duplicate: number }).duplicate, 3);
      assert.equal((dupSync.body.summary as { accepted: number }).accepted, 0);
    });

    // -------------------------------------------------------------------------
    // TEST 2: High-Volume Batch Sync (45+ events) & Out-of-Order Sorting + Lone TIME_OUT Escalation
    // -------------------------------------------------------------------------
    await test('High-volume batch sync (45+ events) sorts out-of-order punches & escalates lone TIME_OUT without clobbering', async () => {
      // Create 20 extra active employees so we can sync 45+ valid distinct punches cleanly
      const dept = db.prepare('SELECT id FROM departments LIMIT 1').get() as { id: number };
      const pos = db.prepare('SELECT id FROM positions LIMIT 1').get() as { id: number };
      const shift = db.prepare("SELECT id FROM shifts WHERE name LIKE '%Regular%' LIMIT 1").get() as { id: number };
      const batchCodes: string[] = [];
      for (let i = 1; i <= 25; i++) {
        const code = `EMP-SYNC-${String(i).padStart(3, '0')}`;
        db.prepare(
          `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status, hired_date)
           VALUES (?, ?, ?, ?, ?, ?, 'Active', '2025-01-01')`
        ).run(code, `Sync Faculty ${i}`, `sync${i}@rsucaj.edu.ph`, dept.id, pos.id, shift.id);
        batchCodes.push(code);
      }

      // Advance clock to Tuesday 2026-04-07 17:10 Asia/Manila (09:10 UTC)
      virtualNowMs = Date.parse('2026-04-07T09:10:00.000Z');
      const bootId = 'boot-hv-01';
      const events: Array<Record<string, unknown>> = [];
      let seq = 100;

      // For 23 employees: submit TIME_OUT *before* TIME_IN in the payload to prove intra-batch chronological sorting
      for (let i = 0; i < 23; i++) {
        const inUtc = `2026-04-07T00:${String(i % 20).padStart(2, '0')}:00.000Z`; // 08:xx AM Manila
        const outUtc = `2026-04-07T09:${String(i % 10).padStart(2, '0')}:00.000Z`; // 05:xx PM Manila

        const uidOut = `hv-out-${i}`;
        const seqOut = ++seq;
        events.push({
          event_uid: uidOut,
          monotonic_seq: seqOut,
          device_boot_id: bootId,
          employee_code: batchCodes[i],
          punch_type: 'TIME_OUT',
          device_timestamp: outUtc,
          offline_replay: true,
          biometric_evidence: createBiometricEvidenceEnvelope({
            apiToken: kiosk.api_token,
            deviceId: kiosk.id,
            deviceBootId: bootId,
            monotonicSeq: seqOut,
            eventUid: uidOut,
            employeeCode: batchCodes[i],
            punchType: 'TIME_OUT',
            capturedAtUtc: outUtc,
          }),
        });

        const uidIn = `hv-in-${i}`;
        const seqIn = ++seq;
        events.push({
          event_uid: uidIn,
          monotonic_seq: seqIn,
          device_boot_id: bootId,
          employee_code: batchCodes[i],
          punch_type: 'TIME_IN',
          device_timestamp: inUtc,
          offline_replay: true,
          biometric_evidence: createBiometricEvidenceEnvelope({
            apiToken: kiosk.api_token,
            deviceId: kiosk.id,
            deviceBootId: bootId,
            monotonicSeq: seqIn,
            eventUid: uidIn,
            employeeCode: batchCodes[i],
            punchType: 'TIME_IN',
            capturedAtUtc: inUtc,
          }),
        });
      }

      // Employee #24: lone TIME_OUT with no TIME_IN -> escalated/conflict
      const loneUid = 'hv-lone-out';
      const loneSeq = ++seq;
      const loneUtc = '2026-04-07T09:05:00.000Z';
      events.push({
        event_uid: loneUid,
        monotonic_seq: loneSeq,
        device_boot_id: bootId,
        employee_code: batchCodes[23],
        punch_type: 'TIME_OUT',
        device_timestamp: loneUtc,
        offline_replay: true,
        biometric_evidence: createBiometricEvidenceEnvelope({
          apiToken: kiosk.api_token,
          deviceId: kiosk.id,
          deviceBootId: bootId,
          monotonicSeq: loneSeq,
          eventUid: loneUid,
          employeeCode: batchCodes[23],
          punchType: 'TIME_OUT',
          capturedAtUtc: loneUtc,
        }),
      });

      assert.equal(events.length, 47);

      const syncRes = await req('/api/kiosk/sync', {
        method: 'POST',
        headers: { 'x-kiosk-token': kiosk.api_token },
        body: JSON.stringify({
          batch_uid: 'hv-batch-47',
          device_boot_id: bootId,
          device_timestamp: new Date(virtualNowMs).toISOString(),
          events,
        }),
      });
      assert.equal(syncRes.status, 200);
      const summary = syncRes.body.summary as { accepted: number; escalated: number; rejected: number };
      assert.equal(summary.accepted, 46);
      assert.equal(summary.escalated, 1);
      assert.equal(summary.rejected, 0);
    });

    // -------------------------------------------------------------------------
    // TEST 3: Biometric HMAC Attestation Tampering Rejected
    // -------------------------------------------------------------------------
    await test('Tampered biometric HMAC evidence envelope is rejected with 422 / BIOMETRIC_EVIDENCE_INVALID', async () => {
      const tamperedEnv = createBiometricEvidenceEnvelope({
        apiToken: kiosk.api_token,
        deviceId: kiosk.id,
        deviceBootId: 'boot-tamper',
        monotonicSeq: 500,
        eventUid: 'tamper-uid-1',
        employeeCode: employees[0].employee_code,
        punchType: 'TIME_IN',
        capturedAtUtc: new Date(virtualNowMs).toISOString(),
      });
      // Tamper with employee_code after HMAC signing
      tamperedEnv.employee_code = employees[1].employee_code;

      const single = await req('/api/kiosk/punch', {
        method: 'POST',
        headers: { 'x-kiosk-token': kiosk.api_token },
        body: JSON.stringify({
          employee_code: employees[1].employee_code,
          punch_type: 'TIME_IN',
          event_uid: 'tamper-uid-1',
          device_boot_id: 'boot-tamper',
          monotonic_seq: 500,
          device_timestamp: new Date(virtualNowMs).toISOString(),
          biometric_evidence: tamperedEnv,
        }),
      });
      assert.equal(single.status, 422);
      assert.equal(single.body.code, 'BIOMETRIC_EVIDENCE_INVALID');
    });

    // -------------------------------------------------------------------------
    // TEST 4: Server Restart Durability
    // -------------------------------------------------------------------------
    await test('Synced attendance events and sync batch logs survive full server & SQLite restart', async () => {
      await new Promise<void>((resolve) => server.close(() => resolve()));
      hub.closeAll();
      closeDatabaseSafely(db);

      // Reopen DB & restart HTTP server
      db = initDatabase(dbPath, { mode: 'test', seedDemoData: false });
      hub = new RealtimeHub({ keepaliveIntervalMs: 60_000 });
      const restarted = await startTestServer();
      server = restarted.server;
      baseUrl = restarted.baseUrl;

      const freshJar = await login('sync_admin', adminPass);
      const batches = await req(`/api/devices/${kiosk.id}/sync-batches`, {}, freshJar);
      assert.equal(batches.status, 200);
      assert.ok((batches.body.data as unknown[]).length >= 2);

      const att = await req('/api/attendance?date=2026-04-07&limit=50', {}, freshJar);
      assert.equal(att.status, 200);
      assert.ok((att.body.total as number) >= 23);
    });

    // -------------------------------------------------------------------------
    // TEST 5: Heartbeat Expiry (Online -> Stale -> Offline), Revoked Device Rejection & Zero Token Leak
    // -------------------------------------------------------------------------
    await test('Heartbeat expiry drives Online -> Stale -> Offline and revoked kiosk is rejected (403 DEVICE_REVOKED)', async () => {
      const jar = await login('sync_admin', adminPass);
      const hb = await req('/api/kiosk/heartbeat', {
        method: 'POST',
        headers: { 'x-kiosk-token': kiosk.api_token },
        body: JSON.stringify({
          device_timestamp: new Date(virtualNowMs).toISOString(),
          pending_queue_count: 0,
        }),
      });
      assert.equal(hb.status, 200);

      // Immediately after heartbeat -> Online
      let list = (await req('/api/devices', {}, jar)).body.data as Array<{
        id: number;
        connectivity: string;
        stale_warning: boolean;
      }>;
      assert.equal(list.find((d) => d.id === kiosk.id)?.connectivity, 'Online');

      // Advance 75 seconds -> Stale
      virtualNowMs += 75_000;
      list = (await req('/api/devices', {}, jar)).body.data as Array<{
        id: number;
        connectivity: string;
        stale_warning: boolean;
      }>;
      assert.equal(list.find((d) => d.id === kiosk.id)?.connectivity, 'Stale');

      // Advance another 180 seconds (> 3 minutes total) -> Offline
      virtualNowMs += 180_000;
      const listOffline = (await req('/api/devices', {}, jar)).body.data as Array<{
        id: number;
        connectivity: string;
      }>;
      assert.equal(listOffline.find((d) => d.id === kiosk.id)?.connectivity, 'Offline');

      // Dashboard must NEVER leak api_token
      const dash = await req('/api/dashboard', {}, jar);
      const dashDevs = dash.body.devices as Array<Record<string, unknown>>;
      for (const d of dashDevs) {
        assert.equal('api_token' in d, false, 'Dashboard devices must not expose api_token');
      }

      // Revoke device -> heartbeat and sync rejected with 403 DEVICE_REVOKED
      const rev = await req(`/api/devices/${kiosk.id}/revoke`, { method: 'POST' }, jar);
      assert.equal(rev.status, 200);

      const revHb = await req('/api/kiosk/heartbeat', {
        method: 'POST',
        headers: { 'x-kiosk-token': kiosk.api_token },
        body: JSON.stringify({ device_timestamp: new Date(virtualNowMs).toISOString() }),
      });
      assert.equal(revHb.status, 403);
      assert.equal(revHb.body.code, 'DEVICE_REVOKED');

      const revSync = await req('/api/kiosk/sync', {
        method: 'POST',
        headers: { 'x-kiosk-token': kiosk.api_token },
        body: JSON.stringify({ batch_uid: 'rev-batch', events: [] }),
      });
      assert.equal(revSync.status, 403);
      assert.equal(revSync.body.code, 'DEVICE_REVOKED');

      // Restore access for SSE test
      const restore = await req(`/api/devices/${kiosk.id}/restore-access`, { method: 'POST' }, jar);
      assert.equal(restore.status, 200);
    });

    // -------------------------------------------------------------------------
    // TEST 6: Authenticated & RBAC-Scoped SSE Delivery (Latency Measurement) & Employee Read-Only Today Attendance
    // -------------------------------------------------------------------------
    await test('SSE stream enforces auth & RBAC scoping, measures live delivery latency, and Employee Today Attendance is read-only', async () => {
      // Unauthenticated SSE must be rejected with 401
      const unauthSse = await fetch(`${baseUrl}/api/events/stream?channels=attendance:updated`);
      assert.equal(unauthSse.status, 401);

      // Create an Employee portal account linked to employees[0]
      const jar = await login('sync_admin', adminPass);
      const empPass = `Emp!${crypto.randomBytes(6).toString('hex')}8Q`;
      const createdEmpUser = await req(
        '/api/users',
        {
          method: 'POST',
          body: JSON.stringify({
            username: 'emp_readonly_sync',
            email: 'emp_readonly_sync@rsucaj.edu.ph',
            full_name: 'Read Only Employee',
            role: 'Employee',
            employee_id: employees[0].id,
            password: empPass,
            must_change_password: false,
          }),
        },
        jar
      );
      assert.equal(createdEmpUser.status, 201);
      const empJar = await login('emp_readonly_sync', empPass);

      // Verify Employee Today Attendance endpoint is read-only with allow_manual_punch=false
      const todayRes = await req('/api/employee/today-attendance', {}, empJar);
      assert.equal(todayRes.status, 200);
      assert.equal(todayRes.body.read_only, true);
      assert.equal(todayRes.body.allow_manual_punch, false);

      // Employee attempting manual attendance write must get 403
      const forbiddenWrite = await req(
        '/api/attendance',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: employees[0].id,
            date: '2026-04-08',
            time_in: '08:00 AM',
            status: 'Present',
          }),
        },
        empJar
      );
      assert.equal(forbiddenWrite.status, 403);

      // Open authenticated SSE stream as Admin & as Employee
      const adminAbort = new AbortController();
      const empAbort = new AbortController();
      const adminSseRes = await fetch(`${baseUrl}/api/events/stream?channels=attendance:updated,device:telemetry`, {
        headers: { Cookie: jar.sessionCookie },
        signal: adminAbort.signal,
      });
      assert.equal(adminSseRes.status, 200);

      const empSseRes = await fetch(`${baseUrl}/api/events/stream?channels=attendance:updated,device:telemetry`, {
        headers: { Cookie: empJar.sessionCookie },
        signal: empAbort.signal,
      });
      assert.equal(empSseRes.status, 200);

      const adminChunks: string[] = [];
      const empChunks: string[] = [];
      const pumpStream = async (reader: ReadableStreamDefaultReader<Uint8Array>, chunks: string[]) => {
        const decoder = new TextDecoder();
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            if (value) chunks.push(decoder.decode(value, { stream: true }));
          }
        } catch {
          // stream aborted cleanly on teardown
        }
      };

      const waitForChunk = async (chunks: string[], needle: string, timeoutMs = 2500): Promise<number> => {
        const deadline = Date.now() + timeoutMs;
        while (Date.now() < deadline) {
          if (chunks.join('').includes(needle)) return Date.now();
          await new Promise((r) => setTimeout(r, 20));
        }
        return -1;
      };

      const adminReader = adminSseRes.body!.getReader();
      const empReader = empSseRes.body!.getReader();
      void pumpStream(adminReader, adminChunks);
      void pumpStream(empReader, empChunks);

      try {
        // Advance clock to Wednesday 2026-04-08 08:00 AM Manila
        virtualNowMs = Date.parse('2026-04-08T00:00:00.000Z');
        const sentAt = Date.now();

        // Punch for employees[1] (NOT employees[0]!) -> Admin receives SSE, Employee[0] must NOT receive it
        const punchOther = await req('/api/kiosk/punch', {
          method: 'POST',
          headers: { 'x-kiosk-token': kiosk.api_token },
          body: JSON.stringify({
            employee_code: employees[1].employee_code,
            punch_type: 'TIME_IN',
            event_uid: 'sse-scope-other-emp',
            device_timestamp: new Date(virtualNowMs).toISOString(),
          }),
        });
        assert.equal(punchOther.status, 201);

        const adminGotAt = await waitForChunk(adminChunks, employees[1].employee_code, 2500);
        assert.ok(adminGotAt > 0, 'Admin SSE should receive attendance:updated event');
        const latencyMs = Math.max(0, adminGotAt - sentAt);
        console.log(`      Measured authenticated SSE attendance:updated latency: ${latencyMs}ms`);

        // Wait briefly and confirm Employee[0] did NOT receive Employee[1]'s event
        await new Promise((r) => setTimeout(r, 250));
        assert.equal(empChunks.join('').includes(employees[1].employee_code), false);

        // Now punch for employees[0] -> Employee[0] MUST receive their own attendance:updated event
        const punchSelf = await req('/api/kiosk/punch', {
          method: 'POST',
          headers: { 'x-kiosk-token': kiosk.api_token },
          body: JSON.stringify({
            employee_code: employees[0].employee_code,
            punch_type: 'TIME_IN',
            event_uid: 'sse-scope-self-emp',
            device_timestamp: new Date(virtualNowMs).toISOString(),
          }),
        });
        assert.equal(punchSelf.status, 201);
        const empGotAt = await waitForChunk(empChunks, employees[0].employee_code, 2500);
        assert.ok(empGotAt > 0, 'Employee SSE should receive own attendance:updated event');
      } finally {
        adminAbort.abort();
        empAbort.abort();
        try {
          await adminReader.cancel();
        } catch {
          // ignore
        }
        try {
          await empReader.cancel();
        } catch {
          // ignore
        }
      }
    });
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    hub.closeAll();
    closeDatabaseSafely(db);
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }

  console.log(`\nSync & Realtime Tests Summary: ${passed} passed, ${failed} failed.`);
  if (failed > 0) process.exit(1);
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
