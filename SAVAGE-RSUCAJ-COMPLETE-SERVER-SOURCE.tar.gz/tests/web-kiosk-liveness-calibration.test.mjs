/**
 * SAVAGE-RSUCAJ BUILD 36 — PROMPT 08/08
 * Targeted Liveness, Anti-Spoofing (PAD), Anti-Averaging State Machine,
 * Calibration Governance & Fail-Closed Server Policy Verification Suite.
 *
 * Run with: npx tsx --test tests/web-kiosk-liveness-calibration.test.mjs
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import express from 'express';

import { initDatabase } from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import { securityHeadersMiddleware } from '../server/security.ts';
import {
  BIOMETRIC_THRESHOLDS,
  decodeClassifierLiveScore,
  EMBEDDING_DIMENSION,
  encodeLivenessBgrNchw,
  encodePadRgbNhwc,
  encodeRecognitionRgbNhwc,
  KIOSK_MODEL_SPECS as SERVER_MODEL_SPECS,
  validateL2NormalizedEmbedding,
} from '../server/webKioskBiometrics.ts';
import {
  computeBiometricCalibrationMetrics,
  evaluateMultiFrameBiometricEvidence,
  WEB_KIOSK_POLICY,
} from '../server/webKioskPolicy.ts';
import {
  DEFAULT_VERIFICATION_POLICY,
  KIOSK_MODEL_SPECS as CLIENT_MODEL_SPECS,
  KioskVerificationStateMachine,
  preprocessFaceFrameTensors,
} from '../src/lib/kioskBiometrics.ts';

process.env.SESSION_SECRET = crypto.randomBytes(48).toString('hex');
process.env.KIOSK_TEMPLATE_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');

function makeUnitVector(seed) {
  const arr = new Array(EMBEDDING_DIMENSION);
  let sumSq = 0;
  for (let i = 0; i < EMBEDDING_DIMENSION; i++) {
    const val = Math.sin((i + 1) * (seed + 2.13)) * Math.cos((i + 5) * (seed * 0.61 + 0.4));
    arr[i] = val;
    sumSq += val * val;
  }
  const norm = Math.sqrt(sumSq);
  return arr.map((v) => v / norm);
}

function makeGoodFrame(ts, overrides = {}) {
  return {
    timestamp_ms: ts,
    face_count: 1,
    detection_confidence: 0.94,
    quality_score: 0.88,
    lighting_ok: true,
    sharpness_ok: true,
    frozen_frame: false,
    occlusion_suspected: false,
    bounding_box: { x: 0.3, y: 0.2, width: 0.4, height: 0.5 },
    pad_score: 0.91,
    liveness_score: 0.92,
    ...overrides,
  };
}

function makeSmFrame(ts, overrides = {}) {
  return {
    timestampMs: ts,
    cameraReady: true,
    cameraErrorCode: null,
    modelsVerifiedOnDisk: true,
    serverInferenceAvailable: true,
    backendOnline: true,
    faceCount: 1,
    centered: true,
    sizeOk: true,
    lightingOk: true,
    sharpnessOk: true,
    frozenFrame: false,
    occlusionSuspected: false,
    boundingBox: { x: 0.3, y: 0.2, width: 0.4, height: 0.5 },
    detectionConfidence: 0.94,
    qualityScore: 0.88,
    padScore: 0.91,
    livenessScore: 0.92,
    ...overrides,
  };
}

function createCookieJar() {
  const map = new Map();
  return {
    ingest(res) {
      const setCookies =
        typeof res.headers.getSetCookie === 'function'
          ? res.headers.getSetCookie()
          : res.headers.get('set-cookie')
            ? [res.headers.get('set-cookie')]
            : [];
      for (const raw of setCookies) {
        const first = String(raw).split(';')[0];
        const eq = first.indexOf('=');
        if (eq > 0) {
          const name = first.slice(0, eq).trim();
          const val = first.slice(eq + 1).trim();
          if (val === '' || /Max-Age=0/i.test(raw)) map.delete(name);
          else map.set(name, val);
        }
      }
    },
    header() {
      return Array.from(map.entries())
        .map(([k, v]) => `${k}=${v}`)
        .join('; ');
    },
  };
}

async function startKioskTestServer(appMode, nowRef) {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-p08-'));
  const dbPath = path.join(tmpDir, 'test.db');
  const db = initDatabase(dbPath, {
    mode: appMode,
    initialAdmin: {
      username: 'sysadmin',
      email: 'admin@rsu-cajidiocan.tech',
      password: 'StrongPassword#2026!',
    },
  });

  db.prepare(`UPDATE users SET must_change_password = 0 WHERE username = 'sysadmin'`).run();
  db.prepare(`INSERT OR IGNORE INTO departments (code, name) VALUES ('DCS', 'Computer Studies')`).run();
  db.prepare(`INSERT OR IGNORE INTO positions (code, name, base_salary) VALUES ('INST1', 'Instructor I', 28000)`).run();
  db.prepare(
    `INSERT OR IGNORE INTO shifts (name, time_in, time_out, grace_minutes, status) VALUES ('Regular Day', '08:00', '17:00', 15, 'Active')`
  ).run();
  const dept = db.prepare(`SELECT id FROM departments LIMIT 1`).get();
  const pos = db.prepare(`SELECT id FROM positions LIMIT 1`).get();
  const shift = db.prepare(`SELECT id FROM shifts LIMIT 1`).get();

  db.prepare(
    `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status)
     VALUES ('RSU-0101', 'Elena Reyes', 'elena@rsu.edu.ph', ?, ?, ?, 'Active'),
            ('RSU-0102', 'Marco Bautista', 'marco@rsu.edu.ph', ?, ?, ?, 'Active')`
  ).run(dept.id, pos.id, shift.id, dept.id, pos.id, shift.id);

  const app = express();
  app.use(securityHeadersMiddleware);
  app.use(express.json({ limit: '2mb' }));
  app.use(
    '/api',
    createApiRouter(db, {
      appMode,
      nowMs: () => nowRef.value,
    })
  );

  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const addr = server.address();
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  return {
    db,
    baseUrl,
    async close() {
      await new Promise((resolve) => server.close(resolve));
      db.close();
      fs.rmSync(tmpDir, { recursive: true, force: true });
    },
  };
}

// ============================================================================
// 1. EXACT BUILD 20 MODEL CONTRACT & PREPROCESSING TESTS
// ============================================================================

test('BUILD 20 model contracts match across client & server (SHA-256, layouts, color orders, live class indices)', () => {
  assert.equal(SERVER_MODEL_SPECS.anti_spoofing_pad.expectedSha256, '5d573d20b795a19d7b2a0f67cc4c1130ce8ec30d5f6aa06b2c788a344a49d4dd');
  assert.equal(SERVER_MODEL_SPECS.liveness_detection.expectedSha256, '4ff758f470b757d9005b418c9978693f09b8f2a5e7b7ee848c160db21208e1b2');
  assert.equal(SERVER_MODEL_SPECS.face_recognition.expectedSha256, 'be4bc7cfc53f7bc336d0f28b1ab92535f618c913a422b683210750f6b5354854');

  // Client & Server SHA-256 and class indices must be identical
  assert.equal(CLIENT_MODEL_SPECS.anti_spoofing_pad.expectedSha256, SERVER_MODEL_SPECS.anti_spoofing_pad.expectedSha256);
  assert.equal(CLIENT_MODEL_SPECS.liveness_detection.expectedSha256, SERVER_MODEL_SPECS.liveness_detection.expectedSha256);
  assert.equal(CLIENT_MODEL_SPECS.face_recognition.expectedSha256, SERVER_MODEL_SPECS.face_recognition.expectedSha256);

  assert.equal(CLIENT_MODEL_SPECS.anti_spoofing_pad.liveClassIndex, 0);
  assert.equal(CLIENT_MODEL_SPECS.liveness_detection.liveClassIndex, 1);
  assert.deepEqual(CLIENT_MODEL_SPECS.anti_spoofing_pad.inputShape, [1, 80, 80, 3]);
  assert.deepEqual(CLIENT_MODEL_SPECS.liveness_detection.inputShape, [1, 3, 80, 80]);
  assert.deepEqual(CLIENT_MODEL_SPECS.face_recognition.inputShape, [1, 112, 112, 3]);

  // Uncalibrated 0.80 thresholds must NEVER be lowered below 0.80
  assert.equal(BIOMETRIC_THRESHOLDS.ANTI_SPOOF_MIN_SCORE, 0.80);
  assert.equal(BIOMETRIC_THRESHOLDS.LIVENESS_MIN_SCORE, 0.80);
  assert.equal(WEB_KIOSK_POLICY.thresholds.pad_min_score, 0.80);
  assert.equal(WEB_KIOSK_POLICY.thresholds.liveness_min_score, 0.80);
  assert.equal(WEB_KIOSK_POLICY.calibration_status, 'UNCALIBRATED_STAGING_ONLY');
  assert.equal(WEB_KIOSK_POLICY.certified_for_production, false);
  assert.equal(DEFAULT_VERIFICATION_POLICY.padMinScore, 0.80);
  assert.equal(DEFAULT_VERIFICATION_POLICY.livenessMinScore, 0.80);
});

test('Tensor encoding & client preprocessing produce exact NHWC RGB, NCHW BGR, and 112x112 RGB normalizations', () => {
  const rgba80 = new Uint8ClampedArray(80 * 80 * 4);
  // Pixel 0: R=255, G=128, B=0
  rgba80[0] = 255;
  rgba80[1] = 128;
  rgba80[2] = 0;
  rgba80[3] = 255;

  const pad = encodePadRgbNhwc(rgba80, 80, 80);
  assert.equal(pad.length, 80 * 80 * 3);
  assert.ok(Math.abs(pad[0] - (255 / 128 - 1)) < 1e-5);
  assert.ok(Math.abs(pad[1] - (128 / 128 - 1)) < 1e-5);
  assert.ok(Math.abs(pad[2] - (0 / 128 - 1)) < 1e-5);

  const liv = encodeLivenessBgrNchw(rgba80, 80, 80);
  assert.equal(liv.length, 3 * 80 * 80);
  const plane = 80 * 80;
  // NCHW BGR: plane 0 = B/255, plane 1 = G/255, plane 2 = R/255
  assert.ok(Math.abs(liv[0] - 0 / 255) < 1e-5);
  assert.ok(Math.abs(liv[plane] - 128 / 255) < 1e-5);
  assert.ok(Math.abs(liv[2 * plane] - 255 / 255) < 1e-5);

  const rgba112 = new Uint8ClampedArray(112 * 112 * 4);
  rgba112[0] = 64;
  rgba112[1] = 192;
  rgba112[2] = 255;
  rgba112[3] = 255;
  const rec = encodeRecognitionRgbNhwc(rgba112, 112, 112);
  assert.equal(rec.length, 112 * 112 * 3);
  assert.ok(Math.abs(rec[0] - (64 / 128 - 1)) < 1e-5);
  assert.ok(Math.abs(rec[1] - (192 / 128 - 1)) < 1e-5);
  assert.ok(Math.abs(rec[2] - (255 / 128 - 1)) < 1e-5);

  // Client pipeline batch wrapper
  const srcRgba = new Uint8ClampedArray(160 * 120 * 4);
  srcRgba.fill(180);
  const bundle = preprocessFaceFrameTensors(
    { data: srcRgba, width: 160, height: 120 },
    { x: 0.25, y: 0.2, width: 0.5, height: 0.6 }
  );
  assert.equal(bundle.pad.data.length, 80 * 80 * 3);
  assert.equal(bundle.liveness.data.length, 3 * 80 * 80);
  assert.equal(bundle.recognition.data.length, 112 * 112 * 3);
});

test('Classifier output decoding handles both raw logits and pre-normalized probabilities and rejects NaN/Infinity/wrong-length', () => {
  // Pre-normalized probabilities: PAD live_class = 0
  const padProb = decodeClassifierLiveScore([0.92, 0.05, 0.03], 0);
  assert.equal(padProb.valid, true);
  assert.ok(Math.abs(padProb.liveProbability - 0.92) < 1e-6);

  // Raw logits: Liveness live_class = 1
  const livLogits = decodeClassifierLiveScore([-2.0, 3.5, -1.5], 1);
  assert.equal(livLogits.valid, true);
  assert.ok(livLogits.liveProbability > 0.98);

  // Spoof logit (live class 1 is lowest)
  const spoofLogits = decodeClassifierLiveScore([3.2, -1.8, 0.4], 1);
  assert.equal(spoofLogits.valid, true);
  assert.ok(spoofLogits.liveProbability < 0.05);

  // Malformed / NaN / Infinity / wrong-length MUST fail closed
  assert.equal(decodeClassifierLiveScore([Number.NaN, 0.5, 0.5], 0).valid, false);
  assert.equal(decodeClassifierLiveScore([Number.POSITIVE_INFINITY, 0.1, 0.1], 0).valid, false);
  assert.equal(decodeClassifierLiveScore([0.9, 0.1], 0).valid, false);
  assert.equal(decodeClassifierLiveScore([0.9, 0.05, 0.05], 4).valid, false);

  // Embedding validation rejects NaN and wrong dimensions
  assert.equal(validateL2NormalizedEmbedding(makeUnitVector(1)).valid, true);
  assert.equal(validateL2NormalizedEmbedding(new Array(128).fill(0.1)).valid, false);
  const badEmb = makeUnitVector(1);
  badEmb[10] = Number.NaN;
  assert.equal(validateL2NormalizedEmbedding(badEmb).valid, false);
});

// ============================================================================
// 2. ANTI-AVERAGING MULTI-FRAME SERVER POLICY EVALUATOR TESTS
// ============================================================================

test('evaluateMultiFrameBiometricEvidence accepts 3 valid monotonic frontal frames with raw 3-class tensors', () => {
  const frames = [
    makeGoodFrame(1000, { pad_score: undefined, liveness_score: undefined, pad_output: [0.91, 0.05, 0.04], liveness_output: [0.04, 0.92, 0.04] }),
    makeGoodFrame(1250, { pad_score: undefined, liveness_score: undefined, pad_output: [0.90, 0.06, 0.04], liveness_output: [0.05, 0.91, 0.04] }),
    makeGoodFrame(1500, { pad_score: undefined, liveness_score: undefined, pad_output: [0.93, 0.04, 0.03], liveness_output: [0.03, 0.94, 0.03] }),
  ];
  const res = evaluateMultiFrameBiometricEvidence(frames, { enforceLiveness: true });
  assert.equal(res.ok, true);
  assert.equal(res.frame_count, 3);
  assert.ok(res.median_pad_score >= 0.90);
  assert.ok(res.median_liveness_score >= 0.91);
});

test('Anti-averaging defense: 2 high frames (0.95) + 1 spoof frame (0.50) MUST FAIL even though mean is 0.80', () => {
  const padSpoofRes = evaluateMultiFrameBiometricEvidence(
    [
      makeGoodFrame(1000, { pad_score: 0.95, liveness_score: 0.92 }),
      makeGoodFrame(1200, { pad_score: 0.50, liveness_score: 0.92 }),
      makeGoodFrame(1400, { pad_score: 0.95, liveness_score: 0.92 }),
    ],
    { enforceLiveness: true }
  );
  assert.equal(padSpoofRes.ok, false);
  assert.equal(padSpoofRes.code, 'PAD_REJECTED');

  const livSpoofRes = evaluateMultiFrameBiometricEvidence(
    [
      makeGoodFrame(1000, { pad_score: 0.92, liveness_score: 0.95 }),
      makeGoodFrame(1200, { pad_score: 0.92, liveness_score: 0.50 }),
      makeGoodFrame(1400, { pad_score: 0.92, liveness_score: 0.95 }),
    ],
    { enforceLiveness: true }
  );
  assert.equal(livSpoofRes.ok, false);
  assert.equal(livSpoofRes.code, 'LIVENESS_UNVERIFIED');
});

test('Differentiated rejection codes: frozen, non-monotonic, stale window, multi-face, no-face, low-light, blur, occlusion, bbox drift, NaN', () => {
  // Non-monotonic timestamp
  assert.equal(
    evaluateMultiFrameBiometricEvidence([makeGoodFrame(1000), makeGoodFrame(1000), makeGoodFrame(1300)], { enforceLiveness: true }).code,
    'FROZEN_FRAME'
  );
  // Too rapid (< 80ms)
  assert.equal(
    evaluateMultiFrameBiometricEvidence([makeGoodFrame(1000), makeGoodFrame(1040), makeGoodFrame(1200)], { enforceLiveness: true }).code,
    'FROZEN_FRAME'
  );
  // Stale window (> 4000ms)
  assert.equal(
    evaluateMultiFrameBiometricEvidence([makeGoodFrame(1000), makeGoodFrame(3000), makeGoodFrame(5500)], { enforceLiveness: true }).code,
    'FROZEN_FRAME'
  );
  // Explicit frozen_frame flag
  assert.equal(
    evaluateMultiFrameBiometricEvidence([makeGoodFrame(1000), makeGoodFrame(1200, { frozen_frame: true }), makeGoodFrame(1400)], { enforceLiveness: true }).code,
    'FROZEN_FRAME'
  );
  // Multiple faces
  assert.equal(
    evaluateMultiFrameBiometricEvidence([makeGoodFrame(1000), makeGoodFrame(1200, { face_count: 2 }), makeGoodFrame(1400)], { enforceLiveness: true }).code,
    'MULTIPLE_FACES'
  );
  // Zero faces
  assert.equal(
    evaluateMultiFrameBiometricEvidence([makeGoodFrame(1000, { face_count: 0 }), makeGoodFrame(1200), makeGoodFrame(1400)], { enforceLiveness: true }).code,
    'NO_FACE'
  );
  // Low light
  assert.equal(
    evaluateMultiFrameBiometricEvidence([makeGoodFrame(1000, { lighting_ok: false }), makeGoodFrame(1200), makeGoodFrame(1400)], { enforceLiveness: true }).code,
    'LOW_LIGHT'
  );
  // Blurry
  assert.equal(
    evaluateMultiFrameBiometricEvidence([makeGoodFrame(1000, { sharpness_ok: false }), makeGoodFrame(1200), makeGoodFrame(1400)], { enforceLiveness: true }).code,
    'BLURRY_IMAGE'
  );
  // Occlusion
  assert.equal(
    evaluateMultiFrameBiometricEvidence([makeGoodFrame(1000, { occlusion_suspected: true }), makeGoodFrame(1200), makeGoodFrame(1400)], { enforceLiveness: true }).code,
    'OCCLUSION_OR_POSE'
  );
  // Abrupt bounding-box jump (mixing unrelated frames)
  assert.equal(
    evaluateMultiFrameBiometricEvidence(
      [
        makeGoodFrame(1000, { bounding_box: { x: 0.25, y: 0.2, width: 0.4, height: 0.5 } }),
        makeGoodFrame(1200, { bounding_box: { x: 0.55, y: 0.2, width: 0.4, height: 0.5 } }),
        makeGoodFrame(1400, { bounding_box: { x: 0.55, y: 0.2, width: 0.4, height: 0.5 } }),
      ],
      { enforceLiveness: true }
    ).code,
    'OCCLUSION_OR_POSE'
  );
  // NaN / malformed model output
  assert.equal(
    evaluateMultiFrameBiometricEvidence([makeGoodFrame(1000, { pad_score: Number.NaN }), makeGoodFrame(1200), makeGoodFrame(1400)], { enforceLiveness: true }).code,
    'MODEL_ERROR'
  );
});

// ============================================================================
// 3. CLIENT FAIL-CLOSED VERIFICATION STATE MACHINE TESTS
// ============================================================================

test('KioskVerificationStateMachine enforces strict PAD+Liveness before Recognition, timeout, cooldown, and false-failure recovery', () => {
  const sm = new KioskVerificationStateMachine();
  sm.startAttempt(10_000);

  // Fails closed when TFLite models are not verified on disk
  const noModelSnap = sm.evaluateFrame(makeSmFrame(10_100, { modelsVerifiedOnDisk: false, serverInferenceAvailable: false }));
  assert.equal(noModelSnap.diagnosticCode, 'MODEL_ERROR');
  assert.equal(noModelSnap.canRunRecognition, false);

  // Frame 1 & Frame 2 pass -> still CANNOT run recognition until 3rd monotonic frame passes
  const f1 = sm.evaluateFrame(makeSmFrame(10_200));
  assert.equal(f1.stage, 'MULTI_FRAME_PAD_LIVENESS');
  assert.equal(f1.acceptedFrames, 1);
  assert.equal(f1.canRunRecognition, false);

  const f2 = sm.evaluateFrame(makeSmFrame(10_400));
  assert.equal(f2.acceptedFrames, 2);
  assert.equal(f2.canRunRecognition, false);

  // Frame 3 passes -> unlocks IDENTITY_VERIFICATION
  const f3 = sm.evaluateFrame(makeSmFrame(10_600));
  assert.equal(f3.stage, 'IDENTITY_VERIFICATION');
  assert.equal(f3.acceptedFrames, 3);
  assert.equal(f3.canRunRecognition, true);
  assert.equal(f3.indicators.quality, 'PASS');
  assert.equal(f3.indicators.pad, 'PASS');
  assert.equal(f3.indicators.liveness, 'PASS');

  // Timeout check (> 12_000ms after startAttempt)
  sm.startAttempt(20_000);
  const timeoutSnap = sm.evaluateFrame(makeSmFrame(33_000));
  assert.equal(timeoutSnap.diagnosticCode, 'TIMEOUT');
  assert.equal(timeoutSnap.canRunRecognition, false);

  // 3 consecutive PAD/Liveness failures trigger bounded cooldown (4000ms)
  sm.resetForRetry();
  sm.startAttempt(50_000);
  const fail1 = sm.evaluateFrame(makeSmFrame(50_100, { padScore: 0.30 }));
  assert.equal(fail1.diagnosticCode, 'PAD_REJECTED');
  assert.equal(fail1.consecutiveFailures, 1);

  const fail2 = sm.evaluateFrame(makeSmFrame(50_300, { livenessScore: 0.35 }));
  assert.equal(fail2.diagnosticCode, 'LIVENESS_UNVERIFIED');
  assert.equal(fail2.consecutiveFailures, 2);

  const fail3 = sm.evaluateFrame(makeSmFrame(50_500, { padScore: 0.20 }));
  assert.equal(fail3.stage, 'FAILED_COOLDOWN');
  assert.equal(fail3.diagnosticCode, 'COOLDOWN_ACTIVE');
  assert.ok(fail3.cooldownRemainingMs > 0);
  assert.equal(fail3.canRunRecognition, false);

  // False-failure recovery: resetForRetry clears cooldown and allows bona-fide retry to succeed
  sm.resetForRetry();
  sm.startAttempt(51_000);
  sm.evaluateFrame(makeSmFrame(51_100));
  sm.evaluateFrame(makeSmFrame(51_300));
  const recovered = sm.evaluateFrame(makeSmFrame(51_500));
  assert.equal(recovered.stage, 'IDENTITY_VERIFICATION');
  assert.equal(recovered.canRunRecognition, true);
});

// ============================================================================
// 4. ISO/IEC 30107-3 CALIBRATION GOVERNANCE ENGINE TESTS
// ============================================================================

test('computeBiometricCalibrationMetrics computes exact BPCER, worst-species APCER, ACER and blocks certification on insufficient data', () => {
  // Small synthetic sample set -> MUST report certifiable=false
  const smallReport = computeBiometricCalibrationMetrics([
    { ground_truth: 'bona_fide', pad_score: 0.90, liveness_score: 0.90 },
    { ground_truth: 'bona_fide', pad_score: 0.70, liveness_score: 0.90 }, // false reject
    { ground_truth: 'printed_photo', pad_score: 0.85, liveness_score: 0.85 }, // false accept (1/2 = 0.50)
    { ground_truth: 'printed_photo', pad_score: 0.20, liveness_score: 0.30 },
    { ground_truth: 'phone_screen', pad_score: 0.25, liveness_score: 0.30 }, // 0/1 = 0.00
  ]);

  assert.equal(smallReport.confusion_matrix.true_accept_bona_fide, 1);
  assert.equal(smallReport.confusion_matrix.false_reject_bona_fide, 1);
  assert.equal(smallReport.confusion_matrix.false_accept_attack, 1);
  assert.equal(smallReport.confusion_matrix.true_reject_attack, 2);
  assert.equal(smallReport.bpcer, 0.5);
  assert.equal(smallReport.apcer, 0.5); // worst-species APCER (printed_photo = 0.5)
  assert.equal(smallReport.acer, 0.5);
  assert.equal(smallReport.certifiable, false);
  assert.ok(smallReport.blocking_reasons.length >= 4);

  // Empty dataset returns null metrics and certifiable=false
  const emptyReport = computeBiometricCalibrationMetrics([]);
  assert.equal(emptyReport.bpcer, null);
  assert.equal(emptyReport.apcer, null);
  assert.equal(emptyReport.acer, null);
  assert.equal(emptyReport.certifiable, false);
});

// ============================================================================
// 5. LIVE EXPRESS HTTP INTEGRATION TESTS (POLICY, MULTI-FRAME, SPOOF, REPLAY,
//    UNAUTHORIZED BYPASS, SESSION EXPIRY, PRODUCTION FAIL-CLOSED)
// ============================================================================

test('Express HTTP integration: /policy, multi-frame enroll & attendance, spoof/frozen/multi-face/NaN rejections, bypass/replay/session-expiry guards', async () => {
  const nowRef = { value: new Date('2026-11-23T08:05:00+08:00').getTime() };
  const srv = await startKioskTestServer('development', nowRef);
  try {
    const adminJar = createCookieJar();
    const kioskJar = createCookieJar();

    // 5.1 Read-only /api/kiosk/web/policy exposes uncalibrated baseline & fail-closed production flag
    const polRes = await fetch(`${srv.baseUrl}/api/kiosk/web/policy`);
    assert.equal(polRes.status, 200);
    const polBody = await polRes.json();
    assert.equal(polBody.policy.calibration_status, 'UNCALIBRATED_STAGING_ONLY');
    assert.equal(polBody.policy.certified_for_production, false);
    assert.equal(polBody.policy.thresholds.pad_min_score, 0.80);
    assert.equal(polBody.policy.thresholds.liveness_min_score, 0.80);
    assert.equal(polBody.production_attendance_blocked, true);

    // 5.2 Admin login -> create kiosk device + activation code
    const loginRes = await fetch(`${srv.baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 'sysadmin', password: 'StrongPassword#2026!' }),
    });
    assert.equal(loginRes.status, 200);
    adminJar.ingest(loginRes);
    const loginData = await loginRes.json();
    const adminCsrf = loginData.csrfToken;

    const createDevRes = await fetch(`${srv.baseUrl}/api/kiosk/devices`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: adminJar.header(), 'X-CSRF-Token': adminCsrf },
      body: JSON.stringify({ device_name: 'Lobby Kiosk P08', location: 'Main Lobby', admin_pin: '246810' }),
    });
    assert.equal(createDevRes.status, 201);
    const devData = await createDevRes.json();

    // 5.3 Activate browser kiosk session
    const actRes = await fetch(`${srv.baseUrl}/api/kiosk/web/activate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ activation_code: devData.activation_code }),
    });
    assert.equal(actRes.status, 200);
    kioskJar.ingest(actRes);
    const actData = await actRes.json();
    const kioskCsrf = actData.csrfToken;

    const emp1 = srv.db.prepare(`SELECT id FROM employees WHERE employee_code = 'RSU-0101'`).get();
    const emb1 = makeUnitVector(42);

    // 5.4 Unauthorized bypass: enrollment without Admin PIN MUST fail 403
    const unauthEnrollRes = await fetch(`${srv.baseUrl}/api/kiosk/web/enroll`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: kioskJar.header(), 'X-CSRF-Token': kioskCsrf },
      body: JSON.stringify({
        employee_id: emp1.id,
        capture_mode: 'FRONT_ONLY',
        embeddings: [emb1, emb1, emb1],
        frames: [makeGoodFrame(1000), makeGoodFrame(1200), makeGoodFrame(1400)],
      }),
    });
    assert.equal(unauthEnrollRes.status, 403);
    assert.equal((await unauthEnrollRes.json()).code, 'ADMIN_UNLOCK_REQUIRED');

    // 5.5 Missing CSRF MUST fail 403
    const noCsrfRes = await fetch(`${srv.baseUrl}/api/kiosk/web/challenge`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: kioskJar.header() },
      body: JSON.stringify({}),
    });
    assert.equal(noCsrfRes.status, 403);

    // 5.6 Unlock Admin PIN -> enroll with anti-averaging SPOOF frame MUST FAIL 422 PAD_REJECTED
    const unlockRes = await fetch(`${srv.baseUrl}/api/kiosk/web/admin/unlock`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: kioskJar.header(), 'X-CSRF-Token': kioskCsrf },
      body: JSON.stringify({ pin: '246810' }),
    });
    assert.equal(unlockRes.status, 200);

    const spoofEnrollRes = await fetch(`${srv.baseUrl}/api/kiosk/web/enroll`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: kioskJar.header(), 'X-CSRF-Token': kioskCsrf },
      body: JSON.stringify({
        employee_id: emp1.id,
        capture_mode: 'FRONT_ONLY',
        embeddings: [emb1, emb1, emb1],
        frames: [
          makeGoodFrame(1000, { pad_score: 0.95 }),
          makeGoodFrame(1200, { pad_score: 0.45 }),
          makeGoodFrame(1400, { pad_score: 0.95 }),
        ],
      }),
    });
    assert.equal(spoofEnrollRes.status, 422);
    assert.equal((await spoofEnrollRes.json()).code, 'PAD_REJECTED');

    // 5.7 Valid multi-frame FRONT_ONLY enrollment succeeds
    const okEnrollRes = await fetch(`${srv.baseUrl}/api/kiosk/web/enroll`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: kioskJar.header(), 'X-CSRF-Token': kioskCsrf },
      body: JSON.stringify({
        employee_id: emp1.id,
        capture_mode: 'FRONT_ONLY',
        embeddings: [emb1, emb1, emb1],
        frames: [makeGoodFrame(1000), makeGoodFrame(1200), makeGoodFrame(1400)],
      }),
    });
    assert.equal(okEnrollRes.status, 200);

    // Helper to issue a fresh challenge nonce
    async function issueChallenge() {
      const r = await fetch(`${srv.baseUrl}/api/kiosk/web/challenge`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Cookie: kioskJar.header(), 'X-CSRF-Token': kioskCsrf },
        body: JSON.stringify({}),
      });
      assert.equal(r.status, 200);
      return (await r.json()).challenge_nonce;
    }

    // 5.8 Attendance attack/quality rejections produce exact differentiated codes and write ZERO attendance rows
    const cases = [
      {
        name: 'PAD spoof attack (printed photo)',
        frames: [makeGoodFrame(1000, { pad_output: [0.12, 0.80, 0.08] }), makeGoodFrame(1200, { pad_output: [0.10, 0.85, 0.05] }), makeGoodFrame(1400, { pad_output: [0.15, 0.78, 0.07] })],
        expectedCode: 'PAD_REJECTED',
      },
      {
        name: 'Passive liveness failure (screen/replay)',
        frames: [makeGoodFrame(1000, { liveness_output: [0.80, 0.14, 0.06] }), makeGoodFrame(1200, { liveness_output: [0.75, 0.18, 0.07] }), makeGoodFrame(1400, { liveness_output: [0.82, 0.12, 0.06] })],
        expectedCode: 'LIVENESS_UNVERIFIED',
      },
      {
        name: 'Frozen/duplicate frame attack',
        frames: [makeGoodFrame(2000), makeGoodFrame(2000), makeGoodFrame(2300)],
        expectedCode: 'FROZEN_FRAME',
      },
      {
        name: 'Multiple faces in frame',
        frames: [makeGoodFrame(2000), makeGoodFrame(2200, { face_count: 2 }), makeGoodFrame(2400)],
        expectedCode: 'MULTIPLE_FACES',
      },
      {
        name: 'Malformed/NaN model output',
        frames: [makeGoodFrame(2000, { pad_score: 'NaN' }), makeGoodFrame(2200), makeGoodFrame(2400)],
        expectedCode: 'MODEL_ERROR',
      },
    ];

    for (const tc of cases) {
      const nonce = await issueChallenge();
      const res = await fetch(`${srv.baseUrl}/api/kiosk/web/attendance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Cookie: kioskJar.header(), 'X-CSRF-Token': kioskCsrf },
        body: JSON.stringify({
          challenge_nonce: nonce,
          embedding: emb1,
          frames: tc.frames,
        }),
      });
      assert.equal(res.status, 422, `${tc.name} should return 422`);
      const body = await res.json();
      assert.equal(body.code, tc.expectedCode, `${tc.name} expected ${tc.expectedCode}, got ${body.code}`);
    }

    const logsBeforeValid = srv.db.prepare(`SELECT COUNT(*) AS cnt FROM attendance_logs`).get().cnt;
    assert.equal(logsBeforeValid, 0, 'No rejected biometric attempt may ever write an attendance row');

    // 5.9 Valid multi-frame attendance succeeds AND ignores forged client employee_id / match_verified
    const validNonce = await issueChallenge();
    const okAttRes = await fetch(`${srv.baseUrl}/api/kiosk/web/attendance`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: kioskJar.header(), 'X-CSRF-Token': kioskCsrf },
      body: JSON.stringify({
        challenge_nonce: validNonce,
        employee_id: 999999, // forged client claim — MUST be ignored
        match_verified: true,
        embedding: emb1,
        frames: [
          makeGoodFrame(3000, { pad_output: [0.91, 0.05, 0.04], liveness_output: [0.04, 0.92, 0.04] }),
          makeGoodFrame(3250, { pad_output: [0.90, 0.06, 0.04], liveness_output: [0.05, 0.91, 0.04] }),
          makeGoodFrame(3500, { pad_output: [0.92, 0.05, 0.03], liveness_output: [0.03, 0.93, 0.04] }),
        ],
      }),
    });
    assert.equal(okAttRes.status, 200);
    const okAttBody = await okAttRes.json();
    assert.equal(okAttBody.employee.id, emp1.id);
    assert.equal(okAttBody.action, 'TIME_IN');

    // 5.10 Replay attack: reusing validNonce MUST fail 409 NONCE_ALREADY_USED
    const replayRes = await fetch(`${srv.baseUrl}/api/kiosk/web/attendance`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: kioskJar.header(), 'X-CSRF-Token': kioskCsrf },
      body: JSON.stringify({
        challenge_nonce: validNonce,
        embedding: emb1,
        frames: [makeGoodFrame(4000), makeGoodFrame(4200), makeGoodFrame(4400)],
      }),
    });
    assert.equal(replayRes.status, 409);
    assert.equal((await replayRes.json()).code, 'NONCE_ALREADY_USED');

    // 5.11 Expired nonce MUST fail 410 NONCE_EXPIRED
    const expiringNonce = await issueChallenge();
    nowRef.value += 90_000; // advance 90s past 45s TTL
    const expNonceRes = await fetch(`${srv.baseUrl}/api/kiosk/web/attendance`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: kioskJar.header(), 'X-CSRF-Token': kioskCsrf },
      body: JSON.stringify({
        challenge_nonce: expiringNonce,
        embedding: emb1,
        frames: [makeGoodFrame(5000), makeGoodFrame(5200), makeGoodFrame(5400)],
      }),
    });
    assert.equal(expNonceRes.status, 410);
    assert.equal((await expNonceRes.json()).code, 'NONCE_EXPIRED');

    // 5.12 Session expiration (> 12 hours) MUST return 401 KIOSK_SESSION_INVALID
    nowRef.value += 13 * 60 * 60 * 1000;
    const expSessionRes = await fetch(`${srv.baseUrl}/api/kiosk/web/challenge`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: kioskJar.header(), 'X-CSRF-Token': kioskCsrf },
      body: JSON.stringify({}),
    });
    assert.equal(expSessionRes.status, 401);
    assert.equal((await expSessionRes.json()).code, 'KIOSK_SESSION_INVALID');
  } finally {
    await srv.close();
  }
});

test('Production mode remains strictly FAIL-CLOSED (503 PRODUCTION_BIOMETRIC_ATTESTATION_BLOCKED)', async () => {
  const nowRef = { value: new Date('2026-11-23T08:10:00+08:00').getTime() };
  const srv = await startKioskTestServer('production', nowRef);
  try {
    const adminJar = createCookieJar();
    const kioskJar = createCookieJar();

    const loginRes = await fetch(`${srv.baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 'sysadmin', password: 'StrongPassword#2026!' }),
    });
    adminJar.ingest(loginRes);
    const adminCsrf = (await loginRes.json()).csrfToken;

    const createDevRes = await fetch(`${srv.baseUrl}/api/kiosk/devices`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: adminJar.header(), 'X-CSRF-Token': adminCsrf },
      body: JSON.stringify({ device_name: 'Prod Gate Kiosk', location: 'Main Gate', admin_pin: '135790' }),
    });
    const devData = await createDevRes.json();

    const actRes = await fetch(`${srv.baseUrl}/api/kiosk/web/activate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ activation_code: devData.activation_code }),
    });
    kioskJar.ingest(actRes);
    const kioskCsrf = (await actRes.json()).csrfToken;

    const chRes = await fetch(`${srv.baseUrl}/api/kiosk/web/challenge`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: kioskJar.header(), 'X-CSRF-Token': kioskCsrf },
      body: JSON.stringify({}),
    });
    const nonce = (await chRes.json()).challenge_nonce;

    const attRes = await fetch(`${srv.baseUrl}/api/kiosk/web/attendance`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: kioskJar.header(), 'X-CSRF-Token': kioskCsrf },
      body: JSON.stringify({
        challenge_nonce: nonce,
        embedding: makeUnitVector(77),
        frames: [makeGoodFrame(1000), makeGoodFrame(1200), makeGoodFrame(1400)],
      }),
    });
    assert.equal(attRes.status, 503);
    assert.equal((await attRes.json()).code, 'PRODUCTION_BIOMETRIC_ATTESTATION_BLOCKED');
  } finally {
    await srv.close();
  }
});
