import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import type { Request, Response } from 'express';
import {
  formatEnvValidationReport,
  validateEnv,
  validatePasswordStrength,
} from '../server/env.ts';
import {
  getActiveSessionSecrets,
  hashPassword,
  MissingSessionSecretError,
  parseCookies,
  verifyPassword,
  verifySignedSessionCookie,
} from '../server/auth.ts';
import { isRequestOriginAllowed, SlidingWindowRateLimiter } from '../server/security.ts';

interface UnitTestResult {
  name: string;
  passed: boolean;
  error?: string;
}

const results: UnitTestResult[] = [];

function runUnit(name: string, fn: () => void) {
  try {
    fn();
    results.push({ name, passed: true });
    console.log(`PASS  ${name}`);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    results.push({ name, passed: false, error: message });
    console.error(`FAIL  ${name}: ${message}`);
  }
}

const VALID_SECRET_A = crypto.randomBytes(32).toString('hex');
const VALID_SECRET_B = crypto.randomBytes(32).toString('hex');

runUnit('validateEnv fails securely when SESSION_SECRET is omitted (zero default secret)', () => {
  const res = validateEnv({});
  assert.equal(res.valid, false);
  assert.ok(res.errors.some((e) => e.includes('SESSION_SECRET')));
});

runUnit('validateEnv accepts valid SESSION_SECRET and defaults in development', () => {
  const res = validateEnv({ SESSION_SECRET: VALID_SECRET_A });
  assert.equal(res.valid, true);
  assert.equal(res.errors.length, 0);
  assert.equal(res.config.nodeEnv, 'development');
  assert.equal(res.config.port, 3000);
  assert.equal(res.config.disableHmr, false);
  assert.equal(res.config.trustProxy, false);
  assert.equal(res.config.maxFailedLoginAttempts, 5);
  assert.equal(res.config.lockoutDurationMinutes, 15);
});

runUnit('validateEnv rejects invalid PORT, NODE_ENV, DISABLE_HMR, TRUST_PROXY, ALLOWED_ORIGINS, COOKIE_DOMAIN, and ADMIN_INITIAL_EMAIL', () => {
  const res = validateEnv({
    SESSION_SECRET: VALID_SECRET_A,
    NODE_ENV: 'staging',
    PORT: '99999',
    DISABLE_HMR: 'maybe',
    TRUST_PROXY: 'sometimes',
    ALLOWED_ORIGINS: 'not-a-valid-url',
    COOKIE_DOMAIN: 'bad domain;evil',
    MAX_FAILED_LOGIN_ATTEMPTS: '1',
    ADMIN_INITIAL_EMAIL: 'not-an-email',
  });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some((e) => e.includes('NODE_ENV')));
  assert.ok(res.errors.some((e) => e.includes('PORT')));
  assert.ok(res.errors.some((e) => e.includes('DISABLE_HMR')));
  assert.ok(res.errors.some((e) => e.includes('TRUST_PROXY')));
  assert.ok(res.errors.some((e) => e.includes('ALLOWED_ORIGINS')));
  assert.ok(res.errors.some((e) => e.includes('COOKIE_DOMAIN')));
  assert.ok(res.errors.some((e) => e.includes('MAX_FAILED_LOGIN_ATTEMPTS')));
  assert.ok(res.errors.some((e) => e.includes('ADMIN_INITIAL_EMAIL')));
});

runUnit('validateEnv rejects placeholder, short, or legacy default credentials', () => {
  const placeholderRes = validateEnv({
    SESSION_SECRET: 'CHANGE_ME_TO_A_STRONG_RANDOM_SECRET',
    SESSION_SECRET_PREVIOUS: 'short',
    ADMIN_INITIAL_PASSWORD: 'Admin@2025',
  });
  assert.equal(placeholderRes.valid, false);
  assert.ok(placeholderRes.errors.some((e) => e.includes('SESSION_SECRET')));
  assert.ok(placeholderRes.errors.some((e) => e.includes('SESSION_SECRET_PREVIOUS')));
  assert.ok(placeholderRes.errors.some((e) => e.includes('ADMIN_INITIAL_PASSWORD')));
});

runUnit('validateEnv requires initial admin credentials in strict/fresh-DB mode and accepts strong configuration', () => {
  const missingAdmin = validateEnv(
    { NODE_ENV: 'production', SESSION_SECRET: VALID_SECRET_A },
    { strict: true, requireInitialAdmin: true }
  );
  assert.equal(missingAdmin.valid, false);
  assert.ok(missingAdmin.errors.some((e) => e.includes('ADMIN_INITIAL_USERNAME')));
  assert.ok(missingAdmin.errors.some((e) => e.includes('ADMIN_INITIAL_EMAIL')));
  assert.ok(missingAdmin.errors.some((e) => e.includes('ADMIN_INITIAL_PASSWORD')));

  const validStrict = validateEnv(
    {
      NODE_ENV: 'production',
      APP_MODE: 'production',
      DATABASE_PATH: '/var/lib/savage-rsucaj/savage_rsucaj.db',
      BACKUP_DIR: '/var/backups/savage-rsucaj',
      SESSION_SECRET: VALID_SECRET_A,
      SESSION_SECRET_PREVIOUS: VALID_SECRET_B,
      ALLOWED_ORIGINS: 'https://attendance.rsucaj.edu.ph, https://portal.rsucaj.edu.ph',
      ADMIN_INITIAL_USERNAME: 'rsu_admin',
      ADMIN_INITIAL_EMAIL: 'admin@rsucaj.edu.ph',
      ADMIN_INITIAL_PASSWORD: 'Campus#Strong2026!Pass',
    },
    { strict: true, requireInitialAdmin: true }
  );
  assert.equal(validStrict.valid, true);
  assert.equal(validStrict.errors.length, 0);
  assert.deepEqual(validStrict.config.allowedOrigins, [
    'https://attendance.rsucaj.edu.ph',
    'https://portal.rsucaj.edu.ph',
  ]);
});

runUnit('validateEnv enforces persistent DATABASE_PATH and forbids APP_MODE=demo or ephemeral dirs in production', () => {
  const demoInProd = validateEnv({
    NODE_ENV: 'production',
    APP_MODE: 'demo',
    DATABASE_PATH: '/var/lib/savage-rsucaj/savage_rsucaj.db',
    SESSION_SECRET: VALID_SECRET_A,
  });
  assert.equal(demoInProd.valid, false);
  assert.ok(demoInProd.errors.some((e) => e.includes('APP_MODE')));

  const memInProd = validateEnv({
    NODE_ENV: 'production',
    DATABASE_PATH: ':memory:',
    SESSION_SECRET: VALID_SECRET_A,
  });
  assert.equal(memInProd.valid, false);
  assert.ok(memInProd.errors.some((e) => e.includes(':memory:')));

  const relInProd = validateEnv({
    NODE_ENV: 'production',
    DATABASE_PATH: './data/savage_rsucaj.db',
    SESSION_SECRET: VALID_SECRET_A,
  });
  assert.equal(relInProd.valid, false);
  assert.ok(relInProd.errors.some((e) => e.includes('absolute path')));

  const distInProd = validateEnv({
    NODE_ENV: 'production',
    DATABASE_PATH: '/srv/app/dist/savage_rsucaj.db',
    BACKUP_DIR: '/srv/app/node_modules/backups',
    SESSION_SECRET: VALID_SECRET_A,
  });
  assert.equal(distInProd.valid, false);
  assert.ok(distInProd.errors.some((e) => e.includes('DATABASE_PATH') && e.includes('ephemeral')));
  assert.ok(distInProd.errors.some((e) => e.includes('BACKUP_DIR') && e.includes('ephemeral')));

  const winPersistent = validateEnv({
    NODE_ENV: 'production',
    DATABASE_PATH: 'C:\\ProgramData\\SAVAGE-RSUCAJ\\data\\savage_rsucaj.db',
    BACKUP_DIR: 'C:\\ProgramData\\SAVAGE-RSUCAJ\\backups',
    SESSION_SECRET: VALID_SECRET_A,
    BACKUP_ENCRYPTION_KEY: VALID_SECRET_B,
  });
  assert.equal(winPersistent.valid, true);
  assert.equal(winPersistent.config.backupEncryptionConfigured, true);
});

runUnit('validateEnv validates SQLITE_BUSY_TIMEOUT_MS, SQLITE_WAL_AUTOCHECKPOINT, and BACKUP_ENCRYPTION_KEY', () => {
  const bad = validateEnv({
    SESSION_SECRET: VALID_SECRET_A,
    SQLITE_BUSY_TIMEOUT_MS: '10',
    SQLITE_WAL_AUTOCHECKPOINT: '5',
    BACKUP_RETENTION_COUNT: '0',
    BACKUP_ENCRYPTION_KEY: 'too-short',
  });
  assert.equal(bad.valid, false);
  assert.ok(bad.errors.some((e) => e.includes('SQLITE_BUSY_TIMEOUT_MS')));
  assert.ok(bad.errors.some((e) => e.includes('SQLITE_WAL_AUTOCHECKPOINT')));
  assert.ok(bad.errors.some((e) => e.includes('BACKUP_RETENTION_COUNT')));
  assert.ok(bad.errors.some((e) => e.includes('BACKUP_ENCRYPTION_KEY')));
});

runUnit('formatEnvValidationReport redacts all secret values including BACKUP_ENCRYPTION_KEY', () => {
  const rawPass = 'UltraSecretAdminPass!987';
  const rawBackupKey = crypto.randomBytes(32).toString('hex');
  const res = validateEnv({
    NODE_ENV: 'production',
    DATABASE_PATH: '/var/lib/savage-rsucaj/savage_rsucaj.db',
    SESSION_SECRET: VALID_SECRET_A,
    SESSION_SECRET_PREVIOUS: VALID_SECRET_B,
    BACKUP_ENCRYPTION_KEY: rawBackupKey,
    ADMIN_INITIAL_PASSWORD: rawPass,
  });
  const report = formatEnvValidationReport(res);
  assert.equal(report.includes(VALID_SECRET_A), false);
  assert.equal(report.includes(VALID_SECRET_B), false);
  assert.equal(report.includes(rawPass), false);
  assert.equal(report.includes(rawBackupKey), false);
  assert.ok(report.includes('[SET - REDACTED]'));
});

runUnit('validatePasswordStrength enforces complexity policy and rejects weak/legacy passwords', () => {
  assert.ok(validatePasswordStrength('short1!A') !== null);
  assert.ok(validatePasswordStrength('alllowercase123!') !== null);
  assert.ok(validatePasswordStrength('ALLUPPERCASE123!') !== null);
  assert.ok(validatePasswordStrength('NoDigitsHere!!') !== null);
  assert.ok(validatePasswordStrength('NoSymbols12345') !== null);
  assert.ok(validatePasswordStrength('Admin@2025') !== null);
  assert.equal(validatePasswordStrength('RsuCaj!2026Strong'), null);
});

runUnit('hashPassword and verifyPassword use unique scrypt salts and reject wrong passwords', () => {
  const first = hashPassword('CampusAdmin@2026!X');
  const second = hashPassword('CampusAdmin@2026!X');
  assert.notEqual(first.salt, second.salt);
  assert.notEqual(first.hash, second.hash);
  assert.equal(verifyPassword('CampusAdmin@2026!X', first.hash, first.salt), true);
  assert.equal(verifyPassword('WrongPassword!2026', first.hash, first.salt), false);
});

runUnit('getActiveSessionSecrets throws MissingSessionSecretError when SESSION_SECRET is unset', () => {
  const prev = process.env.SESSION_SECRET;
  delete process.env.SESSION_SECRET;
  try {
    assert.throws(() => getActiveSessionSecrets(), MissingSessionSecretError);
  } finally {
    if (prev !== undefined) process.env.SESSION_SECRET = prev;
  }
});

runUnit('verifySignedSessionCookie validates primary secret, supports SESSION_SECRET_PREVIOUS rotation, and rejects tampering', () => {
  const prevPrimary = process.env.SESSION_SECRET;
  const prevOld = process.env.SESSION_SECRET_PREVIOUS;

  try {
    const sid = crypto.randomBytes(32).toString('hex');
    const sigA = crypto.createHmac('sha256', VALID_SECRET_A).update(sid).digest('base64url');
    const cookieA = `${sid}.${sigA}`;

    // Verify with primary = A
    process.env.SESSION_SECRET = VALID_SECRET_A;
    delete process.env.SESSION_SECRET_PREVIOUS;
    const direct = verifySignedSessionCookie(cookieA);
    assert.ok(direct);
    assert.equal(direct.sid, sid);
    assert.equal(direct.verifiedWithPreviousSecret, false);

    // Rotate: primary = B, previous = A
    process.env.SESSION_SECRET = VALID_SECRET_B;
    process.env.SESSION_SECRET_PREVIOUS = VALID_SECRET_A;
    const rotated = verifySignedSessionCookie(cookieA);
    assert.ok(rotated);
    assert.equal(rotated.sid, sid);
    assert.equal(rotated.verifiedWithPreviousSecret, true);

    // Complete rotation: remove previous
    delete process.env.SESSION_SECRET_PREVIOUS;
    assert.equal(verifySignedSessionCookie(cookieA), null);

    // Tampered / malformed rejection
    process.env.SESSION_SECRET = VALID_SECRET_A;
    const tampered = cookieA.slice(0, -2) + (cookieA.endsWith('aa') ? 'bb' : 'aa');
    assert.equal(verifySignedSessionCookie(tampered), null);
    assert.equal(verifySignedSessionCookie('invalid.sig'), null);
    assert.equal(verifySignedSessionCookie(undefined), null);
  } finally {
    if (prevPrimary !== undefined) process.env.SESSION_SECRET = prevPrimary;
    else delete process.env.SESSION_SECRET;
    if (prevOld !== undefined) process.env.SESSION_SECRET_PREVIOUS = prevOld;
    else delete process.env.SESSION_SECRET_PREVIOUS;
  }
});

runUnit('parseCookies decodes multiple cookies cleanly', () => {
  const parsed = parseCookies('a=1; savage_rsucaj_session=tok%2E123; savage_rsucaj_csrf=abc');
  assert.equal(parsed.a, '1');
  assert.equal(parsed.savage_rsucaj_session, 'tok.123');
  assert.equal(parsed.savage_rsucaj_csrf, 'abc');
  assert.deepEqual(parseCookies(undefined), {});
});

runUnit('SlidingWindowRateLimiter enforces sliding request budget and returns 429 on overflow', () => {
  const limiter = new SlidingWindowRateLimiter({
    windowMs: 60_000,
    maxRequests: 2,
    message: 'Rate limit exceeded.',
  });
  const mw = limiter.middleware(() => '10.0.0.1');
  let nextCalls = 0;
  let lastStatus = 200;
  const fakeReq = {} as Request;
  const fakeRes = {
    setHeader: () => fakeRes,
    status: (code: number) => {
      lastStatus = code;
      return fakeRes;
    },
    json: () => fakeRes,
  } as unknown as Response;

  mw(fakeReq, fakeRes, () => nextCalls++);
  mw(fakeReq, fakeRes, () => nextCalls++);
  mw(fakeReq, fakeRes, () => nextCalls++);

  assert.equal(nextCalls, 2);
  assert.equal(lastStatus, 429);
});

runUnit('isRequestOriginAllowed enforces same-origin default and ALLOWED_ORIGINS allowlist', () => {
  const prev = process.env.ALLOWED_ORIGINS;
  try {
    delete process.env.ALLOWED_ORIGINS;
    const sameOriginReq = {
      headers: { host: 'localhost:3000', origin: 'http://localhost:3000' },
      secure: false,
    } as unknown as Request;
    const crossOriginReq = {
      headers: { host: 'localhost:3000', origin: 'https://evil.example' },
      secure: false,
    } as unknown as Request;
    assert.equal(isRequestOriginAllowed(sameOriginReq), true);
    assert.equal(isRequestOriginAllowed(crossOriginReq), false);

    process.env.ALLOWED_ORIGINS = 'https://portal.rsucaj.edu.ph';
    const allowlistedReq = {
      headers: { host: 'localhost:3000', origin: 'https://portal.rsucaj.edu.ph' },
      secure: false,
    } as unknown as Request;
    assert.equal(isRequestOriginAllowed(allowlistedReq), true);
    assert.equal(isRequestOriginAllowed(crossOriginReq), false);
  } finally {
    if (prev !== undefined) process.env.ALLOWED_ORIGINS = prev;
    else delete process.env.ALLOWED_ORIGINS;
  }
});

const passed = results.filter((r) => r.passed).length;
const failed = results.filter((r) => !r.passed).length;
console.log(`\nUnit Summary: ${passed}/${results.length} passed, ${failed} failed.`);
if (failed > 0) process.exit(1);
