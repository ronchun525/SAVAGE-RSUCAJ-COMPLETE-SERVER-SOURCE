import assert from 'node:assert/strict';
import { test } from 'node:test';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { checkEvidence } from '../scripts/build29-release-gate.mjs';
import { fileURLToPath } from 'node:url';
const repo=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const template=JSON.parse(fs.readFileSync(path.join(repo,'BUILD29_EVIDENCE_TEMPLATE.json')));
function temp() { return fs.mkdtempSync(path.join(os.tmpdir(),'build29-gates-')); }
test('missing evidence is always NO_GO',()=>{
  assert.equal(checkEvidence('/missing/directory/gates.json').status,'NO_GO');
});
test('all-NOT_RUN evidence template refuses release',()=>{
  const d=temp(); const filename=path.join(d,'status.json');
  fs.writeFileSync(filename,JSON.stringify(template));
  const result=checkEvidence(filename);
  assert.equal(result.status,'NO_GO');
  assert.ok(result.problems.length>=15);
  fs.rmSync(d,{recursive:true,force:true});
});
test('PASS without actual evidence file and named reviewer is rejected',()=>{
  const d=temp(); const filename=path.join(d,'status.json');
  const manifest=structuredClone(template);
  const key=Object.keys(manifest.gates)[0];
  manifest.gates[key]={status:'PASS',evidence_file:'',reviewer:''};
  fs.writeFileSync(filename,JSON.stringify(manifest));
  const result=checkEvidence(filename);
  assert.ok(result.problems.includes(`${key}: missing evidence_file`));
  assert.ok(result.problems.includes(`${key}: reviewer/owner not recorded`));
  fs.rmSync(d,{recursive:true,force:true});
});
test('PASS pointing outside evidence directory is rejected',()=>{
  const d=temp(); const filename=path.join(d,'status.json');
  const manifest=structuredClone(template);
  const key=Object.keys(manifest.gates)[0];
  manifest.gates[key]={status:'PASS',evidence_file:'../../etc/passwd',reviewer:'test operator'};
  fs.writeFileSync(filename,JSON.stringify(manifest));
  assert.ok(checkEvidence(filename).problems.some(p=>p.includes('escapes evidence directory')));
  fs.rmSync(d,{recursive:true,force:true});
});
test('complete operator evidence remains REVIEW_REQUIRED, not auto production-certified',()=>{
  const d=temp(); const filename=path.join(d,'status.json');
  const manifest=structuredClone(template);
  for (const key of Object.keys(manifest.gates)) {
    const evidence=`${key}.txt`;
    fs.writeFileSync(path.join(d,evidence),'synthetic test fixture; not valid production evidence');
    manifest.gates[key]={status:'PASS',evidence_file:evidence,reviewer:'synthetic test only'};
  }
  fs.writeFileSync(filename,JSON.stringify(manifest));
  const result=checkEvidence(filename);
  assert.equal(result.status,'EVIDENCE_PRESENT_REVIEW_REQUIRED');
  assert.equal(result.problems.length,0);
  fs.rmSync(d,{recursive:true,force:true});
});
