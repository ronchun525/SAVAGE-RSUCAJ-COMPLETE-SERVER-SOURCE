import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import Database from 'better-sqlite3';
import express from 'express';
import { closeDatabaseSafely, initDatabase } from '../server/db.ts';
import { logAudit, redactSensitiveValue, verifyAuditLogChain } from '../server/auditHelpers.ts';
import { createApiRouter } from '../server/api.ts';
import { RealtimeHub } from '../server/realtimeHub.ts';

let passed = 0;
let failed = 0;

async function test(name: string, fn: () => Promise<void> | void) {
  try {
    await fn();
    passed++;
    console.log(`PASS  ${name}`);
  } catch (err) {
    failed++;
    console.error(`FAIL  ${name}`);
    console.error('     ', err instanceof Error ? err.stack || err.message : err);
  }
}

interface SessionJar {
  sessionCookie: string;
  csrfToken: string;
}

function parseCookies(setCookieHeaders: string[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const raw of setCookieHeaders) {
    const first = raw.split(';')[0];
    const eq = first.indexOf('=');
    if (eq > 0) out[first.slice(0, eq).trim()] = first.slice(eq + 1).trim();
  }
  return out;
}

async function run() {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-b14-adminops-'));
  const dbPath = path.join(tmpDir, 'adminops.db');
  const backupDir = path.join(tmpDir, 'backups');
  const sessionSecret = crypto.randomBytes(48).toString('hex');
  const adminPass = `Adm!${crypto.randomBytes(6).toString('hex')}9A`;
  const hrPass = `Hro!${crypto.randomBytes(6).toString('hex')}8B`;
  const payPass = `Pay!${crypto.randomBytes(6).toString('hex')}7C`;
  const headPass = `Dhd!${crypto.randomBytes(6).toString('hex')}6D`;
  const empPass = `Emp!${crypto.randomBytes(6).toString('hex')}5E`;

  // Controllable virtual clock: 2026-04-15 09:00:00 Asia/Manila (01:00:00Z)
  let virtualNowMs = Date.parse('2026-04-15T01:00:00.000Z');
  const nowProvider = () => virtualNowMs;

  process.env.SESSION_SECRET = sessionSecret;
  process.env.BACKUP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');

  let activeDb = initDatabase(dbPath, {
    mode: 'test',
    seedDemoData: true,
    initialAdmin: {
      username: 'b14_admin',
      email: 'b14_admin@rsucaj.edu.ph',
      password: adminPass,
    },
  });
  activeDb.prepare("UPDATE users SET must_change_password = 0 WHERE username = 'b14_admin'").run();

  const hub = new RealtimeHub();
  const app = express();
  app.use(express.json({ limit: '2mb' }));
  app.use(
    '/api',
    createApiRouter(activeDb, {
      appMode: 'test',
      dbPath,
      backupDir,
      backupRetentionCount: 5,
      nowProvider,
      realtimeHub: hub,
      onDatabaseReplaced: (nextDb) => {
        activeDb = nextDb;
      },
    })
  );

  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address() as { port: number };
  const baseUrl = `http://127.0.0.1:${address.port}`;

  async function req(
    urlPath: string,
    init: RequestInit = {},
    jar?: SessionJar
  ): Promise<{ status: number; body: Record<string, unknown>; text: string; headers: Headers }> {
    const method = (init.method || 'GET').toUpperCase();
    const headers: Record<string, string> = {
      ...(init.headers as Record<string, string> | undefined),
    };
    if (init.body && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
    if (jar) {
      headers.Cookie = jar.sessionCookie;
      if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method) && jar.csrfToken) {
        headers['X-CSRF-Token'] = jar.csrfToken;
      }
    }
    const res = await fetch(`${baseUrl}${urlPath}`, { ...init, method, headers });
    const text = await res.text();
    let body: Record<string, unknown> = {};
    try {
      body = text ? (JSON.parse(text) as Record<string, unknown>) : {};
    } catch {
      body = {};
    }
    return { status: res.status, body, text, headers: res.headers };
  }

  async function loginAs(identifier: string, password: string): Promise<SessionJar> {
    const res = await req('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier, password }),
    });
    assert.equal(res.status, 200, `Login failed for ${identifier}: ${res.status} ${res.text}`);
    const hdrs = res.headers as unknown as { getSetCookie?: () => string[] };
    const cookies = parseCookies(hdrs.getSetCookie ? hdrs.getSetCookie() : []);
    return {
      sessionCookie: `savage_rsucaj_session=${cookies.savage_rsucaj_session}`,
      csrfToken: String(res.body.csrfToken || ''),
    };
  }

  try {
    const adminJar = await loginAs('b14_admin', adminPass);
    const dept = activeDb.prepare('SELECT id FROM departments ORDER BY id ASC LIMIT 1').get() as { id: number };
    const emp = activeDb.prepare('SELECT id, employee_code FROM employees ORDER BY id ASC LIMIT 1').get() as {
      id: number;
      employee_code: string;
    };

    const provisionUser = async (payload: Record<string, unknown>) => {
      const r = await req('/api/users', { method: 'POST', body: JSON.stringify(payload) }, adminJar);
      assert.equal(r.status, 201, `Create user failed: ${r.text}`);
    };
    await provisionUser({
      username: 'b14_hr',
      email: 'b14_hr@rsucaj.edu.ph',
      full_name: 'HR Officer B14',
      role: 'HR Officer',
      password: hrPass,
      must_change_password: false,
    });
    await provisionUser({
      username: 'b14_pay',
      email: 'b14_pay@rsucaj.edu.ph',
      full_name: 'Payroll Officer B14',
      role: 'Payroll Officer',
      password: payPass,
      must_change_password: false,
    });
    await provisionUser({
      username: 'b14_head',
      email: 'b14_head@rsucaj.edu.ph',
      full_name: 'Dept Head B14',
      role: 'Department Head',
      department_id: dept.id,
      password: headPass,
      must_change_password: false,
    });
    await provisionUser({
      username: 'b14_emp',
      email: 'b14_emp@rsucaj.edu.ph',
      full_name: 'Employee B14',
      role: 'Employee',
      employee_id: emp.id,
      password: empPass,
      must_change_password: false,
    });

    const hrJar = await loginAs('b14_hr', hrPass);
    const payJar = await loginAs('b14_pay', payPass);
    const headJar = await loginAs('b14_head', headPass);
    const empJar = await loginAs('b14_emp', empPass);

    // -----------------------------------------------------------------------
    // TEST 1: Multi-user RBAC Enforcement on Settings, Restore, Retention, Devices & Audit
    // -----------------------------------------------------------------------
    await test('Enforces Administrator-only access on system settings, restore, retention, security history, and audit verification', async () => {
      const adminOnlyEndpoints: Array<{ method: string; path: string; body?: unknown }> = [
        { method: 'GET', path: '/api/settings' },
        { method: 'PUT', path: '/api/settings', body: { updates: { campus_name: 'Test' } } },
        { method: 'GET', path: '/api/security/history' },
        { method: 'GET', path: '/api/audit-logs/verify' },
        { method: 'GET', path: '/api/retention/preview' },
        { method: 'POST', path: '/api/retention/execute', body: { confirmExecute: true } },
        { method: 'GET', path: '/api/retention/jobs' },
        { method: 'POST', path: '/api/backup/restore', body: { fileName: 'x.sqlite', confirmText: 'RESTORE LIVE DATABASE', currentPassword: 'x' } },
        { method: 'POST', path: '/api/devices/1/rotate-token', body: {} },
      ];

      for (const nonAdmin of [hrJar, payJar, headJar, empJar]) {
        for (const ep of adminOnlyEndpoints) {
          const r = await req(
            ep.path,
            {
              method: ep.method,
              body: ep.body ? JSON.stringify(ep.body) : undefined,
            },
            nonAdmin
          );
          assert.equal(r.status, 403, `Expected 403 on ${ep.method} ${ep.path}, got ${r.status}`);
        }
      }
    });

    // -----------------------------------------------------------------------
    // TEST 2: Settings Validation, Persistence, Secret Masking & Audit Redaction
    // -----------------------------------------------------------------------
    await test('Validates and rejects invalid settings, masks environment secrets, and redacts audit before/after diffs', async () => {
      const invalidCases: Array<{ updates: Record<string, unknown>; label: string }> = [
        { updates: { timezone: 'Mars/Phobos' }, label: 'invalid IANA timezone' },
        { updates: { attendance_retention_days: '5' }, label: 'retention days < 30' },
        { updates: { audit_log_retention_days: '10' }, label: 'audit retention days < 90' },
        { updates: { default_grace_minutes: '999' }, label: 'grace minutes > 180' },
        { updates: { device_stale_warning_sec: '120', device_heartbeat_timeout_sec: '90' }, label: 'stale >= timeout' },
        { updates: { require_kiosk_token: 'false' }, label: 'disabling kiosk token requirement' },
        { updates: { cs_form_48_reference_verified: 'true' }, label: 'client CS Form 48 override without verified reference' },
        { updates: { unknown_backdoor_key: '1' }, label: 'unknown setting key' },
      ];

      for (const tc of invalidCases) {
        const r = await req('/api/settings', { method: 'PUT', body: JSON.stringify({ updates: tc.updates }) }, adminJar);
        assert.equal(r.status, 400, `Expected 400 for ${tc.label}, got ${r.status}: ${r.text}`);
      }

      // Valid update persists and writes redacted before/after entry in security history
      const validSave = await req(
        '/api/settings',
        {
          method: 'PUT',
          body: JSON.stringify({
            updates: {
              campus_name: 'RSU Cajidiocan Campus — Verified Ops',
              device_stale_warning_sec: '45',
              device_heartbeat_timeout_sec: '90',
              attendance_retention_days: '1825',
            },
          }),
        },
        adminJar
      );
      assert.equal(validSave.status, 200);

      const getSet = await req('/api/settings', {}, adminJar);
      assert.equal(getSet.status, 200);
      assert.equal((getSet.body.settings as Record<string, string>).campus_name, 'RSU Cajidiocan Campus — Verified Ops');
      assert.equal((getSet.body.settings as Record<string, string>).device_stale_warning_sec, '45');
      const secStatus = getSet.body.secretStatus as Record<string, unknown>;
      assert.equal(secStatus.sessionSecretConfigured, true);
      assert.equal(secStatus.backupEncryptionConfigured, true);
      assert.equal(JSON.stringify(getSet.body).includes(sessionSecret), false, 'GET /api/settings must NEVER leak SESSION_SECRET');
      assert.equal(
        JSON.stringify(getSet.body).includes(process.env.BACKUP_ENCRYPTION_KEY!),
        false,
        'GET /api/settings must NEVER leak BACKUP_ENCRYPTION_KEY'
      );

      // Verify redactSensitiveValue + logAudit redact secrets in stored audit metadata
      const leakedObj = redactSensitiveValue({
        password: 'SuperSecretPassword!99',
        api_token: 'ksk_11223344556677889900aabbccddeeff',
        safeField: 'visible',
      }) as Record<string, unknown>;
      assert.equal(leakedObj.password, '***REDACTED***');
      assert.equal(leakedObj.api_token, '***REDACTED***');
      assert.equal(leakedObj.safeField, 'visible');

      logAudit(activeDb, 'b14_admin', 'Probe redaction password=PlainTextSecret!1 token=ksk_abcdef1234567890', 'Security', 'Success', '127.0.0.1', {
        actionType: 'REDACTION_TEST',
        after: { api_token: 'ksk_abcdef1234567890', nested: { current_password: 'MyPassword!1' } },
      });

      const secHist = await req('/api/security/history?limit=10', {}, adminJar);
      assert.equal(secHist.status, 200);
      const secText = JSON.stringify(secHist.body.data);
      assert.equal(secText.includes('PlainTextSecret!1'), false);
      assert.equal(secText.includes('ksk_abcdef1234567890'), false);
      assert.equal(secText.includes('MyPassword!1'), false);
      assert.ok(secText.includes('SETTINGS_UPDATE'));
    });

    // -----------------------------------------------------------------------
    // TEST 3: Devices One-Time Secret, Rotation, Revoke + Punch & Stale/Offline Alerts
    // -----------------------------------------------------------------------
    let rotatedDeviceId = 0;
    let activeKioskToken = '';

    await test('Protects kiosk credentials via one-time display + SHA-256 hash, rotation invalidates prior token, revoke blocks punches, and stale/offline heartbeats trigger persisted alerts', async () => {
      // Register new kiosk device: returns one-time api_token once and starts Offline
      const reg = await req(
        '/api/devices',
        {
          method: 'POST',
          body: JSON.stringify({
            name: 'Kiosk - Admin Gate B14',
            device_type: 'Raspberry Pi',
            ip_address: '192.168.1.214',
            location: 'North Gate',
          }),
        },
        adminJar
      );
      assert.equal(reg.status, 201);
      assert.equal(reg.body.one_time_secret, true);
      assert.equal(reg.body.status, 'Offline');
      assert.equal(reg.body.connectivity, 'Offline');
      const initialToken = String(reg.body.api_token);
      assert.ok(initialToken.startsWith('ksk_'));
      rotatedDeviceId = Number(reg.body.id);

      // GET /api/devices NEVER exposes raw api_token
      const list1 = await req('/api/devices', {}, adminJar);
      assert.equal(list1.status, 200);
      const devRows = list1.body.data as Array<Record<string, unknown>>;
      for (const row of devRows) {
        assert.equal('api_token' in row, false, 'GET /api/devices must omit plaintext api_token');
        assert.ok(typeof row.token_masked === 'string' && String(row.token_masked).startsWith('••••••••'));
        assert.ok(typeof row.token_fingerprint === 'string');
      }

      // Rotate token: old token rejected (403), new token works
      const rot = await req(`/api/devices/${rotatedDeviceId}/rotate-token`, { method: 'POST', body: JSON.stringify({}) }, adminJar);
      assert.equal(rot.status, 200);
      assert.equal(rot.body.one_time_secret, true);
      activeKioskToken = String(rot.body.api_token);
      assert.notEqual(activeKioskToken, initialToken);

      const oldTokenTry = await req('/api/kiosk/heartbeat', {
        method: 'POST',
        headers: { 'x-kiosk-token': initialToken },
        body: JSON.stringify({}),
      });
      assert.equal(oldTokenTry.status, 403);

      const newTokenHb = await req('/api/kiosk/heartbeat', {
        method: 'POST',
        headers: { 'x-kiosk-token': activeKioskToken },
        body: JSON.stringify({ device_timestamp: new Date(virtualNowMs).toISOString() }),
      });
      assert.equal(newTokenHb.status, 200);

      // Advance clock 55s (> 45s stale warning, < 90s offline timeout) -> Stale alert emitted once
      virtualNowMs += 55_000;
      const staleCheck = await req('/api/devices', {}, adminJar);
      const staleDev = (staleCheck.body.data as Array<Record<string, unknown>>).find((d) => d.id === rotatedDeviceId)!;
      assert.equal(staleDev.connectivity, 'Stale');

      // Advance clock another 50s (105s > 90s offline timeout) -> Offline alert emitted once
      virtualNowMs += 50_000;
      const offlineCheck1 = await req('/api/devices', {}, adminJar);
      const offlineDev = (offlineCheck1.body.data as Array<Record<string, unknown>>).find((d) => d.id === rotatedDeviceId)!;
      assert.equal(offlineDev.connectivity, 'Offline');

      // Poll again — must NOT duplicate offline notification
      await req('/api/devices', {}, adminJar);
      const devAlerts = activeDb
        .prepare("SELECT * FROM notifications WHERE action_entity_id = ? AND event_type IN ('device_stale', 'device_offline') ORDER BY id ASC")
        .all(rotatedDeviceId) as Array<{ event_type: string; title: string }>;
      assert.equal(devAlerts.filter((a) => a.event_type === 'device_stale').length, 1);
      assert.equal(devAlerts.filter((a) => a.event_type === 'device_offline').length, 1);

      // Sync batch failure (rejected event) creates Device Alert failure notification and NO false 'successful sync' message
      const syncFail = await req('/api/kiosk/sync', {
        method: 'POST',
        headers: { 'x-kiosk-token': activeKioskToken },
        body: JSON.stringify({
          batch_uid: 'b14-sync-fail-batch-1',
          events: [
            {
              event_uid: 'b14-bad-evt-1',
              employee_code: 'EMP-NONEXISTENT-999',
              punch_type: 'TIME_IN',
              device_timestamp: new Date(virtualNowMs).toISOString(),
            },
          ],
        }),
      });
      assert.equal(syncFail.status, 200);
      assert.equal((syncFail.body.summary as { rejected: number }).rejected, 1);
      const syncAlert = activeDb
        .prepare("SELECT * FROM notifications WHERE event_type = 'kiosk_sync_failure' AND action_entity_id = ?")
        .get(rotatedDeviceId) as { title: string; category: string } | undefined;
      assert.ok(syncAlert, 'Expected persisted Device Alert for sync failure');
      assert.equal(syncAlert.category, 'Device Alerts');
      const allNotifs = activeDb.prepare('SELECT title, message FROM notifications').all() as Array<{
        title: string;
        message: string;
      }>;
      assert.equal(
        allNotifs.some((n) => /successful sync/i.test(`${n.title} ${n.message}`)),
        false,
        'Must never persist false successful sync notification'
      );

      // Revoke device -> punch immediately rejected with 403
      const revoke = await req(`/api/devices/${rotatedDeviceId}/revoke`, { method: 'POST', body: JSON.stringify({}) }, adminJar);
      assert.equal(revoke.status, 200);
      const punchedWhileRevoked = await req('/api/kiosk/punch', {
        method: 'POST',
        headers: { 'x-kiosk-token': activeKioskToken },
        body: JSON.stringify({
          employee_code: emp.employee_code,
          punch_type: 'TIME_IN',
          event_uid: 'b14-revoked-punch-attempt',
        }),
      });
      assert.equal(punchedWhileRevoked.status, 403);
      assert.equal(punchedWhileRevoked.body.code, 'DEVICE_REVOKED');
    });

    // -----------------------------------------------------------------------
    // TEST 4: Role-Targeted Notifications, Event Triggers, Read/Bulk Actions & Badge Consistency
    // -----------------------------------------------------------------------
    await test('Targets notifications by role, triggers attendance exception alerts, and syncs unread badges cleanly', async () => {
      // Trigger an attendance exception via manual Absent record -> creates Attendance Alert targeted to Admin/HR/DeptHead
      const attException = await req(
        '/api/attendance',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: emp.id,
            date: '2026-04-15',
            status: 'Absent',
            remarks: 'Unscheduled absence QA test',
          }),
        },
        adminJar
      );
      assert.equal(attException.status, 201);

      // Admin sees device_token_rotated + device_offline + attendance_exception; Payroll Officer does NOT see Admin-only device_token_rotated
      const adminNotifs = await req('/api/notifications', {}, adminJar);
      const payNotifs = await req('/api/notifications', {}, payJar);
      assert.equal(adminNotifs.status, 200);
      assert.equal(payNotifs.status, 200);
      const adminList = adminNotifs.body.data as Array<{ id: number; event_type?: string; is_read: number }>;
      const payList = payNotifs.body.data as Array<{ id: number; event_type?: string; is_read: number }>;

      assert.ok(adminList.some((n) => n.event_type === 'device_token_rotated'));
      assert.equal(
        payList.some((n) => n.event_type === 'device_token_rotated'),
        false,
        'Payroll Officer must not receive Admin-only kiosk token rotation notices'
      );
      assert.ok(adminList.some((n) => n.event_type === 'attendance_exception'));

      // Badge consistency: dashboard unreadNotifications matches /api/notifications counts.unread
      const adminDash = await req('/api/dashboard', {}, adminJar);
      assert.equal(adminDash.status, 200);
      assert.equal(
        adminDash.body.unreadNotifications,
        (adminNotifs.body.counts as { unread: number }).unread
      );

      // Selective mark read of 1 notification updates unread badge by 1
      const targetUnread = adminList.filter((n) => n.is_read === 0);
      assert.ok(targetUnread.length >= 2);
      const firstId = targetUnread[0].id;
      const selectiveRead = await req(
        '/api/notifications/mark-all-read',
        { method: 'POST', body: JSON.stringify({ ids: [firstId] }) },
        adminJar
      );
      assert.equal(selectiveRead.status, 200);
      const afterSel = await req('/api/notifications?filter=Unread', {}, adminJar);
      assert.equal((afterSel.body.counts as { unread: number }).unread, targetUnread.length - 1);

      // Read-only notification role (Payroll Officer) can read scoped notifications but gets 403 on write/delete
      const payNotifRead = await req('/api/notifications', {}, payJar);
      assert.equal(payNotifRead.status, 200);
      const payMarkRead = await req('/api/notifications/mark-all-read', { method: 'POST', body: JSON.stringify({}) }, payJar);
      assert.equal(payMarkRead.status, 403);
      const payDelOne = await req(`/api/notifications/${firstId}`, { method: 'DELETE' }, payJar);
      assert.equal(payDelOne.status, 403);
      const payClearAll = await req('/api/notifications', { method: 'DELETE', body: JSON.stringify({}) }, payJar);
      assert.equal(payClearAll.status, 403);

      // Selective bulk dismiss via DELETE /api/notifications { ids: [...] }
      const bulkTargetId = targetUnread[1].id;
      const bulkDismiss = await req(
        '/api/notifications',
        { method: 'DELETE', body: JSON.stringify({ ids: [bulkTargetId] }) },
        adminJar
      );
      assert.equal(bulkDismiss.status, 200);
      assert.equal(bulkDismiss.body.deleted, 1);

      // Delete one notification
      const delOne = await req(`/api/notifications/${firstId}`, { method: 'DELETE' }, adminJar);
      assert.equal(delOne.status, 200);
    });

    // -----------------------------------------------------------------------
    // TEST 5: Retention Dry-Run Preview & Policy-Compliant Purge Execution
    // -----------------------------------------------------------------------
    await test('Previews eligible deletions accurately and enforces retention purge while preserving immutable audit/events & locked payroll records', async () => {
      // Seed historical records > 1825 days before 2026-04-15:
      // oldDate (2018-12-10) is outside finalized payroll period (2019-01-01..2019-01-15) -> eligible to purge
      // lockedDate (2019-01-12) is inside finalized payroll period -> MUST be preserved
      const oldDate = '2018-12-10';
      const lockedDate = '2019-01-12';
      const emp2 = activeDb
        .prepare('SELECT id FROM employees WHERE id != ? LIMIT 1')
        .get(emp.id) as { id: number };

      activeDb
        .prepare(
          `INSERT INTO attendance_records (employee_id, date, time_in, time_out, status)
           VALUES (?, ?, '08:00 AM', '05:00 PM', 'Present')`
        )
        .run(emp.id, oldDate);

      activeDb
        .prepare(
          `INSERT INTO attendance_records (employee_id, date, time_in, time_out, status)
           VALUES (?, ?, '08:00 AM', '05:00 PM', 'Present')`
        )
        .run(emp2.id, lockedDate);

      // Finalized payroll run covering lockedDate -> must protect emp2's locked attendance record
      activeDb
        .prepare(
          `INSERT INTO payroll_runs (period_label, start_date, end_date, status, employee_count)
           VALUES ('2019-01-A', '2019-01-01', '2019-01-15', 'Finalized', 1)`
        )
        .run();

      // Expired user session (> 7 days stale) & old read notification (> 90 days)
      activeDb
        .prepare(
          `INSERT INTO user_sessions (sid, user_id, csrf_token, expires_at, revoked_at)
           VALUES (?, 1, 'csrf_old', ?, ?)`
        )
        .run('sid_' + crypto.randomBytes(8).toString('hex'), virtualNowMs - 15 * 86400_000, virtualNowMs - 14 * 86400_000);

      activeDb
        .prepare(
          `INSERT INTO notifications (title, message, category, priority, is_read, created_at)
           VALUES ('Old Read Notice', 'Historical notice', 'System Notices', 'Low', 1, '2020-01-01 08:00:00')`
        )
        .run();

      // Old immutable attendance_events & old immutable audit_log
      activeDb
        .prepare(
          `INSERT INTO attendance_events (event_uid, employee_id, attendance_date, punch_type, punch_time)
           VALUES ('evt-old-immutable-2019', ?, ?, 'TIME_IN', '08:00 AM')`
        )
        .run(emp.id, oldDate);

      logAudit(activeDb, 'b14_admin', 'Historical 2019 audit entry', 'Settings', 'Success', '127.0.0.1', {
        timestamp: '2019-01-10 09:00:00',
      });

      const prevRes = await req('/api/retention/preview', {}, adminJar);
      assert.equal(prevRes.status, 200);
      assert.equal(prevRes.body.dryRun, true);
      assert.ok((prevRes.body.totalEligibleDeletes as number) >= 3);
      assert.ok((prevRes.body.totalPreservedImmutable as number) >= 3);

      // Dry-run must NOT delete any row
      assert.ok(
        activeDb.prepare('SELECT id FROM attendance_records WHERE employee_id = ? AND date = ?').get(emp.id, oldDate)
      );

      // Requires explicit confirmExecute=true
      const rejectNoConfirm = await req(
        '/api/retention/execute',
        { method: 'POST', body: JSON.stringify({ confirmExecute: false }) },
        adminJar
      );
      assert.equal(rejectNoConfirm.status, 400);

      // Execute retention purge
      const execRes = await req(
        '/api/retention/execute',
        { method: 'POST', body: JSON.stringify({ confirmExecute: true }) },
        adminJar
      );
      assert.equal(execRes.status, 201);
      const job = execRes.body.job as { job_uid: string; total_deleted: number; status: string };
      assert.equal(job.status, 'Completed');
      assert.ok(job.total_deleted >= 3);

      // Unlocked old attendance deleted; payroll-locked attendance, immutable attendance_events & audit_logs preserved
      assert.equal(
        activeDb.prepare('SELECT id FROM attendance_records WHERE employee_id = ? AND date = ?').get(emp.id, oldDate),
        undefined
      );
      assert.ok(
        activeDb.prepare('SELECT id FROM attendance_records WHERE employee_id = ? AND date = ?').get(emp2.id, lockedDate),
        'Finalized payroll attendance record must be preserved'
      );
      assert.ok(
        activeDb.prepare("SELECT id FROM attendance_events WHERE event_uid = 'evt-old-immutable-2019'").get(),
        'Immutable attendance_events must be preserved'
      );
      assert.ok(
        activeDb.prepare("SELECT id FROM audit_logs WHERE timestamp = '2019-01-10 09:00:00'").get(),
        'Immutable audit_logs must be preserved'
      );

      const jobsRes = await req('/api/retention/jobs', {}, adminJar);
      assert.equal(jobsRes.status, 200);
      assert.ok((jobsRes.body.data as Array<{ job_uid: string }>).some((j) => j.job_uid === job.job_uid));
    });

    // -----------------------------------------------------------------------
    // TEST 6: Append-Only Tamper-Evident Audit Log Immutability, Hash Verification & Unclipped CSV Export
    // -----------------------------------------------------------------------
    await test('Enforces append-only audit immutability triggers, verifies SHA-256 hash chain, detects tampering, and exports full CSV', async () => {
      // Triggers block UPDATE and DELETE on audit_logs
      assert.throws(
        () => activeDb.prepare("UPDATE audit_logs SET activity = 'Tampered!' WHERE id = 1").run(),
        /IMMUTABLE_AUDIT_VIOLATION/i
      );
      assert.throws(
        () => activeDb.prepare('DELETE FROM audit_logs WHERE id = 1').run(),
        /IMMUTABLE_AUDIT_VIOLATION/i
      );

      // Generate extra audit rows so total exceeds 15 rows
      for (let i = 1; i <= 15; i++) {
        logAudit(activeDb, 'b14_admin', `Bulk audit chain entry #${i}`, 'Security', 'Success', '127.0.0.1');
      }

      const verifyRes = await req('/api/audit-logs/verify', {}, adminJar);
      assert.equal(verifyRes.status, 200);
      assert.equal(verifyRes.body.valid, true);
      assert.ok((verifyRes.body.checkedCount as number) >= 18);

      // Unclipped full CSV export returns ALL matching rows (> 12 UI page size)
      const csvRes = await req('/api/reports/audit-logs/export.csv?module=Security', {}, adminJar);
      assert.equal(csvRes.status, 200);
      assert.ok(csvRes.headers.get('content-type')?.includes('text/csv'));
      const csvLines = csvRes.text.trim().split(/\r?\n/);
      assert.ok(csvLines.length >= 16, `Expected full unclipped CSV (>15 rows), got ${csvLines.length}`);
      assert.ok(csvLines[0].includes('entry_hash'));

      // Simulated tampering on an isolated snapshot copy (drop trigger -> mutate row) MUST be caught by verifyAuditLogChain
      const tamperPath = path.join(tmpDir, 'tamper-check.db');
      activeDb.exec(`VACUUM INTO '${tamperPath.replace(/'/g, "''")}'`);
      const copyDb = new Database(tamperPath);
      copyDb.exec('DROP TRIGGER IF EXISTS trg_audit_logs_no_update;');
      const targetRow = copyDb.prepare('SELECT id FROM audit_logs ORDER BY id ASC LIMIT 1 OFFSET 2').get() as { id: number };
      copyDb.prepare("UPDATE audit_logs SET activity = 'ALTERED_WITHOUT_HASH' WHERE id = ?").run(targetRow.id);
      const tamperedCheck = verifyAuditLogChain(copyDb);
      copyDb.close();
      assert.equal(tamperedCheck.valid, false);
      assert.equal(tamperedCheck.brokenRowId, targetRow.id);
    });

    // -----------------------------------------------------------------------
    // TEST 7: Online Backup, Guarded Live Restore & Restart Persistence
    // -----------------------------------------------------------------------
    await test('Executes online encrypted snapshot + guarded live restore with rollback safety backup and persists across simulated restart', async () => {
      // Seed marker before taking snapshot
      const preDept = await req(
        '/api/departments',
        { method: 'POST', body: JSON.stringify({ code: 'PRE-RST', name: 'Pre-Restore Dept', head_name: 'Dr. Pre' }) },
        adminJar
      );
      assert.equal(preDept.status, 201);

      const snap = await req('/api/backup/snapshot', { method: 'POST', body: JSON.stringify({}) }, adminJar);
      assert.equal(snap.status, 201);
      const manifest = snap.body.manifest as { sqliteFile: string; encryptedFile: string | null; encrypted: boolean };
      assert.equal(manifest.encrypted, true);
      const archiveFile = String(manifest.encryptedFile || manifest.sqliteFile);
      assert.ok(archiveFile.endsWith('.sqlite.enc'));

      // Mutate database AFTER snapshot
      const postDept = await req(
        '/api/departments',
        { method: 'POST', body: JSON.stringify({ code: 'POST-TMP', name: 'Post-Snapshot Temp', head_name: 'Dr. Post' }) },
        adminJar
      );
      assert.equal(postDept.status, 201);
      await req(
        '/api/settings',
        { method: 'PUT', body: JSON.stringify({ updates: { campus_name: 'TEMPORARY POST BACKUP NAME' } }) },
        adminJar
      );

      // Guard checks on /api/backup/restore
      const badConfirm = await req(
        '/api/backup/restore',
        {
          method: 'POST',
          body: JSON.stringify({ fileName: archiveFile, confirmText: 'wrong', currentPassword: adminPass }),
        },
        adminJar
      );
      assert.equal(badConfirm.status, 400);

      const badPass = await req(
        '/api/backup/restore',
        {
          method: 'POST',
          body: JSON.stringify({
            fileName: archiveFile,
            confirmText: 'RESTORE LIVE DATABASE',
            currentPassword: 'WrongPassword!123',
          }),
        },
        adminJar
      );
      assert.equal(badPass.status, 403);

      // Path traversal attempt must be rejected with 400
      const traversalTry = await req(
        '/api/backup/restore',
        {
          method: 'POST',
          body: JSON.stringify({
            fileName: '../savage-rsucaj-evil.sqlite.enc',
            confirmText: 'RESTORE LIVE DATABASE',
            currentPassword: adminPass,
          }),
        },
        adminJar
      );
      assert.equal(traversalTry.status, 400);

      // Tampered encrypted archive must be rejected pre-restore (422) without touching live DB
      const tamperedFile = 'savage-rsucaj-tampered-test.sqlite.enc';
      const srcBuf = fs.readFileSync(path.join(backupDir, archiveFile));
      const tamperedBuf = Buffer.from(srcBuf);
      tamperedBuf[tamperedBuf.length - 1] ^= 0xff;
      fs.writeFileSync(path.join(backupDir, tamperedFile), tamperedBuf);
      const tamperedRestore = await req(
        '/api/backup/restore',
        {
          method: 'POST',
          body: JSON.stringify({
            fileName: tamperedFile,
            confirmText: 'RESTORE LIVE DATABASE',
            currentPassword: adminPass,
          }),
        },
        adminJar
      );
      assert.equal(tamperedRestore.status, 422);
      assert.equal(tamperedRestore.body.success, false);
      fs.rmSync(path.join(backupDir, tamperedFile), { force: true });

      // Execute valid live restore (adminJar was created BEFORE snapshot, so its session exists in snapshot!)
      const liveRestore = await req(
        '/api/backup/restore',
        {
          method: 'POST',
          body: JSON.stringify({
            fileName: archiveFile,
            confirmText: 'RESTORE LIVE DATABASE',
            currentPassword: adminPass,
          }),
        },
        adminJar
      );
      assert.equal(liveRestore.status, 200, `Live restore failed: ${liveRestore.text}`);
      assert.equal(liveRestore.body.success, true);
      assert.ok(typeof liveRestore.body.preRestoreBackupFile === 'string');
      assert.ok(fs.existsSync(path.join(tmpDir, String(liveRestore.body.preRestoreBackupFile))));

      // Verify restored DB rolled back post-backup changes while preserving pre-backup marker & valid audit chain
      const postSettings = await req('/api/settings', {}, adminJar);
      assert.equal(
        (postSettings.body.settings as Record<string, string>).campus_name,
        'RSU Cajidiocan Campus — Verified Ops'
      );
      assert.ok(activeDb.prepare("SELECT id FROM departments WHERE code = 'PRE-RST'").get());
      assert.equal(activeDb.prepare("SELECT id FROM departments WHERE code = 'POST-TMP'").get(), undefined);

      const verifyAfterRestore = await req('/api/audit-logs/verify', {}, adminJar);
      assert.equal(verifyAfterRestore.status, 200);
      assert.equal(verifyAfterRestore.body.valid, true);

      // Export backup JSON never exposes raw api_token
      const exportJson = await req('/api/backup/export', {}, adminJar);
      assert.equal(exportJson.status, 200);
      const devExports = (exportJson.body.tables as { devices: Array<Record<string, unknown>> }).devices;
      for (const d of devExports) {
        assert.equal('api_token' in d, false, 'Backup JSON export must omit plaintext device api_token');
      }
    });

    await test('Persists settings, device key rotation, notifications, retention history, and audit chain across server restart', async () => {
      // Record retention job & update a setting cleanly, then simulate full server shutdown & restart
      const markerSetting = await req(
        '/api/settings',
        { method: 'PUT', body: JSON.stringify({ updates: { campus_name: 'RSU Cajidiocan Restart Persist' } }) },
        adminJar
      );
      assert.equal(markerSetting.status, 200);

      // Shut down first HTTP server & DB
      await new Promise<void>((resolve) => server.close(() => resolve()));
      hub.closeAll();
      closeDatabaseSafely(activeDb);

      // Boot fresh DB handle & fresh Express instance pointing at the same file
      const restartedDb = initDatabase(dbPath, {
        mode: 'test',
        seedDemoData: false,
        skipAdminBootstrap: true,
      });
      const restartedHub = new RealtimeHub();
      const restartedApp = express();
      restartedApp.use(express.json());
      restartedApp.use(
        '/api',
        createApiRouter(restartedDb, {
          appMode: 'test',
          dbPath,
          backupDir,
          nowProvider,
          realtimeHub: restartedHub,
        })
      );
      const srv2 = http.createServer(restartedApp);
      await new Promise<void>((resolve) => srv2.listen(0, '127.0.0.1', resolve));
      const addr2 = srv2.address() as { port: number };
      const base2 = `http://127.0.0.1:${addr2.port}`;

      try {
        const login2 = await fetch(`${base2}/api/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ identifier: 'b14_admin', password: adminPass }),
        });
        assert.equal(login2.status, 200);
        const loginJson2 = (await login2.json()) as { csrfToken: string };
        const hdrs2 = login2.headers as unknown as { getSetCookie?: () => string[] };
        const c2 = parseCookies(hdrs2.getSetCookie ? hdrs2.getSetCookie() : []);
        const cookie2 = `savage_rsucaj_session=${c2.savage_rsucaj_session}`;

        const s2Res = await fetch(`${base2}/api/settings`, { headers: { Cookie: cookie2 } });
        assert.equal(s2Res.status, 200);
        const s2Json = (await s2Res.json()) as { settings: Record<string, string> };
        assert.equal(s2Json.settings.campus_name, 'RSU Cajidiocan Restart Persist');

        const v2Res = await fetch(`${base2}/api/audit-logs/verify`, { headers: { Cookie: cookie2 } });
        assert.equal(v2Res.status, 200);
        const v2Json = (await v2Res.json()) as { valid: boolean };
        assert.equal(v2Json.valid, true);

        const health2 = await fetch(`${base2}/api/health`);
        const h2Json = (await health2.json()) as { schemaVersion: string; build: string };
        assert.equal(h2Json.schemaVersion, '009');
        assert.equal(h2Json.build, 'BUILD 17');
        assert.ok(loginJson2.csrfToken.length > 10);
      } finally {
        await new Promise<void>((resolve) => srv2.close(() => resolve()));
        restartedHub.closeAll();
        closeDatabaseSafely(restartedDb);
      }
    });
  } finally {
    try {
      server.close();
    } catch {
      // already closed in restart test
    }
    hub.closeAll();
    closeDatabaseSafely(activeDb);
    fs.rmSync(tmpDir, { recursive: true, force: true });
    delete process.env.BACKUP_ENCRYPTION_KEY;
  }

  console.log(`\nAdmin Ops & Security Hardening (BUILD 14) Summary: ${passed} passed, ${failed} failed.`);
  if (failed > 0) process.exit(1);
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
