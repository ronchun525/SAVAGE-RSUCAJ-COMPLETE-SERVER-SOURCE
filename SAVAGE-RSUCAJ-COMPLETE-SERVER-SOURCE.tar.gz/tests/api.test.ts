import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import Database from 'better-sqlite3';
import express from 'express';
import type { AddressInfo } from 'node:net';
import {
  initDatabase,
  InitialAdminCredentialsMissingError,
  recoverAdminAccount,
} from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import { hashPassword, SESSION_COOKIE_NAME } from '../server/auth.ts';
import { securityHeadersMiddleware } from '../server/security.ts';

interface TestResult {
  name: string;
  passed: boolean;
  error?: string;
}

interface SessionJar {
  sessionCookie: string;
  csrfToken: string;
  rawCookies: string[];
}

function parseSetCookies(res: Response): string[] {
  const hdrs = res.headers as unknown as { getSetCookie?: () => string[] };
  if (typeof hdrs.getSetCookie === 'function') {
    return hdrs.getSetCookie();
  }
  const single = res.headers.get('set-cookie');
  return single ? [single] : [];
}

function extractSessionCookie(setCookies: string[]): string {
  const matched = setCookies.find((c) => c.startsWith(`${SESSION_COOKIE_NAME}=`));
  return matched ? matched.split(';')[0] : '';
}

async function runTests() {
  const results: TestResult[] = [];

  async function test(name: string, fn: () => Promise<void>) {
    try {
      await fn();
      results.push({ name, passed: true });
      console.log(`PASS  ${name}`);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      results.push({ name, passed: false, error: message });
      console.error(`FAIL  ${name}: ${message}`);
    }
  }

  // Generate ephemeral test-only secrets (zero hardcoded credentials)
  const INITIAL_SECRET = crypto.randomBytes(48).toString('hex');
  const ROTATED_SECRET = crypto.randomBytes(48).toString('hex');
  const INITIAL_ADMIN_USER = 'rsu_sysadmin';
  const INITIAL_ADMIN_EMAIL = 'sysadmin@rsucaj.edu.ph';
  const INITIAL_ADMIN_PW = `Boot!${crypto.randomBytes(6).toString('hex')}A9`;
  const ROTATED_ADMIN_PW = `Rot!${crypto.randomBytes(6).toString('hex')}B8`;
  const SECOND_ROTATED_PW = `Next!${crypto.randomBytes(6).toString('hex')}C7`;

  process.env.SESSION_SECRET = INITIAL_SECRET;
  delete process.env.SESSION_SECRET_PREVIOUS;
  delete process.env.ALLOWED_ORIGINS;
  delete process.env.GOOGLE_OAUTH_CLIENT_ID;
  delete process.env.SMTP_HOST;

  // -------------------------------------------------------------------------
  // TEST 1: Fail-secure fresh DB initialization when initial credentials absent
  // -------------------------------------------------------------------------
  await test('Fail-secure bootstrap: fresh DB throws InitialAdminCredentialsMissingError when initial credentials absent', async () => {
    delete process.env.ADMIN_INITIAL_USERNAME;
    delete process.env.ADMIN_INITIAL_EMAIL;
    delete process.env.ADMIN_INITIAL_PASSWORD;

    assert.throws(
      () => initDatabase(':memory:', { seedDemoData: false }),
      InitialAdminCredentialsMissingError
    );
  });

  // Provide explicit test initial admin env vars for the main integration test fixture
  process.env.ADMIN_INITIAL_USERNAME = INITIAL_ADMIN_USER;
  process.env.ADMIN_INITIAL_EMAIL = INITIAL_ADMIN_EMAIL;
  process.env.ADMIN_INITIAL_PASSWORD = INITIAL_ADMIN_PW;

  const apiBackupTmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-api-backups-'));
  const db = initDatabase(':memory:', { mode: 'test', seedDemoData: true });
  const app = express();
  app.disable('x-powered-by');
  app.use(securityHeadersMiddleware);
  app.use(
    '/api',
    createApiRouter(db, {
      maxFailedLoginAttempts: 5,
      lockoutDurationMinutes: 15,
      loginRateLimitMax: 200,
      backupDir: apiBackupTmpDir,
      appMode: 'test',
    })
  );

  const server = await new Promise<ReturnType<typeof app.listen>>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });

  const port = (server.address() as AddressInfo).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  async function rawReq(
    urlPath: string,
    init: RequestInit = {},
    jar?: SessionJar | null,
    options: { includeCsrf?: boolean; customCsrf?: string } = {}
  ): Promise<{
    status: number;
    body: Record<string, unknown>;
    setCookies: string[];
    headers: Headers;
  }> {
    const headers: Record<string, string> = {
      ...(init.headers as Record<string, string> | undefined),
    };
    if (init.body && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }
    if (jar?.sessionCookie) {
      headers['Cookie'] = jar.sessionCookie;
    }
    const method = (init.method || 'GET').toUpperCase();
    const isMutating = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(method);
    const shouldIncludeCsrf = options.includeCsrf ?? isMutating;
    if (shouldIncludeCsrf && jar?.csrfToken && !headers['X-CSRF-Token']) {
      headers['X-CSRF-Token'] = options.customCsrf ?? jar.csrfToken;
    } else if (options.customCsrf !== undefined) {
      headers['X-CSRF-Token'] = options.customCsrf;
    }

    const res = await fetch(`${baseUrl}${urlPath}`, { ...init, method, headers });
    const text = await res.text();
    let body: Record<string, unknown> = {};
    try {
      body = text ? (JSON.parse(text) as Record<string, unknown>) : {};
    } catch {
      body = { raw: text };
    }
    return { status: res.status, body, setCookies: parseSetCookies(res), headers: res.headers };
  }

  async function loginAs(
    identifier: string,
    password: string,
    extraHeaders: Record<string, string> = {}
  ): Promise<{ status: number; body: Record<string, unknown>; jar: SessionJar; setCookies: string[]; headers: Headers }> {
    const r = await rawReq('/api/auth/login', {
      method: 'POST',
      headers: extraHeaders,
      body: JSON.stringify({ identifier, password }),
    });
    const sessionCookie = extractSessionCookie(r.setCookies);
    const csrfToken = typeof r.body.csrfToken === 'string' ? r.body.csrfToken : '';
    return {
      status: r.status,
      body: r.body,
      jar: { sessionCookie, csrfToken, rawCookies: r.setCookies },
      setCookies: r.setCookies,
      headers: r.headers,
    };
  }

  let adminJar: SessionJar = { sessionCookie: '', csrfToken: '', rawCookies: [] };

  try {
    // -------------------------------------------------------------------------
    // TEST 2: Health, Security Headers, and Honest Disabled OAuth/SMTP Config
    // -------------------------------------------------------------------------
    await test('Health endpoint, security headers, and honest disabled Google OAuth / SMTP state', async () => {
      const r = await rawReq('/api/health');
      assert.equal(r.status, 200);
      assert.equal(r.body.database, 'connected');
      assert.equal(r.body.version, '1.13.0');
      assert.equal(r.body.build, 'BUILD 17');
      assert.equal(r.body.schemaVersion, '009');
      assert.equal(r.body.timezone, 'Asia/Manila');
      assert.equal(r.body.foreignKeys, true);
      assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
      assert.equal(r.headers.get('x-powered-by'), null);
      assert.ok((r.headers.get('cache-control') || '').includes('no-store'));

      const cfg = await rawReq('/api/auth/config');
      assert.equal(cfg.status, 200);
      assert.equal(cfg.body.googleSsoConfigured, false);
      assert.equal(cfg.body.smtpConfigured, false);

      const forgot = await rawReq('/api/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email: INITIAL_ADMIN_EMAIL }),
      });
      assert.equal(forgot.status, 503);
      assert.equal(forgot.body.smtpConfigured, false);
    });

    // -------------------------------------------------------------------------
    // TEST 3: Unauthenticated Access Denied (401)
    // -------------------------------------------------------------------------
    await test('Unauthenticated access to all administrative routes returns 401', async () => {
      for (const p of [
        '/api/dashboard',
        '/api/employees',
        '/api/payroll',
        '/api/settings',
        '/api/devices',
        '/api/users',
        '/api/audit-logs',
        '/api/backup/export',
      ]) {
        const r = await rawReq(p);
        assert.equal(r.status, 401, `Expected 401 for ${p}, got ${r.status}`);
      }
    });

    // -------------------------------------------------------------------------
    // TEST 4: Wrong Password (401) + Brute-Force Lockout (429 + Retry-After)
    // -------------------------------------------------------------------------
    await test('Wrong password returns 401 and 5 failed attempts trigger brute-force lockout (429 + Retry-After)', async () => {
      // Create a dedicated test account for brute-force lockout testing so admin stays clean for login test
      const { hash, salt } = hashPassword('LockTest!2026Aa');
      db.prepare(
        `INSERT INTO users (username, email, full_name, role, password_hash, salt, must_change_password, is_active)
         VALUES ('locktarget', 'locktarget@rsucaj.edu.ph', 'Lockout Target', 'HR Officer', ?, ?, 0, 1)`
      ).run(hash, salt);

      for (let i = 1; i <= 4; i++) {
        const bad = await loginAs('locktarget', `WrongPass!${i}`);
        assert.equal(bad.status, 401, `Attempt ${i} should return 401`);
      }

      // 5th failed attempt locks the account
      const fifth = await loginAs('locktarget', 'WrongPass!5');
      assert.equal(fifth.status, 429);
      assert.equal(fifth.body.code, 'ACCOUNT_LOCKED');
      assert.ok(Number(fifth.headers.get('retry-after')) > 0);

      // Even the CORRECT password must be rejected while locked
      const validWhileLocked = await loginAs('locktarget', 'LockTest!2026Aa');
      assert.equal(validWhileLocked.status, 429);
      assert.equal(validWhileLocked.body.code, 'ACCOUNT_LOCKED');
    });

    // -------------------------------------------------------------------------
    // TEST 5: Valid Login Issues HttpOnly Cookie Only (No Raw Token in JSON) & HTTPS Cookie Flags
    // -------------------------------------------------------------------------
    await test('Login issues HttpOnly session cookie + CSRF cookie, omits raw token from JSON, and enforces HTTPS flags', async () => {
      const res = await loginAs(INITIAL_ADMIN_USER, INITIAL_ADMIN_PW);
      assert.equal(res.status, 200);
      assert.equal('token' in res.body, false, 'Raw session token must NOT be exposed in JSON');
      assert.ok(typeof res.body.csrfToken === 'string' && res.body.csrfToken.length >= 32);
      const sessHeader = res.setCookies.find((c) => c.startsWith(`${SESSION_COOKIE_NAME}=`)) || '';
      assert.ok(sessHeader.includes('HttpOnly'));
      assert.ok(sessHeader.includes('SameSite=Lax'));
      assert.equal((res.body.user as { must_change_password: boolean }).must_change_password, true);

      // Verify HTTPS proxy cookie flags
      const httpsRes = await loginAs(INITIAL_ADMIN_USER, INITIAL_ADMIN_PW, { 'x-forwarded-proto': 'https' });
      assert.equal(httpsRes.status, 200);
      const httpsSess = httpsRes.setCookies.find((c) => c.startsWith(`${SESSION_COOKIE_NAME}=`)) || '';
      assert.ok(httpsSess.includes('SameSite=None'));
      assert.ok(httpsSess.includes('Secure'));
      assert.ok(httpsSess.includes('Partitioned'));

      adminJar = httpsRes.jar;
    });

    // -------------------------------------------------------------------------
    // TEST 6: Forced First-Login Password Rotation Gate
    // -------------------------------------------------------------------------
    await test('First-login forced password rotation blocks portal endpoints (403) until strong password change completes', async () => {
      for (const blockedPath of ['/api/dashboard', '/api/employees', '/api/payroll', '/api/settings']) {
        const r = await rawReq(blockedPath, {}, adminJar);
        assert.equal(r.status, 403, `Expected 403 PASSWORD_CHANGE_REQUIRED on ${blockedPath}`);
        assert.equal(r.body.code, 'PASSWORD_CHANGE_REQUIRED');
      }

      // Weak password must be rejected with 400
      const weak = await rawReq(
        '/api/auth/change-password',
        {
          method: 'POST',
          body: JSON.stringify({ currentPassword: INITIAL_ADMIN_PW, newPassword: 'weak' }),
        },
        adminJar
      );
      assert.equal(weak.status, 400);

      // Strong password succeeds, clears must_change_password, and issues rotated session + CSRF
      const rotated = await rawReq(
        '/api/auth/change-password',
        {
          method: 'POST',
          body: JSON.stringify({ currentPassword: INITIAL_ADMIN_PW, newPassword: ROTATED_ADMIN_PW }),
        },
        adminJar
      );
      assert.equal(rotated.status, 200);
      assert.equal((rotated.body.user as { must_change_password: boolean }).must_change_password, false);

      const newSessionCookie = extractSessionCookie(rotated.setCookies);
      assert.ok(newSessionCookie && newSessionCookie !== adminJar.sessionCookie);
      adminJar = {
        sessionCookie: newSessionCookie,
        csrfToken: String(rotated.body.csrfToken),
        rawCookies: rotated.setCookies,
      };

      // Portal access now succeeds
      const dash = await rawReq('/api/dashboard?range=week', {}, adminJar);
      assert.equal(dash.status, 200);
    });

    // -------------------------------------------------------------------------
    // TEST 7: CSRF Protection (Missing Token, Invalid Token, Cross-Origin Rejection)
    // -------------------------------------------------------------------------
    await test('CSRF protection rejects mutating requests with missing token, wrong token, or cross-origin header (403)', async () => {
      // Missing X-CSRF-Token
      const noCsrf = await rawReq(
        '/api/settings',
        { method: 'PUT', body: JSON.stringify({ updates: { default_grace_minutes: '12' } }) },
        adminJar,
        { includeCsrf: false }
      );
      assert.equal(noCsrf.status, 403);
      assert.equal(noCsrf.body.code, 'CSRF_INVALID');

      // Wrong X-CSRF-Token
      const badCsrf = await rawReq(
        '/api/settings',
        { method: 'PUT', body: JSON.stringify({ updates: { default_grace_minutes: '12' } }) },
        adminJar,
        { includeCsrf: true, customCsrf: 'forged-csrf-token-value' }
      );
      assert.equal(badCsrf.status, 403);
      assert.equal(badCsrf.body.code, 'CSRF_INVALID');

      // Untrusted Origin
      const evilOrigin = await rawReq(
        '/api/settings',
        {
          method: 'PUT',
          headers: { Origin: 'https://attacker.invalid' },
          body: JSON.stringify({ updates: { default_grace_minutes: '12' } }),
        },
        adminJar
      );
      assert.equal(evilOrigin.status, 403);
      assert.equal(evilOrigin.body.code, 'ORIGIN_DENIED');

      // Valid CSRF + same-origin succeeds
      const valid = await rawReq(
        '/api/settings',
        { method: 'PUT', body: JSON.stringify({ updates: { default_grace_minutes: '10' } }) },
        adminJar
      );
      assert.equal(valid.status, 200);
    });

    // -------------------------------------------------------------------------
    // TEST 8: Session Fixation Prevention
    // -------------------------------------------------------------------------
    await test('Session fixation defense: login revokes any pre-existing session cookie and issues a brand-new sid', async () => {
      const priorLogin = await loginAs(INITIAL_ADMIN_USER, ROTATED_ADMIN_PW);
      assert.equal(priorLogin.status, 200);

      // Re-login while sending the pre-existing session cookie
      const freshLogin = await rawReq('/api/auth/login', {
        method: 'POST',
        headers: { Cookie: priorLogin.jar.sessionCookie },
        body: JSON.stringify({ identifier: INITIAL_ADMIN_USER, password: ROTATED_ADMIN_PW }),
      });
      assert.equal(freshLogin.status, 200);
      const freshCookie = extractSessionCookie(freshLogin.setCookies);
      assert.notEqual(freshCookie, priorLogin.jar.sessionCookie);

      // Pre-existing cookie MUST now be rejected (revoked server-side)
      const replayPrior = await rawReq('/api/auth/me', {}, priorLogin.jar);
      assert.equal(replayPrior.status, 401);

      // Fresh cookie works
      const freshJar: SessionJar = {
        sessionCookie: freshCookie,
        csrfToken: String(freshLogin.body.csrfToken),
        rawCookies: freshLogin.setCookies,
      };
      const checkFresh = await rawReq('/api/auth/me', {}, freshJar);
      assert.equal(checkFresh.status, 200);
    });

    // -------------------------------------------------------------------------
    // TEST 9: Password Change Revokes All Other Concurrent Sessions
    // -------------------------------------------------------------------------
    await test('Password change invalidates all prior sessions across devices and rotates current session', async () => {
      const sessA = await loginAs(INITIAL_ADMIN_USER, ROTATED_ADMIN_PW);
      const sessB = await loginAs(INITIAL_ADMIN_USER, ROTATED_ADMIN_PW);
      assert.equal(sessA.status, 200);
      assert.equal(sessB.status, 200);

      const changed = await rawReq(
        '/api/auth/change-password',
        {
          method: 'POST',
          body: JSON.stringify({ currentPassword: ROTATED_ADMIN_PW, newPassword: SECOND_ROTATED_PW }),
        },
        sessA.jar
      );
      assert.equal(changed.status, 200);

      // Old session A, old session B, and older adminJar must all be revoked (401)
      assert.equal((await rawReq('/api/auth/me', {}, sessA.jar)).status, 401);
      assert.equal((await rawReq('/api/auth/me', {}, sessB.jar)).status, 401);
      assert.equal((await rawReq('/api/auth/me', {}, adminJar)).status, 401);

      // Newly issued rotated session works
      adminJar = {
        sessionCookie: extractSessionCookie(changed.setCookies),
        csrfToken: String(changed.body.csrfToken),
        rawCookies: changed.setCookies,
      };
      assert.equal((await rawReq('/api/auth/me', {}, adminJar)).status, 200);
    });

    // -------------------------------------------------------------------------
    // TEST 10: Logout Server-Side Revocation
    // -------------------------------------------------------------------------
    await test('Logout revokes session server-side so replaying the old cookie returns 401', async () => {
      const tempLogin = await loginAs(INITIAL_ADMIN_USER, SECOND_ROTATED_PW);
      assert.equal(tempLogin.status, 200);

      const out = await rawReq('/api/auth/logout', { method: 'POST' }, tempLogin.jar);
      assert.equal(out.status, 200);

      const replay = await rawReq('/api/auth/me', {}, tempLogin.jar);
      assert.equal(replay.status, 401);
    });

    // -------------------------------------------------------------------------
    // TEST 11: Session Expiry Enforcement
    // -------------------------------------------------------------------------
    await test('Expired server session is rejected with 401', async () => {
      const expLogin = await loginAs(INITIAL_ADMIN_USER, SECOND_ROTATED_PW);
      assert.equal(expLogin.status, 200);

      const encodedVal = expLogin.jar.sessionCookie.split('=')[1];
      const sid = decodeURIComponent(encodedVal).split('.')[0];
      db.prepare('UPDATE user_sessions SET expires_at = ? WHERE sid = ?').run(Date.now() - 5000, sid);

      const afterExp = await rawReq('/api/auth/me', {}, expLogin.jar);
      assert.equal(afterExp.status, 401);
    });

    // -------------------------------------------------------------------------
    // TEST 12: Zero-Downtime Secret Rotation (SESSION_SECRET_PREVIOUS)
    // -------------------------------------------------------------------------
    await test('SESSION_SECRET_PREVIOUS seamlessly verifies and re-signs sessions during key rotation', async () => {
      const oldSignedLogin = await loginAs(INITIAL_ADMIN_USER, SECOND_ROTATED_PW);
      assert.equal(oldSignedLogin.status, 200);

      // Rotate to new secret while retaining previous secret
      process.env.SESSION_SECRET = ROTATED_SECRET;
      process.env.SESSION_SECRET_PREVIOUS = INITIAL_SECRET;

      const meDuringRotation = await rawReq('/api/auth/me', {}, oldSignedLogin.jar);
      assert.equal(meDuringRotation.status, 200);
      const resignedCookie = extractSessionCookie(meDuringRotation.setCookies);
      assert.ok(resignedCookie && resignedCookie !== oldSignedLogin.jar.sessionCookie, 'Expected seamless re-signed cookie');

      // Remove previous secret (rotation window closed)
      delete process.env.SESSION_SECRET_PREVIOUS;

      // Unrotated old cookie fails with 401
      assert.equal((await rawReq('/api/auth/me', {}, oldSignedLogin.jar)).status, 401);

      // Re-signed cookie continues working seamlessly
      const resignedJar: SessionJar = {
        sessionCookie: resignedCookie,
        csrfToken: oldSignedLogin.jar.csrfToken,
        rawCookies: meDuringRotation.setCookies,
      };
      assert.equal((await rawReq('/api/auth/me', {}, resignedJar)).status, 200);

      // Re-authenticate adminJar under the new primary secret for subsequent tests
      const refreshedAdmin = await loginAs(INITIAL_ADMIN_USER, SECOND_ROTATED_PW);
      assert.equal(refreshedAdmin.status, 200);
      adminJar = refreshedAdmin.jar;
    });

    // -------------------------------------------------------------------------
    // TEST 13: Full Role-Per-Route 403 RBAC Matrix (All 6 Roles)
    // -------------------------------------------------------------------------
    await test('Server-side RBAC 403 matrix enforces strict authorization across all 6 roles', async () => {
      const depts = (await rawReq('/api/departments', {}, adminJar)).body.data as Array<{ id: number; code: string }>;
      const emps = (await rawReq('/api/employees?limit=50', {}, adminJar)).body.data as Array<{
        id: number;
        department_id: number;
      }>;
      const dept1Id = depts[0].id;
      const dept2Id = depts[1].id;
      const empInDept1 = emps.find((e) => e.department_id === dept1Id) || emps[0];
      const empInDept2 = emps.find((e) => e.department_id === dept2Id) || emps[1];

      const rolePw = 'RoleMatrix!2026#Aa';
      const createUser = async (payload: Record<string, unknown>) => {
        const r = await rawReq(
          '/api/users',
          { method: 'POST', body: JSON.stringify({ ...payload, password: rolePw, must_change_password: false }) },
          adminJar
        );
        assert.equal(r.status, 201, `Failed creating test user ${String(payload.username)}: ${JSON.stringify(r.body)}`);
      };

      await createUser({ username: 'hr_user', email: 'hr@rsucaj.edu.ph', full_name: 'HR Officer Test', role: 'HR Officer' });
      await createUser({ username: 'pay_user', email: 'pay@rsucaj.edu.ph', full_name: 'Payroll Officer Test', role: 'Payroll Officer' });
      await createUser({
        username: 'head_user',
        email: 'head@rsucaj.edu.ph',
        full_name: 'Dept Head Test',
        role: 'Department Head',
        department_id: dept1Id,
      });
      await createUser({
        username: 'emp_user',
        email: 'emp@rsucaj.edu.ph',
        full_name: 'Employee Self Test',
        role: 'Employee',
        department_id: empInDept1.department_id,
        employee_id: empInDept1.id,
      });

      const hrJar = (await loginAs('hr_user', rolePw)).jar;
      const payJar = (await loginAs('pay_user', rolePw)).jar;
      const headJar = (await loginAs('head_user', rolePw)).jar;
      const empJar = (await loginAs('emp_user', rolePw)).jar;

      // --- HR Officer ---
      assert.equal((await rawReq('/api/employees', {}, hrJar)).status, 200);
      assert.equal((await rawReq('/api/reports/attendance', {}, hrJar)).status, 200);
      assert.equal((await rawReq('/api/payroll', {}, hrJar)).status, 403);
      assert.equal((await rawReq('/api/payroll/compute', { method: 'POST', body: JSON.stringify({}) }, hrJar)).status, 403);
      assert.equal((await rawReq('/api/settings', {}, hrJar)).status, 403);
      assert.equal((await rawReq('/api/devices', {}, hrJar)).status, 403);
      assert.equal((await rawReq('/api/users', {}, hrJar)).status, 403);
      assert.equal((await rawReq('/api/backup/export', {}, hrJar)).status, 403);
      assert.equal((await rawReq('/api/audit-logs', {}, hrJar)).status, 403);
      assert.equal((await rawReq('/api/reports/payroll', {}, hrJar)).status, 403);

      // --- Payroll Officer ---
      assert.equal((await rawReq('/api/payroll', {}, payJar)).status, 200);
      assert.equal((await rawReq('/api/reports/payroll', {}, payJar)).status, 200);
      assert.equal((await rawReq('/api/employees', {}, payJar)).status, 200);
      assert.equal((await rawReq('/api/employees', { method: 'POST', body: JSON.stringify({}) }, payJar)).status, 403);
      assert.equal((await rawReq('/api/corrections/1/status', { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, payJar)).status, 403);
      assert.equal((await rawReq('/api/leaves/1/status', { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, payJar)).status, 403);
      assert.equal((await rawReq('/api/devices', {}, payJar)).status, 403);
      assert.equal((await rawReq('/api/settings', {}, payJar)).status, 403);
      assert.equal((await rawReq('/api/users', {}, payJar)).status, 403);
      assert.equal((await rawReq('/api/backup/export', {}, payJar)).status, 403);

      // --- Department Head (scoped to dept1Id) ---
      assert.equal((await rawReq('/api/dashboard', {}, headJar)).status, 200);
      assert.equal((await rawReq('/api/payroll', {}, headJar)).status, 403);
      assert.equal((await rawReq('/api/settings', {}, headJar)).status, 403);
      assert.equal((await rawReq('/api/devices', {}, headJar)).status, 403);
      assert.equal((await rawReq('/api/users', {}, headJar)).status, 403);
      assert.equal((await rawReq('/api/backup/export', {}, headJar)).status, 403);
      assert.equal((await rawReq('/api/employees', { method: 'POST', body: JSON.stringify({}) }, headJar)).status, 403);

      // Create correction for dept2 employee as Admin -> Department Head of dept1 MUST get 403 approving it
      const dept2Corr = await rawReq(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empInDept2.id,
            attendance_date: '2026-02-11',
            request_type: 'Time In',
            requested_time: '08:00 AM',
            reason: 'Cross-department scope check',
          }),
        },
        adminJar
      );
      assert.equal(dept2Corr.status, 201);
      const crossDeptApprove = await rawReq(
        `/api/corrections/${dept2Corr.body.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) },
        headJar
      );
      assert.equal(crossDeptApprove.status, 403);

      // --- Employee (self-service scoped to empInDept1.id) ---
      assert.equal((await rawReq('/api/attendance', {}, empJar)).status, 200);
      assert.equal((await rawReq('/api/corrections', {}, empJar)).status, 200);
      assert.equal((await rawReq('/api/leaves', {}, empJar)).status, 200);
      // Self correction creation allowed
      const selfCorr = await rawReq(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empInDept1.id,
            attendance_date: '2026-02-12',
            request_type: 'Time Out',
            requested_time: '05:00 PM',
            reason: 'Self correction test',
          }),
        },
        empJar
      );
      assert.equal(selfCorr.status, 201);
      // Submitting correction for another employee denied (403)
      const otherCorr = await rawReq(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empInDept2.id,
            attendance_date: '2026-02-12',
            request_type: 'Time Out',
            requested_time: '05:00 PM',
            reason: 'Spoofed other employee',
          }),
        },
        empJar
      );
      assert.equal(otherCorr.status, 403);
      // Approving own correction denied (403)
      assert.equal(
        (await rawReq(`/api/corrections/${selfCorr.body.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, empJar)).status,
        403
      );
      // Admin modules denied (403)
      for (const forbiddenForEmp of [
        '/api/dashboard',
        '/api/employees',
        '/api/payroll',
        '/api/settings',
        '/api/devices',
        '/api/users',
        '/api/audit-logs',
        '/api/backup/export',
        '/api/reports/payroll',
      ]) {
        assert.equal((await rawReq(forbiddenForEmp, {}, empJar)).status, 403, `Employee should get 403 on ${forbiddenForEmp}`);
      }

      // --- Kiosk Device (x-kiosk-token cannot access admin APIs; GET /api/devices masks raw tokens) ---
      const devs = (await rawReq('/api/devices', {}, adminJar)).body.data as Array<{ id: number; api_token?: string; token_masked?: string }>;
      assert.equal('api_token' in devs[0], false, 'GET /api/devices must not expose raw api_token');
      const rotTok = await rawReq(`/api/devices/${devs[0].id}/rotate-token`, { method: 'POST', body: JSON.stringify({}) }, adminJar);
      assert.equal(rotTok.status, 200);
      const kioskToken = String(rotTok.body.api_token);
      assert.equal((await rawReq('/api/employees', { headers: { 'x-kiosk-token': kioskToken } })).status, 401);
      assert.equal((await rawReq('/api/payroll', { headers: { 'x-kiosk-token': kioskToken } })).status, 401);
      assert.equal((await rawReq('/api/settings', { headers: { 'x-kiosk-token': kioskToken } })).status, 401);
    });

    // -------------------------------------------------------------------------
    // TEST 14: Functional Regression Suite (Preserved BUILD 01–04 Workflows)
    // -------------------------------------------------------------------------
    await test('Dashboard aggregates live KPIs without leaking kiosk API tokens', async () => {
      const r = await rawReq('/api/dashboard?range=week', {}, adminJar);
      assert.equal(r.status, 200);
      const kpis = r.body.kpis as { totalEmployees: number; totalDevices: number };
      assert.ok(kpis.totalEmployees >= 18);
      assert.equal(kpis.totalDevices, 2);
      assert.equal((r.body.weeklyTrend as unknown[]).length, 7);
      const devices = r.body.devices as Array<Record<string, unknown>>;
      for (const d of devices) {
        assert.equal('api_token' in d, false, 'Dashboard device summary must not expose api_token');
      }
    });

    await test('Employees CRUD and CSV bulk import persist in SQLite', async () => {
      const depts = await rawReq('/api/departments', {}, adminJar);
      const positions = await rawReq('/api/positions', {}, adminJar);
      const shifts = await rawReq('/api/shifts', {}, adminJar);
      const deptId = (depts.body.data as Array<{ id: number }>)[0].id;
      const posId = (positions.body.data as Array<{ id: number }>)[0].id;
      const shiftId = (shifts.body.data as Array<{ id: number }>)[0].id;

      const created = await rawReq(
        '/api/employees',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_code: 'EMP-TEST-901',
            full_name: 'Test, Faculty M.',
            email: 'test.faculty@rsucaj.edu.ph',
            department_id: deptId,
            position_id: posId,
            shift_id: shiftId,
            status: 'Active',
            monthly_salary: 35000,
            monthly_allowance: 2500,
          }),
        },
        adminJar
      );
      assert.equal(created.status, 201);
      const empId = created.body.id as number;

      const updated = await rawReq(
        `/api/employees/${empId}`,
        {
          method: 'PUT',
          body: JSON.stringify({
            employee_code: 'EMP-TEST-901',
            full_name: 'Test, Faculty Updated',
            email: 'test.faculty@rsucaj.edu.ph',
            department_id: deptId,
            position_id: posId,
            shift_id: shiftId,
            status: 'Active',
            monthly_salary: 36000,
            monthly_allowance: 2500,
          }),
        },
        adminJar
      );
      assert.equal(updated.status, 200);

      const imported = await rawReq(
        '/api/employees/import',
        {
          method: 'POST',
          body: JSON.stringify({
            rows: [
              {
                employee_code: 'EMP-CSV-902',
                full_name: 'Imported, Staff A.',
                email: 'imported@rsucaj.edu.ph',
                department_code: 'BSIT',
                position_code: 'INST',
                status: 'Active',
              },
            ],
          }),
        },
        adminJar
      );
      assert.equal(imported.status, 200);
      assert.equal(imported.body.inserted, 1);

      const del = await rawReq(`/api/employees/${empId}`, { method: 'DELETE' }, adminJar);
      assert.equal(del.status, 200);
    });

    await test('Correction approval atomically updates Attendance Records in SQLite', async () => {
      const emps = await rawReq('/api/employees?limit=5', {}, adminJar);
      const emp = (emps.body.data as Array<{ id: number }>)[0];
      const testDate = '2026-01-15';

      const created = await rawReq(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: emp.id,
            attendance_date: testDate,
            request_type: 'Time In',
            requested_time: '07:55 AM',
            reason: 'Integration test verification',
          }),
        },
        adminJar
      );
      assert.equal(created.status, 201);

      const approved = await rawReq(
        `/api/corrections/${created.body.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) },
        adminJar
      );
      assert.equal(approved.status, 200);

      const att = await rawReq(`/api/attendance?date=${testDate}`, {}, adminJar);
      const rows = att.body.data as Array<{ employee_id: number; time_in: string; time_out: string | null; status: string }>;
      const matched = rows.find((r) => r.employee_id === emp.id);
      assert.ok(matched);
      assert.equal(matched.time_in, '07:55 AM');
      // BUILD 11: NEVER fabricate a 05:00 PM Time Out counterpart; lone Time In on past date is Missing Time Out
      assert.equal(matched.time_out, null);
      assert.equal(matched.status, 'Missing Time Out');
    });

    await test('Leave application, approval, and leave balance deduction workflow', async () => {
      const emps = await rawReq('/api/employees?limit=5', {}, adminJar);
      const emp = (emps.body.data as Array<{ id: number }>)[1];

      const created = await rawReq(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: emp.id,
            leave_type: 'Sick Leave',
            start_date: '2026-03-10',
            end_date: '2026-03-12',
            reason: 'Medical recovery',
            document_reference: 'MED-CERT-2026-001',
          }),
        },
        adminJar
      );
      assert.equal(created.status, 201);

      const approved = await rawReq(
        `/api/leaves/${created.body.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) },
        adminJar
      );
      assert.equal(approved.status, 200);

      const leavesRes = await rawReq('/api/leaves?year=2026', {}, adminJar);
      const balances = leavesRes.body.balances as Array<{ sl_used: number; sl_remaining: number }>;
      assert.ok(balances.some((b) => b.sl_used >= 3 && b.sl_remaining <= 12));
    });

    await test('Payroll governance workflow enforces Policy -> Compute -> Finalize (maker-checker) -> Finance Sign-Off -> Release', async () => {
      const payMakerJar = (await loginAs('pay_user', 'RoleMatrix!2026#Aa')).jar;

      const createdPolicy = await rawReq(
        '/api/payroll/policies',
        {
          method: 'POST',
          body: JSON.stringify({
            policy_code: 'QA-POL-2026',
            policy_name: 'QA Approved Institutional Policy 2026',
            effective_from: '2026-01-01',
            notes: 'QA integration test policy',
            rules: {
              payFrequency: 'MONTHLY',
              standardWorkHoursPerDay: 8,
              prorationBasis: 'SCHEDULED_WORKING_DAYS_IN_MONTH',
              fixedWorkingDaysPerMonth: null,
              allowanceProrationMode: 'PRORATE_BY_SCHEDULED_DAYS',
              employeeTypes: {
                Regular: {
                  payBasis: 'MONTHLY',
                  overtimeEligible: true,
                  holidayPayEligible: true,
                  statutoryEligible: true,
                  taxEligible: true,
                  paidLeaveEligible: true,
                  allowanceEligible: true,
                },
                Contractual: {
                  payBasis: 'MONTHLY',
                  overtimeEligible: true,
                  holidayPayEligible: true,
                  statutoryEligible: true,
                  taxEligible: true,
                  paidLeaveEligible: false,
                  allowanceEligible: true,
                },
                'Part-Time': {
                  payBasis: 'MONTHLY',
                  overtimeEligible: false,
                  holidayPayEligible: false,
                  statutoryEligible: false,
                  taxEligible: true,
                  paidLeaveEligible: false,
                  allowanceEligible: false,
                },
              },
              tardiness: {
                enabled: true,
                roundingIncrementMinutes: 1,
                rateMultiplier: 1.0,
              },
              undertime: {
                enabled: true,
                roundingIncrementMinutes: 1,
                rateMultiplier: 1.0,
              },
              absences: {
                deductPerDayMultiplier: 1.0,
                deductMissingRecordAsAbsent: false,
              },
              leaves: {
                paidLeaveRateMultiplier: 1.0,
                unpaidLeaveDeductionMultiplier: 1.0,
              },
              overtime: {
                enabled: true,
                minimumOvertimeMinutes: 30,
                ordinaryDayMultiplier: 1.25,
                restDayMultiplier: 1.3,
                specialHolidayMultiplier: 1.3,
                regularHolidayMultiplier: 2.0,
              },
              holidaysAndRestDays: {
                regularHolidayWorkedPremiumMultiplier: 1.0,
                specialHolidayUnworkedPaid: false,
                specialHolidayWorkedPremiumMultiplier: 0.3,
                restDayWorkedMultiplier: 1.3,
              },
              statutoryContributions: [],
              withholdingTax: {
                enabled: false,
                taxExemptAllowances: true,
                brackets: [],
              },
              rounding: {
                currencyDecimals: 2,
                mode: 'HALF_UP',
              },
              specialExceptions: [],
            },
          }),
        },
        payMakerJar
      );
      assert.equal(createdPolicy.status, 201, `Policy creation failed: ${JSON.stringify(createdPolicy.body)}`);
      const policyId = (createdPolicy.body.policy as { id: number }).id;

      const approvedPolicy = await rawReq(
        `/api/payroll/policies/${policyId}/finance-approve`,
        {
          method: 'POST',
          body: JSON.stringify({
            approval_reference: 'FIN-QA-2026-001',
            notes: 'QA integration policy sign-off',
          }),
        },
        adminJar
      );
      assert.equal(approvedPolicy.status, 200, `Policy Finance approval failed: ${JSON.stringify(approvedPolicy.body)}`);

      // January 2026 has an unresolved Missing Time Out from the earlier unpaired correction test -> must block with 409
      const janBlocked = await rawReq(
        '/api/payroll/compute',
        {
          method: 'POST',
          body: JSON.stringify({
            period_label: 'Jan 2026 Blocked Check',
            start_date: '2026-01-01',
            end_date: '2026-01-31',
            policy_id: policyId,
          }),
        },
        payMakerJar
      );
      assert.equal(janBlocked.status, 409);
      assert.equal(janBlocked.body.code, 'UNRESOLVED_MISSING_PUNCHES');

      // Clean period 2026-03-01 to 2026-03-31 computes cleanly
      const computed = await rawReq(
        '/api/payroll/compute',
        {
          method: 'POST',
          body: JSON.stringify({
            period_label: 'QA Test Payroll Period (Mar 2026)',
            start_date: '2026-03-01',
            end_date: '2026-03-31',
            policy_id: policyId,
          }),
        },
        payMakerJar
      );
      assert.equal(computed.status, 201, `Payroll compute failed: ${JSON.stringify(computed.body)}`);
      const runId = computed.body.id as number;

      // Premature release before finalize must be rejected (409)
      assert.equal((await rawReq(`/api/payroll/${runId}/release`, { method: 'PATCH' }, adminJar)).status, 409);
      // Maker attempting to finalize own computed run must be denied (403)
      assert.equal((await rawReq(`/api/payroll/${runId}/finalize`, { method: 'PATCH' }, payMakerJar)).status, 403);
      // Independent checker finalizes run
      assert.equal((await rawReq(`/api/payroll/${runId}/finalize`, { method: 'PATCH' }, adminJar)).status, 200);
      // Release before Finance sign-off must be blocked (409)
      assert.equal((await rawReq(`/api/payroll/${runId}/release`, { method: 'PATCH' }, adminJar)).status, 409);
      // Independent Finance sign-off
      const finSignoff = await rawReq(
        `/api/payroll/${runId}/finance-signoff`,
        {
          method: 'POST',
          body: JSON.stringify({
            finance_signoff_ref: 'FIN-RUN-QA-001',
            notes: 'QA verified payroll totals',
          }),
        },
        adminJar
      );
      assert.equal(finSignoff.status, 200, `Finance signoff failed: ${JSON.stringify(finSignoff.body)}`);
      // Release after Finalize + Finance sign-off succeeds
      assert.equal((await rawReq(`/api/payroll/${runId}/release`, { method: 'PATCH' }, adminJar)).status, 200);
    });

    await test('All 6 Reports, pagination, kiosk punch, settings, backup export, and audit trail work end-to-end', async () => {
      for (const type of ['attendance', 'dtr', 'leaves', 'payroll', 'employees', 'audit-logs']) {
        const r = await rawReq(`/api/reports/${type}`, {}, adminJar);
        assert.equal(r.status, 200, `Report ${type} failed`);
        assert.ok(Array.isArray(r.body.rows));
      }

      // Kiosk token auth
      assert.equal((await rawReq('/api/kiosk/heartbeat', { method: 'POST' })).status, 401);
      assert.equal(
        (await rawReq('/api/kiosk/heartbeat', { method: 'POST', headers: { 'x-kiosk-token': 'bad_token' } })).status,
        403
      );

      const devs = (await rawReq('/api/devices', {}, adminJar)).body.data as Array<{ id: number }>;
      const rot = await rawReq(`/api/devices/${devs[0].id}/rotate-token`, { method: 'POST', body: JSON.stringify({}) }, adminJar);
      assert.equal(rot.status, 200);
      const qaKioskToken = String(rot.body.api_token);
      const hb = await rawReq('/api/kiosk/heartbeat', {
        method: 'POST',
        headers: { 'x-kiosk-token': qaKioskToken },
      });
      assert.equal(hb.status, 200);

      const eventUid = 'kiosk-evt-qa-001';
      const punch = await rawReq('/api/kiosk/punch', {
        method: 'POST',
        headers: { 'x-kiosk-token': qaKioskToken },
        body: JSON.stringify({
          employee_code: 'EMP-CSV-902',
          punch_type: 'TIME_IN',
          event_uid: eventUid,
        }),
      });
      assert.equal(punch.status, 201);
      assert.equal(punch.body.action, 'TIME_IN');
      assert.equal(punch.body.event_uid, eventUid);

      // Replaying the exact same kiosk event_uid must be idempotent (duplicate_ignored)
      const replayPunch = await rawReq('/api/kiosk/punch', {
        method: 'POST',
        headers: { 'x-kiosk-token': qaKioskToken },
        body: JSON.stringify({
          employee_code: 'EMP-CSV-902',
          punch_type: 'TIME_IN',
          event_uid: eventUid,
        }),
      });
      assert.equal(replayPunch.status, 200);
      assert.equal(replayPunch.body.action, 'duplicate_ignored');

      // Online SQLite backup, restore drill, WAL checkpoint, and JSON export
      const bStatus = await rawReq('/api/backup/status', {}, adminJar);
      assert.equal(bStatus.status, 200);
      assert.equal((bStatus.body.database as { schemaVersion: string }).schemaVersion, '009');

      const bSnap = await rawReq('/api/backup/snapshot', { method: 'POST', body: JSON.stringify({}) }, adminJar);
      assert.equal(bSnap.status, 201);
      assert.equal(bSnap.body.success, true);

      const bDrill = await rawReq('/api/backup/verify-drill', { method: 'POST', body: JSON.stringify({}) }, adminJar);
      assert.equal(bDrill.status, 200);
      assert.equal(bDrill.body.success, true);

      const bCp = await rawReq('/api/backup/checkpoint', { method: 'POST', body: JSON.stringify({}) }, adminJar);
      assert.equal(bCp.status, 200);
      assert.equal(bCp.body.success, true);

      const backup = await rawReq('/api/backup/export', {}, adminJar);
      assert.equal(backup.status, 200);
      assert.equal(backup.body.version, '1.13.0');
      assert.ok(backup.body.tables);

      const audits = await rawReq('/api/audit-logs?page=1&limit=5', {}, adminJar);
      assert.equal(audits.status, 200);
      assert.ok(typeof audits.body.total === 'number' && (audits.body.total as number) >= 10);
    });

    // -------------------------------------------------------------------------
    // TEST 15: Legacy BUILD 03/04 Admin Account Migration & Operator Recovery Path
    // -------------------------------------------------------------------------
    await test('Existing legacy admin DB migrates non-destructively and supports recoverAdminAccount()', async () => {
      const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-b05-migrate-'));
      const legacyDbPath = path.join(tmpDir, 'legacy.db');
      try {
        // Construct a pre-BUILD-05 SQLite database with legacy users table and existing records
        const legacy = new Database(legacyDbPath);
        const { hash, salt } = hashPassword('LegacyCampus!2024');
        legacy.exec(`
          CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            full_name TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'Administrator',
            password_hash TEXT NOT NULL,
            salt TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
          );
          CREATE TABLE departments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            head_name TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
          );
          INSERT INTO departments (code, name, head_name) VALUES ('BSIT', 'BS Information Technology', 'Dr. Legacy');
        `);
        legacy
          .prepare(
            `INSERT INTO users (username, email, full_name, role, password_hash, salt)
             VALUES ('admin', 'admin@rsucaj.edu.ph', 'Existing Campus Admin', 'Administrator', ?, ?)`
          )
          .run(hash, salt);
        legacy.close();

        // Remove ADMIN_INITIAL_* env vars to prove existing DB does NOT require re-bootstrap
        delete process.env.ADMIN_INITIAL_USERNAME;
        delete process.env.ADMIN_INITIAL_EMAIL;
        delete process.env.ADMIN_INITIAL_PASSWORD;

        const migrated = initDatabase(legacyDbPath, { seedDemoData: false });
        const existingUser = migrated.prepare('SELECT * FROM users WHERE username = ?').get('admin') as {
          id: number;
          full_name: string;
          is_active: number;
          must_change_password: number;
        };
        assert.equal(existingUser.full_name, 'Existing Campus Admin');
        assert.equal(existingUser.is_active, 1);

        const deptCount = (migrated.prepare('SELECT COUNT(*) as c FROM departments').get() as { c: number }).c;
        assert.equal(deptCount, 1, 'Existing department data must be preserved');

        const roleCount = (migrated.prepare('SELECT COUNT(*) as c FROM roles').get() as { c: number }).c;
        assert.equal(roleCount, 6, 'RBAC roles must be seeded by migration 002');

        // Exercise operator recovery path
        const recovered = recoverAdminAccount(migrated, 'admin', 'Recovered!Campus2026#', {
          requireChangeOnNextLogin: true,
        });
        assert.equal(recovered.username, 'admin');
        const afterRecover = migrated.prepare('SELECT must_change_password FROM users WHERE username = ?').get('admin') as {
          must_change_password: number;
        };
        assert.equal(afterRecover.must_change_password, 1);

        migrated.close();
      } finally {
        fs.rmSync(tmpDir, { recursive: true, force: true });
      }
    });
  } finally {
    server.close();
    db.close();
    fs.rmSync(apiBackupTmpDir, { recursive: true, force: true });
  }

  const passed = results.filter((r) => r.passed).length;
  const failed = results.filter((r) => !r.passed).length;
  console.log(`\nSummary: ${passed}/${results.length} passed, ${failed} failed.`);
  if (failed > 0) process.exit(1);
}

runTests().catch((err) => {
  console.error('Test runner crashed:', err);
  process.exit(1);
});
