/**
 * SAVAGE-RSUCAJ Employee Portal — Automated Playwright Browser E2E & Responsive Verification
 * Walks all 18 Employee Portal screens in headless Chromium against the real built production bundle
 * and verifies zero console/page errors, official shield logo rendering, zero horizontal overflow
 * across 360x800, 393x852, 412x915, 768x1024, and 1440x900, and real interactive workflows.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import { chromium } from 'playwright-core';
import { initDatabase, closeDatabaseSafely } from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import { RealtimeHub } from '../server/realtimeHub.ts';
import { hashPassword } from '../server/auth.ts';

function findBrowserExecutable() {
  const candidates = [
    process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,
    '/ms-playwright/chromium_headless_shell-1247/chrome-headless-shell-linux64/chrome-headless-shell',
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    '/usr/bin/google-chrome',
  ].filter(Boolean);
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

test('All 18 Employee Portal screens render cleanly and function end-to-end across mobile, tablet, and desktop viewports', async (t) => {
  const execPath = findBrowserExecutable();
  if (!execPath) {
    t.skip('No local Chromium executable available in container');
    return;
  }

  const distDir = path.resolve(process.cwd(), 'dist');
  assert.ok(fs.existsSync(path.join(distDir, 'index.html')), 'dist/index.html must exist (run vite build first)');

  const prevSecret = process.env.SESSION_SECRET;
  process.env.SESSION_SECRET = crypto.randomBytes(48).toString('hex');

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-emp18-e2e-'));
  const dbPath = path.join(tmpDir, 'e2e.db');
  const adminPass = `Admin!${crypto.randomBytes(8).toString('hex')}9A`;
  const empPass = `EmpTest!${crypto.randomBytes(8).toString('hex')}7Z`;

  const db = initDatabase(dbPath, {
    mode: 'development',
    seedDemoData: false,
    initialAdmin: {
      username: 'sysadmin',
      email: 'sysadmin@rsucaj.edu.ph',
      password: adminPass,
    },
  });

  const deptId = Number(
    db.prepare(`INSERT INTO departments (code, name, head_name) VALUES ('ICT', 'ICT Office', 'ICT Head')`).run().lastInsertRowid
  );
  const posId = Number(
    db.prepare(`INSERT INTO positions (code, name, type, base_salary, allowance) VALUES ('ITS', 'IT Staff', 'Regular', 22000, 3000)`).run().lastInsertRowid
  );
  const shiftId = Number(
    db.prepare(`INSERT INTO shifts (name, time_in, time_out, grace_minutes, rest_days, status) VALUES ('Regular Day', '08:00', '17:00', 15, 'Saturday,Sunday', 'Active')`).run().lastInsertRowid
  );
  const empId = Number(
    db.prepare(
      `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status, hired_date, monthly_salary, monthly_allowance)
       VALUES ('RSU-0001', 'Juan Dela Cruz', 'juan.delacruz@rsucaj.edu.ph', ?, ?, ?, 'Active', '2024-01-15', 22000, 3000)`
    ).run(deptId, posId, shiftId).lastInsertRowid
  );
  const hashed = hashPassword(empPass);
  db.prepare(
    `INSERT INTO users (username, email, full_name, password_hash, salt, role, department_id, employee_id, must_change_password, is_active)
     VALUES ('jdelacruz', 'juan.delacruz@rsucaj.edu.ph', 'Juan Dela Cruz', ?, ?, 'Employee', ?, ?, 0, 1)`
  ).run(hashed.hash, hashed.salt, deptId, empId);

  db.prepare(`INSERT INTO holidays (date, name, type) VALUES ('2026-11-30', 'Bonifacio Day', 'Regular')`).run();
  db.prepare(
    `INSERT INTO attendance_records (employee_id, date, time_in, time_out, work_hours, status, device_name, remarks)
     VALUES (?, '2026-11-18', '08:02', '17:05', '8h 03m', 'Present', 'Campus Main Kiosk', 'Face verified')`
  ).run(empId);

  const runId = Number(
    db.prepare(
      `INSERT INTO payroll_runs (period_label, start_date, end_date, status, total_basic_pay, total_allowances, total_deductions, total_net_pay, employee_count, created_by)
       VALUES ('November 2026', '2026-11-01', '2026-11-30', 'Computed', 22000, 3000, 1570, 23430, 1, 'sysadmin')`
    ).run().lastInsertRowid
  );
  db.prepare(
    `INSERT INTO payroll_items (payroll_run_id, employee_id, days_present, days_late, days_absent, basic_pay, allowances, deductions, net_pay, prorated_basic_pay, gross_pay, tax_deduction, other_deductions)
     VALUES (?, ?, 20, 0, 0, 22000, 3000, 1570, 23430, 22000, 25000, 1500, 70)`
  ).run(runId, empId);
  db.prepare(`UPDATE payroll_runs SET status = 'Released', released_at = datetime('now') WHERE id = ?`).run(runId);

  const realtimeHub = new RealtimeHub();
  const app = express();
  app.use('/api', createApiRouter(db, { realtimeHub, dbPath }));
  app.use(express.static(distDir));
  app.use((req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(path.join(distDir, 'index.html'));
  });

  const server = await new Promise((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const addr = server.address();
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  const browser = await chromium.launch({
    executablePath: execPath,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });

  const pageErrors = [];

  try {
    const context = await browser.newContext({ viewport: { width: 393, height: 852 } });
    const page = await context.newPage();
    page.on('pageerror', (err) => pageErrors.push(err.message));

    const assertNoOverflow = async (label) => {
      const metrics = await page.evaluate(() => ({
        scrollWidth: document.documentElement.scrollWidth,
        innerWidth: window.innerWidth,
        brokenImgs: Array.from(document.querySelectorAll('img')).filter(
          (img) => !img.complete || img.naturalWidth === 0
        ).length,
      }));
      assert.ok(
        metrics.scrollWidth <= metrics.innerWidth + 1,
        `Horizontal overflow on ${label}: scrollWidth=${metrics.scrollWidth} > innerWidth=${metrics.innerWidth}`
      );
      assert.equal(metrics.brokenImgs, 0, `Broken image detected on ${label}`);
    };

    // Screen 01 -> Screen 02 (Onboarding 1)
    await page.goto(`${baseUrl}/employee`, { waitUntil: 'networkidle' });
    await page.getByRole('heading', { name: 'Face Attendance' }).waitFor({ timeout: 8000 });
    await assertNoOverflow('Screen 02 Onboarding 1');

    // Screen 03 (Onboarding 2)
    await page.getByRole('button', { name: 'Next' }).click();
    await page.getByRole('heading', { name: 'Track Your Records' }).waitFor();
    await assertNoOverflow('Screen 03 Onboarding 2');

    // Screen 04 (Onboarding 3)
    await page.getByRole('button', { name: 'Next' }).click();
    await page.getByRole('heading', { name: 'Secure & Reliable' }).waitFor();
    await assertNoOverflow('Screen 04 Onboarding 3');

    // Screen 05 (Employee Login)
    await page.getByRole('button', { name: 'Get Started' }).click();
    await page.getByPlaceholder('Employee ID').waitFor();
    await assertNoOverflow('Screen 05 Employee Login');

    // Test password visibility toggle + Employee ID login
    await page.getByPlaceholder('Employee ID').fill('RSU-0001');
    await page.getByPlaceholder('Password').fill(empPass);
    await page.getByRole('button', { name: 'Show password' }).click();
    assert.equal(await page.getByPlaceholder('Password').getAttribute('type'), 'text');
    await page.getByRole('button', { name: 'Hide password' }).click();
    await page.getByRole('button', { name: 'Log In' }).click();

    // Screen 06 (Today Dashboard) — Verify read-only & zero punch buttons
    await page.getByRole('heading', { name: 'Employee Dashboard' }).waitFor({ timeout: 8000 });
    await assertNoOverflow('Screen 06 Today Dashboard');
    const bodyText06 = await page.locator('body').innerText();
    assert.ok(bodyText06.includes('Today Attendance'));
    assert.ok(bodyText06.includes('Read-Only'));
    assert.equal(await page.getByRole('button', { name: /punch|clock in|clock out/i }).count(), 0);

    // Screen 07 (Attendance Records)
    await page.getByRole('navigation', { name: 'Employee bottom navigation' }).getByRole('button', { name: 'Attendance' }).click();
    await page.getByRole('heading', { name: 'My Attendance' }).waitFor();
    await assertNoOverflow('Screen 07 Attendance Records');

    // Screen 13 (My Requests Tracking)
    await page.getByRole('navigation', { name: 'Employee bottom navigation' }).getByRole('button', { name: 'Requests' }).click();
    await page.getByRole('heading', { name: 'My Requests' }).waitFor();
    await assertNoOverflow('Screen 13 My Requests');

    // Screen 10 (Leave Request Form) -> submit -> Screen 11 (Success)
    await page.getByRole('button', { name: 'Leave Request', exact: true }).click();
    await page.getByRole('heading', { name: 'Leave Request' }).waitFor();
    await assertNoOverflow('Screen 10 Leave Request Form');
    await page.locator('#leave-start').fill('2026-11-24');
    await page.locator('#leave-end').fill('2026-11-25');
    await page.locator('#leave-reason').fill('Annual family trip outside campus.');
    await page.getByRole('button', { name: 'Submit Request' }).click();
    await page.getByRole('heading', { name: 'Request Submitted!' }).waitFor({ timeout: 8000 });
    const successText11 = await page.locator('body').innerText();
    assert.ok(/LV-2026-\d{5}/.test(successText11), 'Screen 11 must display real LV reference number');
    await assertNoOverflow('Screen 11 Leave Request Success');
    await page.getByRole('button', { name: 'View Request' }).click();
    await page.getByRole('heading', { name: 'My Requests' }).waitFor();

    // Screen 12 (Attendance Correction Form) -> submit -> Screen 11 (Success)
    await page.getByRole('button', { name: 'Correction', exact: true }).click();
    await page.getByRole('heading', { name: 'Attendance Correction' }).waitFor();
    await assertNoOverflow('Screen 12 Attendance Correction Form');
    await page.locator('#corr-date').fill('2026-11-18');
    await page.locator('#corr-reason').fill('Forgot to scan out at the kiosk after afternoon faculty meeting.');
    await page.getByRole('button', { name: 'Submit Correction' }).click();
    await page.getByRole('heading', { name: 'Request Submitted!' }).waitFor({ timeout: 8000 });
    assert.ok(/AC-2026-\d{5}/.test(await page.locator('body').innerText()));
    await page.getByRole('button', { name: 'Back to Requests' }).click();

    // Screen 08 (My Payslips) -> Screen 14 (Payslip Details)
    await page.getByRole('navigation', { name: 'Employee bottom navigation' }).getByRole('button', { name: 'Payslips' }).click();
    await page.getByRole('heading', { name: 'My Payslips' }).waitFor();
    await page.getByText('Payslip – November 2026').waitFor({ timeout: 8000 });
    await assertNoOverflow('Screen 08 My Payslips');
    await page.getByText('Payslip – November 2026').click();
    await page.getByRole('heading', { name: 'Payslip Details' }).waitFor();
    await page.getByText('Net Pay').waitFor();
    await assertNoOverflow('Screen 14 Payslip Details');
    await page.getByRole('button', { name: 'Go back' }).click();

    // Screen 17 (Notifications)
    await page.getByRole('button', { name: /Open notifications/i }).click();
    await page.getByRole('heading', { name: 'Notifications' }).waitFor();
    await assertNoOverflow('Screen 17 Notifications');
    const markAllBtn = page.getByRole('button', { name: 'Mark all read' });
    if (await markAllBtn.isVisible()) {
      await markAllBtn.click();
    }
    await page.getByRole('button', { name: 'Go back' }).click();

    // Screen 09 (My Profile)
    await page.getByRole('navigation', { name: 'Employee bottom navigation' }).getByRole('button', { name: 'Profile' }).click();
    await page.getByRole('heading', { name: 'Juan Dela Cruz' }).waitFor();
    await assertNoOverflow('Screen 09 My Profile');

    // Screen 15 (Change Password)
    await page.getByRole('button', { name: 'Change Password' }).click();
    await page.getByRole('heading', { name: 'Change Password' }).waitFor();
    await assertNoOverflow('Screen 15 Change Password');
    await page.getByRole('button', { name: 'Go back' }).click();

    // Screen 16 (Account Security) — verify honest disabled 2FA + real sessions
    await page.getByRole('button', { name: 'Account Security' }).click();
    await page.getByRole('heading', { name: 'Account Security' }).waitFor();
    const twoFaToggle = page.getByRole('button', { name: /Two-Factor Authentication unavailable/i });
    assert.equal(await twoFaToggle.isDisabled(), true, '2FA toggle must be honestly disabled');
    await assertNoOverflow('Screen 16 Account Security');
    await page.getByRole('button', { name: 'Go back' }).click();

    // Screen 18 (About)
    await page.getByRole('button', { name: 'About System' }).click();
    await page.getByRole('heading', { name: 'About', exact: true }).waitFor();
    await page.getByText('A secure, reliable, and efficient attendance and payroll system').waitFor();
    await assertNoOverflow('Screen 18 About');
    await page.getByRole('button', { name: 'Go back' }).click();

    // Responsive verification across ALL 5 required viewports on Today Dashboard
    await page.getByRole('navigation', { name: 'Employee bottom navigation' }).getByRole('button', { name: 'Today' }).click();
    await page.getByRole('heading', { name: 'Employee Dashboard' }).waitFor();
    for (const vp of [
      { width: 360, height: 800 },
      { width: 393, height: 852 },
      { width: 412, height: 915 },
      { width: 768, height: 1024 },
      { width: 1440, height: 900 },
    ]) {
      await page.setViewportSize(vp);
      await page.waitForTimeout(80);
      await assertNoOverflow(`Today Dashboard @ ${vp.width}x${vp.height}`);
      if (vp.width >= 1024) {
        assert.equal(
          await page.getByRole('complementary', { name: 'Employee desktop navigation' }).isVisible(),
          true,
          'Desktop sidebar must be visible at 1440x900'
        );
      } else {
        assert.equal(
          await page.getByRole('navigation', { name: 'Employee bottom navigation' }).isVisible(),
          true,
          `Mobile bottom nav must be visible at ${vp.width}x${vp.height}`
        );
      }
    }

    // Sign Out confirmation -> returns cleanly to Screen 05 Employee Login
    await page.getByRole('complementary', { name: 'Employee desktop navigation' }).getByRole('button', { name: 'Sign Out' }).click();
    await page.getByRole('dialog').getByRole('button', { name: 'Sign Out' }).click();
    await page.getByPlaceholder('Employee ID').waitFor({ timeout: 8000 });

    assert.equal(pageErrors.length, 0, `Uncaught page errors: ${pageErrors.join('; ')}`);
  } finally {
    await browser.close();
    await new Promise((resolve) => server.close(resolve));
    realtimeHub.closeAll();
    closeDatabaseSafely(db);
    fs.rmSync(tmpDir, { recursive: true, force: true });
    if (prevSecret === undefined) {
      delete process.env.SESSION_SECRET;
    } else {
      process.env.SESSION_SECRET = prevSecret;
    }
  }
});
