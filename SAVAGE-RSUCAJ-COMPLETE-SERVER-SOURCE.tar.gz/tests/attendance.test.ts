import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import type { AddressInfo } from 'node:net';
import { initDatabase } from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import { SESSION_COOKIE_NAME } from '../server/auth.ts';
import { securityHeadersMiddleware } from '../server/security.ts';
import {
  getManilaDateString,
  parseManilaWallClockToUtcMs,
  toManilaParts,
} from '../server/attendanceEngine.ts';

interface TestResult {
  name: string;
  passed: boolean;
  error?: string;
}

/**
 * Helper to construct a deterministic UTC epoch ms from an explicit Philippines wall clock
 * (`Asia/Manila`, UTC+08:00), completely independent of the host machine's local timezone.
 * Example: pht('2026-06-15', '08:00:00') -> 2026-06-15T00:00:00.000Z
 */
function pht(isoDate: string, hhmmss: string): number {
  const [hStr, mStr, sStr] = hhmmss.split(':');
  const minutes = Number(hStr) * 60 + Number(mStr);
  const seconds = sStr ? Number(sStr) : 0;
  return parseManilaWallClockToUtcMs(isoDate, minutes, seconds);
}

function phtIso(isoDate: string, hhmmss: string): string {
  return new Date(pht(isoDate, hhmmss)).toISOString();
}

function parseSetCookies(res: Response): string[] {
  const hdrs = res.headers as unknown as { getSetCookie?: () => string[] };
  if (typeof hdrs.getSetCookie === 'function') {
    return hdrs.getSetCookie();
  }
  const single = res.headers.get('set-cookie');
  return single ? [single] : [];
}

function extractSessionCookie(setCookies: string[]): string {
  const matched = setCookies.find((c) => c.startsWith(`${SESSION_COOKIE_NAME}=`));
  return matched ? matched.split(';')[0] : '';
}

async function runTests() {
  const results: TestResult[] = [];

  async function test(name: string, fn: () => Promise<void> | void) {
    try {
      await fn();
      results.push({ name, passed: true });
      console.log(`PASS  ${name}`);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      results.push({ name, passed: false, error: message });
      console.error(`FAIL  ${name}: ${message}`);
    }
  }

  // Deterministic mutable server clock (Asia/Manila controlled)
  let currentServerNowMs = pht('2026-06-15', '08:00:00');
  const setNow = (isoDate: string, hhmmss: string) => {
    currentServerNowMs = pht(isoDate, hhmmss);
  };

  const INITIAL_SECRET = crypto.randomBytes(48).toString('hex');
  const ADMIN_USER = 'att_admin';
  const ADMIN_EMAIL = 'att_admin@rsucaj.edu.ph';
  const ADMIN_PW = `Att!${crypto.randomBytes(6).toString('hex')}9Z`;
  const ROTATED_PW = `Rot!${crypto.randomBytes(6).toString('hex')}8Y`;

  process.env.SESSION_SECRET = INITIAL_SECRET;
  delete process.env.SESSION_SECRET_PREVIOUS;

  const tmpBackupDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-b08-att-'));
  const db = initDatabase(':memory:', {
    mode: 'test',
    seedDemoData: false,
    initialAdmin: {
      username: ADMIN_USER,
      email: ADMIN_EMAIL,
      password: ADMIN_PW,
    },
  });

  // Seed deterministic organizational & employee fixtures (no hidden demo data)
  const deptId = Number(
    db
      .prepare(`INSERT INTO departments (code, name, head_name) VALUES ('BSIT', 'BS Information Technology', 'Dr. Reyes')`)
      .run().lastInsertRowid
  );
  const posId = Number(
    db
      .prepare(`INSERT INTO positions (code, name, type, base_salary, allowance) VALUES ('INST', 'Instructor', 'Regular', 34500, 2500)`)
      .run().lastInsertRowid
  );

  // Regular Day Shift: 08:00 AM - 05:00 PM, 15 min grace, Sat/Sun rest days
  const dayShiftId = Number(
    db
      .prepare(
        `INSERT INTO shifts (name, time_in, time_out, grace_minutes, rest_days, status)
         VALUES ('Regular Day Shift', '08:00 AM', '05:00 PM', 15, 'Sat,Sun', 'Active')`
      )
      .run().lastInsertRowid
  );

  // Overnight Night Shift: 10:00 PM - 07:00 AM, 15 min grace, Sun rest day
  const nightShiftId = Number(
    db
      .prepare(
        `INSERT INTO shifts (name, time_in, time_out, grace_minutes, rest_days, status)
         VALUES ('Campus Night Watch', '10:00 PM', '07:00 AM', 15, 'Sun', 'Active')`
      )
      .run().lastInsertRowid
  );

  // Inactive shift (for No Schedule testing)
  const inactiveShiftId = Number(
    db
      .prepare(
        `INSERT INTO shifts (name, time_in, time_out, grace_minutes, rest_days, status)
         VALUES ('Archived Shift', '08:00 AM', '05:00 PM', 15, '', 'Inactive')`
      )
      .run().lastInsertRowid
  );

  const insertEmp = db.prepare(
    `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status, monthly_salary, monthly_allowance)
     VALUES (?, ?, ?, ?, ?, ?, 'Active', 34500, 2500)`
  );

  const empCodes = {
    onTime: 'EMP-PHT-01',
    late: 'EMP-PHT-02',
    undertime: 'EMP-PHT-03',
    breaksOt: 'EMP-PHT-04',
    dupIn: 'EMP-PHT-05',
    dupOut: 'EMP-PHT-06',
    unmatchedOut: 'EMP-PHT-07',
    cutoffPass: 'EMP-PHT-08',
    cutoffFail: 'EMP-PHT-09',
    midnightDay: 'EMP-PHT-10',
    nightWorker: 'EMP-PHT-11',
    driftWorker: 'EMP-PHT-12',
    offlineWorker: 'EMP-PHT-13',
    parallelSameUid: 'EMP-PHT-14',
    parallelDiffUid: 'EMP-PHT-15',
    holidayWorker: 'EMP-PHT-16',
    restDayWorker: 'EMP-PHT-17',
    reconcileOpen: 'EMP-PHT-18',
    reconcileAbsent: 'EMP-PHT-19',
    reconcileLeave: 'EMP-PHT-20',
    reconcileOb: 'EMP-PHT-21',
    reconcileNoSched: 'EMP-PHT-22',
  };

  const empIds: Record<string, number> = {};
  for (const [key, code] of Object.entries(empCodes)) {
    const shiftId =
      key === 'nightWorker'
        ? nightShiftId
        : key === 'reconcileNoSched'
          ? inactiveShiftId
          : dayShiftId;
    empIds[key] = Number(
      insertEmp.run(code, `Employee ${key}`, `${key}@rsucaj.edu.ph`, deptId, posId, shiftId).lastInsertRowid
    );
  }

  // Register a real kiosk terminal
  const KIOSK_TOKEN = `ksk_${crypto.randomBytes(16).toString('hex')}`;
  db.prepare(
    `INSERT INTO devices (name, device_type, model_info, ip_address, location, api_token, status)
     VALUES ('Kiosk - Main Gate', 'Raspberry Pi', 'Raspberry Pi 3B', '192.168.1.50', 'Main Gate', ?, 'Online')`
  ).run(KIOSK_TOKEN);

  // Declare a Holiday on 2026-06-12 (Independence Day - Friday)
  db.prepare(`INSERT INTO holidays (date, name, type) VALUES ('2026-06-12', 'Independence Day', 'Regular')`).run();

  // Approve Leave (2026-06-15) & Official Business (2026-06-15) for reconciliation tests
  db.prepare(
    `INSERT INTO leaves (employee_id, leave_type, start_date, end_date, days_count, reason, status, reviewed_by)
     VALUES (?, 'Sick Leave', '2026-06-15', '2026-06-15', 1, 'Medical checkup', 'Approved', 'att_admin')`
  ).run(empIds.reconcileLeave);
  db.prepare(
    `INSERT INTO leaves (employee_id, leave_type, start_date, end_date, days_count, reason, status, reviewed_by)
     VALUES (?, 'Official Business', '2026-06-15', '2026-06-15', 1, 'CHED regional seminar', 'Approved', 'att_admin')`
  ).run(empIds.reconcileOb);

  const app = express();
  app.disable('x-powered-by');
  app.use(securityHeadersMiddleware);
  app.use(
    '/api',
    createApiRouter(db, {
      appMode: 'test',
      backupDir: tmpBackupDir,
      nowProvider: () => currentServerNowMs,
      maxClockDriftSeconds: 120,
      maxOfflineReplayHours: 72,
    })
  );

  const server = await new Promise<ReturnType<typeof app.listen>>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const port = (server.address() as AddressInfo).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  async function postPunch(payload: Record<string, unknown>) {
    const res = await fetch(`${baseUrl}/api/kiosk/punch`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-kiosk-token': KIOSK_TOKEN,
      },
      body: JSON.stringify(payload),
    });
    const body = (await res.json()) as Record<string, unknown>;
    return { status: res.status, body };
  }

  // Authenticate admin & rotate initial password for protected endpoints (/api/attendance/reconcile & /:id/events)
  let adminCookie = '';
  let adminCsrf = '';
  {
    const loginRes = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier: ADMIN_USER, password: ADMIN_PW }),
    });
    const loginBody = (await loginRes.json()) as { csrfToken: string };
    const initCookie = extractSessionCookie(parseSetCookies(loginRes));

    const rotRes = await fetch(`${baseUrl}/api/auth/change-password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: initCookie,
        'X-CSRF-Token': loginBody.csrfToken,
      },
      body: JSON.stringify({ currentPassword: ADMIN_PW, newPassword: ROTATED_PW }),
    });
    const rotBody = (await rotRes.json()) as { csrfToken: string };
    adminCookie = extractSessionCookie(parseSetCookies(rotRes)) || initCookie;
    adminCsrf = rotBody.csrfToken;
  }

  async function adminReq(urlPath: string, init: RequestInit = {}) {
    const method = (init.method || 'GET').toUpperCase();
    const headers: Record<string, string> = {
      Cookie: adminCookie,
      ...(init.headers as Record<string, string> | undefined),
    };
    if (init.body && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) headers['X-CSRF-Token'] = adminCsrf;
    const res = await fetch(`${baseUrl}${urlPath}`, { ...init, method, headers });
    const body = (await res.json()) as Record<string, unknown>;
    return { status: res.status, body };
  }

  try {
    // -------------------------------------------------------------------------
    // TEST 1: Pure Asia/Manila timezone conversion independent of host OS timezone
    // -------------------------------------------------------------------------
    await test('Asia/Manila (UTC+08:00) boundary math handles 11:59 PM vs 12:01 AM PHT deterministically', () => {
      // 2026-06-15 15:59:00 UTC === 2026-06-15 23:59:00 PHT
      const beforeMidnightUtc = Date.UTC(2026, 5, 15, 15, 59, 0);
      const beforeParts = toManilaParts(beforeMidnightUtc);
      assert.equal(beforeParts.isoDate, '2026-06-15');
      assert.equal(beforeParts.time12, '11:59 PM');
      assert.equal(getManilaDateString(beforeMidnightUtc), '2026-06-15');

      // 2026-06-15 16:01:00 UTC === 2026-06-16 00:01:00 PHT
      const afterMidnightUtc = Date.UTC(2026, 5, 15, 16, 1, 0);
      const afterParts = toManilaParts(afterMidnightUtc);
      assert.equal(afterParts.isoDate, '2026-06-16');
      assert.equal(afterParts.time12, '12:01 AM');
      assert.equal(getManilaDateString(afterMidnightUtc), '2026-06-16');
    });

    // -------------------------------------------------------------------------
    // TEST 2: Missing / invalid explicit attendance action rejected (400)
    // -------------------------------------------------------------------------
    await test('Missing or unapproved punch_type is rejected with 400 INVALID_ACTION (no implicit inference)', async () => {
      setNow('2026-06-15', '07:55:00');
      const missing = await postPunch({ employee_code: empCodes.onTime, event_uid: 'evt-no-action' });
      assert.equal(missing.status, 400);
      assert.equal(missing.body.code, 'INVALID_ACTION');

      const bogus = await postPunch({
        employee_code: empCodes.onTime,
        punch_type: 'AUTO_TOGGLE',
        event_uid: 'evt-bogus-action',
      });
      assert.equal(bogus.status, 400);
      assert.equal(bogus.body.code, 'INVALID_ACTION');
    });

    // -------------------------------------------------------------------------
    // TEST 3: On-time TIME_IN + TIME_OUT -> Present
    // -------------------------------------------------------------------------
    await test('On-time TIME_IN (07:55 AM PHT) + TIME_OUT (05:05 PM PHT) computes Present & exact work hours', async () => {
      setNow('2026-06-15', '07:55:00');
      const rIn = await postPunch({
        employee_code: empCodes.onTime,
        punch_type: 'TIME_IN',
        event_uid: 'evt-ontime-in',
      });
      assert.equal(rIn.status, 201);
      assert.equal(rIn.body.action, 'TIME_IN');
      assert.equal(rIn.body.shift_date, '2026-06-15');
      assert.equal(rIn.body.status, 'Present');
      assert.equal(rIn.body.late_minutes, 0);

      setNow('2026-06-15', '17:05:00');
      const rOut = await postPunch({
        employee_code: empCodes.onTime,
        punch_type: 'TIME_OUT',
        event_uid: 'evt-ontime-out',
      });
      assert.equal(rOut.status, 200);
      assert.equal(rOut.body.action, 'TIME_OUT');
      assert.equal(rOut.body.shift_date, '2026-06-15');
      assert.equal(rOut.body.status, 'Present');
      assert.equal(rOut.body.work_hours, '9h 10m');
      assert.equal(rOut.body.undertime_minutes, 0);
    });

    // -------------------------------------------------------------------------
    // TEST 4: Late arrival past 15-min grace period -> Late
    // -------------------------------------------------------------------------
    await test('Late arrival (08:25 AM PHT on 08:00 AM + 15m grace) marks Late with late_minutes=25', async () => {
      setNow('2026-06-15', '08:25:00');
      const rIn = await postPunch({
        employee_code: empCodes.late,
        punch_type: 'TIME_IN',
        event_uid: 'evt-late-in',
      });
      assert.equal(rIn.status, 201);
      assert.equal(rIn.body.status, 'Late');
      assert.equal(rIn.body.late_minutes, 25);

      setNow('2026-06-15', '17:00:00');
      const rOut = await postPunch({
        employee_code: empCodes.late,
        punch_type: 'TIME_OUT',
        event_uid: 'evt-late-out',
      });
      assert.equal(rOut.status, 200);
      assert.equal(rOut.body.status, 'Late');
      assert.equal(rOut.body.work_hours, '8h 35m');
    });

    // -------------------------------------------------------------------------
    // TEST 5: Early departure -> Undertime
    // -------------------------------------------------------------------------
    await test('Early departure (04:15 PM PHT on 05:00 PM shift) marks Undertime with undertime_minutes=45', async () => {
      setNow('2026-06-15', '07:55:00');
      const rIn = await postPunch({
        employee_code: empCodes.undertime,
        punch_type: 'TIME_IN',
        event_uid: 'evt-ut-in',
      });
      assert.equal(rIn.status, 201);
      assert.equal(rIn.body.status, 'Present');

      setNow('2026-06-15', '16:15:00');
      const rOut = await postPunch({
        employee_code: empCodes.undertime,
        punch_type: 'TIME_OUT',
        event_uid: 'evt-ut-out',
      });
      assert.equal(rOut.status, 200);
      assert.equal(rOut.body.status, 'Undertime');
      assert.equal(rOut.body.undertime_minutes, 45);
      assert.equal(rOut.body.work_hours, '8h 20m');
    });

    // -------------------------------------------------------------------------
    // TEST 6: Full Break Out -> Break In -> Time Out -> Overtime Out
    // -------------------------------------------------------------------------
    await test('BREAK_OUT -> BREAK_IN deducts break duration; OVERTIME_OUT records OT without overwriting TIME_OUT', async () => {
      setNow('2026-06-15', '08:00:00');
      assert.equal(
        (await postPunch({ employee_code: empCodes.breaksOt, punch_type: 'TIME_IN', event_uid: 'evt-bo-1' })).status,
        201
      );

      setNow('2026-06-15', '12:00:00');
      const bOut = await postPunch({ employee_code: empCodes.breaksOt, punch_type: 'BREAK_OUT', event_uid: 'evt-bo-2' });
      assert.equal(bOut.status, 200);
      assert.equal(bOut.body.action, 'BREAK_OUT');

      setNow('2026-06-15', '13:00:00');
      const bIn = await postPunch({ employee_code: empCodes.breaksOt, punch_type: 'BREAK_IN', event_uid: 'evt-bo-3' });
      assert.equal(bIn.status, 200);
      assert.equal(bIn.body.action, 'BREAK_IN');

      setNow('2026-06-15', '17:00:00');
      const tOut = await postPunch({ employee_code: empCodes.breaksOt, punch_type: 'TIME_OUT', event_uid: 'evt-bo-4' });
      assert.equal(tOut.status, 200);
      assert.equal(tOut.body.work_hours, '8h 00m'); // 9h span minus 1h break = 8h 00m

      setNow('2026-06-15', '19:30:00');
      const otOut = await postPunch({
        employee_code: empCodes.breaksOt,
        punch_type: 'OVERTIME_OUT',
        event_uid: 'evt-bo-5',
      });
      assert.equal(otOut.status, 200);
      assert.equal(otOut.body.action, 'OVERTIME_OUT');
      assert.equal(otOut.body.overtime_minutes, 150);

      // Verify TIME_OUT was preserved untouched in DB
      const row = db
        .prepare('SELECT time_in, break_out, break_in, time_out, overtime_out, overtime_minutes FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.breaksOt, '2026-06-15') as {
        time_in: string;
        break_out: string;
        break_in: string;
        time_out: string;
        overtime_out: string;
        overtime_minutes: number;
      };
      assert.equal(row.time_in, '08:00 AM');
      assert.equal(row.break_out, '12:00 PM');
      assert.equal(row.break_in, '01:00 PM');
      assert.equal(row.time_out, '05:00 PM');
      assert.equal(row.overtime_out, '07:30 PM');
      assert.equal(row.overtime_minutes, 150);
    });

    // -------------------------------------------------------------------------
    // TEST 7: Repeated TIME_IN rejected (NO implicit conversion to TIME_OUT, NO overwrite)
    // -------------------------------------------------------------------------
    await test('Repeated TIME_IN returns 409 DUPLICATE_TIME_IN and NEVER converts into TIME_OUT or overwrites', async () => {
      setNow('2026-06-15', '07:50:00');
      const first = await postPunch({ employee_code: empCodes.dupIn, punch_type: 'TIME_IN', event_uid: 'evt-dupin-1' });
      assert.equal(first.status, 201);

      setNow('2026-06-15', '08:40:00');
      const second = await postPunch({ employee_code: empCodes.dupIn, punch_type: 'TIME_IN', event_uid: 'evt-dupin-2' });
      assert.equal(second.status, 409);
      assert.equal(second.body.code, 'DUPLICATE_TIME_IN');

      const row = db
        .prepare('SELECT time_in, time_out, status FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.dupIn, '2026-06-15') as { time_in: string; time_out: string | null; status: string };
      assert.equal(row.time_in, '07:50 AM');
      assert.equal(row.time_out, null, 'Repeated TIME_IN must never implicitly set time_out');
      assert.equal(row.status, 'Present');
    });

    // -------------------------------------------------------------------------
    // TEST 8: Repeated TIME_OUT rejected (NO overwrite of original TIME_OUT)
    // -------------------------------------------------------------------------
    await test('Repeated TIME_OUT returns 409 DUPLICATE_TIME_OUT and NEVER overwrites existing valid TIME_OUT', async () => {
      setNow('2026-06-15', '08:00:00');
      assert.equal(
        (await postPunch({ employee_code: empCodes.dupOut, punch_type: 'TIME_IN', event_uid: 'evt-dupout-1' })).status,
        201
      );

      setNow('2026-06-15', '17:05:00');
      assert.equal(
        (await postPunch({ employee_code: empCodes.dupOut, punch_type: 'TIME_OUT', event_uid: 'evt-dupout-2' })).status,
        200
      );

      setNow('2026-06-15', '18:30:00');
      const repeatOut = await postPunch({
        employee_code: empCodes.dupOut,
        punch_type: 'TIME_OUT',
        event_uid: 'evt-dupout-3',
      });
      assert.equal(repeatOut.status, 409);
      assert.equal(repeatOut.body.code, 'DUPLICATE_TIME_OUT');

      const row = db
        .prepare('SELECT time_out, work_hours FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.dupOut, '2026-06-15') as { time_out: string; work_hours: string };
      assert.equal(row.time_out, '05:05 PM', 'Original valid TIME_OUT must never be overwritten');
      assert.equal(row.work_hours, '9h 05m');
    });

    // -------------------------------------------------------------------------
    // TEST 9: TIME_OUT without TIME_IN -> rejected & escalated (NEVER fabricates TIME_IN)
    // -------------------------------------------------------------------------
    await test('TIME_OUT without prior TIME_IN returns 409 UNMATCHED_TIME_OUT, escalates to HR, and fabricates nothing', async () => {
      setNow('2026-06-15', '17:10:00');
      const res = await postPunch({
        employee_code: empCodes.unmatchedOut,
        punch_type: 'TIME_OUT',
        event_uid: 'evt-unmatched-out',
      });
      assert.equal(res.status, 409);
      assert.equal(res.body.code, 'UNMATCHED_TIME_OUT');
      assert.equal(res.body.escalated, true);

      const rec = db
        .prepare('SELECT * FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.unmatchedOut, '2026-06-15');
      assert.equal(rec, undefined, 'Must NOT fabricate an attendance_records row for unmatched TIME_OUT');

      const corr = db
        .prepare(`SELECT status, request_type FROM corrections WHERE employee_id = ? AND attendance_date = '2026-06-15'`)
        .get(empIds.unmatchedOut) as { status: string; request_type: string } | undefined;
      assert.ok(corr, 'HR escalation correction must be created');
      assert.equal(corr.status, 'Pending');
      assert.equal(corr.request_type, 'Time Out');
    });

    // -------------------------------------------------------------------------
    // TEST 10: 11:59 PM -> 12:01 AM next-day TIME_OUT assigns to prior shift date
    // -------------------------------------------------------------------------
    await test('11:59 PM to 12:01 AM PHT crossing assigns TIME_OUT to previous day open shift date', async () => {
      setNow('2026-06-15', '08:00:00');
      assert.equal(
        (await postPunch({ employee_code: empCodes.midnightDay, punch_type: 'TIME_IN', event_uid: 'evt-mid-in' })).status,
        201
      );

      // Next calendar day 00:01 AM PHT (still before 03:00 AM next-day cutoff)
      setNow('2026-06-16', '00:01:00');
      const outRes = await postPunch({
        employee_code: empCodes.midnightDay,
        punch_type: 'TIME_OUT',
        event_uid: 'evt-mid-out',
      });
      assert.equal(outRes.status, 200);
      assert.equal(outRes.body.shift_date, '2026-06-15', '12:01 AM TIME_OUT must attach to 2026-06-15 open shift');
      assert.equal(outRes.body.work_hours, '16h 01m');
    });

    // -------------------------------------------------------------------------
    // TEST 11: 02:59 AM vs 03:01 AM Asia/Manila next-day cutoff enforcement
    // -------------------------------------------------------------------------
    await test('02:59 AM next-day TIME_OUT is ACCEPTED while 03:01 AM is REJECTED & ESCALATED to HR', async () => {
      // Both employees clock in on 2026-06-15 08:00 AM PHT
      setNow('2026-06-15', '08:00:00');
      assert.equal(
        (await postPunch({ employee_code: empCodes.cutoffPass, punch_type: 'TIME_IN', event_uid: 'evt-cutpass-in' })).status,
        201
      );
      assert.equal(
        (await postPunch({ employee_code: empCodes.cutoffFail, punch_type: 'TIME_IN', event_uid: 'evt-cutfail-in' })).status,
        201
      );

      // 02:59 AM PHT next day -> ACCEPTED on 2026-06-15
      setNow('2026-06-16', '02:59:00');
      const passOut = await postPunch({
        employee_code: empCodes.cutoffPass,
        punch_type: 'TIME_OUT',
        event_uid: 'evt-cutpass-out',
      });
      assert.equal(passOut.status, 200);
      assert.equal(passOut.body.shift_date, '2026-06-15');
      assert.equal(passOut.body.work_hours, '18h 59m');

      // 03:01 AM PHT next day -> REJECTED & ESCALATED (422 CUTOFF_EXCEEDED_ESCALATED)
      setNow('2026-06-16', '03:01:00');
      const failOut = await postPunch({
        employee_code: empCodes.cutoffFail,
        punch_type: 'TIME_OUT',
        event_uid: 'evt-cutfail-out',
      });
      assert.equal(failOut.status, 422);
      assert.equal(failOut.body.code, 'CUTOFF_EXCEEDED_ESCALATED');
      assert.equal(failOut.body.escalated, true);

      // Verify cutoffFail's 2026-06-15 record still has time_out=NULL (not overwritten with 03:01 AM)
      const failRow = db
        .prepare('SELECT time_in, time_out FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.cutoffFail, '2026-06-15') as { time_in: string; time_out: string | null };
      assert.equal(failRow.time_in, '08:00 AM');
      assert.equal(failRow.time_out, null);

      // Verify escalation created pending HR correction + immutable ESCALATED event
      const corr = db
        .prepare(`SELECT status FROM corrections WHERE employee_id = ? AND attendance_date = '2026-06-15'`)
        .get(empIds.cutoffFail) as { status: string } | undefined;
      assert.equal(corr?.status, 'Pending');

      const escEvent = db
        .prepare(`SELECT decision, decision_code FROM attendance_events WHERE event_uid = 'evt-cutfail-out'`)
        .get() as { decision: string; decision_code: string } | undefined;
      assert.equal(escEvent?.decision, 'ESCALATED');
      assert.equal(escEvent?.decision_code, 'CUTOFF_EXCEEDED_ESCALATED');
    });

    // -------------------------------------------------------------------------
    // TEST 12: Overnight Night Shift (10:00 PM - 07:00 AM) crossing midnight
    // -------------------------------------------------------------------------
    await test('Overnight shift (10:00 PM - 07:00 AM PHT) assigns TIME_IN & next-morning TIME_OUT to shift start date', async () => {
      setNow('2026-06-15', '21:50:00');
      const nIn = await postPunch({
        employee_code: empCodes.nightWorker,
        punch_type: 'TIME_IN',
        event_uid: 'evt-night-in',
      });
      assert.equal(nIn.status, 201);
      assert.equal(nIn.body.shift_date, '2026-06-15');
      assert.equal(nIn.body.status, 'Present');

      setNow('2026-06-16', '07:05:00');
      const nOut = await postPunch({
        employee_code: empCodes.nightWorker,
        punch_type: 'TIME_OUT',
        event_uid: 'evt-night-out',
      });
      assert.equal(nOut.status, 200);
      assert.equal(nOut.body.shift_date, '2026-06-15');
      assert.equal(nOut.body.status, 'Present');
      assert.equal(nOut.body.work_hours, '9h 15m');
    });

    // -------------------------------------------------------------------------
    // TEST 13: Separate Day Reconciliation Engine (before vs after 03:00 AM cutoff)
    // -------------------------------------------------------------------------
    await test('Reconciliation marks Missing Time Out, Absent, On Leave, OB, and No Schedule strictly by policy', async () => {
      // Create an open TIME_IN for reconcileOpen on 2026-06-15 08:00 AM PHT
      setNow('2026-06-15', '08:00:00');
      assert.equal(
        (await postPunch({ employee_code: empCodes.reconcileOpen, punch_type: 'TIME_IN', event_uid: 'evt-rec-open' })).status,
        201
      );

      // Run reconciliation BEFORE cutoff (2026-06-16 02:30 AM PHT)
      // Open TIME_IN and unpunched active employees MUST NOT be prematurely flagged as Missing Time Out or Absent
      setNow('2026-06-16', '02:30:00');
      const preCutoff = await adminReq('/api/attendance/reconcile', {
        method: 'POST',
        body: JSON.stringify({ date: '2026-06-15' }),
      });
      assert.equal(preCutoff.status, 200);
      const openBefore = db
        .prepare('SELECT status, time_out FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.reconcileOpen, '2026-06-15') as { status: string; time_out: string | null };
      assert.equal(openBefore.status, 'Present', 'Must not mark Missing Time Out before 03:00 AM cutoff');
      const absentBefore = db
        .prepare('SELECT status FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.reconcileAbsent, '2026-06-15');
      assert.equal(absentBefore, undefined, 'Must not mark Absent before 03:00 AM cutoff');

      // Run reconciliation AFTER cutoff (2026-06-16 03:05 AM PHT)
      setNow('2026-06-16', '03:05:00');
      const postCutoff = await adminReq('/api/attendance/reconcile', {
        method: 'POST',
        body: JSON.stringify({ date: '2026-06-15' }),
      });
      assert.equal(postCutoff.status, 200);

      const openAfter = db
        .prepare('SELECT status, time_out FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.reconcileOpen, '2026-06-15') as { status: string; time_out: string | null };
      assert.equal(openAfter.status, 'Missing Time Out');
      assert.equal(openAfter.time_out, null, 'Reconciliation must NEVER fabricate a time_out');

      const absentAfter = db
        .prepare('SELECT status, time_in, time_out FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.reconcileAbsent, '2026-06-15') as { status: string; time_in: string | null; time_out: string | null };
      assert.equal(absentAfter.status, 'Absent');
      assert.equal(absentAfter.time_in, null);
      assert.equal(absentAfter.time_out, null);

      const leaveAfter = db
        .prepare('SELECT status FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.reconcileLeave, '2026-06-15') as { status: string };
      assert.equal(leaveAfter.status, 'On Leave');

      const obAfter = db
        .prepare('SELECT status FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.reconcileOb, '2026-06-15') as { status: string };
      assert.equal(obAfter.status, 'OB');

      const noSchedAfter = db
        .prepare('SELECT status FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.reconcileNoSched, '2026-06-15') as { status: string };
      assert.equal(noSchedAfter.status, 'No Schedule');

      // Completed Present record (empCodes.onTime) MUST remain untouched
      const completed = db
        .prepare('SELECT status, time_in, time_out FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.onTime, '2026-06-15') as { status: string; time_in: string; time_out: string };
      assert.equal(completed.status, 'Present');
      assert.equal(completed.time_in, '07:55 AM');
      assert.equal(completed.time_out, '05:05 PM');
    });

    // -------------------------------------------------------------------------
    // TEST 14: Server clock authority, untrusted punch_time ignored, ±120s drift validation
    // -------------------------------------------------------------------------
    await test('Server clock is authoritative: forged punch_time is ignored and >120s live drift is rejected', async () => {
      // Server clock is 2026-06-17 08:30 AM PHT (Late!)
      setNow('2026-06-17', '08:30:00');

      // Excessive device clock drift (+300s) -> REJECTED 422 CLOCK_DRIFT_EXCEEDED
      const badDrift = await postPunch({
        employee_code: empCodes.driftWorker,
        punch_type: 'TIME_IN',
        event_uid: 'evt-drift-bad',
        device_timestamp: phtIso('2026-06-17', '08:35:00'),
      });
      assert.equal(badDrift.status, 422);
      assert.equal(badDrift.body.code, 'CLOCK_DRIFT_EXCEEDED');

      // Forged punch_time='07:00 AM' with acceptable +60s drift -> server ignores '07:00 AM' and logs 08:30 AM (Late)
      const forged = await postPunch({
        employee_code: empCodes.driftWorker,
        punch_type: 'TIME_IN',
        event_uid: 'evt-drift-ok',
        punch_time: '07:00 AM',
        device_timestamp: phtIso('2026-06-17', '08:31:00'),
      });
      assert.equal(forged.status, 201);
      assert.equal(forged.body.time, '08:30 AM', 'Server must ignore client-supplied punch_time string');
      assert.equal(forged.body.status, 'Late');
      assert.equal(forged.body.clock_drift_seconds, 60);

      const driftEvent = db
        .prepare(`SELECT clock_drift_seconds, decision FROM attendance_events WHERE event_uid = 'evt-drift-ok'`)
        .get() as { clock_drift_seconds: number; decision: string };
      assert.equal(driftEvent.clock_drift_seconds, 60);
      assert.equal(driftEvent.decision, 'ACCEPTED');
    });

    // -------------------------------------------------------------------------
    // TEST 15: Offline replay ordering, bounded 72h window, and stale escalation
    // -------------------------------------------------------------------------
    await test('Offline replay accepts chronological <=72h events, rejects out-of-order, and escalates >72h stale events', async () => {
      // Server clock is 2026-06-18 10:00 AM PHT
      setNow('2026-06-18', '10:00:00');

      // Stale offline punch (>72h old: 2026-06-14 08:00 AM PHT = 98h ago) -> 422 OFFLINE_REPLAY_EXPIRED
      const stale = await postPunch({
        employee_code: empCodes.offlineWorker,
        punch_type: 'TIME_IN',
        event_uid: 'evt-off-stale',
        offline_replay: true,
        device_timestamp: phtIso('2026-06-14', '08:00:00'),
      });
      assert.equal(stale.status, 422);
      assert.equal(stale.body.code, 'OFFLINE_REPLAY_EXPIRED');
      assert.equal(stale.body.escalated, true);

      // Valid offline TIME_IN from yesterday (2026-06-17 08:00 AM PHT = 26h ago) -> ACCEPTED
      const offIn = await postPunch({
        employee_code: empCodes.offlineWorker,
        punch_type: 'TIME_IN',
        event_uid: 'evt-off-in',
        offline_replay: true,
        device_timestamp: phtIso('2026-06-17', '08:00:00'),
      });
      assert.equal(offIn.status, 201);
      assert.equal(offIn.body.shift_date, '2026-06-17');
      assert.equal(offIn.body.offline_replay, true);

      // Out-of-order offline TIME_OUT earlier than TIME_IN (07:30 AM < 08:00 AM) -> REJECTED 409 OUT_OF_ORDER_TIMESTAMP
      const outOfOrder = await postPunch({
        employee_code: empCodes.offlineWorker,
        punch_type: 'TIME_OUT',
        event_uid: 'evt-off-ooo',
        offline_replay: true,
        device_timestamp: phtIso('2026-06-17', '07:30:00'),
      });
      assert.equal(outOfOrder.status, 409);
      assert.equal(outOfOrder.body.code, 'OUT_OF_ORDER_TIMESTAMP');

      // Valid chronological offline TIME_OUT (2026-06-17 05:00 PM PHT) -> ACCEPTED
      const offOut = await postPunch({
        employee_code: empCodes.offlineWorker,
        punch_type: 'TIME_OUT',
        event_uid: 'evt-off-out',
        offline_replay: true,
        device_timestamp: phtIso('2026-06-17', '17:00:00'),
      });
      assert.equal(offOut.status, 200);
      assert.equal(offOut.body.work_hours, '9h 00m');
    });

    // -------------------------------------------------------------------------
    // TEST 16: Retry idempotency & parallel duplicate HTTP requests
    // -------------------------------------------------------------------------
    await test('Parallel duplicate HTTP requests (same event_uid and distinct event_uid TIME_IN) remain atomic & idempotent', async () => {
      setNow('2026-06-17', '07:58:00');

      // 6 parallel requests with the EXACT SAME event_uid
      const sameUidResults = await Promise.all(
        Array.from({ length: 6 }, () =>
          postPunch({
            employee_code: empCodes.parallelSameUid,
            punch_type: 'TIME_IN',
            event_uid: 'evt-par-same-001',
          })
        )
      );
      const createdCount = sameUidResults.filter((r) => r.status === 201 && r.body.action === 'TIME_IN').length;
      const dupIgnoredCount = sameUidResults.filter(
        (r) => r.status === 200 && r.body.action === 'duplicate_ignored'
      ).length;
      assert.equal(createdCount, 1, 'Exactly one parallel request with same event_uid must create the punch');
      assert.equal(dupIgnoredCount, 5, 'Remaining 5 identical retries must return 200 duplicate_ignored');

      // 6 parallel TIME_IN requests with DISTINCT event_uids
      const diffUidResults = await Promise.all(
        Array.from({ length: 6 }, (_, i) =>
          postPunch({
            employee_code: empCodes.parallelDiffUid,
            punch_type: 'TIME_IN',
            event_uid: `evt-par-diff-${i}`,
          })
        )
      );
      const acceptedDiff = diffUidResults.filter((r) => r.status === 201 && r.body.action === 'TIME_IN').length;
      const rejectedDiff = diffUidResults.filter(
        (r) => r.status === 409 && r.body.code === 'DUPLICATE_TIME_IN'
      ).length;
      assert.equal(acceptedDiff, 1, 'Exactly one parallel TIME_IN must be accepted');
      assert.equal(rejectedDiff, 5, 'Remaining 5 parallel TIME_IN attempts must be rejected as 409 DUPLICATE_TIME_IN');

      const row = db
        .prepare('SELECT time_in, time_out FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.parallelDiffUid, '2026-06-17') as { time_in: string; time_out: string | null };
      assert.equal(row.time_in, '07:58 AM');
      assert.equal(row.time_out, null, 'Parallel TIME_IN must never implicitly turn into TIME_OUT');
    });

    // -------------------------------------------------------------------------
    // TEST 17: Holiday & Rest-Day worked and unworked reconciliation
    // -------------------------------------------------------------------------
    await test('Holiday (2026-06-12) and Rest Day (2026-06-14 Sun) preserve Holiday/Rest Day status whether worked or reconciled', async () => {
      // Worked on Holiday (Friday 2026-06-12 Independence Day)
      setNow('2026-06-12', '08:00:00');
      const hIn = await postPunch({
        employee_code: empCodes.holidayWorker,
        punch_type: 'TIME_IN',
        event_uid: 'evt-hol-in',
      });
      assert.equal(hIn.status, 201);
      assert.equal(hIn.body.status, 'Holiday');

      setNow('2026-06-12', '12:00:00');
      const hOut = await postPunch({
        employee_code: empCodes.holidayWorker,
        punch_type: 'TIME_OUT',
        event_uid: 'evt-hol-out',
      });
      assert.equal(hOut.status, 200);
      assert.equal(hOut.body.status, 'Holiday');
      assert.equal(hOut.body.work_hours, '4h 00m');

      // Reconcile 2026-06-12 on 2026-06-13 04:00 AM -> unworked employees marked Holiday, NEVER Absent
      setNow('2026-06-13', '04:00:00');
      const recHol = await adminReq('/api/attendance/reconcile', {
        method: 'POST',
        body: JSON.stringify({ date: '2026-06-12' }),
      });
      assert.equal(recHol.status, 200);
      const unworkedHol = db
        .prepare('SELECT status FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.onTime, '2026-06-12') as { status: string };
      assert.equal(unworkedHol.status, 'Holiday');

      // Worked on Rest Day (Sunday 2026-06-14)
      setNow('2026-06-14', '09:00:00');
      const rdIn = await postPunch({
        employee_code: empCodes.restDayWorker,
        punch_type: 'TIME_IN',
        event_uid: 'evt-rd-in',
      });
      assert.equal(rdIn.status, 201);
      assert.equal(rdIn.body.status, 'Rest Day');

      setNow('2026-06-14', '13:30:00');
      const rdOut = await postPunch({
        employee_code: empCodes.restDayWorker,
        punch_type: 'TIME_OUT',
        event_uid: 'evt-rd-out',
      });
      assert.equal(rdOut.status, 200);
      assert.equal(rdOut.body.status, 'Rest Day');
      assert.equal(rdOut.body.work_hours, '4h 30m');

      // Reconcile Sunday 2026-06-14 on 2026-06-15 04:00 AM -> unworked employees marked Rest Day, NEVER Absent
      setNow('2026-06-15', '04:00:00');
      const recRd = await adminReq('/api/attendance/reconcile', {
        method: 'POST',
        body: JSON.stringify({ date: '2026-06-14' }),
      });
      assert.equal(recRd.status, 200);
      const unworkedRd = db
        .prepare('SELECT status FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.onTime, '2026-06-14') as { status: string };
      assert.equal(unworkedRd.status, 'Rest Day');
    });

    // -------------------------------------------------------------------------
    // TEST 18: Immutable attendance_events SQLite triggers & GET /api/attendance/:id/events API
    // -------------------------------------------------------------------------
    await test('Immutable attendance_events rejects UPDATE/DELETE and GET /api/attendance/:id/events returns forensic history', async () => {
      // Immutability triggers at DB layer
      assert.throws(
        () => db.prepare(`UPDATE attendance_events SET decision = 'REJECTED' WHERE event_uid = 'evt-ontime-in'`).run(),
        /IMMUTABLE_AUDIT_VIOLATION/i
      );
      assert.throws(
        () => db.prepare(`DELETE FROM attendance_events WHERE event_uid = 'evt-ontime-in'`).run(),
        /IMMUTABLE_AUDIT_VIOLATION/i
      );

      // Query immutable punch history via authenticated API
      const attRec = db
        .prepare('SELECT id FROM attendance_records WHERE employee_id = ? AND date = ?')
        .get(empIds.breaksOt, '2026-06-15') as { id: number };
      const evRes = await adminReq(`/api/attendance/${attRec.id}/events`);
      assert.equal(evRes.status, 200);
      const events = evRes.body.data as Array<{ punch_type: string; decision: string }>;
      assert.equal(events.length, 5);
      assert.deepEqual(
        events.map((e) => e.punch_type),
        ['TIME_IN', 'BREAK_OUT', 'BREAK_IN', 'TIME_OUT', 'OVERTIME_OUT']
      );
      assert.ok(events.every((e) => e.decision === 'ACCEPTED'));
    });
  } finally {
    server.close();
    db.close();
    fs.rmSync(tmpBackupDir, { recursive: true, force: true });
  }

  const passed = results.filter((r) => r.passed).length;
  const failed = results.filter((r) => !r.passed).length;
  console.log(`\nAttendance Policy Summary: ${passed}/${results.length} passed, ${failed} failed.`);
  if (failed > 0) process.exit(1);
}

runTests().catch((err) => {
  console.error('Attendance test suite crashed:', err);
  process.exit(1);
});
