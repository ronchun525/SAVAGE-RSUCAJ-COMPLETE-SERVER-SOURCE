import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import zlib from 'node:zlib';
import express from 'express';
import { closeDatabaseSafely, initDatabase } from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import { processKioskPunch } from '../server/attendanceEngine.ts';
import { approvePayrollPolicyByFinance, computeOrRecomputePayrollRun, createPayrollPolicy, getPayrollPolicyTemplate } from '../server/payrollEngine.ts';
import { buildMonthlyDtrReports, escapeCsvCell } from '../server/reportsEngine.ts';

let passed = 0;
let failed = 0;

async function test(name: string, fn: () => Promise<void> | void) {
  try {
    await fn();
    passed++;
    console.log(`PASS  ${name}`);
  } catch (err) {
    failed++;
    console.error(`FAIL  ${name}`);
    console.error('     ', err instanceof Error ? err.stack || err.message : err);
  }
}

interface SessionJar {
  sessionCookie: string;
  csrfToken: string;
}

function parseCookies(setCookieHeaders: string[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const raw of setCookieHeaders) {
    const first = raw.split(';')[0];
    const eq = first.indexOf('=');
    if (eq > 0) out[first.slice(0, eq).trim()] = first.slice(eq + 1).trim();
  }
  return out;
}

/**
 * Extracts raw PDF text by inflating all FlateDecode content streams with node:zlib.
 */
function extractPdfInspectInfo(buf: Buffer): {
  header: string;
  eof: string;
  hasA4PortraitMediaBox: boolean;
  hasImageXObject: boolean;
  decompressedText: string;
  rawLatin1: string;
} {
  const rawLatin1 = buf.toString('latin1');
  const header = buf.subarray(0, 8).toString('ascii');
  const eof = buf.subarray(Math.max(0, buf.length - 16)).toString('ascii').trim();
  const hasA4PortraitMediaBox = /\/MediaBox\s*\[\s*0\s+0\s+595\.28\s+841\.89\s*\]/.test(rawLatin1);
  const hasImageXObject = /\/Subtype\s*\/Image/.test(rawLatin1);

  const chunks: string[] = [];
  let cursor = 0;
  while (cursor < buf.length) {
    const streamIdx = buf.indexOf('stream', cursor, 'ascii');
    if (streamIdx === -1) break;
    let dataStart = streamIdx + 6;
    if (buf[dataStart] === 0x0d && buf[dataStart + 1] === 0x0a) dataStart += 2;
    else if (buf[dataStart] === 0x0a) dataStart += 1;

    const endStreamIdx = buf.indexOf('endstream', dataStart, 'ascii');
    if (endStreamIdx === -1) break;

    let dataEnd = endStreamIdx;
    while (dataEnd > dataStart && (buf[dataEnd - 1] === 0x0a || buf[dataEnd - 1] === 0x0d)) {
      dataEnd--;
    }

    const slice = buf.subarray(dataStart, dataEnd);
    try {
      const inflated = zlib.inflateSync(slice);
      const txt = inflated.toString('latin1');
      // Decode PDFKit WinAnsi hex strings (<4452...>) and literal strings ((...)) inside content streams
      const extractedPieces: string[] = [];
      const tokenRe = /<([0-9a-fA-F]+)>|\(((?:\\.|[^\\)])*)\)/g;
      let m: RegExpExecArray | null;
      while ((m = tokenRe.exec(txt)) !== null) {
        if (m[1]) {
          if (m[1].length % 2 === 0) {
            extractedPieces.push(Buffer.from(m[1], 'hex').toString('latin1'));
          }
        } else if (m[2] !== undefined) {
          extractedPieces.push(m[2].replace(/\\([()\\])/g, '$1'));
        }
      }
      chunks.push(extractedPieces.length > 0 ? extractedPieces.join('') : txt);
    } catch {
      // Not a FlateDecode text stream (e.g. raw or image) — ignore
    }
    cursor = endStreamIdx + 9;
  }

  const joined = chunks.join('\n');
  return {
    header,
    eof,
    hasA4PortraitMediaBox,
    hasImageXObject,
    decompressedText: joined,
    rawLatin1,
  };
}

function pdfTextContains(pdfText: string, needle: string): boolean {
  const normalizedPdf = pdfText.replace(/\s+/g, ' ');
  const normalizedNeedle = needle.replace(/\s+/g, ' ');
  const compactStream = pdfText.replace(/\s+/g, '');
  const compactNeedle = needle.replace(/\s+/g, '');
  return normalizedPdf.includes(normalizedNeedle) || compactStream.includes(compactNeedle);
}

async function run() {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-b13-reports-'));
  const dbPath = path.join(tmpDir, 'reports.db');
  const sessionSecret = crypto.randomBytes(48).toString('hex');
  const adminPass = `Adm!${crypto.randomBytes(6).toString('hex')}9A`;
  const hrPass = `Hro!${crypto.randomBytes(6).toString('hex')}8B`;
  const payrollPass = `Pay!${crypto.randomBytes(6).toString('hex')}7C`;
  const deptHeadPass = `Dhd!${crypto.randomBytes(6).toString('hex')}6D`;
  const empPass = `Emp!${crypto.randomBytes(6).toString('hex')}5E`;

  // Controllable virtual server clock: 2026-04-02 10:00:00 Asia/Manila
  const virtualNowMs = Date.parse('2026-04-02T02:00:00.000Z');
  const nowProvider = () => virtualNowMs;

  process.env.SESSION_SECRET = sessionSecret;

  const db = initDatabase(dbPath, {
    mode: 'test',
    seedDemoData: true,
    initialAdmin: {
      username: 'b13_admin',
      email: 'b13_admin@rsucaj.edu.ph',
      password: adminPass,
    },
  });
  db.prepare(`UPDATE users SET must_change_password = 0 WHERE username = 'b13_admin'`).run();

  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '5mb' }));
  app.use('/api', createApiRouter(db, { nowProvider, appMode: 'test' }));

  const server = await new Promise<http.Server>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const addr = server.address();
  assert.ok(addr && typeof addr !== 'string');
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  async function req(
    urlPath: string,
    options: RequestInit = {},
    jar?: SessionJar
  ): Promise<{ status: number; body: Record<string, unknown>; text: string; buffer: Buffer; headers: Headers }> {
    const headers: Record<string, string> = {
      ...((options.headers as Record<string, string>) || {}),
    };
    if (options.body && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }
    if (jar?.sessionCookie) headers.Cookie = jar.sessionCookie;
    if (jar?.csrfToken && options.method && !['GET', 'HEAD', 'OPTIONS'].includes(options.method.toUpperCase())) {
      headers['X-CSRF-Token'] = jar.csrfToken;
    }
    const res = await fetch(`${baseUrl}${urlPath}`, { ...options, headers });
    const ab = await res.arrayBuffer();
    const buffer = Buffer.from(ab);
    const text = buffer.toString('utf8');
    let body: Record<string, unknown> = {};
    if (text && (res.headers.get('content-type') || '').includes('application/json')) {
      try {
        body = JSON.parse(text);
      } catch {
        body = { raw: text };
      }
    }
    return { status: res.status, body, text, buffer, headers: res.headers };
  }

  async function loginAs(identifier: string, password: string): Promise<SessionJar> {
    const res = await req('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier, password }),
    });
    assert.equal(res.status, 200, `Expected login 200 for ${identifier}, got ${res.status}: ${res.text}`);
    const hdrs = res.headers as unknown as { getSetCookie?: () => string[] };
    const cookies = parseCookies(hdrs.getSetCookie ? hdrs.getSetCookie() : []);
    return {
      sessionCookie: `savage_rsucaj_session=${cookies.savage_rsucaj_session}`,
      csrfToken: String(res.body.csrfToken),
    };
  }

  const adminJar = await loginAs('b13_admin', adminPass);

  // Set official Campus Director signatory in settings while keeping cs_form_48_reference_verified='false'
  const setUpdate = await req(
    '/api/settings',
    {
      method: 'PUT',
      body: JSON.stringify({ updates: { campus_director_name: 'Dr. Elena R. Cajidiocan' } }),
    },
    adminJar
  );
  assert.equal(setUpdate.status, 200);

  // Lookup seeded departments, positions, shifts, employees
  const deptRows = db.prepare('SELECT id, code, name FROM departments ORDER BY id ASC').all() as Array<{
    id: number;
    code: string;
    name: string;
  }>;
  assert.ok(deptRows.length >= 2, 'Expected at least 2 seeded departments');
  const deptA = deptRows[0];
  const deptB = deptRows[1];

  const posRow = db.prepare('SELECT id FROM positions LIMIT 1').get() as { id: number };
  const dayShift = db.prepare(`SELECT id FROM shifts WHERE time_in = '08:00 AM' LIMIT 1`).get() as { id: number };

  // Create Overnight Shift (10:00 PM - 06:00 AM)
  const nightShiftRes = await req(
    '/api/shifts',
    {
      method: 'POST',
      body: JSON.stringify({
        name: 'Campus Night Watch',
        time_in: '10:00 PM',
        time_out: '06:00 AM',
        grace_minutes: 15,
        rest_days: 'Sat,Sun',
        status: 'Active',
      }),
    },
    adminJar
  );
  assert.equal(nightShiftRes.status, 201);
  const nightShiftId = Number(nightShiftRes.body.id);

  // Create isolated test employees in Dept A and Dept B (avoiding seeded attendance noise)
  const empARes = await req(
    '/api/employees',
    {
      method: 'POST',
      body: JSON.stringify({
        employee_code: 'EMP-B13-DAY',
        full_name: 'Maria Clara Santos',
        email: 'maria.b13@rsucaj.edu.ph',
        department_id: deptA.id,
        position_id: posRow.id,
        shift_id: dayShift.id,
        hired_date: '2023-01-15',
        status: 'Active',
      }),
    },
    adminJar
  );
  assert.equal(empARes.status, 201);
  const empAId = Number(empARes.body.id);

  const empNightRes = await req(
    '/api/employees',
    {
      method: 'POST',
      body: JSON.stringify({
        employee_code: 'EMP-B13-NIGHT',
        full_name: 'Juanito NightGuard',
        email: 'juanito.b13@rsucaj.edu.ph',
        department_id: deptA.id,
        position_id: posRow.id,
        shift_id: nightShiftId,
        hired_date: '2023-01-15',
        status: 'Active',
      }),
    },
    adminJar
  );
  assert.equal(empNightRes.status, 201);
  const empNightId = Number(empNightRes.body.id);

  const empBRes = await req(
    '/api/employees',
    {
      method: 'POST',
      body: JSON.stringify({
        employee_code: 'EMP-B13-DEPTB',
        full_name: 'Pedro CrossDept',
        email: 'pedro.b13@rsucaj.edu.ph',
        department_id: deptB.id,
        position_id: posRow.id,
        shift_id: dayShift.id,
        hired_date: '2023-01-15',
        status: 'Active',
      }),
    },
    adminJar
  );
  assert.equal(empBRes.status, 201);
  const empBId = Number(empBRes.body.id);

  // Create RBAC portal users for HR Officer, Payroll Officer, Department Head (Dept A), and Employee (empA)
  for (const u of [
    { username: 'b13_hr', email: 'b13_hr@rsucaj.edu.ph', full_name: 'HR Tester', role: 'HR Officer', password: hrPass },
    { username: 'b13_pay', email: 'b13_pay@rsucaj.edu.ph', full_name: 'Payroll Tester', role: 'Payroll Officer', password: payrollPass },
    {
      username: 'b13_dhead',
      email: 'b13_dhead@rsucaj.edu.ph',
      full_name: 'Dept A Head',
      role: 'Department Head',
      department_id: deptA.id,
      password: deptHeadPass,
    },
    {
      username: 'b13_emp',
      email: 'b13_emp@rsucaj.edu.ph',
      full_name: 'Maria Clara Santos',
      role: 'Employee',
      employee_id: empAId,
      password: empPass,
    },
  ]) {
    const ur = await req('/api/users', { method: 'POST', body: JSON.stringify({ ...u, must_change_password: false }) }, adminJar);
    assert.equal(ur.status, 201, `Failed creating user ${u.username}: ${ur.text}`);
  }

  const hrJar = await loginAs('b13_hr', hrPass);
  const payJar = await loginAs('b13_pay', payrollPass);
  const deptHeadJar = await loginAs('b13_dhead', deptHeadPass);
  const empJar = await loginAs('b13_emp', empPass);

  try {
    // -------------------------------------------------------------------------
    // TEST 1: Calendar days across 28 / 29 (Leap Year) / 30 / 31-day months
    // -------------------------------------------------------------------------
    await test('Monthly DTR produces exact 28 / 29 (leap year) / 30 / 31 calendar days', async () => {
      const m29 = await req(`/api/reports/dtr/monthly?month=2024-02&employee_id=${empAId}`, {}, adminJar);
      assert.equal(m29.status, 200);
      const rep29 = (m29.body.reports as Array<{ days_in_month: number; is_leap_year: boolean; rows: Array<{ date: string }> }>)[0];
      assert.equal(rep29.days_in_month, 29);
      assert.equal(rep29.is_leap_year, true);
      assert.equal(rep29.rows.length, 29);
      assert.equal(rep29.rows[28].date, '2024-02-29');

      const m28 = await req(`/api/reports/dtr/monthly?month=2025-02&employee_id=${empAId}`, {}, adminJar);
      assert.equal(m28.status, 200);
      const rep28 = (m28.body.reports as Array<{ days_in_month: number; is_leap_year: boolean; rows: Array<{ date: string }> }>)[0];
      assert.equal(rep28.days_in_month, 28);
      assert.equal(rep28.is_leap_year, false);
      assert.equal(rep28.rows.length, 28);
      assert.equal(rep28.rows[27].date, '2025-02-28');

      const m30 = await req(`/api/reports/dtr/monthly?month=2026-04&employee_id=${empAId}`, {}, adminJar);
      assert.equal(m30.status, 200);
      const rep30 = (m30.body.reports as Array<{ days_in_month: number; rows: Array<{ date: string }> }>)[0];
      assert.equal(rep30.days_in_month, 30);
      assert.equal(rep30.rows.length, 30);
      assert.equal(rep30.rows[29].date, '2026-04-30');

      const m31 = await req(`/api/reports/dtr/monthly?month=2026-03&employee_id=${empAId}`, {}, adminJar);
      assert.equal(m31.status, 200);
      const rep31 = (m31.body.reports as Array<{ days_in_month: number; rows: Array<{ date: string }> }>)[0];
      assert.equal(rep31.days_in_month, 31);
      assert.equal(rep31.rows.length, 31);
      assert.equal(rep31.rows[30].date, '2026-03-31');
    });

    // -------------------------------------------------------------------------
    // TEST 2: Overnight shift & 03:00 Asia/Manila cutoff attribution on Monthly DTR
    // -------------------------------------------------------------------------
    await test('Overnight shift and 03:00 Asia/Manila cutoff punches map accurately onto Monthly DTR', async () => {
      const dev = db
        .prepare('SELECT id, name, status FROM devices WHERE is_revoked = 0 LIMIT 1')
        .get() as { id: number; name: string; status: string };

      // 2026-03-10 overnight shift: Time In 22:05 Manila -> Time Out 06:05 next morning (2026-03-11 06:05 Manila)
      const p1 = processKioskPunch(db, {
        employeeCode: 'EMP-B13-NIGHT',
        actionRaw: 'TIME_IN',
        device: dev,
        clientIp: '127.0.0.1',
        serverNowUtc: Date.parse('2026-03-10T14:05:00.000Z'), // 22:05 Asia/Manila
      });
      assert.equal(p1.statusCode, 201);
      assert.equal(p1.body.shift_date, '2026-03-10');

      const p2 = processKioskPunch(db, {
        employeeCode: 'EMP-B13-NIGHT',
        actionRaw: 'TIME_OUT',
        device: dev,
        clientIp: '127.0.0.1',
        serverNowUtc: Date.parse('2026-03-10T22:05:00.000Z'), // 2026-03-11 06:05 Asia/Manila
      });
      assert.equal(p2.statusCode, 200);
      assert.equal(p2.body.shift_date, '2026-03-10');

      // 02:30 Asia/Manila early-morning punch on March 13 (before 03:00 cutoff -> attributed to March 12!)
      const p3 = processKioskPunch(db, {
        employeeCode: 'EMP-B13-DAY',
        actionRaw: 'TIME_IN',
        device: dev,
        clientIp: '127.0.0.1',
        serverNowUtc: Date.parse('2026-03-12T00:00:00.000Z'), // 08:00 Manila
      });
      assert.equal(p3.statusCode, 201);
      const pCutoff = processKioskPunch(db, {
        employeeCode: 'EMP-B13-DAY',
        actionRaw: 'TIME_OUT',
        device: dev,
        clientIp: '127.0.0.1',
        serverNowUtc: Date.parse('2026-03-12T18:30:00.000Z'), // 2026-03-13 02:30 Manila
      });
      assert.equal(pCutoff.statusCode, 200);
      assert.equal(pCutoff.body.shift_date, '2026-03-12');

      const dtrNightRes = await req(`/api/reports/dtr/monthly?month=2026-03&employee_id=${empNightId}`, {}, adminJar);
      assert.equal(dtrNightRes.status, 200);
      const nightRep = (dtrNightRes.body.reports as Array<{ rows: Array<Record<string, unknown>> }>)[0];
      const mar10 = nightRep.rows.find((r) => r.date === '2026-03-10')!;
      assert.equal(mar10.time_in, '10:05 PM');
      assert.equal(mar10.time_out, '06:05 AM');
      assert.equal(mar10.work_hours, '8h 00m');
      assert.ok(String(mar10.overnight_note).includes('Overnight'));

      const dtrDayRes = await req(`/api/reports/dtr/monthly?month=2026-03&employee_id=${empAId}`, {}, adminJar);
      const dayRep = (dtrDayRes.body.reports as Array<{ rows: Array<Record<string, unknown>> }>)[0];
      const mar12 = dayRep.rows.find((r) => r.date === '2026-03-12')!;
      assert.equal(mar12.time_in, '08:00 AM');
      assert.equal(mar12.time_out, '02:30 AM');
    });

    // -------------------------------------------------------------------------
    // TEST 3: Approved Corrections, Leaves (Half-Day, OB, Cancelled/Rejected), Holidays & Rest Days
    // -------------------------------------------------------------------------
    await test('Monthly DTR & Leaves Report reflect approved corrections, leaves (Half-Day/OB), holidays, and rest days', async () => {
      // Seed clean attendance on March 2, 3, 4 (2026-03-04 intentionally Missing Time Out!)
      db.prepare(
        `INSERT INTO attendance_records (employee_id, date, time_in, time_out, work_hours, late_minutes, undertime_minutes, overtime_minutes, status, device_name, remarks)
         VALUES (?, '2026-03-02', '08:00 AM', '05:00 PM', '08h 00m', 0, 0, 0, 'Present', 'Kiosk', '')`
      ).run(empAId);
      db.prepare(
        `INSERT INTO attendance_records (employee_id, date, time_in, time_out, work_hours, late_minutes, undertime_minutes, overtime_minutes, status, device_name, remarks)
         VALUES (?, '2026-03-03', '08:25 AM', '05:00 PM', '07h 35m', 10, 0, 0, 'Late', 'Kiosk', '')`
      ).run(empAId);

      // Submit a correction on 2026-03-02 for Time Out -> 06:00 PM
      const corrRes = await req(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empAId,
            attendance_date: '2026-03-02',
            request_type: 'Time Out',
            requested_time: '06:00 PM',
            reason: 'Extended lab supervision',
            document_reference: 'CORR-B13-01',
          }),
        },
        adminJar
      );
      assert.equal(corrRes.status, 201);
      const corrId = Number(corrRes.body.id);

      // While correction is Pending, DTR must be DRAFT_UNRESOLVED and block signing
      const draftCheck = await req(`/api/reports/dtr/monthly?month=2026-03&employee_id=${empAId}`, {}, adminJar);
      const draftRep = (draftCheck.body.reports as Array<Record<string, unknown>>)[0];
      assert.equal(draftRep.dtr_state, 'DRAFT_UNRESOLVED');
      assert.equal(draftRep.is_draft, true);

      // Approve correction
      const appCorr = await req(
        `/api/corrections/${corrId}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved', reviewer_notes: 'Verified' }) },
        hrJar
      );
      assert.equal(appCorr.status, 200);

      // Submit & approve a half-day Vacation Leave on 2026-03-16 and an OB on 2026-03-17
      const lvHalf = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empAId,
            leave_type: 'Vacation Leave',
            start_date: '2026-03-16',
            end_date: '2026-03-16',
            day_portion: 'HALF_AM',
            reason: 'Morning personal errand',
          }),
        },
        adminJar
      );
      assert.equal(lvHalf.status, 201);
      const appHalf = await req(
        `/api/leaves/${Number(lvHalf.body.id)}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved', reviewer_notes: 'Approved half-day' }) },
        hrJar
      );
      assert.equal(appHalf.status, 200);

      const lvOb = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empAId,
            leave_type: 'Official Business',
            start_date: '2026-03-17',
            end_date: '2026-03-17',
            reason: 'CHED regional conference',
            document_reference: 'TO-2026-031',
          }),
        },
        adminJar
      );
      assert.equal(lvOb.status, 201);
      const appOb = await req(
        `/api/leaves/${Number(lvOb.body.id)}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved', reviewer_notes: 'Approved OB' }) },
        hrJar
      );
      assert.equal(appOb.status, 200);

      // Submit and Reject/Cancel a leave on 2026-03-18 — must NOT appear as approved on DTR
      const lvRej = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empAId,
            leave_type: 'Sick Leave',
            start_date: '2026-03-18',
            end_date: '2026-03-18',
            reason: 'Test rejected',
          }),
        },
        adminJar
      );
      assert.equal(lvRej.status, 201);
      const rejLv = await req(
        `/api/leaves/${Number(lvRej.body.id)}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Rejected', reviewer_notes: 'No med cert' }) },
        hrJar
      );
      assert.equal(rejLv.status, 200);

      // Add a holiday in March 2026
      await req(
        '/api/holidays',
        {
          method: 'POST',
          body: JSON.stringify({ date: '2026-03-20', name: 'RSU Cajidiocan Charter Day', type: 'Regular' }),
        },
        adminJar
      );

      const dtrAfter = await req(`/api/reports/dtr/monthly?month=2026-03&employee_id=${empAId}`, {}, adminJar);
      assert.equal(dtrAfter.status, 200);
      const rep = (dtrAfter.body.reports as Array<{
        totals: Record<string, number>;
        rows: Array<Record<string, unknown>>;
      }>)[0];

      const mar02 = rep.rows.find((r) => r.date === '2026-03-02')!;
      assert.equal(mar02.time_out, '06:00 PM');
      const mar16 = rep.rows.find((r) => r.date === '2026-03-16')!;
      assert.equal(mar16.status, 'On Leave');
      assert.ok(String(mar16.leave_label).includes('HALF_AM'));
      const mar17 = rep.rows.find((r) => r.date === '2026-03-17')!;
      assert.equal(mar17.status, 'OB');
      const mar18 = rep.rows.find((r) => r.date === '2026-03-18')!;
      assert.notEqual(mar18.status, 'On Leave');
      const mar20 = rep.rows.find((r) => r.date === '2026-03-20')!;
      assert.equal(mar20.status, 'Holiday');
      assert.ok(String(mar20.holiday_label).includes('RSU Cajidiocan Charter Day'));
      const mar07 = rep.rows.find((r) => r.date === '2026-03-07')!; // Saturday
      assert.equal(mar07.status, 'Rest Day');

      assert.equal(rep.totals.approved_corrections_count, 1);

      // Check Leaves Report summary + leave_balances
      const leaveRep = await req(`/api/reports/leaves?month=2026-03&employee_id=${empAId}`, {}, adminJar);
      assert.equal(leaveRep.status, 200);
      assert.equal((leaveRep.body.summary as { approved_count: number }).approved_count, 2);
      assert.equal((leaveRep.body.summary as { rejected_count: number }).rejected_count, 1);
      assert.ok(Array.isArray(leaveRep.body.leave_balances) && leaveRep.body.leave_balances.length === 1);
    });

    // -------------------------------------------------------------------------
    // TEST 4: Missing Times Never Fabricated + Strict Blocking + Signed/Unsigned/Stale Lifecycle
    // -------------------------------------------------------------------------
    await test('Missing punches stay null/MISSING, block strict export/sign (409), and detect stale post-sign edits', async () => {
      // Insert Missing Time Out on 2026-03-04 for empA
      db.prepare(
        `INSERT INTO attendance_records (employee_id, date, time_in, time_out, work_hours, late_minutes, undertime_minutes, overtime_minutes, status, device_name, remarks)
         VALUES (?, '2026-03-04', '08:00 AM', NULL, '00h 00m', 0, 0, 0, 'Missing Time Out', 'Kiosk', 'Forgot out punch')`
      ).run(empAId);

      const dtrMissing = await req(`/api/reports/dtr/monthly?month=2026-03&employee_id=${empAId}`, {}, adminJar);
      const repMissing = (dtrMissing.body.reports as Array<{
        dtr_state: string;
        is_draft: boolean;
        is_signed: boolean;
        unresolved_blockers: Array<{ type: string; date: string }>;
        rows: Array<Record<string, unknown>>;
      }>)[0];
      assert.equal(repMissing.dtr_state, 'DRAFT_UNRESOLVED');
      assert.equal(repMissing.is_draft, true);
      assert.equal(repMissing.is_signed, false);
      const mar04 = repMissing.rows.find((r) => r.date === '2026-03-04')!;
      assert.equal(mar04.time_out, null, 'Missing time_out must remain null and NEVER be silently fabricated');
      assert.ok(repMissing.unresolved_blockers.some((b) => b.type === 'MISSING_PUNCH' && b.date === '2026-03-04'));

      // Strict PDF and strict CSV exports must reject with 409 DTR_UNRESOLVED_DRAFT
      const strictPdf = await req(`/api/reports/dtr/export.pdf?month=2026-03&employee_id=${empAId}&strict=true`, {}, adminJar);
      assert.equal(strictPdf.status, 409);
      assert.equal(strictPdf.body.code, 'DTR_UNRESOLVED_DRAFT');

      const strictCsv = await req(`/api/reports/dtr/export.csv?month=2026-03&employee_id=${empAId}&strict=true`, {}, adminJar);
      assert.equal(strictCsv.status, 409);

      // Signing must also be rejected while unresolved blockers exist
      const blockSign = await req(
        '/api/reports/dtr/sign',
        { method: 'POST', body: JSON.stringify({ employee_id: empAId, month: '2026-03', role_action: 'BOTH' }) },
        adminJar
      );
      assert.equal(blockSign.status, 409);

      // Non-strict Draft PDF succeeds and carries DRAFT - UNRESOLVED watermark & CS Form 48 Pending notice
      const draftPdf = await req(`/api/reports/dtr/export.pdf?month=2026-03&employee_id=${empAId}`, {}, adminJar);
      assert.equal(draftPdf.status, 200);
      assert.equal(draftPdf.headers.get('content-type'), 'application/pdf');
      const inspectedDraft = extractPdfInspectInfo(draftPdf.buffer);
      assert.equal(inspectedDraft.header, '%PDF-1.3');
      assert.ok(inspectedDraft.eof.endsWith('%%EOF'), `Expected PDF to end with %%EOF, got ${inspectedDraft.eof}`);
      assert.equal(inspectedDraft.hasA4PortraitMediaBox, true);
      assert.equal(inspectedDraft.hasImageXObject, true);
      assert.ok(pdfTextContains(inspectedDraft.decompressedText, 'DRAFT - UNRESOLVED'));
      assert.ok(pdfTextContains(inspectedDraft.decompressedText, 'CS FORM 48 REFERENCE PENDING RSU APPROVAL'));
      assert.ok(pdfTextContains(inspectedDraft.decompressedText, 'Maria Clara Santos'));
      assert.ok(pdfTextContains(inspectedDraft.decompressedText, 'DR. ELENA R. CAJIDIOCAN'));
      assert.ok(pdfTextContains(inspectedDraft.decompressedText, 'Employee Signature'));

      // Resolve Missing Time Out cleanly via SQLite update (simulating manual/correction fix)
      db.prepare(
        `UPDATE attendance_records SET time_out = '05:00 PM', work_hours = '08h 00m', status = 'Present' WHERE employee_id = ? AND date = '2026-03-04'`
      ).run(empAId);

      const readyCheck = await req(`/api/reports/dtr/monthly?month=2026-03&employee_id=${empAId}`, {}, adminJar);
      const repReady = (readyCheck.body.reports as Array<{ dtr_state: string; is_signed: boolean }>)[0];
      assert.equal(repReady.dtr_state, 'READY_UNSIGNED');
      assert.equal(repReady.is_signed, false);

      // Exporting with require_signed=true fails with 409 while unsigned
      const reqSignedFail = await req(`/api/reports/dtr/export.pdf?month=2026-03&employee_id=${empAId}&require_signed=true`, {}, adminJar);
      assert.equal(reqSignedFail.status, 409);

      // Employee signs own DTR -> then HR verifies
      const empSign = await req(
        '/api/reports/dtr/sign',
        { method: 'POST', body: JSON.stringify({ employee_id: empAId, month: '2026-03', role_action: 'EMPLOYEE_SIGN' }) },
        empJar
      );
      assert.equal(empSign.status, 200);

      const hrSign = await req(
        '/api/reports/dtr/sign',
        { method: 'POST', body: JSON.stringify({ employee_id: empAId, month: '2026-03', role_action: 'SUPERVISOR_VERIFY' }) },
        hrJar
      );
      assert.equal(hrSign.status, 200);
      const signedReport = hrSign.body.report as { dtr_state: string; is_signed: boolean; is_draft: boolean };
      assert.equal(signedReport.dtr_state, 'SIGNED');
      assert.equal(signedReport.is_signed, true);
      assert.equal(signedReport.is_draft, false);

      // Now require_signed=true PDF succeeds and has NO DRAFT - UNRESOLVED watermark
      const signedPdf = await req(`/api/reports/dtr/export.pdf?month=2026-03&employee_id=${empAId}&require_signed=true`, {}, adminJar);
      assert.equal(signedPdf.status, 200);
      const inspectedSigned = extractPdfInspectInfo(signedPdf.buffer);
      assert.equal(pdfTextContains(inspectedSigned.decompressedText, 'DRAFT - UNRESOLVED'), false);
      assert.ok(pdfTextContains(inspectedSigned.decompressedText, 'VERIFIED & SIGNED'));

      // Modify attendance time/overtime after signing -> snapshot SHA-256 mismatch flips state to SIGNED_STALE
      db.prepare(`UPDATE attendance_records SET time_out = '05:15 PM', overtime_minutes = 15 WHERE employee_id = ? AND date = '2026-03-04'`).run(empAId);
      const staleCheck = await req(`/api/reports/dtr/monthly?month=2026-03&employee_id=${empAId}`, {}, adminJar);
      const repStale = (staleCheck.body.reports as Array<{ dtr_state: string; is_signed: boolean; is_draft: boolean }>)[0];
      assert.equal(repStale.dtr_state, 'SIGNED_STALE');
      assert.equal(repStale.is_signed, false);
      assert.equal(repStale.is_draft, true);

      // Revoke test
      const revokeRes = await req(
        '/api/reports/dtr/revoke',
        { method: 'POST', body: JSON.stringify({ employee_id: empAId, month: '2026-03', reason: 'Re-check' }) },
        hrJar
      );
      assert.equal(revokeRes.status, 200);
      assert.equal((revokeRes.body.report as { dtr_state: string }).dtr_state, 'READY_UNSIGNED');
    });

    // -------------------------------------------------------------------------
    // TEST 5: Role Authorization & Department Scoping (401 / 403 Unauthorized Downloads)
    // -------------------------------------------------------------------------
    await test('Unauthorized report and CSV/PDF download attempts are rejected with 401 and 403', async () => {
      // Unauthenticated
      assert.equal((await req('/api/reports/attendance')).status, 401);
      assert.equal((await req('/api/reports/dtr/export.pdf?month=2026-03')).status, 401);
      assert.equal((await req('/api/reports/payroll/export.csv')).status, 401);

      // HR Officer denied Payroll and Audit Logs reports/exports
      assert.equal((await req('/api/reports/payroll', {}, hrJar)).status, 403);
      assert.equal((await req('/api/reports/payroll/export.pdf', {}, hrJar)).status, 403);
      assert.equal((await req('/api/reports/audit-logs/export.csv', {}, hrJar)).status, 403);

      // Payroll Officer denied Audit Logs exports
      assert.equal((await req('/api/reports/audit-logs/export.pdf', {}, payJar)).status, 403);

      // Department Head (Dept A) denied cross-department or cross-dept employee download, allowed own dept
      assert.equal((await req(`/api/reports/attendance?department_id=${deptB.id}`, {}, deptHeadJar)).status, 403);
      assert.equal((await req(`/api/reports/dtr/export.pdf?month=2026-03&employee_id=${empBId}`, {}, deptHeadJar)).status, 403);
      const deptHeadOwn = await req('/api/reports/dtr/monthly?month=2026-03', {}, deptHeadJar);
      assert.equal(deptHeadOwn.status, 200);
      const dhReps = deptHeadOwn.body.reports as Array<{ employee: { department_id: number } }>;
      assert.ok(dhReps.length >= 1);
      assert.ok(dhReps.every((r) => r.employee.department_id === deptA.id));

      // Employee denied global reports/exports and other employees' DTR, allowed self-service my-dtr
      assert.equal((await req('/api/reports/attendance', {}, empJar)).status, 403);
      assert.equal((await req('/api/reports/employees/export.csv', {}, empJar)).status, 403);
      assert.equal((await req('/api/reports/dtr/export.pdf?month=2026-03', {}, empJar)).status, 403);
      assert.equal((await req(`/api/reports/my-dtr?month=2026-03&employee_id=${empBId}`, {}, empJar)).status, 403);
      const myDtr = await req('/api/reports/my-dtr?month=2026-03', {}, empJar);
      assert.equal(myDtr.status, 200);
      const myPdf = await req('/api/reports/my-dtr/export.pdf?month=2026-03', {}, empJar);
      assert.equal(myPdf.status, 200);
      assert.equal(myPdf.headers.get('content-type'), 'application/pdf');
    });

    // -------------------------------------------------------------------------
    // TEST 6: Host Timezone Invariance (America/Los_Angeles vs Asia/Manila)
    // -------------------------------------------------------------------------
    await test('DTR calendar & snapshot computations are invariant under non-Manila host TZ', async () => {
      const prevTz = process.env.TZ;
      try {
        process.env.TZ = 'Asia/Manila';
        const manilaBuilt = buildMonthlyDtrReports(db, {
          month: '2026-03',
          empId: empNightId,
          serverNowUtc: virtualNowMs,
        });

        process.env.TZ = 'America/Los_Angeles';
        const laBuilt = buildMonthlyDtrReports(db, {
          month: '2026-03',
          empId: empNightId,
          serverNowUtc: virtualNowMs,
        });

        assert.equal(laBuilt.reports[0].rows.length, manilaBuilt.reports[0].rows.length);
        assert.equal(laBuilt.reports[0].snapshot_sha256, manilaBuilt.reports[0].snapshot_sha256);
        assert.deepEqual(laBuilt.reports[0].totals, manilaBuilt.reports[0].totals);
      } finally {
        if (prevTz === undefined) delete process.env.TZ;
        else process.env.TZ = prevTz;
      }
    });

    // -------------------------------------------------------------------------
    // TEST 7: Very Large Exports (5,200 Attendance Rows + 2,500 Audit Rows), Pagination & Formula Neutralization
    // -------------------------------------------------------------------------
    await test('Full-range pagination, unclipped 5,200+ row streaming CSV, multi-page PDF, and formula neutralization', async () => {
      // Formula-injection test employee
      const injEmpRes = await req(
        '/api/employees',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_code: 'EMP-B13-INJ',
            full_name: '=HYPERLINK("http://evil.example","Click")',
            email: 'inj.b13@rsucaj.edu.ph',
            department_id: deptB.id,
            position_id: posRow.id,
            shift_id: dayShift.id,
            hired_date: '2024-01-10',
            status: 'Active',
          }),
        },
        adminJar
      );
      assert.equal(injEmpRes.status, 201);
      const injEmpId = Number(injEmpRes.body.id);

      // Verify formula-escape unit behavior directly as well
      assert.equal(escapeCsvCell('=SUM(A1)'), "'=SUM(A1)");
      assert.equal(escapeCsvCell('  +1+1'), "'  +1+1");
      assert.equal(escapeCsvCell('-cmd'), "'-cmd");
      assert.equal(escapeCsvCell('@SUM(1,2)'), '"@SUM(1,2)"'.replace('"@', `"'@`));

      // Bulk insert 5,200 attendance_records + 2,500 audit_logs inside fast transaction
      const insertTx = db.transaction(() => {
        const attStmt = db.prepare(
          `INSERT INTO attendance_records (employee_id, date, time_in, time_out, work_hours, late_minutes, undertime_minutes, overtime_minutes, status, device_name, remarks)
           VALUES (?, ?, '08:00 AM', '05:00 PM', '08h 00m', 0, 0, 0, 'Present', 'Batch Kiosk', ?)`
        );
        const startDay = Date.UTC(2010, 0, 1);
        for (let i = 0; i < 5200; i++) {
          const dt = new Date(startDay + i * 86_400_000).toISOString().slice(0, 10);
          attStmt.run(injEmpId, dt, i === 0 ? '  +cmd|"/C calc"!A0' : `Batch day ${i}`);
        }

        const audStmt = db.prepare(
          `INSERT INTO audit_logs (timestamp, username, activity, module, status, ip_address)
           VALUES ('2026-03-15 10:00:00', 'batch_auditor', ?, 'Reports', 'Success', '127.0.0.1')`
        );
        for (let i = 0; i < 2500; i++) {
          audStmt.run(`Bulk security event #${i}`);
        }
      });
      insertTx();

      // Paginated attendance query reaches page 2 properly
      const page2 = await req(`/api/reports/attendance?employee_id=${injEmpId}&page=2&limit=50`, {}, adminJar);
      assert.equal(page2.status, 200);
      assert.equal((page2.body.rows as unknown[]).length, 50);
      assert.equal((page2.body.pagination as { total: number }).total, 5200);
      assert.equal((page2.body.pagination as { totalPages: number }).totalPages, 104);

      // Streaming CSV returns ALL 5,200 attendance rows (no old LIMIT 2000 truncation!) + neutralizes dangerous cells
      const attCsv = await req(`/api/reports/attendance/export.csv?employee_id=${injEmpId}`, {}, adminJar);
      assert.equal(attCsv.status, 200);
      assert.ok((attCsv.headers.get('content-type') || '').startsWith('text/csv'));
      assert.ok((attCsv.headers.get('content-disposition') || '').includes('filename="SAVAGE-RSUCAJ-attendance-'));
      const csvLines = attCsv.text.trimEnd().split('\r\n');
      assert.equal(csvLines.length, 5201, 'Header + all 5,200 rows must stream unclipped');
      assert.ok(attCsv.text.includes("'=HYPERLINK("), 'Formula payload in employee_name must be neutralized');
      assert.ok(attCsv.text.includes("'  +cmd|"), 'Leading-space formula payload in remarks must be neutralized');

      // Audit Logs streaming CSV returns all >= 2,500 rows (no old LIMIT 200 truncation!)
      const audCsv = await req('/api/reports/audit-logs/export.csv', {}, adminJar);
      assert.equal(audCsv.status, 200);
      const audLines = audCsv.text.trimEnd().split('\r\n');
      assert.ok(audLines.length >= 2501, `Expected >= 2501 audit CSV lines, got ${audLines.length}`);

      // Large PDF renders valid multi-page A4 document
      const audPdf = await req('/api/reports/audit-logs/export.pdf', {}, adminJar);
      assert.equal(audPdf.status, 200);
      assert.equal(audPdf.headers.get('content-type'), 'application/pdf');
      const pageHdr = Number(audPdf.headers.get('x-report-page-count') || 0);
      assert.ok(pageHdr > 20, `Expected multi-page audit PDF (>20 pages), got ${pageHdr}`);
      const inspectedAud = extractPdfInspectInfo(audPdf.buffer);
      assert.equal(inspectedAud.header, '%PDF-1.3');
      assert.equal(inspectedAud.hasA4PortraitMediaBox, true);
    });

    // -------------------------------------------------------------------------
    // TEST 8: Payroll & Masterlist Reports Reconcile 100% Against SQLite Database
    // -------------------------------------------------------------------------
    await test('Payroll, Employees, and DTR report totals reconcile 100% against SQLite DB', async () => {
      // Create and Finance-approve a payroll policy, then compute payroll for 2026-03-01..2026-03-15
      const template = getPayrollPolicyTemplate();
      const actor = { userId: 1, username: 'b13_pay', role: 'Payroll Officer', ipAddress: '127.0.0.1' };
      const createdPol = createPayrollPolicy(
        db,
        {
          policy_code: 'RSU-B13-RPT-2026',
          policy_name: 'RSU B13 Reports Reconciliation Policy',
          effective_from: '2026-01-01',
          rules: template.fields.rules,
        },
        actor,
        virtualNowMs
      );
      approvePayrollPolicyByFinance(
        db,
        createdPol.id,
        { approval_reference: 'MEMO-B13-FIN-01', notes: 'Reconciliation test approval' },
        actor,
        virtualNowMs
      );

      const runResult = computeOrRecomputePayrollRun(
        db,
        {
          period_label: 'March 1-15, 2026 (B13 Reconcile)',
          start_date: '2026-03-01',
          end_date: '2026-03-15',
          policy_id: createdPol.id,
        },
        actor,
        virtualNowMs
      );

      const payRep = await req(`/api/reports/payroll?run_id=${runResult.id}`, {}, payJar);
      assert.equal(payRep.status, 200);
      const summary = payRep.body.summary as { total_basic_pay: number; total_net_pay: number; total_deductions: number };
      assert.equal(summary.total_basic_pay, runResult.totals.total_basic_pay);
      assert.equal(summary.total_deductions, runResult.totals.total_deductions);
      assert.equal(summary.total_net_pay, runResult.totals.total_net_pay);

      const payPdf = await req(`/api/reports/payroll/export.pdf?run_id=${runResult.id}`, {}, payJar);
      assert.equal(payPdf.status, 200);
      const inspectedPay = extractPdfInspectInfo(payPdf.buffer);
      assert.equal(inspectedPay.hasA4PortraitMediaBox, true);
      assert.ok(pdfTextContains(inspectedPay.decompressedText, 'PAYROLL LEDGER'));

      // Reconcile Employees Masterlist count against SQLite
      const dbEmpCount = (db.prepare('SELECT COUNT(*) as c FROM employees').get() as { c: number }).c;
      const empRep = await req('/api/reports/employees', {}, adminJar);
      assert.equal(empRep.status, 200);
      assert.equal((empRep.body.pagination as { total: number }).total, dbEmpCount);
      assert.equal((empRep.body.summary as { total_employees: number }).total_employees, dbEmpCount);

      // Reconcile Monthly DTR totals for empAId directly against SQLite attendance_records
      const dtrCheck = await req(`/api/reports/dtr/monthly?month=2026-03&employee_id=${empAId}`, {}, adminJar);
      const dtrRep = (dtrCheck.body.reports as Array<{
        totals: { days_present: number; days_late: number; total_late_minutes: number; days_on_leave: number; days_ob: number };
      }>)[0];
      const directSql = db
        .prepare(
          `SELECT
             SUM(CASE WHEN status IN ('Present','Late','Undertime') THEN 1 ELSE 0 END) as present_days,
             SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) as late_days,
             COALESCE(SUM(late_minutes), 0) as late_mins,
             SUM(CASE WHEN status = 'On Leave' THEN 1 ELSE 0 END) as leave_days,
             SUM(CASE WHEN status = 'OB' THEN 1 ELSE 0 END) as ob_days
           FROM attendance_records WHERE employee_id = ? AND date >= '2026-03-01' AND date <= '2026-03-31'`
        )
        .get(empAId) as { present_days: number; late_days: number; late_mins: number; leave_days: number; ob_days: number };

      assert.equal(dtrRep.totals.days_present, directSql.present_days);
      assert.equal(dtrRep.totals.days_late, directSql.late_days);
      assert.equal(dtrRep.totals.total_late_minutes, directSql.late_mins);
      assert.equal(dtrRep.totals.days_on_leave, directSql.leave_days);
      assert.equal(dtrRep.totals.days_ob, directSql.ob_days);
    });
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    closeDatabaseSafely(db);
    try {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    } catch {
      // ignore
    }
  }

  console.log(`Summary: ${passed}/${passed + failed} reports & Monthly DTR tests passed.`);
  if (failed > 0) process.exit(1);
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
