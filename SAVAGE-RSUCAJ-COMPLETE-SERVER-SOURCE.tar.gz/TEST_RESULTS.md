# TEST RESULTS — SAVAGE-RSUCAJ BUILD 36 Web Face Recognition Kiosk (`/kiosk`) (2026-11-22)

**Execution Date:** `2026-11-22`  
**Runtime:** Linux x64 · Node.js `v22.23.2` · Vite 8 · Chromium Headless Shell `1247` (`playwright-core`)  
**Schema Version:** `011` (`web_kiosk_sessions`, `web_kiosk_challenges`, additive `devices` & `settings` keys)  
**Production Verdict:** **`NOT PRODUCTION READY`**

| Category | Command Executed | Actual Result | Status |
|---|---|---|---|
| Static Type Check | `npm run lint` (`tsc --noEmit`) | `0` errors | **PASS** |
| Production Bundle Build | `npm run build` (`vite build`) | Built cleanly (`dist/`) | **PASS** |
| BUILD 36 Web Kiosk Backend, Biometric Math & Security Suite (BUILD 20 tensor codecs, softmax/NaN fail-closed, model disk check, 192D L2 norm, `Permissions-Policy`, activation & `HttpOnly` cookie, replay block, Admin PIN scrypt unlock, settings/sync, front-face enrollment & cross-employee `409`, server-side 1:N attendance, tampered claim ignored, Time In/Out & `"Already taken attendance"` `409`, instant device revocation, production fail-closed `503` & `403` liveness lock) | `npx tsx --test tests/web-kiosk-build36.test.mjs` | `12/12` assertions passed (`1.89 s`) | **PASS** |
| BUILD 36 Playwright 16-Screen & 4-Viewport Browser E2E (`1024×600`, `390×844`, `768×1024`, `1366×768` + 19 PNG screenshots inspected) | `npx tsx --test tests/web-kiosk-browser-e2e.test.mjs` | `19/19` screen/viewport checks passed (`0` page errors, `0` broken images, `0px` horizontal overflow, `0` manual Capture buttons on Screen 11, `0` forbidden left/right head-turn prompts; `10.29 s`) | **PASS** |
| Core Unit & Security Regression | `npm run test:unit` | `15/15` passed | **PASS** |
| Attendance Policy & Overnight/Cutoff Regression | `npm run test:attendance` | `18/18` passed | **PASS** |
| Payroll Engine & Payslip Isolation Regression | `npm run test:payroll` | `10/10` passed | **PASS** |
| Employee Portal 18-Screen Backend & RBAC Regression | `npx tsx --test tests/employee-portal-18screens.test.mjs` | `1/1` suite passed (`1.33 s`) | **PASS** |
| Live TFLite Neural Model Inference (3 `.tflite` binaries) | *(Models absent from workspace/ZIP; Node.js TFLite runtime not deployed)* | `0/3` verified on disk; production fails closed (`503`) | **BLOCKED** |
| Physical Camera & Anti-Spoofing Trials (Windows PC, Android Phone/Tablet, Raspberry Pi 3 Model B) | *(Physical devices not attached to container)* | Printed-photo, phone-screen, video-replay & thermal soak unexecuted | **BLOCKED** |
| Pre-Existing Upstream Legacy Baseline Suites (`test:build30`, `test:db`, `test:api`, `test:admin-ops`, `test:sync`, `test:reports`) | *(Unmodified legacy assertions from BUILD 17/30 expecting older schema `009`/`010`, sibling Android repo path, or `must_change_password=0`)* | Not modified in BUILD 36 | **NOT TESTED (Pre-existing upstream baseline)** |

---

# TEST RESULTS — Employee Portal Master Prompt 03 Verification (2026-11-22)

**Execution Date:** `2026-11-22`  
**Runtime:** Linux x64 · Node.js `v22.23.2` · Vite 8 · Chromium Headless Shell (`playwright-core`)

| Category | Command Executed | Actual Result | Status |
|---|---|---|---|
| Static Type Check | `npm run lint` (`tsc --noEmit`) | `0` errors | **PASS** |
| Production Bundle Build | `npm run build` (`vite build`) | Built cleanly (`dist/`) | **PASS** |
| Master Audit Suite (Security RBAC, Overnight Shift, Duplicate Correction `409`, Future-Date `400`, Supporting Doc Persistence, Live Attendance & Notification SSE, Browser Back, Session Expiry, Password Rotation, WCAG Accessibility & All-18 Responsive × 4 Viewports + 21 Screenshots) | `npx tsx --test tests/employee-portal-master-audit.test.mjs` | `4/4` passed (`0` page/console errors, `0` broken images, `0px` overflow, `0` nameless buttons, `0` unlabeled controls) | **PASS** |
| Employee Portal API, RBAC, PDF & Isolation | `npx tsx --test tests/employee-portal-18screens.test.mjs` | `1/1` suite passed | **PASS** |
| Employee Portal 18-Screen × 5-Viewport Playwright E2E | `npx tsx --test tests/employee-portal-browser-e2e.test.mjs` | `1/1` suite passed | **PASS** |
| Core Unit & Security Tests | `npm run test:unit` | `15/15` passed | **PASS** |
| Attendance Policy & Overnight/Cutoff Engine | `npm run test:attendance` | `18/18` passed | **PASS** |
| Payroll Engine & Employee Payslip Isolation | `npm run test:payroll` | `10/10` passed | **PASS** |
| Admin Ops & Security Hardening | `npm run test:admin-ops` | `7/8` passed (`1` pre-existing upstream Schema `'010' !== '009'` assertion) | **FAIL (pre-existing schema baseline)** |
| Sync & Reports Legacy Suites | `npm run test:sync`, `npm run test:reports` | `test:sync` `5/6`, `test:reports` `6/8` (pre-existing upstream BUILD 30 forced `must_change_password=1` on new Employee accounts) | **FAIL (pre-existing BUILD 30 policy baseline)** |
| Physical Mobile Devices, Kiosk Hardware & Institutional Sign-Off | *(Outside container)* | `RG-05`–`RG-10` blocked | **BLOCKED** |

---

# TEST RESULTS — Employee Portal Master Prompt 02 Audit (2026-11-22)

**Execution Date:** `2026-11-22`  
**Runtime:** Linux x64 · Node.js `v22.23.2` · Vite 8 · Chromium Headless Shell (`playwright-core`)

| Category | Command Executed | Actual Result | Status |
|---|---|---|---|
| Static Type Check | `npm run lint` (`tsc --noEmit`) | 0 errors | **PASS** |
| Production Bundle Build | `npm run build` (`vite build`) | Built cleanly (`dist/`) | **PASS** |
| Master Prompt 02 Complete Audit Suite (Security RBAC, Overnight Shift, Live SSE, Browser Back, Session Expiry, All-18 Responsive × 4 Viewports & 21 Runtime Screenshots) | `npx tsx --test tests/employee-portal-master-audit.test.mjs` | 4/4 passed (0 page errors, 0 console errors, 0 broken images, 0px overflow across all 18 screens) | **PASS** |
| Employee Portal API, RBAC, PDF & Isolation | `npx tsx --test tests/employee-portal-18screens.test.mjs` | 1/1 suite (all 9 flow blocks) | **PASS** |
| Employee Portal 18-Screen × 5-Viewport Playwright E2E | `npx tsx --test tests/employee-portal-browser-e2e.test.mjs` | 1/1 suite (18 screens, 5 viewports) | **PASS** |
| Core Unit Tests | `npm run test:unit` | 15/15 passed | **PASS** |
| Payroll Engine & Employee Payslip Isolation | `npm run test:payroll` | 10/10 passed | **PASS** |
| Physical Mobile Devices & Kiosk Hardware | *(Not attached in container)* | — | **BLOCKED** |
| Institutional HRMO CS Form 48 & Finance Payroll Sign-Off | *(Pending campus offices)* | — | **BLOCKED** |

---

# TEST RESULTS — Employee Portal 18-Screen Rebuild (2026-11-22)

**Execution Date:** `2026-11-22`  
**Runtime:** Linux x64 · Node.js `v22.23.2` · Vite 8 · Chromium Headless Shell (`playwright-core`)

| Category | Command Executed | Actual Result | Status |
|---|---|---|---|
| Static Type Check | `npm run lint` (`tsc --noEmit`) | 0 errors | **PASS** |
| Production Bundle Build | `npm run build` (`vite build`) | Built cleanly (`dist/`) | **PASS** |
| Employee Portal API, RBAC, PDF & Isolation | `node scripts/run-tsx.mjs tests/employee-portal-18screens.test.mjs` | 1/1 suite (all 9 flow blocks) | **PASS** |
| Employee Portal 18-Screen × 5-Viewport Playwright E2E | `node scripts/run-tsx.mjs tests/employee-portal-browser-e2e.test.mjs` | 1/1 suite (18 screens, 5 viewports, 0 page errors, 0 broken images, 0px overflow) | **PASS** |
| Core Unit Tests | `npm run test:unit` | 15/15 passed | **PASS** |
| Payroll Engine & Employee Payslip Isolation | `npm run test:payroll` | 10/10 passed | **PASS** |
| Build 30 Hardening, Realtime, Employee Accounts & Integration | `npm run test:build30` | 59/60 passed (1 fail: sibling Android repo path `/app/finalngfacerecogantion-main/...` absent in workspace) | **FAIL (external sibling path)** |
| Legacy DB / API / Corrections-Leaves Regression | `test:db`, `test:api`, `test:corrections-leaves` | `test:db` 9/10, `test:api` 17/20, `test:corrections-leaves` 9/13 (pre-existing upstream Schema `010` vs `009` & RBAC baseline assertions in imported repo) | **PARTIAL / PRE-EXISTING** |
| Physical Mobile Devices & Kiosk Hardware | *(Not attached in container)* | — | **NOT TESTED / BLOCKED** |

---

# TEST RESULTS — SAVAGE-RSUCAJ Smart Attendance Admin Portal (BUILD 17 / v1.13.0)

**Execution Date (UTC):** `2026-11-21T10:00:03Z`  
**Runtime:** Linux x64 · Node.js `v22.23.2` · npm `>=10.0.0` · Chromium Headless Shell (`playwright-core`)  
**Schema Version:** `009` (live `./data/savage_rsucaj.db` verified untouched)  
**Mandatory Release Gate Verdict:** **`NO-GO` (`PASS=4`, `FAIL=0`, `BLOCKED=6`, exit code `2`)**

---

## Summary Matrix

| Category | Command Executed | Passed | Failed | Status |
|---|---|---:|---:|---|
| TypeScript Static Typecheck | `npm run lint` (`tsc --noEmit`) | 1 | 0 | **PASS** (`0` errors) |
| Production Frontend Bundle | `npm run build` (`vite build`) | 1 | 0 | **PASS** (`754 ms`) |
| Dependency Security Audit | `bun audit` | 1 | 0 | **PASS** (`0` vulnerabilities / 277 packages) |
| Unit Tests (Env, Mode, Security, Crypto) | `npm run test:unit` | 15 | 0 | **PASS** |
| Database Durability, Migrations (`001`–`009`), WAL, Backup & Restore | `npm run test:db` | 10 | 0 | **PASS** |
| Attendance Policy, `Asia/Manila`, `03:00` Cutoff, Reconciliation & Immutability | `npm run test:attendance` | 18 | 0 | **PASS** |
| Kiosk Encrypted Offline Queue, Batch Sync, HMAC Evidence, Heartbeat & SSE | `npm run test:sync` | 6 | 0 | **PASS** |
| Corrections Immutability/Reversal, Configurable Leave Policies & Reports | `npm run test:corrections-leaves` | 13 | 0 | **PASS** |
| Institutional Payroll Policies, Split-Month Proration, Golden Vectors, Maker-Checker, Immutability, Payslips & Safe CSV | `npm run test:payroll` | 10 | 0 | **PASS** |
| DB-Backed Reports, Monthly DTR Calendar/Overnight/Leave/Corrections, A4 `pdfkit` PDF, Unclipped CSV Streaming, Formula Neutralization & RBAC | `npm run test:reports` | 8 | 0 | **PASS** |
| System Settings, Live Restore, Retention Dry-Run/Purge, Device Rotation/Revocation/Alerts, Role Notifications, Tamper-Evident Audit & Restart Persistence | `npm run test:admin-ops` | 8 | 0 | **PASS** |
| API, Security, RBAC, Backup Endpoints & SQLite Integration | `npm run test:api` | 20 | 0 | **PASS** |
| Staging Security Audit, Controllable Impairment, Offline Sync, Load/Concurrency & DR Benchmark | `npm run test:staging` | 7 | 0 | **PASS** |
| Isolated Production Startup & Empty-State Smoke (`v1.13.0` / `BUILD 17` / Schema `009`) | `npm run test:startup` | 5 | 0 | **PASS** |
| Playwright Chromium 16-Screen × 4-Viewport Browser E2E + WCAG/Overflow Audit | `npm run test:browser` | 22 | 0 | **PASS** (`41` screenshots, `0` errors) |
| Live DB Isolated Migration Rollback Dry Run (`009 -> 009 -> 009`) | `npm run db:migrate -- --dry-run --db ./data/savage_rsucaj.db` | 1 | 0 | **PASS** |
| Isolated Staging DB Bootstrapper | `npm run staging:setup -- --db /tmp/savage-b17-setup-smoke.db --reset` | 1 | 0 | **PASS** |
| Fail-Secure Env Validation (Unconfigured Local Shell) | `npm run check:env` | 1 | 0 | **PASS** (correctly exited `1` `INVALID` without `SESSION_SECRET`) |
| Mandatory Automated Go/No-Go Release Gate | `npm run release:gate` | 4 gates | 0 fail / 6 blocked | **`NO-GO` (EXIT 2 — BLOCKED)** |
| Physical Hardware (Raspberry Pi 3B+ Kiosk, Android Kiosk APK, Android Employee APK) | `npm run test:hardware` | — | — | **NOT TESTED / BLOCKED** |
| Windows Desktop Browser (Edge / Chrome on Windows 10/11) | *(No Windows host in container)* | — | — | **NOT TESTED** |
| Official RSU CS Form 48 Layout Reference Verification | `cs_form_48_reference_verified='false'` (`RG-06`) | — | — | **BLOCKED** |
| Institutional Finance Sign-Off on Written Payroll Policy & Actual Scenario Outputs | `approvedPayrollPolicies=0` (`RG-07`) | — | — | **BLOCKED** |
| Real Biometric Verification & Anti-Spoofing (BUILD 09) | Reserved for BUILD 09 (`RG-08`) | — | — | **BLOCKED** |
| Production Host HTTPS, Persistent Volume, Google SSO/SMTP, Offsite Backup & Go-Live Sign-Off | `RG-05`, `RG-10` | — | — | **BLOCKED** |

**Total Automated Software Checks Executed:** **142 / 142 PASS** (`115` backend/staging + `5` startup smoke + `22` Playwright Chromium E2E) + Build/Lint/Audit/Dry-Run/Staging-Setup **PASS**.

---

## 1. Playwright Chromium 16-Screen & 4-Viewport Browser E2E Output (`22/22 PASS`)

Command: `npm run test:browser`  
Evidence artifact: `test-results/e2e-screenshots/e2e-audit-summary.json` (`41` audited PNG captures across `desktop-1366x768`, `desktop-1920x1080`, `tablet-768x1024`, `mobile-390x844`)

```text
PASS  01_Login — branding, disabled Google SSO, recovery modal, keyboard/Escape, invalid login error, real auth & password rotation
PASS  02_Admin_Dashboard — KPI cards, donut SVG, weekly trend toggle, device status, notifications panel
PASS  11_Departments — Add, Edit, Search filter persisted in SQLite
PASS  12_Positions — Add, Edit, Search filter persisted in SQLite
PASS  10_Shifts_and_Schedules — Add, Edit, Search filter persisted in SQLite
PASS  13_Holidays — Add, Edit, Search filter persisted in SQLite
PASS  04_Employees_Management — Add, View/Escape, Edit, CSV Import, Department Filter, Search & CSV Export
PASS  15_Devices_Kiosk — Register, One-Time Secret reveal, Heartbeat -> Online, Test API Punch, Telemetry, Rotate & Revoke/Restore
PASS  05_Attendance_Records — Verify kiosk punch, Log Attendance, Reconcile Day, Details/Immutable trail, Filter & Export CSV
PASS  06_Attendance_Corrections — File correction, Approve & Sync, Reverse with reason, and verify Audit Trail
PASS  07_Leaves_Management — Live eligibility preview, File leave, Approve & Propagate, Leave Balances & Policies tabs
PASS  08_Payroll_Processing — Institutional Policy creation & Finance Approval, Precheck, Compute, Payslip Print, Server CSV Export & Audit
PASS  09_Reports — All 6 Report Cards, Monthly DTR A4 Sheet, Verify & Sign, Print A4, Server PDF & CSV Exports
PASS  03_Notifications — Real event notifications, Filter tabs, Bulk Select, Mark Selected Read & Dismiss
PASS  14_Audit_Logs — Verify SHA-256 Hash Chain, Module Filter, Search & Authenticated CSV Export
PASS  16_System_Settings — General validation/save, API masked secrets, Security create user, Backup/Restore Drill, Retention Dry Run & About v1.13.0
PASS  02_Admin_Dashboard (populated) + Profile Sign Out + Maker-Checker Finalize -> Finance Sign-Off -> Release
PASS  Responsive & WCAG Sweep (desktop-1920x1080) — Key Modules & Navigation Drawer
PASS  Responsive & WCAG Sweep (tablet-768x1024) — Key Modules & Navigation Drawer
PASS  Responsive & WCAG Sweep (mobile-390x844) — Key Modules & Navigation Drawer
PASS  Responsive Login Screen Audit (1920x1080, 768x1024, 390x844)
PASS  Zero Uncaught Page Errors & Zero Blocking Console Errors Across All 16 Screens

Playwright Browser E2E Summary: 22 passed, 0 failed, 41 audited screenshots saved in test-results/e2e-screenshots/
```

---

## 2. Staging Integration, Security Audit, Impairment, Load & DR Benchmark (`7/7 PASS`)

Command: `npm run test:staging`  
Evidence artifact: `test-results/staging-evidence.json`

```text
PASS  01. Staging env validation & hard production block on network impairment
PASS  02. Staging auth, forced initial password rotation & 6-role least-privilege provisioning
PASS  03. Kiosk API contract: heartbeat, TIME_IN, backend-confirmed duplicate voice cue, biometric tamper block & <=03:00 AM next-day cutoff
PASS  04. Controllable staging network impairment -> encrypted offline queue -> recovery sync & live SSE dashboard
PASS  05. DTR, approvals, incident notifications & maker-checker payroll release (TEST-ONLY FAKE CURRENCY)
PASS  06. Security Audit: RBAC, CSRF cross-origin block, brute-force lockout, replay, zero secret leakage, SQLi & XSS
PASS  07. Load & concurrency benchmark (200 API reads + 50 concurrent kiosk punches) + encrypted backup & guarded live restore recovery

BUILD 16 Staging, Security, Impairment & Load Summary: 7 passed, 0 failed.
Load Benchmark: {"concurrentReadCount":200,"readWallMs":675.79,"readThroughputRps":295.9,"readP50Ms":365.18,"readP95Ms":585.17,"readP99Ms":606.9,"concurrentKioskPunches":50,"deduplicatedRecords":25,"punchWallMs":207.88,"punchP50Ms":129.03,"punchP95Ms":199.31,"punchP99Ms":199.61,"http5xxCount":0}
Backup/Restore Benchmark: {"archiveFilename":"savage-rsucaj-bkp-2026-11-21T10-00-02-443Z-55009d.sqlite.enc","encryptedBackupMs":69.09,"guardedLiveRestoreMs":261.98,"auditChainValid":true,"integrityCheck":"ok","fkViolations":0}
```

---

## 3. Automated Go/No-Go Release Gate Output (`NO-GO`, Exit Code `2`)

Command: `npm run release:gate`  
Evidence artifact: `test-results/release-gate-report.json`

```text
========================================================================
SAVAGE-RSUCAJ RELEASE GATE EVALUATION — savage-rsucaj-admin-portal v1.13.0 (BUILD 17)
========================================================================
[PASS   ] RG-01 (Build Integrity): Production SPA bundle (dist/index.html) compiled cleanly
[PASS   ] RG-02 (Security, Staging & DR): Automated staging, security, network impairment, load & backup-restore suite
[PASS   ] RG-03 (Browser E2E & Accessibility): Playwright Chromium 16-screen & 4-viewport E2E + WCAG/overflow audit
[PASS   ] RG-04 (Database Integrity): SQLite schema at 009 and PRAGMA integrity_check = ok
[BLOCKED] RG-05 (Production Host & Secrets): Verified production host .env (NODE_ENV=production, persistent DATABASE_PATH, SESSION_SECRET, BACKUP_ENCRYPTION_KEY, TLS/HTTPS proxy)
[BLOCKED] RG-06 (Institutional Policy (HR)): Official RSU Cajidiocan Civil Service Form 48 layout verified (`cs_form_48_reference_verified=true`)
[BLOCKED] RG-07 (Institutional Policy (Finance)): RSU Cajidiocan Finance written payroll policy & golden scenario output sign-off
[BLOCKED] RG-08 (Biometric Trust (BUILD 09)): Real neural face recognition + anti-spoof liveness verified end-to-end
[BLOCKED] RG-09 (Physical Hardware & External Apps): Staging acceptance from physical Raspberry Pi kiosk, Android kiosk, Android employee app & Windows browser
[BLOCKED] RG-10 (Operations & Go-Live Governance): Offsite encrypted backup replication, verified DNS/TLS (e.g., attendance.rsu-cajidiocan.tech), RPO/RTO sign-off, on-call roster & Project Owner formal Go-Live approval
------------------------------------------------------------------------
SUMMARY:  PASS=4 | FAIL=0 | BLOCKED=6
DECISION: NO-GO (PRODUCTION DEPLOYMENT BLOCKED)
========================================================================
```

---

## 4. Isolated Production Startup Smoke & Migration Dry Run Outputs

```text
> npm run test:startup
PASS  Production startup GET /api/health (HTTP 200): {"status":"ok","database":"connected","version":"1.13.0","build":"BUILD 17","mode":"production","timezone":"Asia/Manila","journalMode":"wal","foreignKeys":true,"schemaVersion":"009","dbFileBytes":4096,"walFileBytes":894072,"realtimeClients":0,"uptimeSeconds":1,"requestId":"req_aa414f97334c4d31","stagingImpairmentActive":false,"timestamp":"2026-11-21T09:46:37.282Z"}
PASS  Production static SPA GET / (HTTP 200)
PASS  Official RSU emblem asset GET /assets/aistudio/SAVAGE-RSUCAJ_Smart_Attendance_Emblem_39488c28.png (HTTP 200)
PASS  Production fresh install authentic empty state (0 employees, 0 devices, 0 demo notifications)
PASS  Production E2E login -> password rotation -> logout -> server revocation (401)
Summary: 5/5 startup smoke checks passed (isolated temp DB; live data/ untouched).

> npm run db:migrate -- --dry-run --db ./data/savage_rsucaj.db
SAVAGE-RSUCAJ Migration & Rollback Dry Run (Isolated Temp Copy — Live DB Untouched)
  Source Schema Version:   009
  Migrated Schema Version: 009
  Restored Schema Version: 009
  Snapshot SHA-256:        41108f1f033b66576ff0e86da021db1d164bbb9491261f5328363dd454754c3b
  Integrity Check:         ok
  FK Violations:           0
  Exact Row Counts Match:  true
  Status:                  PASS

> bun audit
bun audit v1.4.4 (38afee6c8)
No vulnerabilities found (checked 277 packages) [208.00ms]
```
