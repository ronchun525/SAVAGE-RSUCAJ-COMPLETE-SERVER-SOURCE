# BUILD 39 health check fix

Root cause addressed: the original script ran curl immediately after systemctl restart, before the Node application necessarily bound port 3100.

This corrected helper waits for JSON status=ok and database=connected, checks baseline health before changing files, and prints systemd/journal/port diagnostics before rollback when startup fails. It does not bypass the biometric safety gate.

Deploy the replacement ZIP under `/root/SAVAGE-RSUCAJ-BUILD39-ADMIN-LOGIN-PATCH-HEALTHFIX.zip` and extract the helper from that ZIP.
