# SAVAGE-RSUCAJ Smart Attendance Admin Portal — Operations Runbook

**Build:** `BUILD 17` (`v1.13.0`, Schema `009`)  
**Timezone Authority:** `Asia/Manila` (UTC+08:00, host-OS independent)  
**Go-Live Status:** **NO-GO / BLOCKED** until institutional sign-offs, BUILD 09 biometrics, and physical hardware acceptance pass.

---

## 1. Proposed Service Level Objectives (SLO), Uptime & Latency Targets

Proposed targets for RSU Cajidiocan MIS & Project Owner formal sign-off (grounded in BUILD 16/17 measured staging benchmarks: 200 concurrent API reads p95 `478.07 ms` at `365.2 req/s`; 50 concurrent kiosk punches p95 `144.46 ms`; 0 HTTP 5xx errors):

| Metric | Proposed Target | Measurement Source | Alert Threshold |
|---|---:|---|---|
| **API Availability (Campus Hours 06:00–21:00 PHT)** | `>= 99.5%` monthly | External `/api/health` probe every 60s | 2 consecutive failed probes (120s) |
| **Kiosk Punch API Latency (p95)** | `<= 300 ms` | Structured JSON logs (`X-Request-Id`) | p95 `> 500 ms` for 5 min |
| **Admin Portal API Read Latency (p95)** | `<= 600 ms` | Structured JSON logs | p95 `> 1000 ms` for 5 min |
| **HTTP 5xx Error Rate** | `< 0.1%` | Nginx + Express structured logs | `>= 5` HTTP 5xx in 5 min |
| **Kiosk Heartbeat Freshness** | `<= 60 s` (Stale), `<= 90 s` (Offline) | `GET /api/devices` + persisted Device Alerts | Any active gate kiosk `Offline` > 3 min |
| **Recovery Point Objective (RPO)** | `<= 6 hours` (proposed) | Scheduled 6-hourly `VACUUM INTO` + AES-256-GCM offsite sync | Backup job failure or missing archive > 7h |
| **Recovery Time Objective (RTO)** | `<= 30 minutes` (proposed) | Measured guarded live restore (`275 ms` DB swap) + verification | Restore drill exceeds 15 min |

> **Sign-Off Required:** Project Owner and RSU Cajidiocan MIS must formally approve or adjust the RPO/RTO and SLO targets before Go-Live.

---

## 2. Routine Operational Checklists

### Daily (07:30 PHT & 18:00 PHT)
1. Check `GET /api/health` (`status: "ok"`, `database: "connected"`, `journalMode: "wal"`, `foreignKeys: true`, `schemaVersion: "009"`).
2. Review **Devices / Kiosk** screen: confirm all physical gate kiosks show `Online`, acceptable `clock_drift_seconds` (`<= ±120s`), and `pending_queue_count = 0`.
3. Review **Notifications**: triage persisted `Attendance Alerts` (e.g., `> 03:00 AM` next-day cutoff escalations) and `Device Alerts` (offline/stale transitions or sync failures).

### Weekly (Friday 16:00 PHT)
1. Run **Audit Logs -> Verify Hash Chain** (`GET /api/audit-logs/verify`) and confirm `valid: true`.
2. Inspect backup history in **System Settings -> Backup & Restore** and run a non-destructive **Dry-Run Restore Verification Drill**.
3. Review **System Settings -> Security & Access** change history for unexpected role or settings modifications.

### Monthly (Before Payroll Cutoff & Month-End)
1. Run **Attendance -> Reconcile Day** for any missed dates and verify zero unresolved `Missing Time In` / `Missing Time Out`, pending corrections, or pending leaves via `GET /api/payroll/precheck`.
2. Export verified encrypted backup archive to offsite institutional media and execute an isolated CLI restore verification (`npm run db:restore -- --archive <file> --target /tmp/monthly-drill.db`).
3. Review **System Settings -> Data Retention** dry-run preview (`GET /api/retention/preview`); execute retention purge ONLY when authorized by RSU Cajidiocan Records Management.

---

## 3. Incident Response Playbooks

### Incident A — Kiosk Device Offline or Sync Failures
1. Inspect **Devices / Kiosk -> Telemetry** for `last_heartbeat_utc`, `pending_queue_count`, `last_clock_drift_seconds`, and `last_sync_error`.
2. Verify campus LAN/Wi-Fi and NTP clock synchronization on the kiosk (drift exceeding `±120s` triggers `422 CLOCK_DRIFT_EXCEEDED`).
3. While offline, kiosks store punches in their local AES-256-GCM encrypted queue (`EncryptedKioskQueue`). Once connectivity returns, `POST /api/kiosk/sync` drains punches chronologically (bounded by 72-hour replay limit).
4. If a kiosk credential is suspected compromised, click **Revoke Access** (`POST /api/devices/:id/revoke` immediately blocks punches with `403 DEVICE_REVOKED`) and **Rotate Key** before re-provisioning.

### Incident B — Audit Log Hash Chain Verification Failure (`409`)
1. **Treat as a Priority-1 Security Incident.** Do NOT overwrite or delete database files.
2. Immediately capture a read-only forensic copy of `savage_rsucaj.db`, `-wal`, `-shm`, and `/var/log/savage-rsucaj/*`.
3. Note `brokenRowId` from `GET /api/audit-logs/verify`, compare against the latest verified offsite encrypted backup manifest SHA-256, and escalate to RSU Cajidiocan MIS & Data Privacy Officer.

### Incident C — Administrator Account Lockout or Lost Password
1. Outbound SMTP self-service reset is disabled until institutional SMTP is configured.
2. Authorised host operator executes CLI recovery directly on the server:
   `npm run admin:recover -- --username <admin_username> --force-rotate`
3. Administrator signs in and completes mandatory immediate password rotation.

### Incident D — Database Corruption or Accidental Data Mutation (Guarded Live Restore)
1. Confirm exact last-known-good encrypted archive in **System Settings -> Backup & Restore** and execute **Dry-Run Drill** first.
2. Execute guarded live restore (`POST /api/backup/restore` requires Administrator password + exact phrase `RESTORE LIVE DATABASE` and automatically creates a `.pre-restore-*.bak` safety snapshot before swapping).
3. Immediately verify `GET /api/health` and `GET /api/audit-logs/verify`.

---

## 4. On-Call & Escalation Contacts (MUST BE POPULATED BEFORE GO-LIVE)

| Role | Name | Contact / Email | Escalation Window | Status |
|---|---|---|---|---|
| **Primary On-Call (RSU Cajidiocan MIS)** | _[PENDING INSTITUTIONAL ASSIGNMENT]_ | _[PENDING]_ | 15 min | **BLOCKED** |
| **Secondary On-Call (Campus System Admin)** | _[PENDING INSTITUTIONAL ASSIGNMENT]_ | _[PENDING]_ | 30 min | **BLOCKED** |
| **HRMO / DTR Policy Owner** | _[PENDING INSTITUTIONAL ASSIGNMENT]_ | _[PENDING]_ | Business Hours | **BLOCKED** |
| **Finance / Payroll Approver** | _[PENDING INSTITUTIONAL ASSIGNMENT]_ | _[PENDING]_ | Business Hours | **BLOCKED** |
| **Data Privacy Officer (DPO)** | _[PENDING INSTITUTIONAL ASSIGNMENT]_ | _[PENDING]_ | Immediate (Sec Inc) | **BLOCKED** |
