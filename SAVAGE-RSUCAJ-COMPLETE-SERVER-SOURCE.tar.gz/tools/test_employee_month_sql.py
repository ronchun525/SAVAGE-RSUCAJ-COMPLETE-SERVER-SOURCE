#!/usr/bin/env python3
"""SQLite smoke test for the read-only employee/month scope used by the portal."""
import sqlite3
conn=sqlite3.connect(':memory:')
conn.execute('''CREATE TABLE attendance_records (
 employee_id INTEGER, date TEXT, time_in TEXT, time_out TEXT,
 break_out TEXT, break_in TEXT, overtime_out TEXT, work_hours TEXT,
 status TEXT, late_minutes INTEGER, undertime_minutes INTEGER, overtime_minutes INTEGER
)''')
conn.executemany('INSERT INTO attendance_records (employee_id,date,status) VALUES (?,?,?)',[
 (5,'2026-11-20','Present'),(5,'2026-11-21','Late'),(5,'2026-12-01','Present'),
 (6,'2026-11-22','Present'),(5,'2026-10-31','Absent')
])
q='''SELECT date, time_in, time_out, break_out, break_in, overtime_out,
 work_hours, status, late_minutes, undertime_minutes, overtime_minutes
 FROM attendance_records WHERE employee_id = ? AND date >= ? AND date < ? ORDER BY date DESC'''
rows=conn.execute(q,(5,'2026-11-01','2026-12-01')).fetchall()
assert [r[0] for r in rows]==['2026-11-21','2026-11-20'], rows
assert all(row[1] is None or isinstance(row[1],str) for row in rows)
print('PASS: employee #5 sees exactly own November attendance; other employees/months excluded (2 rows).')
