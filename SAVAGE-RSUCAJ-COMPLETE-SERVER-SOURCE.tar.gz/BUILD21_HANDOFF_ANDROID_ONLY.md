# SAVAGE-RSUCAJ — BUILD 21 Android Build Repair & Test Handoff

**Release verdict: DEVELOPMENT SOURCE PACKAGE — NO-GO FOR PRODUCTION**

## 1. Overview

Continues from the exact uploaded `SAVAGE-RSUCAJ-BUILD20-TFLITE-ANDROID-ADMIN-INTEGRATED-SOURCE.zip` (227 archive entries), preserving the same Android package ID, Express/admin portal modules, training-candidate TFLite binaries, logos, design references, UI screens, fonts and visual assets. The objective of BUILD 21 is to remove provable build/security defects and provide reproducible Windows build recovery and testing. **No APK was generated in this environment**, because Gradle, the Gradle wrapper executable/JAR and Android SDK were unavailable and the sandbox could not reach Gradle's distribution domain.

## 2. Architecture

Android CameraX/MLKit -> TFLite PAD + passive liveness + MobileFaceNet -> encrypted template store -> authenticated Retrofit bridge -> Node/Express attendance engine -> admin portal. No fabricated biometric verification, backend acknowledgements or UI screens were added. Actual hardware inference, live backend E2E and payroll consistency remain pending.

### Build toolchain

The existing project pins Android Gradle Plugin **9.1.1**, Gradle **9.3.1**, and compileSdk 36.1. Google documents Gradle 9.3.1, Build Tools 36.0.0 and JDK 17 as compatible baseline for AGP 9.1.1: <https://developer.android.com/build/releases/agp-9-1-0-release-notes>.

Gradle 9.3.1 verified SHA-256 values from <https://gradle.org/release-checksums/>:
- Binary Gradle ZIP `b266d5ff6b90eada6dc3b20cb090e3731302e553a27c5d3e4df1f0d76beaff06`.
- Generated wrapper JAR `b3a875ddc1f044746e1b1a55f645584505f4a10438c1afea9f15e92a7c42ec13`.

**Supply chain note:** The ZIP still lacks the actual wrapper scripts and JAR; they are **not simulated**. `scripts/bootstrap-gradle-wrapper.ps1` obtains an official Gradle 9.3.1 distribution from services.gradle.org, verifies its checksum, generates wrapper scripts/JAR in an isolated empty project (so it does not execute Android project scripts during bootstrap), verifies wrapper-JAR SHA, and copies the official files into the project. Network recovery is to run on the operator's Windows machine; this script was not executed here.

## 3. UI/UX Design

All **38** original Android `app/src/main/res/**` and uploaded original `public/assets/aistudio/**` files are unchanged byte-for-byte. A `tools/BUILD20_UI_REFERENCE_HASHES.json` baseline lets the operator recheck the original references. No new UI or logo assets were substituted. Android screenshots, accessibility and device size tests remain unverified.

## 4. Implementation — exact paths

Project root: `finalngfacerecogantion-main/`

| File | Change |
| --- | --- |
| `app/build.gradle.kts` | Corrects broken debug keystore assumption: uses AGP's standard `debug` signing; retains release signing configuration and release identity. |
| `gradle/wrapper/gradle-wrapper.properties` | Adds official 9.3.1 binary distribution SHA-256 for subsequent wrapper runs. |
| `scripts/bootstrap-gradle-wrapper.ps1` | Official checksum-verified, isolated Gradle wrapper bootstrap for Windows. |
| `scripts/build21-windows.ps1` | Windows SDK/source checks -> real JUnit Gradle task -> `assembleDebug` -> APK file/hash report, only if every command succeeds. |
| `app/src/main/java/com/example/kiosk/platform/KioskServerUrlPolicy.kt` | Centralized parsed URI validation for HTTPS, debug-only localhost and emulator loopback. Rejects userinfo, forged hosts and malformed URLs. |
| `app/src/main/java/com/example/kiosk/platform/KioskSettingsStore.kt` | Uses parsed URL policy instead of insecure string-prefix validation. |
| `app/src/main/java/com/example/kiosk/data/AttendanceApiService.kt` | Rejects non-HTTPS remote URL; permits loopback HTTP only on debug builds. Authorization/token and attendance protocol preserved. |
| `app/src/debug/AndroidManifest.xml` | Debug-only local network security config reference; main/release manifest still forbids cleartext. |
| `app/src/debug/res/xml/debug_network_security_config.xml` | Local emulator/localhost cleartext allowance only for debug, no arbitrary external cleartext. |
| `app/src/test/java/com/example/Build21UrlPolicyTest.kt` | New URL-policy JUnit tests (execution via Gradle pending). |
| `app/src/test/java/com/example/AttendanceApiAndFlowTest.kt` | Updates older mock HTTP tests to include a provisioned token and the new `device-info` authentication request. |
| `app/src/test/java/com/example/OfflineQueueAndSyncTest.kt` | Updates older mock offline-sync HTTP fixture ordering and mandatory API response fields. |
| `tools/jvm_smoke/Build21ContractsSmoke.kt` | Executable pure-Kotlin JVM test harness for URL and original model input/score contracts. |
| `tools/verify_build21_source.py` | Checksum and original UI preservation checks; clear runtime limitations. |
| `tools/BUILD20_UI_REFERENCE_HASHES.json` | Hashes of unchanged BUILD 20 reference files for operator verification. |

The entire `adminwebportal-imaw-na-ini-main/` directory was **not modified** in this build.

## 5. Error Analysis — root cause / fix

1. **Debug signing:** The original `debugConfig` pointed at a missing `root/debug.keystore`. Clean checkouts can fail signing validation. Switched the debug build to the documented AGP managed debug key. Never re-use this key for release.
2. **Missing wrapper:** Source archive had only `gradle-wrapper.properties`. Rather than invent an executable/JAR, added a checksum-verified official Windows bootstrap procedure.
3. **Unpinned Gradle ZIP:** Wrapper download previously lacked `distributionSha256Sum`. Pinned Gradle 9.3.1 to published SHA-256.
4. **URL prefix bypass:** `http://localhost.attacker.example` could be accepted as a settings URL by a prefix check. Now requires URI host equality and debug-build restriction. This is a defense-in-depth correction; the Retrofit implementation previously rejected some spoofed host values already.
5. **Emulator networking:** Base release manifest blocks cleartext; emulator `http://10.0.2.2` testing required an isolated debug-only network policy.
6. **Outdated Android tests:** Several old fixtures supplied no token and did not anticipate `GET /api/v1/kiosk/device-info` before attendance upload. Updated corresponding mock request/response setup; **full Android JUnit results were not verified**.

## 6. Actual tests (performed in current tool runtime)

| Check | Actual result | Meaning |
| --- | --- | --- |
| `kotlinc` standalone source contracts | **18/18 PASS** | Compiled real `BiometricTensorCodec.kt` + new `KioskServerUrlPolicy.kt` against a pure-JVM smoke harness, then executed with Java. This is **not** a Gradle/Android build. |
| `python tools/verify_build21_source.py` | **9/9 PASS** | 3 model headers/SHA/pins, Gradle digest, debug signing configuration, base release cleartext, debug network policy, Windows scripts, 38 unchanged reference files. Static checks only. |
| `npm run test:build19` under admin portal | **9/9 PASS** | Existing backend API digest, HMAC and validation protocol unit tests, Node v22.16.0. |
| Android `:app:testDebugUnitTest` | **NOT RUN** | Android SDK and Gradle wrapper/distribution unavailable. Existing modified JUnit fixtures must still be confirmed by Gradle. |
| Android `:app:assembleDebug` | **NOT RUN** | No Android SDK / Gradle available. **No APK created.** |
| Android instrumentation / actual camera + TFLite inference | **NOT RUN** | Requires physical approved Android hardware and trained model accuracy evaluation. |
| Live Android-to-admin end-to-end | **NOT TESTED** | No deployed authorized staging backend or provisioned kiosk available. |

Do not interpret the pure JVM test results as APK compilation, device tests, or production confirmation.

## 7. Deployment / Windows build instructions

1. Extract the BUILD 21 ZIP on Windows. Open `finalngfacerecogantion-main` in Android Studio. Use JDK **17+**, install the Android SDK Platform **36.1** and Build Tools **36.0.0** as needed in Android Studio SDK Manager. Set `ANDROID_HOME` or let the script discover `%LOCALAPPDATA%\Android\Sdk`.
2. Open PowerShell at `finalngfacerecogantion-main` and run:

   ```powershell
   python .\tools\verify_build21_source.py
   powershell -ExecutionPolicy Bypass -File .\scripts\build21-windows.ps1 -BootstrapWrapper
   ```

   First run downloads/checks official Gradle 9.3.1 and project dependencies (internet required); JUnit Gradle tasks and `assembleDebug` follow. If a command fails, the script stops rather than marking a false success. Files are saved under `build21_artifacts/`; a real APK, when successful, appears under `app\build\outputs\apk\debug\app-debug.apk`. This path is **not present in the delivered ZIP**.
3. Do **not** release a debug APK. For a release keystore, use your own protected `KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD` and signing identity. Never upload signing credentials. Run release tests and confirm signed APK/AAB on Windows separately.
4. Provision the real kiosk in the admin backend; rotate the setup PIN; configure the approved HTTPS URL and valid device token. Enroll only consented testers with the actual 192D MobileFaceNet model. Test real face/PAD/replay cases, attendance, duplicate behavior, offline sync, and admin reports end to end.

## 8. Final Report

**Completed:** BUILD 21 build-recovery scripts, fixed debug signing assumption, official checksum pin, parsed URL security, debug-only local network access, updated old mock integration tests and new URL/pure-JVM smoke tests, preserved all existing reference assets and backend code.

**Remaining critical issues:** actual Android Gradle build and JUnit verification; TFLite Interpreter runtime tests; physical camera acceptance with measured false acceptance/rejection; liveness PAD validation; biometric model licensing review; capture-time offline attestation; backend enrollment authorization review; staging device registration; integration with admin portal under real HTTPS; release signing and deployment approval. No claim of production readiness.
