# SAVAGE-RSUCAJ BUILD 42 — Trusted Web Kiosk Frame Inference (Staged)

**Scope:** source patch for the already-running Hostinger Web Kiosk. The BUILD 41 misleading-model-warning fix remains intact. The target is `https://attendance.rsu-cajidiocan.tech/kiosk`. This package does **not** include model binaries, keys, data, sessions or the production SQLite database.

## 1. Overview

The observed Android Chrome enrollment screenshot shows a camera pointed at a wooden surface, `Quality: FAIL`, PAD/liveness pending and a notice saying 3/3 TFLite files are installed but trusted server attestation is inactive. The server already confirms all three original SHA256-pinned models (MiniFASNetV1, MiniFASNetV2 and MobileFaceNet192) are valid. A model checksum is not a production-verification result.

The patch wires *actual camera JPEG frames* from the Web Kiosk into a restricted Node.js subprocess bridge and Python worker, for OpenCV YuNet face detection, 5-point face alignment, and all three LiteRT models. **By default production enrollment and attendance remain disabled until actual camera testing, threshold calibration, security evaluation and explicit approval.**

## 2. Architecture

Browser: activated HTTPS session and camera → server-issued single-use challenge → 3 JPEG frames at 320ms intervals → authenticated Express `/kiosk/web/enroll` or `/kiosk/web/attendance` → Python worker (YuNet + pinned MiniFASNetV1/V2 + MobileFaceNet192) → server-owned PAD/quality/liveness/embedding → existing server policy, duplicate check and encrypted template matching → existing SQLite attendance engine. The browser never submits trusted PAD scores, matching identities or embeddings. A separate Admin PIN-protected `POST /api/kiosk/web/models/face-test` tests real camera inference and returns diagnostic scores, without writing biometric templates or attendance.

YuNet is a **fourth** model for face detection only. Source: OpenCV Zoo, MIT license: https://github.com/opencv/opencv_zoo/tree/main/models/face_detection_yunet . This deployment script downloads `face_detection_yunet_2023mar.onnx` from a fixed OpenCV/Hugging Face repository revision. It does not replace the 3 existing TFLite models. Review third-party license notices before commercial redistribution.

## 3. UI/UX design

Preserves original transparent SAVAGE logo, emerald/gold colors, enrollment layout, camera preview, PIN modal and attendance voice policy. The enrollment screen adds a small **Test Face AI (Admin Diagnostic)** button after administrator unlock. Native `FaceDetector` absence is **not** interpreted as `NO_FACE` or a fake `PASS`; its quality badge stays `Checking` until backend evaluation. Actual `NO_FACE` from the server instructs users to point the camera at a face, not the floor.

## 4. Implementation: complete changed files

| File | Description |
|---|---|
| `server/webKioskBiometrics.ts` | Expiring trusted-worker health status, separate calibration gate |
| `server/webKioskRoutes.ts` | Staged readiness polling, Admin PIN-protected face-test, server evidence only in production enrollment/attendance |
| `server/webKioskAttestation.ts` | Spawn subprocess without shell, bounded JSON, concurrency, timeout, strict schema |
| `src/lib/kioskBiometrics.ts` | Browser native detector capability reported explicitly; no fabricated face PASS/FAIL |
| `src/components/WebKioskPortal.tsx` | 3 frame camera bundle, real auto-enroll, secure face-test and clearer errors |
| `src/components/kiosk/KioskScreens.tsx` | Matching green-outline admin diagnostic button and result text |
| `deployment/hostinger-vps/biometric_inference_worker.py` | Original model preprocessing functions reused by new worker |
| `deployment/hostinger-vps/kiosk_attestation_worker.py` | YuNet detection, crop/align, real LiteRT PAD/liveness/embedding and frame replay/quality checks |
| `tests/build42-attestation.test.mjs` | Node bridge/input/inference contract tests |
| `deployment/hostinger-vps/tests/test_build42_attestation.py` | Python negative-path frame tests |
| `deployment/hostinger-vps/build42-deploy.sh` | Hostinger staged deploy/rollback/health checks |

## 5. Root causes and fixes

1. `serverInferenceAvailable = false` was static, even though all TFLite files were installed. It is now based on *recent verified worker health*, which expires if the worker fails.
2. The browser submitted only quality metadata, not verified pixel evidence. It now sends bounded JPEG frames after a fresh challenge; the Node backend computes all biometric evidence in Python. Browser-supplied scores/embeddings are ignored in production.
3. Enrollment `3/3` counter previously incremented from quality checks without persisting a template. Now a success screen requires a backend-confirmed encrypted template write.
4. Chromium lacking `FaceDetector` previously meant `face_count=0` and `Quality FAIL` forever. Now unknown detection is displayed as `Checking`; YuNet decides from frames.
5. Production cutoffs (`PAD >=.8`, liveness >=.8, recognition >=.62) were explicitly uncalibrated. The deploy script **does not** mark them approved.

## 6. Actual test results from isolated local source tests

- Python tests: **7/7 PASS** — frame count, repeated JPEGs, timestamp order, invalid bytes, fake frame structure, real `NO_FACE` fail-closed, valid distinct JPEG parsing.
- Node tests: **8/8 PASS** — bounds, client score rejection, timestamps, base64, subprocess contract rejects fake worker, valid worker probe fixture, Chromium fallback.
- Syntax parsing: **6/6 changed TS/TSX files PASS** (syntax only, not full TS type validation).
- Bash: `bash -n` PASS; Python worker `py_compile` PASS.
- **Not tested here:** exact installed TFLite binaries (not included locally), YuNet download and running on VPS, real FullPageOS/Android camera, 1:N matching, PAD false-accept/false-reject performance, network latency, end-to-end attendance, full TypeScript build. Those must pass on VPS before any production approval.

## 7. Deployment — Hostinger VPS (existing application)

**Windows PowerShell (download this patch ZIP first):**

```powershell
scp "$env:USERPROFILE\Downloads\SAVAGE-RSUCAJ-BUILD42-REAL-INFERENCE-PATCH.zip" root@201.18.218.208:/root/
ssh root@201.18.218.208
```

**VPS terminal:**

```bash
unzip -p /root/SAVAGE-RSUCAJ-BUILD42-REAL-INFERENCE-PATCH.zip \
  deployment/hostinger-vps/build42-deploy.sh > /root/build42-deploy.sh
chmod 700 /root/build42-deploy.sh
sudo bash /root/build42-deploy.sh
```

The installer checks the exact BUILD 41 base source hashes, backs up existing source/dist and production.env, installs `opencv-python-headless` inside the existing `savage` Python venv, downloads the YuNet ONNX detector only if absent, probes *all models* as the `savage` user, runs 7 Python + 8 Node tests, performs TypeScript lint and Vite build, then restarts `savage-rsucaj` with readiness retries and rollback if checks fail. It enables **runtime health probing only** (`KIOSK_SERVER_ATTESTATION_ENABLED=1`). It does **not** approve official production attendance.

To confirm:

```bash
systemctl is-active savage-rsucaj
curl -fsS http://127.0.0.1:3100/api/health | python3 -m json.tool
curl -fsS http://127.0.0.1:3100/api/kiosk/web/models/status | python3 -m json.tool
```

Expected **after successful VPS installation and real worker probe**:

```
all_models_verified_on_disk: true
server_inference_available: true
production_attendance_ready: false
```

If the source-checksum guard fails, **do not force overwrite**. The installed files differ from the BUILD 41 source used here; obtain the actual current files and rebase the patch. The script has not been run against this VPS from this chat.

### Real-device tests BEFORE production approval

1. Reopen the activated Web Kiosk, enter the Admin PIN, select an employee, point the actual webcam at one real frontal face, and tap **Test Face AI (Admin Diagnostic)**. The worker must return real PAD/liveness scores or a specific error such as `NO_FACE`, `LOW_LIGHT`, `BLURRY_IMAGE`, `MULTIPLE_FACES`, `PAD_REJECTED`.
2. Test genuine faces across devices and lighting, distinct people, duplicate enrollment, a printed photo, phone/tablet replay, poor illumination, frozen frames, and offline/backend failure. Do not relax thresholds just to pass. Maintain documented calibration, errors, reproducibility and security review.
3. Validate YuNet five-landmark order against the actual MobileFaceNet recognition preprocessing. If output normalization/alignment differs from enrollment, matching will fail.
4. Only after the evaluation is independently reviewed should a server administrator decide whether to set `KIOSK_BIOMETRIC_CALIBRATION_APPROVED=YES_VERIFIED` in `/etc/savage-rsucaj/production.env` and restart service. **Do not set it merely to hide a warning**. This is a high-impact security switch; a web browser cannot cryptographically prove that submitted images came from a live camera, so PAD/replay testing is essential.

### Rollback

If the installer fails it automatically restores the backup and service. If post-deployment tests reveal a problem, identify the backup locations printed by the installer, then (as root):

```bash
sudo tar -xzf /root/SAVAGE-BUILD42-BEFORE-<TIMESTAMP>.tar.gz -C /opt/savage-rsucaj/app
sudo install -o root -g savage -m 0640 /root/SAVAGE-BUILD42-ENV-BEFORE-<TIMESTAMP>.env /etc/savage-rsucaj/production.env
sudo systemctl restart savage-rsucaj
curl -fsS http://127.0.0.1:3100/api/health
```

Replace `<TIMESTAMP>` with the actual timestamp generated by the deployment. Preserve the backups securely: the environment copy contains secrets. Existing Caddy, port 3100, database and login routes are otherwise unchanged.

## 8. Final report and limitations

**Completed in source:** real JPEG inference worker, Node subprocess bridge, three-model scoring, server-owned enrollment/attendance evidence flow, automatic capture and backend-confirmed enrollment, PIN-only diagnostics, timeout and validity gates, browser FaceDetector fallback, deployment script and local tests.

**Remaining issues before production:** actual VPS installation/tests, detector model validation, calibrated face/PAD/liveness thresholds, end-to-end device session and challenge tests, real-world spoof/replay evaluation, genuine recognition identity/duplicate tests and audit/security review. **Do not claim the system is fully working or production-ready until these tests pass.**


## BUILD 42 TypeScript correction (2026-11-23)

This ZIP corrects union-type narrowing in `server/webKioskAttestation.ts` and `server/webKioskRoutes.ts` identified by the first Hostinger `npm run lint` attempt. The original attempt rolled back; these changes are not yet deployed or production-verified. The successful inference result is explicitly narrowed to `mode === 'infer'` before accessing `frames` and `embedding`; unexpected mode is rejected with 502 or `UNVERIFIED_RESULT` instead of trusting an empty probe. The source-hash base guard for BUILD 41 is unchanged.


## BUILD 42 — Typeguard correction (VPS tsc TS2339)

The previous BUILD 42 installer failed on four TypeScript errors at
`server/webKioskAttestation.ts:123-128`, rolled back, and left the prior
application healthy. This package narrows `validAttestationOutput` to
`Extract<AttestationResult, { ok: true }>` rather than the entire
`AttestationResult` union, so TypeScript can safely discriminate
`mode: probe | infer` before using `frames`/`embedding`.

The deployment script now reads this uniquely named ZIP without overwriting
previous packages. The original BUILD 41 source-hash guards remain active.
Until live device testing and calibrated approval, production attendance
remains fail-closed. Model integrity and worker probe do not prove biometric
accuracy.
