# SAVAGE-RSUCAJ BUILD 19 — Biometric & Security Hardening Source Build

**Decision:** NO-GO FOR PRODUCTION. **Scope achieved:** incremental security fixes in the actual BUILD 18 Android + admin sources, not a deployed or signed APK/AAB and not an independently verified biometric system.

## 1. Overview

Continues `SAVAGE-RSUCAJ-BUILD18-ANDROID-ADMIN-INTEGRATED-SOURCE.zip` without replacing its React/Express admin portal or Kotlin/Compose Android kiosk. BUILD 18's API adapter and existing backend attendance engine are retained. This phase adds stricter validation, TFLite fingerprint pinning, and local encrypted biometric-vector storage. The required biometric models were **not provided**, and no real camera biometric, Android APK compilation, or backend-to-device integration test took place.

## 2. Architecture

- Admin: Express API -> `/api/v1/kiosk/...` adapter -> canonical SQLite attendance engine and audit/events. HMAC envelope verification is unchanged. A new reusable *pure validator* handles attendance/enrollment payload integrity.
- Android: CameraX/ML Kit -> three TFLite inference stages -> local template store -> Retrofit attendance bridge; the AndroidKeyStore AES-256-GCM encryption is applied to each biometric vector before writing it into the existing SQLite table. `employee_id|pose_column` is bound as authenticated additional data (AAD).
- Existing legacy BUILD18 **plaintext** face vectors are migrated in an atomic database transaction at first read; a row is not used if integrity verification, encryption, decryption, or migration fails. Encrypted data cannot be recovered after Keystore loss; re-enrollment is necessary. Old database backups/WAL can still contain historical plaintext and must be retired through the institution's documented retention and re-enrollment process.
- Model assets now require explicit SHA-256 model hashes via build-time environment variables; missing or wrong hashes **fail closed**. SHA pinning does NOT establish accuracy, class meanings, anti-spoof security, or legal rights to a model; those require a model-specific validation plan and actual device tests.

## 3. UI/UX Design

Existing admin portal and Android screen/theme/assets retained; no screen redesign. Admin settings, device provision control and original branding remain as in BUILD 18. No pixel-by-pixel UI screenshot comparison or device screenshot test was run.

## 4. Implementation — exact changed/new paths

### Admin web portal (`adminwebportal-imaw-na-ini-main/`)
- `server/androidBridgeProtocol.ts`: `validateAndroidPunch` and `validateAndroidEnrollment`; validates device association, strict event and time bounds, status/score ranges, independent SHA-256 recomputation and idempotency header matching.
- `server/androidBridge.ts`: uses those checked inputs; requires exact authenticated kiosk device-name header; honors encrypted enrollment and original canonical attendance logic.
- `tests/build19-hardening.test.mjs`: new real execution of positive/negative backend protocol validation and existing backend HMAC evidence verifier; no fake backend.
- `package.json`: `test:build19` for reproducible executable contract tests.

### Android (`finalngfacerecogantion-main/`)
- `app/src/main/java/com/example/kiosk/biometrics/KioskTemplateCipher.kt`: new AES-GCM versioned envelope with AndroidKeyStore nonexportable default key and per-employee/pose AAD. Disposable JCE key injection supports isolated unit tests; production creates the AndroidKeyStore key.
- `app/src/main/java/com/example/kiosk/biometrics/EnrolledTemplateStore.kt`: encrypt new vectors and migrate old data without deleting tables or enrolled records; invalid AES-GCM tags/checksums block matching.
- `app/src/main/java/com/example/kiosk/biometrics/TfliteBiometricEngine.kt`: reject any loaded, unpinned or mismatched model asset; existing missing-asset behavior maintained.
- `app/src/main/java/com/example/kiosk/data/AttendanceApiService.kt`: reject 2xx response if server-record identity, action, ID, date or status is incomplete or mismatched; require same identity, action and attendance period on backend-confirmed HTTP 409 duplicates. No locally fabricated success fallback.
- `app/build.gradle.kts`: compile-time public fingerprints `BIO_PAD_SHA256`, `BIO_LIVENESS_SHA256`, `BIO_RECOGNITION_SHA256` from environment, default empty (fail-closed).
- `app/src/test/java/com/example/TfliteBiometricEngineTest.kt`, `app/src/test/java/com/example/EnrollmentAndTemplateStorageTest.kt`: existing mock-model tests updated to pin *test fixture* digests; test Keystore seam and encrypted-blob assertion added for the SQLite template fixture. **Android unit tests were not executed here.**

## 5. Error Analysis — root causes and fixes

1. **Plaintext local face embeddings**: BUILD 18 SQLite store wrote `FloatArray` blobs without encryption. BUILD 19 now uses authenticated AES-GCM encryption at rest with an AndroidKeyStore-held key; older data migrated when read. Full backup/retention audit remains.
2. **Arbitrary model replacement**: existing model shape validation skipped checksum when no digest configured. BUILD 19 requires a pinned SHA-256 before a present asset is loaded; operator must separately certify output labels and PAD thresholds.
3. **Weak success acknowledgement**: Android treated `SUCCESS`/`ALREADY_RECORDED` and missing record identifiers as valid. BUILD 19 accepts only correctly bound `RECORDED` confirmation, blocks ambiguous duplicate responses.
4. **Bridge validation scattered in route code**: centralized pure payload validators with runnable positive and adversarial cases. HMAC still binds metadata but **does not authenticate a physical camera/liveness measurement**.
5. **Offline evidence still generated at upload time**: capture-time protected offline evidence and secure anti-replay device attestations remain **NOT IMPLEMENTED**. Do not claim offline events are cryptographically proven at capture. This is a production blocker.
6. **Enrollment authority**: a provisioned kiosk credential can currently submit a face template without independently approved enrollment authorization on the backend. The Android admin PIN does not prove backend HR/operator approval. Require separate authorization workflow/approvals before production.
7. **Missing real face models and model calibration**: three required `.tflite` files are absent. No fake/synthetic production inference is added, and unattended biometric recognition remains blocked.

## 6. Testing — **actually executed here**

| Check | Actual result | Scope |
|---|---|---|
| `npm run test:build19` in admin root | **PASS: 9/9** | Node 22 built-in tests, digest, vector hash, HMAC tamper, endpoint drift, thresholds, timestamps, enrollment checks |
| `node --experimental-strip-types --check server/androidBridge.ts` | **PASS** | Parser/syntax only, not full TS semantic typecheck |
| `node --experimental-strip-types --check server/androidBridgeProtocol.ts` | **PASS** | Parser/syntax only |
| Source archive integrity and image/logo checks | **PASS** | Byte comparison and ZIP integrity, see final packaging verification |
| Full `npm install` / `npm test` / Vite production build / full TS typecheck | **NOT RUN** | No network-fetched dependencies/package-lock in supplied source |
| Android Gradle assemble/test/Android instrumentation | **NOT RUN** | No Gradle wrapper script/JAR or Android SDK in this execution environment |
| Android Keystore encryption migration on actual hardware | **NOT TESTED** | Code present, requires Android runtime and migration rehearsal with backup |
| Actual PAD/liveness/recognition | **NOT TESTED** | Real model files and qualified samples missing |
| End-to-end Android to deployed admin | **NOT TESTED** | No live host/device provisioning/credentials available |

This report does not re-certify the historical test claims in the project directories.

## 7. Deployment and acceptance setup (operator-run, unverified)

### Backend (Node host with HTTPS + persistent database)

1. Make a consistent online SQLite backup of any **real** operational database; verify restore on staging; do not overwrite a deployed DB with the source ZIP.
2. Create `.env` from `.env.example` with strong `SESSION_SECRET`, `KIOSK_TEMPLATE_ENCRYPTION_KEY` (64 hex characters; `openssl rand -hex 32`), actual production `DATABASE_PATH`, domain/CORS, and the required bootstrap settings. Never commit any secrets.
3. `npm install` and commit the audited lockfile to your release repository. Run `npm run db:migrate`, `npm run lint`, `npm run build`, `npm test`, `npm run test:build19`, `npm run release:gate` on staging. Do not deploy if any fail.
4. Deploy to a Node-compatible host with TLS and backups; ensure `/api/v1/kiosk/device-info` accepts only an authorized device token and exact device ID. Provision device tokens using the admin portal; rotate/revoke them if exposed.

### Android (Windows PowerShell + Android Studio)

1. Supply the **licensed**, compatible model binaries in `app/src/main/assets/models/` with exact names: `anti_spoofing_pad.tflite`, `liveness_detection.tflite`, `face_recognition.tflite`. Verify input normalization, output class labels, anti-spoof thresholds, and supported hardware using the actual model documentation.
2. Before launching Android Studio from the same PowerShell terminal, assign the **public model fingerprints**:

```powershell
$models = 'app\src\main\assets\models'
$env:BIO_PAD_SHA256 = (Get-FileHash "$models\anti_spoofing_pad.tflite" -Algorithm SHA256).Hash.ToLower()
$env:BIO_LIVENESS_SHA256 = (Get-FileHash "$models\liveness_detection.tflite" -Algorithm SHA256).Hash.ToLower()
$env:BIO_RECOGNITION_SHA256 = (Get-FileHash "$models\face_recognition.tflite" -Algorithm SHA256).Hash.ToLower()
```

3. Restore verified official Gradle wrapper scripts/JAR appropriate for the checked-in `gradle/wrapper/gradle-wrapper.properties`; install the required Android SDK and JDK; validate Gradle and dependencies on staging. Do **not** replace missing wrapper JAR with an unverified download.
4. Build unit/instrumentation test targets and a signed release artifact under your organization's keystore procedure; do not commit signing credentials. Run the actual UI and enrollment on supported Android hardware with camera permissions.
5. Carefully back up existing enrolled employees under a privacy-controlled process, validate BUILD 18 -> 19 encryption migration on test devices, verify reinstall/restore/rekey behavior and test revocation and recovery. Delete/retire old unencrypted backups appropriately; never include personal templates in test/demo ZIPs.
6. Configure an HTTPS backend origin and matching registered kiosk device and token in Device Settings, change default setup PIN. Test live attendance visible on admin, duplicate rejection, offline sync and reboot, token rotation, clock drift, model tampering, camera replay/photo/PAD and payroll report reconciliation. Obtain management/privacy/security signoff.

## 8. Final Report — completed and remaining

**Implemented in source:** encrypted local face templates, transaction-based migration, model fingerprint enforcement, stricter attendance/enrollment and duplicate confirmations, device header enforcement, reproducible contract tests. **UI remains unchanged.**

**Not completed / production blockers:** capture-time proof for offline queue; independent backend approval for enrollments; real model provisioning/calibration/licensing; device/APK/AndroidKeyStore tests; testable Gradle wrapper, npm lock/dependencies; full TypeScript/Vite build, full integration, deployment, database migration rehearsal, data retention review, security acceptance and release gate.

**Final decision: BUILD 19 source-stage hardening only. NOT PRODUCTION READY, and not proven connected live.**
