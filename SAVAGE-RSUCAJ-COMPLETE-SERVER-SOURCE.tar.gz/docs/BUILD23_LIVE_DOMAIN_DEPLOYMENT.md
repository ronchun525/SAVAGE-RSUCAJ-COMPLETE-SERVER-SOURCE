# BUILD 23 — rsu-cajidiocan.tech live domain integration (operator runbook)

**Status: NOT DEPLOYED, NOT PRODUCTION VERIFIED.** This runbook applies to the bundled Node/Express + SQLite admin portal AND the bundled Android kiosk. Do not substitute a different Laravel/PHP backend without a tested API adapter.

## Architecture, exact endpoints

Android kiosk -> HTTPS `https://rsu-cajidiocan.tech` -> `GET /api/health` and authenticated `GET /api/v1/kiosk/device-info` -> Express routes -> durable SQLite -> attendance engine -> server-managed realtime notifications -> admin portal.

The base URL in Android Device Settings is the origin `https://rsu-cajidiocan.tech`, NOT `/api` and NOT `/api/v1/kiosk`. The app requires a separate device name, provisioned API token, and a changed setup PIN. Domain prefilling does NOT certify that any API is deployed.

### Critical hosting compatibility check

Verify which app is actually served on the domain before any write operations. If Hostinger serves only a static website, the uploaded Android-compatible Express routes WILL NOT exist merely because the domain is live. Host the Node app on a suitable always-on Node runtime with persistent data storage, then configure HTTPS routing of `/api/*` to that runtime (with the same website origin, if the web frontend continues using `/api/*`). On a hosting plan without Node or configurable reverse proxy, use a compatible external host and a DNS/subdomain design; update both frontend API routing and the Android origin as needed. DO NOT overwrite the existing live website, database, login or employee records to test.

Live endpoint identity is checked by the new BUILD 23 device-info field `bridge_contract: "SAVAGE_ANDROID_V1"`. The API must answer JSON with the appropriate response contract, not a 200 HTML SPA landing page, 301 login redirect or generic Laravel health response.

## Server deployment checklist (human execution, NO credential copy into chat)

1. Back up the LIVE website assets and LIVE database before making any change. Identify whether domain points to the bundled Express Node service; preserve existing working services, authentication, database and integrations.
2. Confirm the production runtime can run the project engine requirements, install native SQLite dependencies and persist a database and backup files outside ephemeral `dist`, `node_modules` or disposable containers. Follow the existing `DEPLOYMENT.md` and `docs/BACKUP_AND_RECOVERY.md` first.
3. On a staging host first, provide all required `.env` secrets securely: valid `SESSION_SECRET`, `DATABASE_PATH`, backup keys, admin initialization only on a fresh empty database, and `KIOSK_TEMPLATE_ENCRYPTION_KEY` (64 hex digits). Preserve existing rotated credentials and migrations. **Never** put secrets in frontend JS, source ZIP, git or this chat.
4. Use the project's real database migration script, and inspect schema migrations. Do not replace the production SQLite database with the provided sources.
5. Expose HTTPS `/api/health` with `application/json` and JSON `{status:"ok",database:"connected"}`. Expose authenticated `/api/v1/kiosk/device-info` from the exact BUILD 23 Node code, with the extra `bridge_contract` string. Ensure WAF/proxy permits these narrow routes, while honoring auth and rate limits. An unknown `/api/*` path should return JSON `API_NOT_FOUND` rather than index.html.
6. Provision the kiosk in **Admin Portal > Devices** using the existing backend workflow. Record its exact **device name**; securely deliver its token out-of-band to the kiosk administrator. No default or shared tokens in ZIPs or QR codes. Rotate the default kiosk PIN before enabling live attendance.
7. First run the **READ-ONLY** diagnostics (below), then conduct staged real employee/time-in/out acceptance using consented test records. Confirm the record appears in authenticated Admin Attendance and employee views with matching employee/date/action; confirm duplicate action policy, offline behavior and realtime SSE. Never make a production punch merely to test connectivity.
8. Only after full release testing, implement backup restoration drill, operational monitoring, signing, rollbacks, privacy/retention/consent and explicit production approvals.

## Read-only API diagnostics

PowerShell in `adminwebportal-imaw-na-ini-main`:

```powershell
# Public health only: success is PARTIAL, NOT proof of live kiosk integration.
node .\scripts\build23-probe-live-api.mjs --base-url https://rsu-cajidiocan.tech

# Only when Build 23 API has been deployed and a test kiosk is provisioned.
# Type token into a local, private PowerShell session; do not paste in chat.
$env:SAVAGE_KIOSK_PROBE_DEVICE_ID = 'SAVAGE-RSUCAJ-KIOSK-01'
$secret = Read-Host 'Enter provisioned kiosk token' -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
try { $env:SAVAGE_KIOSK_PROBE_TOKEN = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
node .\scripts\build23-probe-live-api.mjs --base-url https://rsu-cajidiocan.tech
Remove-Item Env:\SAVAGE_KIOSK_PROBE_TOKEN -ErrorAction SilentlyContinue
```

The CLI returns `PASS` only if health and the exact device identity + bridge contract match, `PARTIAL` if no credentials were supplied, `FAIL` otherwise. The CLI does not submit or modify attendance/enrollment. Its output never includes tokens. Shell environment is still a short-lived secret exposure risk; run only on a trusted computer. Android Device Settings now has a **Test Live Connection** button with the same server/device validation, and keeps the token encrypted by Android Keystore.

### Expected failure interpretations

| Result | Action |
| --- | --- |
| `NETWORK_OR_TLS_UNREACHABLE` | Check DNS, TLS, firewall, hosting and internet |
| `HTTP_ERROR` 403 | Check Hostinger WAF/route or backend authentication according to step (health vs device) |
| `NOT_JSON_API` | `/api` points at the static frontend, wrong server or proxy fallback |
| `HTTP_REDIRECT` | API request is being redirected to login, www or another host; fix HTTPS origin/routing |
| `WRONG_API_HEALTH_CONTRACT` | Not the expected Express API or DB not healthy |
| `BRIDGE_CONTRACT_NOT_DEPLOYED` | Deploy current Build 23 backend; don't silently accept an old API |
| `DEVICE_ID_MISMATCH` | Device ID must exactly match Admin Portal > Devices |

## Source and tests

```powershell
# Under Android project (requires Python 3 and JDK with kotlinc for JVM smoke)
python .\tools\verify_build23_source.py
# The real APK build and physical acceptance still require Android SDK and device:
powershell -ExecutionPolicy Bypass -File .\scripts\build22-android-acceptance.ps1 -BootstrapWrapper -RunDeviceTests

# Under admin portal (Node >=20.19/22.12 as package requires)
npm run test:build23
npm run probe:live-api
```

## Security/no-go boundaries

- A device token HMAC is not hardware biometric attestation. An offline replay remains not capture-time attested; do not approve offline attendance for payroll without closing this issue. Limit/disable offline mode when entering production.
- `/api/health` plus a valid device token only establishes API identity and access. Face matching, PAD/liveness accuracy, duplicate behavior, device security and HR payroll need physical acceptance.
- No DNS/HTTP check from this build environment conclusively verified the target site. Domain web fetch returned 403; separate container DNS lookup failed. These are observations from this environment, not a blanket claim that the site is down.
- This build **does not** modify the user's live domain, issue tokens, trigger attendance, deploy to Hostinger or generate an installable APK.
