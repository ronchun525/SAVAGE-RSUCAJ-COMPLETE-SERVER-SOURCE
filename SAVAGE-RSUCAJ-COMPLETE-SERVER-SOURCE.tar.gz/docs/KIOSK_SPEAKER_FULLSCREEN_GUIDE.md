# Web Kiosk — Offline Speaker and Fullscreen Setup

## Implemented changes

- `/audio/thank-you.mp3`: packaged English speech for **backend-confirmed** Time In / Time Out only.
- `/audio/try-again.mp3`: packaged English speech for attendance verification failure only.
- `/audio/speaker-test.mp3`: short neutral diagnostic tone (Admin PIN -> Kiosk Settings -> **Test Speaker**).
- `/audio/prime.mp3`: silent audio clip played upon a user-initiated Start Attendance/Scan tap to help satisfy browser autoplay restrictions.
- Browser `speechSynthesis` is the fallback when a media asset cannot be played. Browser TTS is not always available on Linux.
- The **Voice Prompt** switch remains server-persisted; its OFF state suppresses automatic attendance voice cues. **Test Speaker** is a deliberate admin diagnostic and does not call out attendance text.
- `npm run test:speaker` runs self-contained audio flow tests without needing a physical speaker.

## Raspberry Pi desktop session (not an SSH-only headless console)

1. Ensure the backend and built website are accessible by HTTPS, or via loopback if running on the Pi. Set `KIOSK_URL` accordingly.
2. Connect a USB speaker or HDMI audio output, and select the actual output sink under Raspberry Pi OS Sound settings. A Pi 3 B also supports its analog audio output when configured.
3. In a terminal on the Pi desktop, check the detected devices: `aplay -l` and `wpctl status` (if WirePlumber is installed).
4. Test the OS independently of Chromium: `speaker-test -c 2 -t wav` (Ctrl+C to stop). If no output, fix the Linux sink and mute/volume before debugging the app.
5. Set audio volume if using PipeWire: `wpctl set-volume @DEFAULT_AUDIO_SINK@ 0.85` and `wpctl set-mute @DEFAULT_AUDIO_SINK@ 0`.
6. Grant **Camera** access in Chromium once for the trusted site. Do not use `--use-fake-ui-for-media-stream` or any camera spoofing flags.
7. From the project folder on the Pi desktop: `KIOSK_URL=https://your-approved-domain.example/kiosk bash scripts/start-kiosk-pi.sh`. Replace the example domain with your actual HTTPS host. For local development, omit `KIOSK_URL` to use `http://127.0.0.1:3000/kiosk`.
8. Unlock **Settings** with Admin PIN, turn on **Voice Prompt (Time In/Out Only)**, and click **Test Speaker**. You should hear a short tone. Then verify the actual attendance phrases using a successful or failed **real** biometric request, not a fake result.

**Important:** The launcher uses `--autoplay-policy=no-user-gesture-required` only on your physically managed kiosk device. This is needed for sound when a kiosk boots unattended, since browser audio autoplay may otherwise be blocked until a real click. This flag is a kiosk-side browser launch setting, **not** a server setting and not a substitute for working audio hardware. It does not bypass camera permissions or biometric security.

For Raspberry Pi OS desktop autostart, edit the **existing working** `.desktop` kiosk autostart to execute your `start-kiosk-pi.sh` script under the desktop user's environment. Do not replace a working service or autostart file without backup. Use the absolute source path after installing/deploying the project.

## Windows kiosk

Open PowerShell inside the project folder and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\start-kiosk-windows.ps1 -KioskUrl 'https://your-approved-domain.example/kiosk'
```

Select the output speaker and verify sound in Windows **Settings -> System -> Sound**. In kiosk Admin Settings, press **Test Speaker**. Grant browser camera permission for the trusted HTTPS kiosk origin.

## Troubleshooting

| Symptom | Verification / correction |
|---|---|
| Test Speaker is blocked | Browser autoplay disallowed. First click Test Speaker in a user gesture or launch managed Chromium with the kiosk autoplay flag. |
| Browser says it played but no sound | Check OS output sink, HDMI vs USB vs analog output, device volume and mute; test `speaker-test`. Browser promise cannot establish whether you physically heard the sound. |
| Audio test works but no Thank you / Try again | Enable Voice Prompt in Admin Settings. A cue is emitted only when an attendance request returns a real success or verification error; scanning/enrollment alone is intentionally silent. |
| Camera does not start on remote site | Serve the app over HTTPS (not HTTP over a LAN IP), allow browser camera permission, and verify a connected camera. |
| Faces cannot mark attendance | Source lacks production TFLite runtime and verified model files. Do not bypass recognition/liveness safeguards. |
| Local MP3 returns 404 | Redeploy the rebuilt frontend including the entire `public/audio/` directory (Vite copies it to `dist/audio/`). |
| Audio plays once, then stops after restart | Confirm the browser launch/autoplay policy and reconnect/check the OS speaker after power-on. |

## Not covered by software-only tests

Actual speaker hardware, Pi 3 B audio output, device wake/suspend, fullscreen compositor audio focus, Android browser volume, camera availability, and biometric inference still need device tests. Physical audio audibility has not been confirmed here.
