# CORRECTIONS & LEAVES POLICY SPECIFICATION (BUILD 11 / Schema 006)

**Institution:** Romblon State University – Cajidiocan Campus (`SAVAGE-RSUCAJ Smart Attendance System`)  
**Core Engine:** `server/correctionsLeavesEngine.ts`  
**Schema Migration:** `006` (`build11_corrections_leaves_policies_allocations_and_audits`)

---

## 1. Attendance Corrections Integrity & Audit-Safe Reversal

1. **Zero Fabricated Counterpart Punches:**
   - Approving an unpaired `Time In` correction sets `time_out = NULL` and attendance status to **`Missing Time Out`** (never fabricates `'05:00 PM'`).
   - Approving an unpaired `Time Out` correction sets `time_in = NULL` and attendance status to **`Missing Time In`** (never fabricates `'08:00 AM'`).
   - `Full Day` corrections require explicit `requested_time`, `requested_time_out`, mandatory reason, and supporting `document_reference`.
2. **Preservation of Authentic Kiosk Events:**
   - Original kiosk capture rows in `attendance_events` are immutable (`IMMUTABLE_AUDIT_VIOLATION` SQLite triggers).
   - Correction approvals and reversals append new audit events (`punch_type = 'correction'`, `decision_code = 'CORRECTION_APPROVED'` / `'CORRECTION_REVERSED'`) alongside pre/post JSON snapshots on `corrections` and append-only records in `correction_audit_log`.
3. **Audit-Safe Reversal (`POST /api/corrections/:id/reverse`):**
   - Requires `corrections:approve` and a mandatory reversal reason (`>= 5` chars).
   - Atomically restores `attendance_records` to its exact pre-correction snapshot (or deletes the attendance row if no record existed prior to approval) and appends a `'REVERSED'` record to `correction_audit_log`.
4. **Concurrency & State Protection:**
   - Duplicate approvals/rejections on an already-reviewed correction are atomically rejected with **HTTP `409` (`ALREADY_REVIEWED`)**.

---

## 2. Configurable Leave Policies, Multi-Day Propagation & Cross-Year Accounting

1. **Configurable HR Leave Policies (`leave_policies`):**
   - Managed via `GET /api/leave-policies` and `PUT /api/leave-policies/:id` (`leaves:policy_manage`).
   - Controls `annual_credits`, `is_paid`, `allow_half_day`, `exclude_weekends`, `exclude_holidays`, `requires_doc_days_threshold`, and `counts_as_ob`.
2. **Date-by-Date Eligible Day Allocation (`leave_day_allocations`):**
   - Spans past, current, and future dates across full ranges (not just today).
   - Automatically excludes shift `rest_days` / weekends and institutional `holidays` per policy configuration, recording each allocated day with `credit_year` and `day_fraction` (`1.0` for `FULL`, `0.5` for `HALF_AM` / `HALF_PM`).
   - **Half-Day Rules:** Rejects multi-day half-day requests; allows complementary `HALF_AM` + `HALF_PM` leaves on the same date while blocking overlapping same-portion duplicates.
   - **Cross-Year Ranges:** Splits leave credit charges cleanly across calendar years (e.g., Dec 30–31 charged to `2026`, Jan 4 charged to `2027`).
   - **Documentation Thresholds:** Enforces supporting documentation (e.g., Sick Leave `>= 3` days -> `400 DOCUMENTATION_REQUIRED`).
   - **Balance Protection:** Rejects approvals that would cause balance underflow with **HTTP `409` (`INSUFFICIENT_LEAVE_BALANCE`)**.
3. **Punch Conflict Detection & Resolution:**
   - Default `conflict_resolution = 'BLOCK'` rejects leave approval (`409 CONFLICTING_VALID_PUNCHES`) if valid punches exist on any requested leave date.
   - Explicit `conflict_resolution = 'PRESERVE_PUNCHES'` keeps punched dates intact and applies `On Leave` / `OB` only to non-conflicting eligible dates.
4. **Atomic Cancellation (`POST /api/leaves/:id/cancel`):**
   - Cancelling an `Approved` leave (restricted to authorized approvers) atomically restores prior `attendance_records` from stored pre-approval snapshots, reverses `leave_day_allocations`, restores leave credits, and appends `'CANCELLED'` to immutable `leave_audit_log`.
5. **Monthly Report Propagation:**
   - `GET /api/reports/attendance`, `GET /api/reports/dtr`, and `GET /api/reports/leaves` support overlap-safe date range queries (`start_date`/`startDate`, `end_date`/`endDate`, `employee_id`/`empId`, `department_id`/`deptId`) so multi-day and cross-year leaves never drop at month boundaries.
