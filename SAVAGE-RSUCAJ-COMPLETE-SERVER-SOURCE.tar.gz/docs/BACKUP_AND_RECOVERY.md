# SAVAGE-RSUCAJ Smart Attendance Admin Portal — Backup, Recovery & Legacy Data Import Guide

**Institution:** Romblon State University – Cajidiocan Campus  
**Version:** `1.4.0` (BUILD 06)  
**Database Engine:** SQLite (`better-sqlite3`, WAL mode, `PRAGMA foreign_keys = ON`, `PRAGMA synchronous = FULL`)

---

## 1. Persistent Storage & File-Permission Requirements (Production)

In production (`NODE_ENV=production`, `APP_MODE=production`), SQLite database files and backup directories **MUST** reside on persistent host storage outside the application build tree (never inside `dist/`, `build/`, `node_modules/`, `.git/`, or `:memory:`).

| Environment | Recommended `DATABASE_PATH` | Recommended `BACKUP_DIR` | Required Permissions |
|---|---|---|---|
| **Linux / Campus Server** | `/var/lib/savage-rsucaj/savage_rsucaj.db` | `/var/backups/savage-rsucaj` | Owned by dedicated service user (`savage:savage`), dir mode `0750`, files `0640`/`0600` |
| **Windows Server** | `C:\ProgramData\SAVAGE-RSUCAJ\data\savage_rsucaj.db` | `C:\ProgramData\SAVAGE-RSUCAJ\backups` | Service account Read/Write/Modify only; disable non-admin write access |

> Startup fails securely (`validateEnv` in `server/env.ts`) if `NODE_ENV=production` is paired with a missing, relative, `:memory:`, or ephemeral-build-tree `DATABASE_PATH`, or if `APP_MODE !== 'production'`.

---

## 2. WAL Mode, Checkpointing & Safe Shutdown

SQLite runs with:
- `PRAGMA foreign_keys = ON`
- `PRAGMA journal_mode = WAL`
- `PRAGMA synchronous = FULL`
- `PRAGMA busy_timeout = 5000` (configurable `1000..60000` via `SQLITE_BUSY_TIMEOUT_MS`)
- `PRAGMA wal_autocheckpoint = 1000` (configurable `100..10000` via `SQLITE_WAL_AUTOCHECKPOINT`)

### Why WAL Checkpointing Matters
The initial project ZIP contained a WAL-only artifact (`savage_rsucaj.db-wal` without a fully checkpointed main `.db` file). Never copy only `.db` with `cp` while the app is live — doing so risks missing uncheckpointed WAL frames or creating a corrupt snapshot.

In BUILD 06:
- Graceful server shutdown (`SIGINT`/`SIGTERM` in `server.ts`) calls `closeDatabaseSafely(db)` which runs `PRAGMA wal_checkpoint(TRUNCATE)` before `db.close()`.
- Administrators can trigger a manual checkpoint via `POST /api/backup/checkpoint` (Settings -> Backup & Recovery tab) or inspect live DB/WAL file sizes via `GET /api/health` and `GET /api/backup/status`.

---

## 3. Consistent Online Backups & Encrypted Offsite Archival

Online backups use SQLite's transactional `VACUUM INTO` command (`server/backup.ts`), producing a defragmented, self-contained single-file SQLite snapshot without stopping the live service.

### Backup Workflow (`createOnlineSqliteBackup`)
1. Runs best-effort passive WAL checkpoint (`PRAGMA wal_checkpoint(PASSIVE)`).
2. Executes `VACUUM INTO '<backupDir>/savage-rsucaj-<backupId>.sqlite'`.
3. Opens the snapshot read-only and verifies:
   - `PRAGMA integrity_check` === `'ok'`
   - `PRAGMA foreign_key_check` === `0` violations
   - Exact row counts across all 19 canonical business/security tables
4. Computes SHA-256 checksums and writes a `.manifest.json` file (mode `0600`).
5. When `BACKUP_ENCRYPTION_KEY` (>=32 chars) is configured, encrypts the snapshot to `.sqlite.enc` using **AES-256-GCM** with `scrypt` key derivation (`N=16384, r=8, p=1`, unique 16-byte random salt, 12-byte random IV, 16-byte authentication tag, magic header `SVB1`) so any bit-level tampering or wrong passphrase fails authentication immediately.
6. Records the backup in `backup_history` and prunes older local snapshots beyond `BACKUP_RETENTION_COUNT` (default `14`).

### CLI Backup Commands
```bash
# Linux / macOS
npm run db:backup
# Optional explicit paths:
npm run db:backup -- --db /var/lib/savage-rsucaj/savage_rsucaj.db --out /var/backups/savage-rsucaj

# Windows PowerShell
npm run db:backup -- --db "C:\ProgramData\SAVAGE-RSUCAJ\data\savage_rsucaj.db" --out "C:\ProgramData\SAVAGE-RSUCAJ\backups"
```

### Offsite Archival Transfer (Campus Operations Requirement)
After `npm run db:backup` creates the `.sqlite.enc` and `.manifest.json` pair, schedule an OS cron job / Windows Task Scheduler job to replicate ONLY the `.sqlite.enc` + `.manifest.json` files to an off-host target (campus NAS or encrypted cloud bucket) via `rsync`/`rclone`/S3 sync. Store `BACKUP_ENCRYPTION_KEY` in the campus password vault **separately** from both the server and offsite backup storage.

---

## 4. Verification, Restore Drills & Automatic Rollback

### Safe Dry-Run Restore Drill (Default Mode — Live DB Untouched)
```bash
npm run db:restore -- \
  --archive /var/backups/savage-rsucaj/savage-rsucaj-bkp-....sqlite.enc \
  --manifest /var/backups/savage-rsucaj/savage-rsucaj-bkp-....manifest.json \
  --target /var/lib/savage-rsucaj/savage_rsucaj.db
```
Dry-run verifies:
1. Encrypted archive SHA-256 against manifest
2. AES-256-GCM authenticated decryption using `BACKUP_ENCRYPTION_KEY`
3. Decrypted SQLite SHA-256 against manifest
4. `PRAGMA integrity_check === 'ok'` and `PRAGMA foreign_key_check === 0`
5. Exact per-table row count equality against manifest

### Live Restore Procedure (`--apply`)
1. Stop the SAVAGE-RSUCAJ portal service (`systemctl stop savage-rsucaj` or Windows Service stop) so no writers hold open handles.
2. Run live restore:
   ```bash
   npm run db:restore -- \
     --archive /var/backups/savage-rsucaj/savage-rsucaj-bkp-....sqlite.enc \
     --manifest /var/backups/savage-rsucaj/savage-rsucaj-bkp-....manifest.json \
     --target /var/lib/savage-rsucaj/savage_rsucaj.db \
     --apply
   ```
3. Before modifying the target DB, `restoreSqliteBackup` automatically:
   - Captures a consistent pre-restore snapshot (`<target>.pre-restore-<timestamp>.bak` via `VACUUM INTO`).
   - Removes stale `-wal` and `-shm` sidecars.
   - Atomically replaces the target database file.
   - Runs post-restore integrity, FK, and row-count checks; if ANY check fails, automatically restores the `.pre-restore-*.bak` snapshot and exits non-zero.
4. Restart the service and verify `npm run health`.

### Migration & Rollback Dry-Run Procedure
Before applying any schema migration to production, test an isolated snapshot-migrate-rollback cycle without touching the live database:
```bash
npm run db:migrate -- --dry-run --db /var/lib/savage-rsucaj/savage_rsucaj.db
```
When ready to apply migrations during a maintenance window:
```bash
npm run db:backup && npm run db:migrate -- --db /var/lib/savage-rsucaj/savage_rsucaj.db
```

---

## 5. Proposed RPO / RTO Targets *(PENDING PROJECT OWNER APPROVAL)*

> **Governance Notice:** The figures below are an engineering **PROPOSAL** for Romblon State University – Cajidiocan Campus MIS / Project Owner sign-off. They are **NOT** active SLA commitments until approved and automated offsite scheduling is deployed on the campus server.

| Objective | Proposed Target | Operational Mechanism | Approval Status |
|---|---|---|---|
| **RPO (Recovery Point Objective)** | **<= 6 hours** (4x daily automated `db:backup` + offsite sync, plus pre-payroll & pre-migration snapshots) | Cron / Task Scheduler running `npm run db:backup` + encrypted offsite replication; WAL durability protects against single-process crash between backups | **PENDING PROJECT OWNER APPROVAL** |
| **RTO (Recovery Time Objective)** | **<= 30 minutes** (same-host restore) / **<= 2 hours** (bare-metal rebuild from offsite `.sqlite.enc`) | Tested `npm run db:restore -- --apply` + `npm run health` + `npm run test:startup` verification | **PENDING PROJECT OWNER APPROVAL** |
| **Retention Policy** | **14 local online snapshots** + **90-day encrypted offsite retention** + **12 monthly payroll-close archives** | `BACKUP_RETENTION_COUNT=14` local pruning + offsite lifecycle policy | **PENDING PROJECT OWNER APPROVAL** |
| **Restore Drill Cadence** | **Monthly** automated dry-run (`POST /api/backup/verify-drill`) + **Quarterly** bare-metal staging restore | Logged in `backup_history` & `audit_logs` | **PENDING PROJECT OWNER APPROVAL** |

---

## 6. Legacy-Data Import Plan *(APPLICABLE ONLY IF A VERIFIED LEGACY SQLITE BACKUP IS SUPPLIED)*

### Honest Baseline Statement
The original uploaded project archive contained a **WAL-only artifact** (`data/savage_rsucaj.db-wal`) without a verified complete full SQLite database backup. In strict accordance with SAVAGE-RSUCAJ engineering integrity rules:
- **Zero legacy records were inferred, reconstructed, or fabricated from partial WAL fragments.**
- **Production deployments start with an authentic empty state** (`0` employees, `0` devices, `0` attendance records, `0` payroll runs, `0` demo notifications) until real campus records are entered or imported from an authenticated source.
- The legacy import procedure below applies **ONLY** if RSU Cajidiocan MIS supplies a verified, complete legacy SQLite database backup file.

### Verified Legacy-Data Import Procedure (8 Mandatory Steps)
1. **Chain-of-Custody & Checksum Intake:** Obtain the official legacy `.sqlite`/`.db` backup (and any companion `-wal`/`-shm` taken while the legacy app was stopped), record its SHA-256 hash (`sha256sum`), and store an immutable read-only archival copy.
2. **Offline Integrity Inspection (Staging Copy Only):** Copy the legacy file to an isolated staging directory (never directly onto production) and run:
   - `PRAGMA integrity_check;` (must return `ok`)
   - `PRAGMA foreign_key_check;` (must return `0` rows; document and remediate any orphan references with HR/MIS sign-off before import)
   - Capture exact source row counts per table (`employees`, `departments`, `positions`, `shifts`, `holidays`, `attendance_records`, `corrections`, `leaves`, `payroll_runs`, `payroll_items`, `devices`, `users`, `audit_logs`).
3. **Dry-Run Schema Migration & Rollback Verification:** Run `npm run db:migrate -- --dry-run --db <staging-copy.db>` to confirm non-destructive upgrade from legacy schema (`001`/`002`) to BUILD 06 (`003`) with zero data loss and verified rollback parity.
4. **Data Quality & Constraint Audit:** Inspect and resolve any legacy violations of BUILD 06 constraints prior to cutover:
   - Duplicate `(employee_id, attendance_date)` attendance rows
   - Negative salary/allowance values or invalid status enums
   - Invalid leave/payroll date ranges (`end_date < start_date`)
   - Duplicate kiosk `api_token` values (rotate all kiosk tokens before campus rollout)
5. **Account & Credential Remediation:** Verify existing `users` rows, disable any unused/test accounts, and execute `npm run admin:recover -- --username <admin> --force-rotate` so every migrated administrator account enforces strong password rotation on first login.
6. **Pre-Cutover Production Backup:** Capture a verified `npm run db:backup` snapshot of the target environment before applying any data migration.
7. **Controlled Cutover & Post-Import Reconciliation:** Promote the verified migrated SQLite file via `npm run db:restore -- --apply`, restart the service, and reconcile exact row counts, employee IDs (`EMP-XXXX`), payroll totals, and leave balances against the Step 2 baseline report with written MIS + HR sign-off.
8. **Post-Cutover Archival & Audit:** Run `npm run db:backup` immediately after sign-off to establish the verified post-import baseline snapshot and record the import event in campus change-control logs.
