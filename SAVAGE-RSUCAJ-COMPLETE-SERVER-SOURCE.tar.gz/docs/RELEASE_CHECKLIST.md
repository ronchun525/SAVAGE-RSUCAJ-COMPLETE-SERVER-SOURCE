# SAVAGE-RSUCAJ Smart Attendance Admin Portal — Release Checklist (BUILD 17)

**Current Build:** `BUILD 17` (`v1.13.0`, Schema `009`)  
**Evaluation Timestamp (UTC):** `2026-11-21T10:00:03Z`  
**Automated Gate Command:** `npm run release:gate` -> **`NO-GO` (`PASS=4`, `FAIL=0`, `BLOCKED=6`, exit code `2`)**  
**Production Release Status:** **`NO-GO` — PRODUCTION DEPLOYMENT BLOCKED**

> **MANDATORY RULE:** Do **NOT** deploy to live Romblon State University – Cajidiocan Campus production or declare `PRODUCTION-READY` until **EVERY** gate below (`RG-01` through `RG-10`) is verified `PASS` with recorded institutional, biometric, hardware, and operational evidence.

---

## Gate 1 — Reproducible Dependency & Build Integrity (`RG-01`: **PASS**)

- [x] `package-lock.json` committed and synchronized with `package.json` (`v1.13.0`).
- [x] Dependency audit clean (`bun audit`: **0 vulnerabilities** across 277 packages).
- [x] Cross-platform scripts (`npm start`, `npm run clean`, `npm test`, `npm run test:browser`, `npm run test:staging`, `npm run test:startup`, `npm run staging:setup`, `npm run release:gate`, `npm run health`, `npm run admin:recover`, `npm run db:migrate`, `npm run db:backup`, `npm run db:restore`, `npm run db:seed-demo`) verified.
- [x] `npm run lint` (`tsc --noEmit`) exits with code `0` (0 errors).
- [x] `npm run build` (`vite build`) produces `dist/index.html` and static assets with zero errors (`754 ms`).

## Gate 2 — Automated Software, Security, Staging Load & Browser E2E Verification (`RG-02`, `RG-03`: **PASS**)

- [x] Unit tests (`npm run test:unit`): **15/15 PASS**
- [x] Database Durability, Migrations (`001`–`009`), WAL, Concurrency & Encrypted Backup/Restore (`npm run test:db`): **10/10 PASS**
- [x] Attendance Policy, `Asia/Manila`, `03:00` Cutoff, Drift/Replay & Immutability (`npm run test:attendance`): **18/18 PASS**
- [x] Kiosk AES-256-GCM Offline Queue, Batch Sync, HMAC Evidence, Heartbeat & SSE (`npm run test:sync`): **6/6 PASS**
- [x] Corrections Immutability/Reversal, Multi-Day/Half-Day/Cross-Year Leave Policies & Reports (`npm run test:corrections-leaves`): **13/13 PASS**
- [x] Institutional Payroll Engine, Split-Month Proration, Golden Vectors, Maker-Checker, Immutability & Payslips (`npm run test:payroll`): **10/10 PASS**
- [x] DB-Backed Reports, Monthly DTR (`28`/`29`/`30`/`31` days), A4 `pdfkit` PDF, Unclipped Streaming CSV & RBAC (`npm run test:reports`): **8/8 PASS**
- [x] Admin Ops, Validated Settings, Secret Masking, Guarded Live Restore, Retention, Device Secrets, Role Notifications & Tamper-Evident Audit (`npm run test:admin-ops`): **8/8 PASS**
- [x] API, Security, RBAC & Backup Endpoint Integration (`npm run test:api`): **20/20 PASS**
- [x] Staging Security Audit, Controllable Impairment, Offline Sync, Load/Concurrency (`200` reads `p95=585.17 ms`, `50` punches `p95=199.31 ms`, `0` HTTP 5xx) & Backup/Restore Benchmark (`npm run test:staging`): **7/7 PASS**
- [x] Isolated Production Startup, Authentic Empty-State & Auth Revocation Smoke (`npm run test:startup` at `v1.13.0` / `BUILD 17` / Schema `009`): **5/5 PASS**
- [x] Real Browser Playwright Chromium E2E across **all 16 reference screens & 4 viewports** (`1366×768`, `1920×1080`, `768×1024`, `390×844`) (`npm run test:browser`): **22/22 PASS** (`41` audited screenshots, `0` page errors, `0` blocking console errors, `0px` overflow, `0` broken images, `0` unlabeled inputs, `0` Admin Biometrics links).
- [x] Side-by-side visual inspection of captured desktop, tablet, and mobile screenshots against all 16 reference PNGs in `public/assets/aistudio/` completed (faithful palette, official RSU emblem, layout, icons, zero redesign).

## Gate 3 — Database Integrity, Live DB Safety & Backup/Restore (`RG-04`: **PASS**)

- [x] Live `./data/savage_rsucaj.db` preserved untouched at Schema `009`, verified via `npm run db:migrate -- --dry-run --db ./data/savage_rsucaj.db` (`009 -> 009 -> 009`, `Integrity Check: ok`, `FK Violations: 0`, `Exact Row Counts Match: true`).
- [x] Cross-module audit hash-chain bug (`server/correctionsLeavesEngine.ts` `recordGeneralAudit`) fixed by delegating to `logAudit()`; `GET /api/audit-logs/verify` confirmed `valid: true` before and after guarded live restore.
- [x] Online `VACUUM INTO` + AES-256-GCM backup (`69.09 ms`) and guarded live restore (`261.98 ms`) verified with automatic `.pre-restore-*.bak` snapshot and rollback on failure.

## Gate 4 — Environment, Production Host, TLS & Secrets (`RG-05`: **BLOCKED**)

- [x] Zero hardcoded default credentials; fail-secure startup validation; `APP_MODE=production` strictly blocks demo seeding and `/api/staging/*` (`403 STAGING_ONLY_ENDPOINT`).
- [x] `DEPLOYMENT.md`, `OPERATIONS_RUNBOOK.md`, and `SECURITY.md` authored for Linux VPS (`systemd`, Nginx/Caddy TLS, UFW, logrotate, cron backups), Hostinger Single static alternative, and Windows PowerShell.
- [ ] **BLOCKER (`RG-05`):** Provision production Linux VPS `.env` from approved secret store (`NODE_ENV=production`, `APP_MODE=production`, persistent `/var/lib/savage-rsucaj/data/savage_rsucaj.db`, `/var/backups/savage-rsucaj`, unique 48-byte `SESSION_SECRET` & `BACKUP_ENCRYPTION_KEY`, `ALLOWED_ORIGINS`, `TRUST_PROXY=true`) and pass `NODE_ENV=production npm run check:env -- --strict`.
- [ ] **BLOCKER (`RG-05`):** Confirm DNS ownership & valid HTTPS/TLS 1.2+ certificate (e.g., `attendance.rsu-cajidiocan.tech` only once verified) with unbuffered SSE reverse proxy and HSTS.

## Gate 5 — Institutional HR & Finance Governance (`RG-06`, `RG-07`: **BLOCKED**)

- [ ] **BLOCKER (`RG-06`):** Obtain written **RSU Cajidiocan HRMO** confirmation against the official Civil Service Form 48 template before setting `cs_form_48_reference_verified='true'` (currently `false`; PDFs honestly render Draft Institutional Format).
- [ ] **BLOCKER (`RG-07`):** Obtain written **RSU Cajidiocan Finance Office** sign-off on institutional GSIS/PhilHealth/Pag-IBIG/BIR payroll policy tables and golden scenario outputs (`approvedPayrollPolicies = 0` in live DB).

## Gate 6 — Real Biometric Verification & Anti-Spoofing (`RG-08`: **BLOCKED**)

- [ ] **BLOCKER (`RG-08`):** Complete **BUILD 09** real neural face recognition and passive/active Presentation Attack Detection (anti-spoof liveness) integrated with BUILD 10 cryptographic envelopes (`liveness_verified` and `match_verified` remain `false` by design until verified with measured FAR/FRR/APCER/BPCER evidence).

## Gate 7 — Physical Kiosk Hardware & External App Staging Acceptance (`RG-09`: **BLOCKED**)

- [ ] **BLOCKER (`RG-09`):** Connect real **Raspberry Pi 3B+ Kiosk**, **Android Kiosk**, **Android Employee Mobile App**, and **Windows Desktop Browser** to an HTTPS staging host and complete every pending row (`HW-01`..`HW-04`) in `docs/STAGING_ACCEPTANCE_MATRIX.md` (separate repositories/APKs/devices were not supplied in this workspace).

## Gate 8 — Offsite Backup Replication, On-Call Roster & Project Owner Go-Live Sign-Off (`RG-10`: **BLOCKED**)

- [ ] **BLOCKER (`RG-10`):** Configure and drill automated offsite encrypted backup transfer (`.sqlite.enc` + `.manifest.json` -> campus NAS or encrypted cloud storage) with bare-metal restore verification.
- [ ] **BLOCKER (`RG-10`):** Configure institutional Google SSO OAuth & outbound SMTP (or record formal RSU MIS sign-off accepting local auth + `npm run admin:recover` CLI SOP).
- [ ] **BLOCKER (`RG-10`):** Populate named on-call contacts in `OPERATIONS_RUNBOOK.md`, approve proposed SLO/RPO/RTO targets, and record written **Project Owner Go-Live Authorization**.

---

## Final Release Gate Decision

| Criterion | Result |
|---|---|
| **BUILD 17 Software & Verification Engineering Scope Met?** | **YES** — `142/142` automated checks PASS (`115` backend/staging + `5` startup smoke + `22` Playwright Chromium 16-screen/4-viewport E2E), `0` vulnerabilities, live DB untouched at Schema `009`, full ops/security/release pack delivered. |
| **Automated Release Gate (`npm run release:gate`)** | **`NO-GO`** (`PASS=4`, `FAIL=0`, `BLOCKED=6`, exit code `2`) |
| **Production Deployment Permitted?** | **NO — `NO-GO` (PRODUCTION RELEASE STATUS: BLOCKED)** until Gates `RG-05` through `RG-10` are closed and signed off. |
