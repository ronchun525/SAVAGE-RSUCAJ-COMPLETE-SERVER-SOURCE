# PAYROLL POLICY, CALCULATION ENGINE & GOVERNANCE CONTROLS (BUILD 12 / v1.8.0)

**Institution:** Romblon State University – Cajidiocan Campus (`SAVAGE-RSUCAJ Smart Attendance System`)  
**Schema Version:** `007` (`build12_payroll_policies_immutability_maker_checker_and_audit`)  
**Engine Version:** `BUILD12-v1.0` (`server/payrollEngine.ts`)  
**Production Release Gate Status:** **BLOCKED** — *Live payroll Finalize & Release remain strictly blocked until RSU Cajidiocan Finance signs off the institutional policy schedule and verifies actual campus scenario outputs.*

---

## 1. Elimination of Placeholder Payroll Logic

BUILD 12 permanently removes all legacy hard-coded payroll placeholders (`11.5% + ₱200` static deductions and fixed `salary / 22` daily divisors). Every calculation now requires an **effective-dated institutional payroll policy** stored in `payroll_policies` (`GET /api/payroll/policies`).

- If no effective-dated policy exists for the requested period, `POST /api/payroll/compute` returns **HTTP `422` (`PAYROLL_POLICY_REQUIRED`)** and directs operators to the blank **Institutional Policy Input Template** (`GET /api/payroll/policy-template`).
- If a policy exists in `DRAFT_NOT_APPROVED` status, authorized payroll makers may preview draft computations, which are explicitly stamped **`NOT APPROVED FOR PRODUCTION`** (`is_production_approved = 0`).
- **Hard Release Gate:** `PATCH /api/payroll/:id/finalize` and `PATCH /api/payroll/:id/release` strictly reject any run linked to an unapproved policy with **HTTP `409` (`PAYROLL_POLICY_NOT_APPROVED`)**.

---

## 2. Institutional Policy Input Template (`GET /api/payroll/policy-template`)

The blank template supplies structure and documentation with zero fabricated statutory rates. Institutional Finance must complete and formally approve (`POST /api/payroll/policies/:id/finance-approve`) the following rule blocks:

1. **Schedule & Proration Basis:**
   - `payFrequency`: `SEMI_MONTHLY` | `MONTHLY` | `BI_WEEKLY`
   - `standardWorkHoursPerDay`: numeric (e.g., `8`)
   - `prorationBasis`: `SCHEDULED_WORKING_DAYS_IN_MONTH` | `CALENDAR_DAYS_IN_MONTH` | `FIXED_WORKING_DAYS_PER_MONTH`
   - `fixedWorkingDaysPerMonth`: `null` or explicit integer when `FIXED_WORKING_DAYS_PER_MONTH` is chosen
   - `allowanceProrationMode`: `PRORATE_BY_SCHEDULED_DAYS` | `HALF_FOR_SEMI_MONTHLY` | `FULL_PER_PERIOD`
2. **Employee Type Matrix (`employeeTypes`):**
   - Separate eligibility flags per classification (`Regular`, `Contractual`, `Part-Time`, etc.): `payBasis`, `overtimeEligible`, `holidayPayEligible`, `statutoryEligible`, `taxEligible`, `paidLeaveEligible`, `allowanceEligible`.
3. **Attendance Deductions & Multipliers:**
   - `tardiness`: `enabled`, `roundingIncrementMinutes`, `rateMultiplier`
   - `undertime`: `enabled`, `roundingIncrementMinutes`, `rateMultiplier`
   - `absences`: `deductPerDayMultiplier`, `deductMissingRecordAsAbsent`
   - `leaves`: `paidLeaveRateMultiplier`, `unpaidLeaveDeductionMultiplier`
4. **Overtime, Holidays & Rest Days:**
   - `overtime`: `enabled`, `minimumOvertimeMinutes`, `ordinaryDayMultiplier`, `restDayMultiplier`, `specialHolidayMultiplier`, `regularHolidayMultiplier`
   - `holidaysAndRestDays`: `regularHolidayWorkedPremiumMultiplier`, `specialHolidayUnworkedPaid`, `specialHolidayWorkedPremiumMultiplier`, `restDayWorkedMultiplier`
5. **Statutory Contributions (`statutoryContributions[]`):**
   - Effective-dated institutional brackets/percentages/fixed amounts (GSIS/SSS, PhilHealth, Pag-IBIG, etc.) with basis (`MONTHLY_SALARY` | `GROSS_PAY` | `BASIC_PAY`), mode (`PERCENTAGE` | `FIXED_PER_PERIOD` | `BRACKET`), caps, and `periodDivisor`.
6. **Withholding Tax (`withholdingTax`):**
   - `enabled`, `taxExemptAllowances`, and progressive `brackets[]` (`min`, `max`, `baseTax`, `excessRatePercent`).
7. **Rounding (`rounding`):**
   - `currencyDecimals` (`0–4`, standard `2`) and `mode` (`HALF_UP` | `HALF_EVEN`).
8. **Special Pay Exceptions (`specialExceptions[]`):**
   - Explicit employee-scoped earnings/deductions (honoraria, overload pay, approved deductions) with `taxable` flag.

---

## 3. Split-Month & Partial-Period Proration Formula

For any payroll period `[start_date, end_date]` (including periods crossing month boundaries such as `2026-04-27` to `2026-05-08`), the engine partitions the period by calendar month:

1. For each calendar month `m` overlapping `[start_date, end_date]`:
   - Determine the employee's active employment window (`date >= hired_date`, respecting active/employment dates).
   - Enumerate every day in month `m` using pure `Asia/Manila` date math, respecting the employee's assigned shift `rest_days`.
   - Compute `scheduled_days_in_month(m)` (or configured divisor) -> `daily_rate(m) = monthly_salary / divisor(m)`, `hourly_rate(m) = daily_rate(m) / standardWorkHoursPerDay`, `minute_rate(m) = hourly_rate(m) / 60`.
   - Sum prorated basic pay and allowance across the employee's scheduled working days falling inside `[start_date, end_date]` in month `m`.
2. Day-level adjustments inside `[start_date, end_date]` use the exact month `m` daily/hourly/minute rate for that date:
   - **Approved Leaves:** Evaluated from `leave_day_allocations` joined with `leave_policies.is_paid` (`FULL = 1.0`, `HALF_AM`/`HALF_PM = 0.5`). Unpaid leaves (`LWOP`) deduct `fraction * daily_rate(m) * unpaidLeaveDeductionMultiplier`.
   - **Holidays & Rest Days:** Regular Holidays worked add `daily_rate(m) * regularHolidayWorkedPremiumMultiplier`; Special Non-Working Holidays unworked deduct `daily_rate(m)` if `specialHolidayUnworkedPaid === false`; worked Rest Days add `daily_rate(m) * restDayWorkedMultiplier`.
   - **Tardiness, Undertime & Absences:** Computed strictly from `attendance_records` (`late_minutes`, `undertime_minutes`, `Absent`), respecting rounding increments and multipliers.
   - **Overtime:** Applied only when `overtime_minutes >= minimumOvertimeMinutes` and employee type is overtime-eligible, using the day-type multiplier (`ordinary`, `restDay`, `specialHoliday`, `regularHoliday`).
3. Every line item stores a structured `breakdown_json` snapshot recording month splits, rates, day counts, statutory items, withholding tax, exceptions, and exact intermediate totals.

---

## 4. Pre-Compute Reconciliation Blockers (`GET /api/payroll/precheck`)

Before `POST /api/payroll/compute` writes any payroll rows, `reconcilePayrollPeriodPrecheck()` inspects the requested period and blocks computation with **HTTP `409`** if ANY unresolved anomaly exists:

| Blocker Condition | HTTP Status & Code | Required Resolution |
|---|---|---|
| Pending attendance corrections inside `[start_date, end_date]` | `409 PENDING_CORRECTIONS_EXIST` | Approve or reject all pending corrections for the period. |
| Pending leave applications overlapping `[start_date, end_date]` | `409 PENDING_LEAVES_EXIST` | Approve, reject, or cancel overlapping pending leaves. |
| Unresolved `Missing Time In` or `Missing Time Out` records | `409 UNRESOLVED_MISSING_PUNCHES` | Resolve incomplete punches via HR corrections or reconciliation. |

---

## 5. Period Uniqueness, Versioning, Atomicity & Immutability

- **Period Uniqueness:** Unique index `idx_payroll_runs_period_unique` on `(start_date, end_date)` plus overlap checks block duplicate (`409 DUPLICATE_PAYROLL_PERIOD`) and overlapping (`409 OVERLAPPING_PAYROLL_PERIOD`) runs unless explicitly invoked with `recompute: true` on a `Draft` run.
- **Idempotent Recompute & Versioning:**
  - Every computed run computes a deterministic **SHA-256 snapshot hash** (`snapshot_sha256`) over the sorted canonical policy + line items.
  - Invoking `recompute: true` on an unchanged `Draft` period returns **HTTP `200`** with `idempotentNoOp: true` without incrementing `calculation_version`.
  - When upstream attendance/corrections/leaves change (e.g., a backdated approved correction), `recompute: true` atomically replaces `payroll_items`, increments `calculation_version`, updates `snapshot_sha256`, and appends a `RECOMPUTED` entry to `payroll_audit_log`.
- **Atomic `BEGIN IMMEDIATE` Rollback:** All writes execute inside `db.transaction(...).immediate()`. Any partial failure rolls back both `payroll_runs` and all `payroll_items` cleanly with zero orphaned rows.
- **SQLite Immutability Triggers (Migration `007`):**
  - `trg_payroll_runs_immutable_upd` / `trg_payroll_runs_immutable_del` raise `PAYROLL_LOCKED_VIOLATION` on unauthorized edits or deletes of `Finalized` / `Released` runs.
  - `trg_payroll_items_locked_ins` / `upd` / `del` raise `PAYROLL_LOCKED_VIOLATION` on any insert, update, or delete against items belonging to a `Finalized` or `Released` run.
  - `trg_payroll_audit_log_immutable_upd` / `del` raise `IMMUTABLE_AUDIT_VIOLATION` on any modification or deletion of `payroll_audit_log`.

---

## 6. Governance Workflow: Maker-Checker Separation & Finance Sign-Off

1. **Compute (`Draft`)** — `POST /api/payroll/compute` (`payroll:compute`). Records `computed_by_user_id`.
2. **Finalize (`Finalized`)** — `PATCH /api/payroll/:id/finalize` (`payroll:finalize`).
   - Requires `policy.approval_status === 'APPROVED_BY_FINANCE'` (`409 PAYROLL_POLICY_NOT_APPROVED`).
   - Enforces **Maker-Checker Separation**: `actor.userId !== run.computed_by_user_id` (`403 MAKER_CHECKER_VIOLATION`).
3. **Finance Sign-Off** — `POST /api/payroll/:id/finance-signoff` (`payroll:finance_signoff`).
   - Requires `status === 'Finalized'` and a non-empty institutional voucher/memo reference (`finance_signoff_ref`).
   - Enforces **Maker-Checker Separation**: `actor.userId !== run.computed_by_user_id` (`403 MAKER_CHECKER_VIOLATION`).
4. **Release (`Released`)** — `PATCH /api/payroll/:id/release` (`payroll:release`).
   - Requires `status === 'Finalized'` (`409 PAYROLL_NOT_FINALIZED`), Finance-approved policy, AND recorded Finance sign-off (`409 FINANCE_SIGNOFF_REQUIRED`).
   - Enforces `actor.userId !== run.computed_by_user_id` (`403 MAKER_CHECKER_VIOLATION`).

---

## 7. Payslip Privacy, CSV Formula Injection Protection & Reconciliation

- **Employee Self-Service (`payroll:read_self`):**
  - `GET /api/payroll/my-payslips` returns **ONLY** `Released` payslips matching `req.user.employee_id`.
  - `GET /api/payroll/:runId/payslip/:employeeId` enforces strict authorization: employees receive `403` on any `Draft` or `Finalized` (unreleased) run or any other employee's payslip.
- **Formula-Injection-Safe Server CSV Export (`GET /api/payroll/:id/export.csv`):**
  - Sanitizes every CSV cell beginning with `=`, `+`, `-`, `@`, `\t`, or `\r` (including after leading whitespace) by prefixing `'` (`sanitizeCsvCell`).
  - Sets `Cache-Control: no-store`, `Content-Disposition: attachment`, and exports zero user credentials, password hashes, session tokens, or kiosk secrets.
- **Reconciled Reporting (`GET /api/reports/payroll`):**
  - Reconciles directly against `payroll_runs` and `payroll_items` so `SUM(payroll_items.*) === payroll_runs.total_* === GET /api/reports/payroll`.

---

## 8. Institutional Finance Sign-Off Blocker

Automated verification (`tests/payroll.test.ts`, 10/10 PASS) validates engine precision down to `0.01` using an explicitly labeled **synthetic test fixture policy**. Before RSU Cajidiocan transitions payroll to live production use:

1. Campus Finance must complete the blank Policy Input Template (`GET /api/payroll/policy-template`) with official RSU / DBM / GSIS / PhilHealth / Pag-IBIG / BIR tables and rounding rules.
2. Campus Finance must review and sign off sample campus payroll runs covering all employee types and edge cases.
3. Policy approval (`POST /api/payroll/policies/:id/finance-approve`) and per-run Finance sign-off (`POST /api/payroll/:id/finance-signoff`) must be executed by authorized separate personnel.
