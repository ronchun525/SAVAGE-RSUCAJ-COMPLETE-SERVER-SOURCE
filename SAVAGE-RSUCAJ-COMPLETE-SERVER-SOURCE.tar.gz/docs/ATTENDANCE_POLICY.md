# SAVAGE-RSUCAJ Attendance Policy & Timezone Specification (BUILD 08)

**Institution:** Romblon State University – Cajidiocan Campus  
**Canonical Timezone:** `Asia/Manila` (Philippines Standard Time, UTC+08:00, fixed offset, no DST)  
**Implemented In:** `server/attendanceEngine.ts`, `server/db.ts` (Migration `004`), `server/api.ts`, `src/components/AttendanceView.tsx`

---

## 1. Explicit Attendance Actions (No Implicit Inference)

Every kiosk request to `POST /api/kiosk/punch` MUST declare an explicit approved `punch_type`:

| Action | Purpose | Duplicate Behavior |
|---|---|---|
| `TIME_IN` | Starts an employee's shift on the resolved shift date. | Rejected with HTTP `409 DUPLICATE_TIME_IN`. **Never** implicitly converted into `TIME_OUT` and **never** overwrites existing `time_in`. |
| `BREAK_OUT` | Marks start of an unpaid/scheduled break after `TIME_IN`. | Rejected with HTTP `409 DUPLICATE_BREAK_OUT`. Requires open `TIME_IN` and no prior `TIME_OUT`. |
| `BREAK_IN` | Marks return from break after `BREAK_OUT`. | Rejected with HTTP `409 DUPLICATE_BREAK_IN` or `409 UNMATCHED_BREAK_IN`. |
| `TIME_OUT` | Closes the active shift and computes net work hours, undertime, and overtime. | Rejected with HTTP `409 DUPLICATE_TIME_OUT`. **Never** overwrites existing valid `time_out`. |
| `OVERTIME_OUT` | Records post-shift overtime end after `TIME_OUT` without modifying `time_out`. | Rejected with HTTP `409 DUPLICATE_OVERTIME_OUT` or `409 UNMATCHED_OVERTIME_OUT`. |

Omitting `punch_type` or supplying an unapproved value returns HTTP `400 INVALID_ACTION`.

---

## 2. Work/Shift Date Assignment & 03:00 Asia/Manila Next-Day Cutoff

- All date boundaries are computed strictly in **`Asia/Manila` (UTC+08:00)**, independent of host OS or browser UTC timezone.
- **Day Shifts** (e.g., `08:00 AM – 05:00 PM`):
  - `TIME_IN` attaches to the `Asia/Manila` calendar date of the authoritative punch timestamp.
  - `TIME_OUT` (including late-night `11:59 PM -> 12:01 AM` transitions) attaches to the previous day's open shift up to **03:00 AM `Asia/Manila` next calendar day** (`02:59 AM` ACCEPTED; `03:01 AM` REJECTED & ESCALATED).
- **Overnight / Night Shifts** (e.g., `10:00 PM – 07:00 AM`, where `shift_end <= shift_start`):
  - `TIME_IN` occurring after midnight prior to shift end attaches to the shift's start date (`yesterday`).
  - `TIME_OUT` attaches to the prior day's open shift within the approved overnight cutoff window (bounded at `min(scheduled_end + 4h, next_shift_start - 2h)`).
- **HR Escalation (`422 CUTOFF_EXCEEDED_ESCALATED` / `409 UNMATCHED_TIME_OUT` / `422 OFFLINE_REPLAY_EXPIRED`):**
  - Never fabricates missing `TIME_IN` or `TIME_OUT`.
  - Never overwrites an existing valid punch.
  - Creates a `Pending` row in `corrections`, emits a `High`-priority `Attendance Alerts` notification, and appends an immutable `ESCALATED` row to `attendance_events`.

---

## 3. Server Clock Authority, Drift Tolerance & Offline Replay

- **Server Clock Authority:** Client-supplied `punch_time` strings are ignored for live punches; the server clock (`nowProvider()` / `Date.now()`) in `Asia/Manila` is authoritative.
- **Live Drift Tolerance:** When `device_timestamp` (ISO-8601 with timezone) is supplied on a live punch, drift exceeding `±120s` (configurable via `kiosk_max_clock_drift_sec`) is rejected with HTTP `422 CLOCK_DRIFT_EXCEEDED`.
- **Offline Replay (`offline_replay: true`):**
  - Requires a valid explicit ISO-8601 `device_timestamp`.
  - Must not exceed `72 hours` age (`kiosk_offline_replay_max_hours`); older events return `422 OFFLINE_REPLAY_EXPIRED` and escalate to HR.
  - Enforces strict chronological ordering against recorded UTC punch timestamps (`409 OUT_OF_ORDER_TIMESTAMP`).
- **Idempotency & Concurrency:**
  - Executes inside a SQLite `BEGIN IMMEDIATE` transaction (`db.transaction(...).immediate()`).
  - Duplicate `event_uid` retries return HTTP `200 duplicate_ignored` without mutating records or duplicating events.
  - Parallel duplicate HTTP requests are serialized atomically with zero overwrites.

---

## 4. Canonical Attendance Statuses & Separate Reconciliation Engine

Only the following **10 approved statuses** are permitted (enforced at both application layer and SQLite triggers `trg_att_status_valid_ins` / `trg_att_status_valid_upd`):

`Present`, `Late`, `Absent`, `Undertime`, `On Leave`, `OB`, `Rest Day`, `Holiday`, `Missing Time Out`, `No Schedule`

**Reconciliation (`POST /api/attendance/reconcile`):**
- Evaluates active employees for a target `Asia/Manila` shift date without overwriting completed punches.
- Precedence for employees without a completed punch:
  1. Inactive/missing shift -> `No Schedule`
  2. Approved `OB` / `Official Business` -> `OB`
  3. Approved Leave -> `On Leave`
  4. Declared Holiday -> `Holiday`
  5. Configured Shift `rest_days` match -> `Rest Day`
  6. Open `TIME_IN` with `time_out IS NULL` **strictly after** shift cutoff (`> 03:00 AM` next day) -> `Missing Time Out` (`time_out` remains `NULL`, never fabricated)
  7. Zero punches on working day **strictly after** shift cutoff -> `Absent`

---

## 5. Immutable Punch Audit Trail

- Table `attendance_events` stores forensic columns (`event_uid`, `server_timestamp_utc`, `manila_timestamp`, `device_timestamp_utc`, `clock_drift_seconds`, `offline_replay`, `decision`, `decision_code`, `decision_reason`, `source`).
- Protected by SQLite `BEFORE UPDATE` (`trg_att_events_immutable_upd`) and `BEFORE DELETE` (`trg_att_events_immutable_del`) triggers raising `IMMUTABLE_AUDIT_VIOLATION`, plus partial unique index `idx_att_events_accepted_unique` on `(employee_id, attendance_date, punch_type) WHERE decision = 'ACCEPTED'`.
- Accessible per attendance record via `GET /api/attendance/:id/events` (RBAC + department/self scope enforced).

> **Biometric Boundary:** BUILD 08 enforces attendance policy, timezone correctness, idempotency, and audit immutability only. Real facial recognition / liveness / anti-spoofing verification is NOT claimed here and is reserved for BUILD 09.
