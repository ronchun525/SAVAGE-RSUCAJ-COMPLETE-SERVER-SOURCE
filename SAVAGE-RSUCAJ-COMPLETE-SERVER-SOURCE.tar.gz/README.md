# SAVAGE-RSUCAJ Smart Attendance System

**Romblon State University – Cajidiocan Campus**  
*Safe · Secure · Smart*  
**Version:** `1.14.0` (BUILD 36 · Schema `011`)  
**Release Gate Status:** **`NOT PRODUCTION READY` / `NO-GO`** *(run `npm run release:gate` for live 10-gate report; Web Kiosk production biometrics fail closed `503` until `.tflite` models & server-side inference are deployed)*

A full-stack campus attendance, schedule, leave, kiosk device, Employee Portal (`/employee`), Web Face Recognition Kiosk (`/kiosk`), and payroll management platform built with **React 19**, **TypeScript**, **Tailwind CSS v4**, **Vite 8**, **Node.js / Express**, and **SQLite (`better-sqlite3`, WAL mode)**.

## Supported Runtime

- **Node.js:** `^20.19.0` or `>=22.12.0` (verified on Node `v22.23.2`)
- **npm:** `>=10.0.0` (uses committed `package-lock.json` with `npm ci`)
- **Operating Systems:** Cross-platform scripts verified for **Linux**, **macOS**, and **Windows PowerShell / CMD**
- **Institutional Timezone:** `Asia/Manila` (Philippines Standard Time, UTC+08:00 — host-OS independent)

## Web Face Recognition Kiosk (`/kiosk`) — BUILD 36

- **Route:** `/kiosk` (or `/?portal=kiosk`) — responsive 16-screen browser kiosk for Windows PC, Android phone/tablet, and Raspberry Pi 3 Model B (`1024×600` Chromium kiosk mode).
- **Mandatory Rules:** **FRONT FACE ONLY** (zero left/right head-turn prompts, zero manual enrollment shutter button), Admin PIN + Employee Selection required before touchless enrollment, strict server-side 1:N cosine matching against AES-256-GCM templates, and attendance-only voice prompts (`"Thank you."` / `"Try again."`).
- **Required Environment Variables (`.env`):**
  - `KIOSK_TEMPLATE_ENCRYPTION_KEY`: 64-character hex AES-256-GCM key (mandatory in `staging`/`production`).
  - `KIOSK_MODELS_DIR`: Directory containing verified BUILD 20 `.tflite` models (`anti_spoofing_pad.tflite`, `liveness_detection.tflite`, `face_recognition.tflite`, default `./models`).
- **Admin Provisioning Flow:** Sign in to Admin Portal (`/`) -> **Devices** -> set **Kiosk Admin PIN** (`PUT /api/kiosk/web/admin-pin`) -> click **Activation Code** on an active kiosk device (`POST /api/devices/:id/activation-code`) -> open `https://rsu-cajidiocan.tech/kiosk` (HTTPS required for browser `getUserMedia` camera access on non-localhost hosts) and enter the one-time activation code.
- **Deployment Notes (`https://rsu-cajidiocan.tech/kiosk`):**
  - Serve behind Nginx/Caddy HTTPS TLS with `Permissions-Policy: camera=(self)` preserved on `/kiosk*` (automatically emitted by Express `server/security.ts`).
  - **Raspberry Pi 3 Model B Chromium Kiosk:** `chromium-browser --kiosk --incognito --noerrdialogs --disable-infobars --autoplay-policy=no-user-gesture-required https://rsu-cajidiocan.tech/kiosk`
  - **Automated Verification:** `npx tsx --test tests/web-kiosk-build36.test.mjs && npx tsx --test tests/web-kiosk-browser-e2e.test.mjs`

## Key Engineering Highlights (BUILD 05 – BUILD 36)

- **Mandatory Go/No-Go Release Gate & Production Ops Pack (BUILD 17):** Automated 10-gate evaluator (`scripts/release-gate.ts`, `npm run release:gate`) outputting deterministic `NO-GO` (exit `2`) when institutional, biometric, hardware, or host gates remain blocked; complete `DEPLOYMENT.md` (Linux VPS systemd/Nginx/Caddy/UFW/logrotate/backups, Hostinger Single static alternative, Windows PowerShell SOP, rollback rehearsal), `OPERATIONS_RUNBOOK.md`, `SECURITY.md`, `RELEASE_NOTES.md`, and `docs/STAGING_ACCEPTANCE_MATRIX.md`.
- **Production-Like Staging Runtime, Security Audit, Controllable Impairment & Load Verification (BUILD 16):** `APP_MODE=staging` with `X-Request-Id` structured JSON logs and strict secret redaction (`server/stagingRuntime.ts`), staging-only controllable network impairment (`403 STAGING_ONLY_ENDPOINT` in production), server-confirmed kiosk `backend_confirmed` & `voice_cue`, sanitized `npm run staging:setup` CLI, critical cross-module audit hash-chain bugfix (`server/correctionsLeavesEngine.ts`), and 7-group staging security/impairment/load/DR benchmark suite (`npm run test:staging`).
- **16-Screen Playwright Chromium E2E & WCAG 2.1 AA Responsive Polish (BUILD 15):** Full 22-test headless Chromium suite (`npm run test:browser`) verifying all 16 reference screens across 4 viewports (`1366×768`, `1920×1080`, `768×1024`, `390×844`) with 41 audited screenshots, 0 page/console errors, 0px overflow, keyboard/Escape support, explicit ARIA labels, and faithful visual preservation of all 16 reference PNGs.
- **System Settings, Guarded Live Restore, Data Retention, Device Secrets, Role Notifications & Tamper-Evident Audit (BUILD 14):** Allowlisted settings validation with environment secret masking & security change history (`server/adminOpsEngine.ts`); Administrator-only guarded live SQLite restore (`POST /api/backup/restore`) with password re-verification, `RESTORE LIVE DATABASE` confirmation, strict `BACKUP_DIR` confinement, `.pre-restore-*.bak` safety snapshot, auto-rollback & live handle rebinding; policy-compliant Data Retention dry-run preview & recorded purge jobs (`retention_jobs`) preserving payroll-locked attendance, `attendance_events`, and `audit_logs`; kiosk one-time token display, SHA-256 hashing/masking, key rotation, revocation (`403 DEVICE_REVOKED`), heartbeat-driven connectivity & deduplicated stale/offline alerting; event-driven role-targeted Notifications with RBAC-gated controls, selective mark-read/bulk dismiss, and zero false `"successful sync"` notices; append-only SHA-256 hash-chained `audit_logs` with SQLite immutability triggers (`IMMUTABLE_AUDIT_VIOLATION`), secret redaction, and chain verification (`GET /api/audit-logs/verify`).
- **DB-Backed Reports, Monthly DTR & Streaming Exports (BUILD 13):** Full SQLite-backed reporting across Attendance, Monthly DTR (`28`/`29`/`30`/`31` days incl. leap years, overnight shifts & `03:00` cutoff, approved corrections, half-day/OB/full leaves, holidays, rest days), Leaves, Payroll, Employee Masterlist, and Audit Logs (`server/reportsEngine.ts`); zero silent punch fabrication (`null`/`MISSING`); strict unresolved-draft blocking (`409 DTR_UNRESOLVED_DRAFT`) and SHA-256 sign-off lifecycle (`dtr_signoffs`); A4 portrait `pdfkit` PDF generator with RSU emblem, CS Form 48 Pending notice (`cs_form_48_reference_verified='false'`), and Employee/Campus Director signature lines; unclipped streaming RFC 4180 CSV exports with spreadsheet formula neutralization; strict RBAC (`401`/`403` + Department Head & self-service `/api/reports/my-dtr*`).
- **Institutional Policy-Driven Payroll & Governance (BUILD 12):** Permanently removed hard-coded `11.5% + ₱200` and `salary / 22` placeholders; requires effective-dated institutional policies (`payroll_policies`) + blank Policy Input Template (`GET /api/payroll/policy-template`); stamps unapproved runs `NOT APPROVED FOR PRODUCTION` and blocks Finalize/Release until Finance approval; supports split-month/partial-period proration, pre-compute reconciliation blockers (`PENDING_CORRECTIONS_EXIST`, `PENDING_LEAVES_EXIST`, `UNRESOLVED_MISSING_PUNCHES`), period uniqueness & idempotent SHA-256 versioned recompute, atomic `BEGIN IMMEDIATE` rollback, maker-checker separation, Finance Sign-Off gate, SQLite immutability triggers (`PAYROLL_LOCKED_VIOLATION` / `IMMUTABLE_AUDIT_VIOLATION`), employee Released-only payslips (`payroll:read_self`), and formula-injection-safe server CSV exports.
- **Corrections Immutability & Multi-Day Leave Propagation (BUILD 11):** Zero fabricated counterpart punches (`Missing Time Out` / `Missing Time In`), audit-safe correction reversal (`correction_audit_log`), configurable HR leave policies (`leave_policies`), date-by-date eligible allocations (`leave_day_allocations`) across past/today/future and cross-year spans, half-day support, punch-conflict controls (`BLOCK` / `PRESERVE_PUNCHES`), atomic cancellation, and overlap-safe monthly reports.
- **Kiosk Offline Sync, Heartbeat Telemetry & Authenticated SSE (BUILD 10):** AES-256-GCM encrypted offline queue (`server/kioskOfflineQueue.ts`), chronological batch sync (`POST /api/kiosk/sync`), HMAC biometric evidence envelope verification, Online -> Stale -> Offline heartbeat transitions, revoked-kiosk blocking (`403 DEVICE_REVOKED`), and RBAC-scoped authenticated SSE (`GET /api/events/stream`).
- **Attendance Policy Engine & `Asia/Manila` Correctness (BUILD 08):** Explicit actions (`TIME_IN`, `TIME_OUT`, `BREAK_OUT`, `BREAK_IN`, `OVERTIME_OUT`), midnight/overnight shift-date assignment, `03:00 Asia/Manila` next-day cutoff with HR escalation, ±120s drift + 72h offline replay, `POST /api/attendance/reconcile`, and append-only immutable `attendance_events`.
- **SQLite Durability & Versioned Migrations (`001` -> `009`) (BUILD 06–14):** `PRAGMA foreign_keys = ON`, WAL mode, `synchronous = FULL`, online `VACUUM INTO` backups + SHA-256 manifest + optional AES-256-GCM encryption, dry-run restore drills, guarded live restore with auto-rollback, and strict `APP_MODE=production|staging|demo|test` separation.
- **Zero Default Credentials & Server-Side RBAC (BUILD 05):** No hardcoded `admin`/`Admin@2025`, fail-secure `SESSION_SECRET` + `SESSION_SECRET_PREVIOUS` rotation, revocable `HttpOnly` sessions, double-submit CSRF + `Origin` allowlist, rate limiting + lockout, and 6-role / 38-permission server-side RBAC.
- **Honest External, Biometric & Production Gate Status:** Google SSO OAuth and outbound SMTP remain visibly disabled until institutional credentials are configured. Official RSU Cajidiocan CS Form 48 reference confirmation, Finance payroll policy sign-off, real biometric verification & anti-spoofing (BUILD 09), physical kiosk hardware/external apps, and live production host verification remain **BLOCKED** — Release Gate Status is **`NO-GO` / BLOCKED**.

> **Excluded by Rule:** The Admin Biometrics sidebar module is intentionally omitted per SAVAGE-RSUCAJ mandatory project rules.

## Quick Start (Linux / macOS & Windows PowerShell)

### Linux / macOS (bash / zsh)

```bash
# 1. Clean reproducible dependency install from package-lock.json
npm ci

# 2. Configure required secrets & persistent paths in .env (zero defaults)
cp .env.example .env
# Generate a strong SESSION_SECRET and BACKUP_ENCRYPTION_KEY:
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
# Edit .env: set APP_MODE, DATABASE_PATH, SESSION_SECRET (and ADMIN_INITIAL_* for fresh DB)
npm run check:env

# 3. Start full-stack dev server (Express + Vite on port 3000)
npm run dev

# 4. Run full verification gates (lint, 108 automated unit/DB/attendance/sync/workflow/payroll/reports/admin-ops/API tests, build, 5 startup smoke checks)
npm run lint
npm test
npm run build
npm run test:startup

# 5. Start production server & probe health
npm start
# In another terminal:
npm run health
```

### Windows PowerShell

```powershell
# 1. Clean reproducible dependency install from package-lock.json
npm ci

# 2. Configure required secrets & persistent paths in .env
Copy-Item .env.example .env
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
npm run check:env

# 3. Start full-stack dev server (Express + Vite on port 3000)
npm run dev

# 4. Run full verification gates
npm run lint
npm test
npm run build
npm run test:startup

# 5. Clean build artifacts safely (preserves data/ SQLite DB)
npm run clean

# 6. Start production server & probe health
npm start
# In another PowerShell window:
npm run health
```

## Database Operations, Backups & Recovery

```bash
# Dry-run migration & rollback parity check (isolated temp copy; live DB untouched)
npm run db:migrate -- --dry-run --db /var/lib/savage-rsucaj/savage_rsucaj.db

# Create consistent online SQLite backup (+ SHA-256 manifest + AES-256-GCM .enc if key set)
npm run db:backup

# Dry-run restore verification drill (default safe mode; does not touch target DB)
npm run db:restore -- --archive /var/backups/savage-rsucaj/savage-rsucaj-bkp-....sqlite.enc --target /var/lib/savage-rsucaj/savage_rsucaj.db

# Live restore (stop service first; automatically saves .pre-restore-*.bak and rolls back on failure)
npm run db:restore -- --archive /var/backups/savage-rsucaj/savage-rsucaj-bkp-....sqlite.enc --target /var/lib/savage-rsucaj/savage_rsucaj.db --apply

# Explicit non-production DEMO sandbox seeding ONLY (strictly refused in production)
APP_MODE=demo npm run db:seed-demo -- --db /tmp/savage-demo.db

# Recover/rotate existing administrator password non-destructively
RECOVERY_NEW_PASSWORD='StrongUniqueTempPassword!2026' npm run admin:recover -- --username admin --force-rotate
```

## Available npm Scripts

| Script | Description |
|---|---|
| `npm run dev` | Starts Express + Vite middleware dev server on `PORT` (default `3000`). |
| `npm run build` | Compiles production React/Tailwind bundle into `dist/`. |
| `npm start` | Cross-platform production server (`NODE_ENV=production`) serving `dist/` + `/api`. |
| `npm run clean` | Cross-platform removal of `dist/` and `server.js` (never deletes `data/`). |
| `npm run lint` | Runs TypeScript static type-checking (`tsc --noEmit`). |
| `npm run check:env` | Validates environment, mode separation, and persistent storage (`--strict` also requires `ADMIN_INITIAL_*`). |
| `npm run db:migrate` | Runs idempotent SQLite migrations (`--dry-run` verifies isolated migration + rollback parity). |
| `npm run db:backup` | Creates consistent online `VACUUM INTO` backup + SHA-256 manifest + optional AES-256-GCM archive. |
| `npm run db:restore` | Verifies & restores SQLite backups (dry-run by default; `--apply` for live restore with rollback). |
| `npm run db:seed-demo` | Seeds an isolated non-production sandbox DB only (strictly refuses production mode & live `data/`). |
| `npm run admin:recover` | Non-destructive MIS CLI tool to recover/rotate an existing user password and revoke prior sessions. |
| `npm run health` | Repeatable `GET /api/health` probe asserting HTTP 200 and SQLite connectivity. |
| `npm test` | Runs all 10 automated suites (`115` checks): Unit (15), DB (10), Attendance (18), Sync/SSE (6), Corrections/Leaves (13), Payroll (10), Reports/DTR (8), Admin Ops/Security (8), API/RBAC (20), and Staging Security/Impairment/Load/DR (7). |
| `npm run test:unit` | Runs pure unit tests (`tests/unit.test.ts` — 15 cases). |
| `npm run test:db` | Runs DB durability, migrations, WAL, concurrency, encrypted backup & restore tests (`tests/db.test.ts` — 10 cases). |
| `npm run test:attendance` | Runs deterministic `Asia/Manila` attendance policy, 03:00 cutoff, drift/offline replay & reconciliation tests (`tests/attendance.test.ts` — 18 cases). |
| `npm run test:sync` | Runs kiosk AES-256-GCM offline queue, batch sync, HMAC evidence, heartbeat & authenticated SSE tests (`tests/sync.test.ts` — 6 cases). |
| `npm run test:corrections-leaves` | Runs corrections immutability/reversal, configurable leave policies, multi-day/cross-year allocation & monthly report tests (`tests/corrections-leaves.test.ts` — 13 cases). |
| `npm run test:payroll` | Runs BUILD 12 institutional payroll policy, golden vector math (0.01 precision), maker-checker, immutability, rollback & payslip/CSV security tests (`tests/payroll.test.ts` — 10 cases). |
| `npm run test:reports` | Runs BUILD 13 DB-backed reports, Monthly DTR (28/29/30/31 days, overnight cutoff, draft blocking, sign-off), A4 `pdfkit` PDF, streaming CSV & RBAC tests (`tests/reports.test.ts` — 8 cases). |
| `npm run test:admin-ops` | Runs BUILD 14 settings validation, secret masking, guarded live restore, data retention dry-run/purge, device rotation/revocation/alerts, role notifications, tamper-evident audit & restart persistence tests (`tests/admin-ops.test.ts` — 8 cases). |
| `npm run test:api` | Runs Express + SQLite API, security, RBAC & backup endpoint integration tests (`tests/api.test.ts` — 20 cases). |
| `npm run test:staging` | Runs BUILD 16 staging env, controllable network impairment, 7-domain security audit, 200-read/50-punch load & DR backup/restore benchmarks (`tests/staging-security-load.test.ts` — 7 cases). |
| `npm run staging:setup` | Bootstraps an isolated sanitized staging DB (`[STAGING TEST-ONLY — FAKE CURRENCY]`, strictly refuses `./data/savage_rsucaj.db`). |
| `npm run test:startup` | Repeatable isolated production startup + authentic empty-state + E2E auth/revocation smoke test (`5` checks). |
| `npm run test:browser` | Runs BUILD 15 Playwright Chromium 16-screen × 4-viewport E2E + WCAG/overflow audit (`tests/e2e.browser.test.ts` — `22` cases, `41` screenshots). |
| `npm run release:gate` | Runs BUILD 17 automated 10-gate Go/No-Go evaluator (`scripts/release-gate.ts`, exits `2` on `NO-GO`). |
| `npm run test:hardware` | Reports current status of Physical Kiosk Hardware suite (`NOT TESTED / BLOCKED`). |

## Documentation

- [`DEPLOYMENT.md`](DEPLOYMENT.md) — Linux VPS (`systemd`, Nginx/Caddy TLS, UFW, logrotate, cron backups), Hostinger Single static alternative, Windows PowerShell SOP & rollback rehearsal
- [`OPERATIONS_RUNBOOK.md`](OPERATIONS_RUNBOOK.md) — Proposed SLO/RPO/RTO targets, daily/weekly/monthly checklists, incident response playbooks & on-call roster
- [`SECURITY.md`](SECURITY.md) — Verified security architecture, dependency audit summary & remaining trust blockers
- [`RELEASE_NOTES.md`](RELEASE_NOTES.md) — Cumulative BUILD 15–17 (`v1.13.0`) release notes & mandatory `NO-GO` notice
- [`docs/STAGING_ACCEPTANCE_MATRIX.md`](docs/STAGING_ACCEPTANCE_MATRIX.md) — Recorded `X-Request-Id` staging evidence, load/DR benchmarks & explicit hardware/institutional blockers
- [`docs/RELEASE_CHECKLIST.md`](docs/RELEASE_CHECKLIST.md) — Mandatory 10-gate Go/No-Go release checklist (`RG-01`..`RG-10`)
- [`docs/PAYROLL_POLICY_AND_CONTROLS.md`](docs/PAYROLL_POLICY_AND_CONTROLS.md) — BUILD 12 institutional payroll Policy Input Template, split-month proration formulas, pre-compute reconciliation blockers, maker-checker separation, Finance sign-off gate, immutability triggers, and payslip/CSV controls
- [`docs/CORRECTIONS_AND_LEAVES_POLICY.md`](docs/CORRECTIONS_AND_LEAVES_POLICY.md) — BUILD 11 corrections immutability/reversal and configurable multi-day leave allocation policy
- [`docs/KIOSK_SYNC_AND_REALTIME.md`](docs/KIOSK_SYNC_AND_REALTIME.md) — BUILD 10 encrypted offline queue, batch sync, heartbeat telemetry, and authenticated SSE architecture
- [`docs/ATTENDANCE_POLICY.md`](docs/ATTENDANCE_POLICY.md) — Formal BUILD 08 attendance action contract, `Asia/Manila` shift-date assignment, `03:00` cutoff, HR escalation, drift/offline replay, and reconciliation policy
- [`docs/BACKUP_AND_RECOVERY.md`](docs/BACKUP_AND_RECOVERY.md) — Persistent storage, WAL checkpointing, online encrypted backups, restore drills, proposed RPO/RTO targets, and Legacy-Data Import Plan
- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — Full-stack architecture, mode separation, security & RBAC design, schema migrations, and scripts
- [`docs/TEST_INVENTORY.md`](docs/TEST_INVENTORY.md) — Categorized baseline test inventory (`142/142` automated checks)
- [`BUILD_REPORT.md`](BUILD_REPORT.md) · [`TEST_RESULTS.md`](TEST_RESULTS.md) · [`CHANGELOG.md`](CHANGELOG.md)
